Dernière mise à jour : 26/08/2026

## 1. Où l'IA intervient, où elle n'intervient pas

| Étape | Rôle de l'IA | Décision finale |
|---|---|---|
| Collecte de publications publiques | Aucune. Simple récupération de contenus publics via le subnet 13 du réseau Bittensor | — |
| Extraction d'une fiche candidate depuis une publication | Structuration du texte brut en champs, par un modèle de langage (subnet 64) | Aucune publication automatique |
| Notation de fiabilité de la fiche candidate | Note indicative de complétude et de vérifiabilité | Indicative uniquement |
| Publication d'une fiche | Aucune | **Humaine, systématique** |
| Classement des correspondances | **Aucune.** Le classement est calculé par un programme déterministe et publié dans les [CGU](/legal/cgu) | Programme, non modifiable par paiement |
| Résumé en français clair | Reformulation d'un résultat déjà calculé | Filtré et affiché avec sa mention d'origine |

**Aucune décision produisant un effet juridique n'est prise de façon
automatisée.** Une fiche n'est jamais publiée sans relecture humaine.

## 2. Ce qui est envoyé aux modèles

Uniquement des contenus publics et des critères anonymes. Avant tout envoi, un
filtre serveur retire automatiquement : adresses e-mail, numéros de téléphone,
adresses postales, IBAN et identifiants de portefeuille. Les coordonnées d'un
musicien ne sont **jamais** transmises à un modèle.

## 3. Limites assumées

Un modèle de langage peut se tromper, mal interpréter une source ou produire une
formulation imprécise. En conséquence :

- tout résumé automatique est signalé comme tel et daté ;
- les informations d'une fiche prévalent sur le résumé ;
- les informations fournies par l'artisan prévalent sur les informations
  collectées ;
- le vocabulaire promotionnel ou juridiquement risqué est retiré
  automatiquement du texte généré avant affichage.

## 4. Prestataires techniques

| Prestataire | Rôle |
|---|---|
| Chutes, subnet 64 du réseau Bittensor | Modèles de langage pour l'extraction et la reformulation |
| Macrocosmos, subnet 13 du réseau Bittensor | Accès à des publications publiques de X et Reddit |

Ces prestataires sont interchangeables : leur remplacement ne modifie ni le
classement, ni le contenu des fiches publiées.

## 5. Signaler une erreur produite par l'IA

contact@novaluth.com, en précisant la page concernée. Correction ou retrait sous
quinze jours ouvrés, et retrait immédiat du texte contesté en cas de doute.
