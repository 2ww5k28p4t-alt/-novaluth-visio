"""
NOVALUTH — Recherche et ordre d'affichage de l'annuaire
=======================================================

Deux responsabilités, volontairement séparées de `web/main.py` :

1. **Filtrer** sur des faits déclarés (budget, délai, instrument, style, zone
   de livraison, façons de travailler). Un filtre retire des fiches, il n'en
   avantage aucune.

2. **Ordonner**. C'est le point délicat. L'annuaire triait auparavant par score
   d'innovation décroissant : Novaluth classait donc publiquement les artisans
   selon une note produite par un modèle. L'ordre par défaut est maintenant une
   rotation équitable, tirée une fois par jour, identique pour tous les
   visiteurs du jour et vérifiable — voir `legal/classement.md`.

Une règle à garder en tête si vous modifiez ce fichier : quand une information
manque, la fiche est **conservée**, jamais écartée. Un artisan qui n'a pas
encore renseigné ses tarifs ne doit pas disparaître des résultats à cause de
ce silence ; à l'inverse, l'écarter reviendrait à sanctionner une fiche
incomplète.
"""

from __future__ import annotations

import datetime as dt
import random
from dataclasses import dataclass, field

from . import facettes
from .schemas import Fiche

TRIS: dict[str, str] = {
    "equitable": "Rotation équitable du jour",
    "delai": "Délai annoncé le plus court",
    "budget": "Tarif annoncé le plus bas",
    "alpha": "Ordre alphabétique",
    "maj": "Fiches mises à jour récemment",
}

ZONES = {
    "france": "expedie_france",
    "europe": "expedie_europe",
    "monde": "expedie_monde",
}


@dataclass
class Criteres:
    pays: str | None = None
    type: str | None = None
    instrument: str | None = None
    style: str | None = None
    zone: str | None = None
    budget_eur: int | None = None
    delai_max_mois: int | None = None
    relue_seulement: bool = False
    facons: list[str] = field(default_factory=list)
    tri: str = "equitable"

    def actifs(self) -> bool:
        return bool(self.pays or self.type or self.instrument or self.style
                    or self.zone or self.budget_eur or self.delai_max_mois
                    or self.relue_seulement or self.facons)


# --------------------------------------------------------------------------- #
# Filtres — un par critère, chacun tolérant à l'information absente
# --------------------------------------------------------------------------- #

def _corresp_pays(f: Fiche, pays: str) -> bool:
    return (f.pays or "").lower() == pays.lower()


def _corresp_instrument(f: Fiche, instrument: str) -> bool:
    if not f.modeles:
        return True          # aucun modèle déclaré : on ne peut rien exclure
    return any(m.type.value == instrument for m in f.modeles)


def _corresp_style(f: Fiche, style: str) -> bool:
    voulu = style.lower().strip()
    if not f.profil_sonore.styles:
        return True
    return any(voulu in s.lower() for s in f.profil_sonore.styles)


def _corresp_zone(f: Fiche, zone: str) -> bool:
    champ = ZONES.get(zone)
    if not champ:
        return True
    if getattr(f.logistique, champ, False):
        return True
    # Rien de déclaré du tout : on laisse la fiche, le musicien demandera.
    return not any(getattr(f.logistique, c, False) for c in ZONES.values())


def _corresp_budget(f: Fiche, budget: int) -> bool:
    if f.prix_min_eur is None:
        return True
    return f.prix_min_eur <= budget


def _corresp_delai(f: Fiche, mois: int) -> bool:
    if f.delai_moyen_mois is None:
        return True
    return f.delai_moyen_mois <= mois


def filtrer(fiches: list[Fiche], c: Criteres) -> list[Fiche]:
    """Applique les critères. Les façons cochées se cumulent : une fiche doit
    présenter **toutes** celles demandées, sinon cocher deux cases donnerait
    plus de résultats qu'une seule, ce qui est déroutant."""
    resultat = list(fiches)
    if c.pays:
        resultat = [f for f in resultat if _corresp_pays(f, c.pays)]
    if c.type:
        resultat = [f for f in resultat if f.type.value == c.type]
    if c.instrument:
        resultat = [f for f in resultat if _corresp_instrument(f, c.instrument)]
    if c.style:
        resultat = [f for f in resultat if _corresp_style(f, c.style)]
    if c.zone:
        resultat = [f for f in resultat if _corresp_zone(f, c.zone)]
    if c.budget_eur:
        resultat = [f for f in resultat if _corresp_budget(f, c.budget_eur)]
    if c.delai_max_mois:
        resultat = [f for f in resultat if _corresp_delai(f, c.delai_max_mois)]
    if c.relue_seulement:
        resultat = [f for f in resultat if f.valide_par_artisan]
    if c.facons:
        voulues = set(c.facons)
        resultat = [f for f in resultat
                    if voulues <= set(facettes.facons_de(f))]
    return resultat


# --------------------------------------------------------------------------- #
# Ordre d'affichage
# --------------------------------------------------------------------------- #

def graine_du_jour(jour: dt.date | None = None) -> str:
    return (jour or dt.date.today()).isoformat()


def ordre_equitable(fiches: list[Fiche], jour: dt.date | None = None) -> list[Fiche]:
    """Mélange stable sur la journée, identique pour tous les visiteurs.

    Le mélange est amorcé par la date seule : deux serveurs, deux visiteurs ou
    deux rechargements de page donnent le même ordre le même jour, et l'ordre
    change le lendemain. Aucun atelier n'est durablement en tête, et personne
    n'a à nous croire sur parole — l'ordre est reproductible à partir de la
    date. Le tri par slug avant mélange garantit que l'ordre ne dépend pas de
    celui dans lequel la base a renvoyé les lignes.
    """
    ordonnees = sorted(fiches, key=lambda f: f.slug)
    tirage = random.Random(graine_du_jour(jour))
    tirage.shuffle(ordonnees)
    return ordonnees


def _sans_valeur_en_dernier(valeur: int | None, defaut: int) -> int:
    return defaut if valeur is None else valeur


def ordonner(fiches: list[Fiche], tri: str = "equitable",
             jour: dt.date | None = None) -> list[Fiche]:
    base = ordre_equitable(fiches, jour)   # départage neutre pour tous les tris
    if tri == "delai":
        return sorted(base, key=lambda f: _sans_valeur_en_dernier(
            f.delai_moyen_mois, 10_000))
    if tri == "budget":
        return sorted(base, key=lambda f: _sans_valeur_en_dernier(
            f.prix_min_eur, 10_000_000))
    if tri == "alpha":
        return sorted(base, key=lambda f: (f.nom or "").lower())
    if tri == "maj":
        return sorted(base, key=lambda f: f.maj_le or "", reverse=True)
    return base


def tri_valide(tri: str | None) -> str:
    return tri if tri in TRIS else "equitable"


# --------------------------------------------------------------------------- #
# Valeurs proposées dans le formulaire, déduites des fiches réelles
# --------------------------------------------------------------------------- #

def styles_disponibles(fiches: list[Fiche], limite: int = 24) -> list[str]:
    compte: dict[str, int] = {}
    for f in fiches:
        for s in f.profil_sonore.styles:
            cle = s.strip().lower()
            if cle:
                compte[cle] = compte.get(cle, 0) + 1
    return [s for s, _ in sorted(compte.items(), key=lambda kv: (-kv[1], kv[0]))][:limite]


def pays_disponibles(fiches: list[Fiche]) -> list[str]:
    return sorted({f.pays for f in fiches if f.pays})


def familles_affichables(fiches: list[Fiche], cochees: list[str]
                         ) -> list[dict[str, object]]:
    """Familles de façons de travailler à montrer dans le formulaire.

    Une façon absente de toutes les fiches n'est pas proposée : une case qui ne
    renvoie jamais rien fait douter de l'annuaire entier. Une façon cochée reste
    affichée même si elle ne concerne plus personne, sinon le visiteur ne
    pourrait plus la décocher.
    """
    presentes = facettes.facons_disponibles(fiches) | set(cochees)
    familles: list[dict[str, object]] = []
    for cle_famille, titre, facons in facettes.FAMILLES:
        cases = [{"cle": f.cle, "libelle": f.libelle, "aide": f.aide,
                  "cochee": f.cle in cochees}
                 for f in facons if f.cle in presentes]
        if cases:
            familles.append({"cle": cle_famille, "titre": titre, "cases": cases})
    return familles
