"""
NOVALUTH — Application publique (FastAPI, port 8000)
====================================================

Ce service ne détient aucune clé de subnet Bittensor. Quand il a besoin d'IA,
il signe une demande et l'envoie à la passerelle (gateway/), qui est le seul
détenteur des clés.

Routes principales :
  GET  /                     accueil
  GET  /annuaire             fiches publiées, filtrables
  GET  /fiche/{slug}         fiche détaillée
  GET  /brief                formulaire de projet
  POST /api/recommend        moteur de correspondance (JSON)
  POST /brief                envoi du brief (formulaire, anti-CSRF)
  GET  /legal/{document}     mentions légales, CGU, CGV, confidentialité…
  GET  /donnees              exercice des droits RGPD (accès / effacement)
  GET  /atelier              espace atelier (connexion par lien reçu par courriel)
  GET  /projet/{jeton}       self-service du musicien : accepter, décliner, clôturer
  GET  /admin                supervision des fiches candidates (protégé)
  GET  /sante                état du service et de la passerelle

Le circuit d'accès aux projets (facturation seulement après l'accord du
musicien) vit dans web/acces.py et web/store_acces.py.
"""

from __future__ import annotations

import json
import os
import secrets
from pathlib import Path

from fastapi import Depends, FastAPI, Form, HTTPException, Query, Request
from fastapi.responses import (FileResponse, HTMLResponse, JSONResponse,
                               RedirectResponse)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from common.isolation import cles_subnet_dans_environnement
from common.passerelle_client import passerelle_en_vie

from . import acces, courriel, store, store_acces
from .ia import resumer_correspondances
from . import facettes, recherche
from .legal import DOCUMENTS_LEGAUX, rendre_document
from .matching import recommander
from .schemas import Brief, Fiche, StatutFiche
from .securite import (MiddlewareSecurite, creer_jeton_csrf, exiger_admin,
                       fermer_session_admin, limiter, ouvrir_session_admin,
                       session_admin_valide, verifier_jeton_csrf)

RACINE = Path(__file__).resolve().parent.parent
ENV = os.environ.get("NOVALUTH_ENV", "dev")

app = FastAPI(
    title="Novaluth",
    description="Annuaire des luthiers innovants et des marques émergentes.",
    docs_url="/api/docs" if ENV != "prod" else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if ENV != "prod" else None,
)
app.add_middleware(MiddlewareSecurite)
app.mount("/static", StaticFiles(directory=RACINE / "static"), name="static")
gabarits = Jinja2Templates(directory=str(RACINE / "templates"))


@app.on_event("startup")
def demarrage() -> None:
    store.initialiser()
    store_acces.initialiser()
    store.purger_briefs_expires()
    compteurs = store.compter_par_statut()
    print(f"[novaluth] base prête — {compteurs}")


def contexte(request: Request, **extra):
    base = {
        "request": request,
        "csrf": creer_jeton_csrf(),
        "admin": session_admin_valide(request),
        "documents_legaux": DOCUMENTS_LEGAUX,
        "env": ENV,
        "atelier": acces.atelier_connecte(request),
    }
    base.update(extra)
    return base


def rendre(request: Request, gabarit: str, *, status_code: int = 200, **extra):
    """Rendu d'un gabarit. On passe la requête en premier argument : c'est la
    signature attendue par les versions récentes de Starlette, et elle reste
    acceptée par les anciennes."""
    return gabarits.TemplateResponse(
        request, gabarit, contexte(request, **extra), status_code=status_code,
    )


# --------------------------------------------------------------------------- #
# Pages publiques
# --------------------------------------------------------------------------- #

@app.get("/", response_class=HTMLResponse)
def accueil(request: Request):
    # Les six ateliers mis en avant suivent la rotation équitable du jour : sans
    # elle, la page d'accueil deviendrait la vitrine permanente des six mêmes.
    publiees = store.lister_fiches(StatutFiche.publiee.value, limite=300)
    fiches = recherche.ordonner(publiees, "equitable")[:6]
    compteurs = store.compter_par_statut()
    cartes = [{"fiche": f,
               "facons": facettes.libelles(
                   facettes.normaliser(facettes.facons_de(f))),
               "provenance": facettes.provenance(f)}
              for f in fiches]
    return rendre(request, "accueil.html", fiches=fiches, cartes=cartes,
                  total_publiees=compteurs.get("publiee", 0))


@app.get("/annuaire", response_class=HTMLResponse)
def annuaire(request: Request,
             pays: str | None = None,
             type: str | None = None,
             instrument: str | None = None,
             style: str | None = None,
             zone: str | None = None,
             budget: str = "",
             delai: str = "",
             relue: str = "",
             tri: str | None = None,
             facon: list[str] = Query(default=[])):
    """Recherche par faits déclarés, jamais par note.

    L'ancienne version acceptait `innovation_min` et classait les artisans par
    un score sur 10 produit par un modèle. Les paramètres sont maintenant des
    faits : budget, délai, instrument, style, zone de livraison, façons de
    travailler. L'ordre par défaut est une rotation équitable du jour, expliquée
    sur /legal/classement.
    """
    def entier(v: str) -> int | None:
        v = (v or "").strip()
        return int(v) if v.isdigit() and int(v) > 0 else None

    toutes = store.lister_fiches(StatutFiche.publiee.value, limite=300)
    criteres = recherche.Criteres(
        pays=pays or None,
        type=type or None,
        instrument=instrument or None,
        style=style or None,
        zone=zone or None,
        budget_eur=entier(budget),
        delai_max_mois=entier(delai),
        relue_seulement=relue == "oui",
        facons=facettes.normaliser(facon),
        tri=recherche.tri_valide(tri),
    )
    fiches = recherche.ordonner(recherche.filtrer(toutes, criteres), criteres.tri)
    cartes = [{"fiche": f,
               "facons": facettes.libelles(facettes.normaliser(facettes.facons_de(f))),
               "provenance": facettes.provenance(f)}
              for f in fiches]
    return rendre(request, "annuaire.html",
                  cartes=cartes, total=len(fiches), total_publiees=len(toutes),
                  criteres=criteres,
                  familles=recherche.familles_affichables(toutes, criteres.facons),
                  pays_disponibles=recherche.pays_disponibles(toutes),
                  styles_disponibles=recherche.styles_disponibles(toutes),
                  tris=recherche.TRIS)


@app.get("/fiche/{slug}", response_class=HTMLResponse)
def page_fiche(request: Request, slug: str):
    fiche = store.lire_fiche(slug)
    if not fiche or fiche.statut != StatutFiche.publiee:
        raise HTTPException(404, "Fiche introuvable.")
    return rendre(request, "fiche.html", fiche=fiche,
                  facons=facettes.libelles(
                      facettes.normaliser(facettes.facons_de(fiche))),
                  provenance=facettes.provenance(fiche))


@app.get("/brief", response_class=HTMLResponse)
def page_brief(request: Request):
    # Les cases proposées sont celles réellement présentes chez au moins un
    # atelier publié : une case qui ne renverrait personne ferait douter du
    # reste du formulaire.
    publiees = store.lister_fiches(StatutFiche.publiee.value, limite=300)
    return rendre(request, "brief.html",
                  familles=recherche.familles_affichables(publiees, []),
                  libelle_consentement=store.LIBELLE_CONSENTEMENT)


# --------------------------------------------------------------------------- #
# API de recommandation
# --------------------------------------------------------------------------- #

@app.post("/api/recommend")
async def api_recommend(request: Request):
    limiter(request, "recommend", maximum=20, fenetre_s=60)
    try:
        brief = Brief(**(await request.json()))
    except Exception as e:
        raise HTTPException(422, f"Brief invalide : {e}")

    fiches = store.lister_fiches(StatutFiche.publiee.value, limite=300)
    resultats = recommander(brief, fiches, nombre=3)
    resume, origine = resumer_correspondances(brief, resultats)
    return {
        "resume": resume,
        "origine_resume": origine,
        "resultats": resultats,
        "avertissement": (
            "Novaluth référence et met en relation. Novaluth n'est ni vendeur, "
            "ni fabricant, ni transporteur, ni intermédiaire de paiement. "
            "Les informations proviennent de sources publiques ou de l'artisan "
            "lui-même et doivent être confirmées auprès de lui avant toute commande."
        ),
    }


@app.post("/brief", response_class=HTMLResponse)
async def envoyer_brief(
    request: Request,
    csrf: str = Form(...),
    type_instrument: str = Form("electrique"),
    budget_min_eur: int = Form(0),
    budget_max_eur: int = Form(5000),
    styles: str = Form(""),
    bois_souhaites: str = Form(""),
    delai_max_mois: str = Form(""),
    zone_preferee: str = Form("europe"),
    chaleur_souhaitee: str = Form(""),
    brillance_souhaitee: str = Form(""),
    facon: list[str] = Form(default=[]),
    personnalisation: str = Form(""),
    description_libre: str = Form(""),
    email: str = Form(""),
    consentement: str = Form(""),
    piege: str = Form(""),   # champ masqué anti-robot
):
    verifier_jeton_csrf(csrf)
    limiter(request, "brief", maximum=6, fenetre_s=300)
    if piege:
        raise HTTPException(400, "Requête refusée.")

    def entier(v: str) -> int | None:
        return int(v) if v.strip().isdigit() else None

    donne_consentement = consentement == "oui"
    try:
        brief = Brief(
            type_instrument=type_instrument,
            budget_min_eur=budget_min_eur,
            budget_max_eur=budget_max_eur,
            styles=[s.strip() for s in styles.split(",") if s.strip()][:8],
            bois_souhaites=[s.strip() for s in bois_souhaites.split(",") if s.strip()][:8],
            delai_max_mois=entier(delai_max_mois),
            zone_preferee=zone_preferee,
            chaleur_souhaitee=entier(chaleur_souhaitee),
            brillance_souhaitee=entier(brillance_souhaitee),
            facons_recherchees=facettes.normaliser(facon),
            personnalisation=personnalisation == "oui",
            description_libre=description_libre[:1500],
            email=(email.strip() or None) if donne_consentement else None,
            consentement_transmission=donne_consentement,
        )
    except Exception as e:
        raise HTTPException(422, f"Formulaire invalide : {e}")

    if brief.email and not brief.consentement_transmission:
        raise HTTPException(400, "Aucune transmission sans consentement explicite.")

    # Un seul projet ouvert par adresse : plutôt qu'un refus sec, on renvoie le
    # musicien vers la page de suivi du projet qu'il a déjà déposé. Cela évite
    # les dépôts en rafale sans coûter un centime au musicien.
    if brief.email:
        deja = store_acces.projet_ouvert_de_email(brief.email)
        if deja:
            jeton_existant = store_acces.jeton_du_brief(deja["reference"])
            courriel.confirmation_projet(brief.email, jeton_existant,
                                         deja["reference"])
            return rendre(request, "projet_existant.html",
                          reference=deja["reference"],
                          jeton_projet=jeton_existant)

    fiches = store.lister_fiches(StatutFiche.publiee.value, limite=300)
    resultats = recommander(brief, fiches, nombre=3)
    resume, origine = resumer_correspondances(brief, resultats)

    reference = "NV-" + secrets.token_hex(4).upper()
    # `facons_affichees` double `facons_recherchees` en clair : l'atelier et le
    # musicien lisent des libellés français, pas des clés techniques.
    criteres = brief.model_dump(mode="json")
    criteres["facons_affichees"] = facettes.libelles(brief.facons_recherchees)
    store.enregistrer_brief(
        reference=reference,
        criteres=criteres,
        recommandations=resultats,
        email=brief.email,
        consentement=brief.consentement_transmission,
    )
    # Lien de self-service : le musicien peut dès maintenant suivre les demandes
    # de contact, confirmer que son projet est d'actualité ou le clôturer.
    jeton = (store_acces.jeton_du_brief(reference)
             if brief.consentement_transmission else None)
    # Double confirmation : le projet n'est proposé aux ateliers qu'après le clic
    # dans ce courriel. Une adresse mal saisie ne mobilise donc aucun artisan.
    if jeton and brief.email:
        courriel.confirmation_projet(brief.email, jeton, reference)
    return rendre(request, "resultat.html", reference=reference, resume=resume,
                  origine=origine, resultats=resultats, brief=brief,
                  jeton_projet=jeton,
                  plafond_ateliers=store_acces.PLAFOND_ATELIERS_PAR_PROJET)


# --------------------------------------------------------------------------- #
# Pages légales et droits RGPD
# --------------------------------------------------------------------------- #

@app.get("/legal", response_class=HTMLResponse)
def index_legal(request: Request):
    return rendre(request, "legal_index.html")


@app.get("/legal/{document}", response_class=HTMLResponse)
def page_legale(request: Request, document: str):
    if document not in DOCUMENTS_LEGAUX:
        raise HTTPException(404, "Document introuvable.")
    titre, corps_html, maj = rendre_document(document)
    return rendre(request, "legal.html", titre=titre, corps=corps_html,
                  maj=maj, cle=document)


@app.get("/donnees", response_class=HTMLResponse)
def page_donnees(request: Request):
    return rendre(request, "donnees.html")


@app.post("/donnees/{action}")
async def exercer_droit(request: Request, action: str,
                        csrf: str = Form(...), email: str = Form(...)):
    """Droits d'accès, de portabilité et d'effacement, exécutés immédiatement.
    Aucune vérification d'identité poussée n'est possible ici : on ne renvoie
    donc jamais les données par la page, on confirme et on traite."""
    verifier_jeton_csrf(csrf)
    limiter(request, "droits", maximum=5, fenetre_s=600)
    adresse = email.strip().lower()
    if action == "effacement":
        n = store.effacer_donnees_email(adresse)
        message = (f"Demande enregistrée. {n} enregistrement(s) associé(s) à cette "
                   f"adresse ont été anonymisés immédiatement.")
    elif action == "acces":
        donnees = store.exporter_donnees_email(adresse)
        store.journaliser("droit_acces", "brief", f"{len(donnees)} enregistrements")
        message = (f"Demande enregistrée : {len(donnees)} enregistrement(s) trouvé(s). "
                   f"Conformément au RGPD, l'export vous est adressé par e-mail sous "
                   f"un mois à l'adresse indiquée, après vérification.")
    else:
        raise HTTPException(404, "Action inconnue.")
    return rendre(request, "donnees.html", message=message)


# --------------------------------------------------------------------------- #
# Supervision — validation humaine des fiches (le cœur qualité du projet)
# --------------------------------------------------------------------------- #

@app.get("/admin", response_class=HTMLResponse)
def page_admin(request: Request):
    if not session_admin_valide(request):
        return rendre(request, "admin_connexion.html")
    candidates = store.lister_fiches(
        [StatutFiche.candidate.value, StatutFiche.a_verifier.value,
         StatutFiche.a_suivre.value], limite=200,
    )
    return rendre(request, "admin.html", candidates=candidates,
                  compteurs=store.compter_par_statut(),
                  passerelle=passerelle_en_vie(),
                  statistiques_acces=store_acces.statistiques(),
                  publiees=store.lister_fiches(StatutFiche.publiee.value,
                                               limite=300))


@app.post("/admin/connexion")
def connexion_admin(request: Request, csrf: str = Form(...), jeton: str = Form(...)):
    verifier_jeton_csrf(csrf)
    limiter(request, "admin_connexion", maximum=5, fenetre_s=600)
    reponse = RedirectResponse("/admin", status_code=303)
    ouvrir_session_admin(reponse, jeton)
    store.journaliser("admin_connexion", "succes")
    return reponse


@app.post("/admin/deconnexion")
def deconnexion_admin(request: Request, csrf: str = Form(...)):
    verifier_jeton_csrf(csrf)
    reponse = RedirectResponse("/", status_code=303)
    fermer_session_admin(reponse)
    return reponse


@app.post("/admin/statut")
def maj_statut(request: Request, csrf: str = Form(...), slug: str = Form(...),
               statut: str = Form(...)):
    exiger_admin(request)
    verifier_jeton_csrf(csrf)
    if not store.changer_statut(slug, statut):
        raise HTTPException(404, "Fiche introuvable ou statut inconnu.")
    return RedirectResponse("/admin", status_code=303)


@app.post("/admin/atelier")
def declarer_atelier(request: Request, csrf: str = Form(...),
                     slug: str = Form(...), email: str = Form(...)):
    """Rattache une adresse de contact à une fiche publiée : c'est ce qui ouvre
    l'espace atelier à l'artisan, sans mot de passe à gérer. L'adresse doit
    avoir été communiquée par l'artisan lui-même."""
    exiger_admin(request)
    verifier_jeton_csrf(csrf)
    if store.lire_fiche(slug) is None:
        raise HTTPException(404, "Fiche introuvable.")
    if "@" not in email:
        raise HTTPException(422, "Adresse de contact invalide.")
    store_acces.enregistrer_atelier(slug, email)
    return RedirectResponse("/admin", status_code=303)


@app.post("/admin/fiche")
async def creer_fiche_manuelle(request: Request):
    """Saisie manuelle d'une fiche (les 10-20 premières fiches d'amorçage).
    Accepte le JSON complet d'une fiche conforme au schéma des 7 blocs."""
    exiger_admin(request)
    try:
        fiche = Fiche(**(await request.json()))
    except Exception as e:
        raise HTTPException(422, f"Fiche invalide : {e}")
    store.enregistrer_fiche(fiche)
    store.journaliser("fiche_manuelle", fiche.slug)
    return {"enregistre": fiche.slug, "statut": fiche.statut.value}


# --------------------------------------------------------------------------- #
# Application installable (PWA)
# --------------------------------------------------------------------------- #

@app.get("/manifest.json", include_in_schema=False)
def manifeste():
    return FileResponse(RACINE / "static" / "manifest.json",
                        media_type="application/manifest+json")


@app.get("/sw.js", include_in_schema=False)
def service_worker():
    """Servi à la racine : un service worker ne peut piloter que les pages
    situées sous son propre chemin. Depuis /static/, il ne verrait rien."""
    return FileResponse(
        RACINE / "static" / "sw.js",
        media_type="application/javascript",
        headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"},
    )


# --------------------------------------------------------------------------- #
# Circuit d'accès aux projets — espace atelier et self-service du musicien
# --------------------------------------------------------------------------- #

acces.brancher(app, rendre)


# --------------------------------------------------------------------------- #
# Santé
# --------------------------------------------------------------------------- #

@app.get("/sante")
def sante():
    etat_passerelle = passerelle_en_vie()
    # Deux informations distinctes, souvent confondues — voir common/isolation.py :
    #  · lues par ce service   → jamais. Invariant de code.
    #  · dans l'environnement  → mesuré, car cela dépend de l'hébergement.
    return {
        "service": "novaluth-web",
        "environnement": ENV,
        "fiches": store.compter_par_statut(),
        "passerelle_ia": "disponible" if etat_passerelle else "indisponible",
        "cles_subnet_lues_par_ce_service": False,
        "cles_subnet_dans_environnement": cles_subnet_dans_environnement(),
    }


@app.exception_handler(HTTPException)
async def erreur_lisible(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api/"):
        return JSONResponse({"erreur": exc.detail}, status_code=exc.status_code)
    return rendre(request, "erreur.html", status_code=exc.status_code,
                  code=exc.status_code, message=exc.detail)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
