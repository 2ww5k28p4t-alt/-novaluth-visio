"""
NOVALUTH — Accès aux projets : facturation à l'acceptation du musicien
=====================================================================

Le problème que ce module résout
-------------------------------
Un atelier paie l'accès à un projet, écrit au musicien, et n'obtient jamais de
réponse : le projet avait déjà été abandonné. L'atelier a payé pour rien, et
c'est le moyen le plus rapide de le perdre.

La réponse retenue : **l'argent ne bouge qu'après un signe du musicien.**

    1. l'atelier demande l'accès   → autorisation de paiement, rien de débité,
                                     aucune coordonnée transmise ;
    2. le musicien reçoit un message avec trois réponses possibles ;
    3. il accepte                  → coordonnées échangées, accès encaissé ;
       il décline, signale un abandon, ou ne répond pas dans la fenêtre
                                   → autorisation annulée, rien de débité.

Le cas résiduel — le musicien accepte puis l'échange s'éteint — donne droit à un
**crédit de relance** : un prochain accès, jamais une somme d'argent, après
vérification auprès du musicien et dans la limite d'un crédit par tranche
d'accès facturés.

Trois garde-fous complètent le dispositif :

    · plafond d'ateliers par projet, pour que cinq ateliers ne paient pas le
      même projet dont un seul emportera la commande ;
    · relance de fraîcheur, pour ne plus proposer les projets sans signe de vie ;
    · clôture en un clic par le musicien, parce que la plupart des abandons ne
      sont pas de la mauvaise volonté : personne n'a de bouton pour prévenir.

Novaluth vend l'accès à un projet, jamais un résultat, et n'encaisse rien sur le
prix de l'instrument.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import time

from fastapi import Form, HTTPException, Request
from fastapi.responses import RedirectResponse

from common.paiement import PaiementIndisponible, fournisseur

from . import courriel, store, store_acces as sa
from .schemas import StatutFiche
from .securite import limiter, secret_app, verifier_jeton_csrf

NOM_COOKIE_ATELIER = "nv_atelier"
DUREE_SESSION_ATELIER_S = 12 * 3600
DUREE_LIEN_CONNEXION_S = 30 * 60

MESSAGE_CONNEXION = (
    "Si cette adresse correspond à un atelier référencé, un lien de connexion "
    "vient de lui être envoyé. Le lien est valable 30 minutes."
)


# --------------------------------------------------------------------------- #
# Session atelier — lien de connexion par courriel, sans mot de passe
# --------------------------------------------------------------------------- #

def _signer(charge: str) -> str:
    return hmac.new(secret_app().encode(), charge.encode(), hashlib.sha256).hexdigest()


def _jeton_connexion(slug: str) -> str:
    expiration = int(time.time()) + DUREE_LIEN_CONNEXION_S
    charge = f"c:{slug}:{expiration}"
    return f"{charge}:{_signer(charge)}"


def _verifier_jeton_connexion(jeton: str) -> str | None:
    morceaux = jeton.split(":")
    if len(morceaux) != 4 or morceaux[0] != "c":
        return None
    _, slug, expiration, signature = morceaux
    if not hmac.compare_digest(signature, _signer(f"c:{slug}:{expiration}")):
        return None
    if not expiration.isdigit() or int(expiration) < time.time():
        return None
    return slug


def _ouvrir_session(reponse, slug: str) -> None:
    expiration = int(time.time()) + DUREE_SESSION_ATELIER_S
    charge = f"s:{slug}:{expiration}"
    reponse.set_cookie(
        NOM_COOKIE_ATELIER, f"{charge}:{_signer(charge)}",
        max_age=DUREE_SESSION_ATELIER_S, httponly=True, samesite="lax",
        secure=os.environ.get("NOVALUTH_ENV", "dev") == "prod", path="/",
    )


def atelier_connecte(request: Request) -> str | None:
    cookie = request.cookies.get(NOM_COOKIE_ATELIER)
    if not cookie:
        return None
    morceaux = cookie.split(":")
    if len(morceaux) != 4 or morceaux[0] != "s":
        return None
    _, slug, expiration, signature = morceaux
    if not hmac.compare_digest(signature, _signer(f"s:{slug}:{expiration}")):
        return None
    if not expiration.isdigit() or int(expiration) < time.time():
        return None
    return slug


def _exiger_atelier(request: Request) -> str:
    slug = atelier_connecte(request)
    if not slug:
        raise HTTPException(401, "Connexion à l'espace atelier requise.")
    return slug


# --------------------------------------------------------------------------- #
# Espace atelier
# --------------------------------------------------------------------------- #

def liberer_engagement(dossier: dict, motif: str) -> None:
    """Rend à l'atelier ce qu'il avait engagé sur une demande qui n'aboutit pas.

    Trois cas selon la façon dont l'accès avait été couvert : une autorisation
    de carte est annulée, un accès pris sur un carnet est remis au solde, un
    crédit de relance est restitué. Aucune somme n'a jamais été débitée : il
    s'agit seulement de lever la réservation."""
    mode = dossier.get("mode_paiement") or (
        "credit" if dossier.get("paye_par_credit") else "carte")
    if mode == "credit" or dossier.get("paye_par_credit"):
        sa.rendre_credit(dossier["atelier_slug"], dossier["reference"])
    elif mode == "solde":
        sa.rendre_au_solde(dossier["atelier_slug"], dossier["montant_cents"],
                           dossier["reference"], f"accès non abouti — {motif}")
    elif dossier.get("autorisation_id"):
        try:
            fournisseur().annuler(dossier["autorisation_id"], motif)
        except PaiementIndisponible as e:
            store.journaliser("annulation_echouee", dossier["reference"],
                              str(e)[:200])


def annuler_demandes_restantes(brief_reference: str, motif: str,
                               sauf: str | None = None) -> int:
    """Quand un projet se clôture, toutes les demandes encore en attente sur ce
    projet sont annulées : aucune n'est facturée, et chaque atelier concerné est
    prévenu."""
    annulees = 0
    for dossier in sa.acces_en_attente_du_brief(brief_reference):
        if sauf and dossier["reference"] == sauf:
            continue
        liberer_engagement(dossier, motif)
        sa.clore_acces(dossier["reference"], "abandonne", motif)
        atelier = sa.lire_atelier(dossier["atelier_slug"])
        if atelier:
            courriel.acces_annule(atelier["email"], dossier["reference"],
                                  brief_reference, motif)
        annulees += 1
    return annulees


# Libellés lisibles des critères d'un projet, dans l'ordre d'affichage.
LIBELLES_CRITERES: tuple[tuple[str, str], ...] = (
    ("type_instrument", "Type d'instrument"),
    ("budget_min_eur", "Budget minimum (€)"),
    ("budget_max_eur", "Budget maximum (€)"),
    ("styles", "Styles joués"),
    ("bois_souhaites", "Essences souhaitées"),
    ("chaleur_souhaitee", "Chaleur recherchée"),
    ("brillance_souhaitee", "Brillance recherchée"),
    ("delai_max_mois", "Délai maximum (mois)"),
    ("zone_preferee", "Zone de livraison"),
    ("pays_livraison", "Pays de livraison"),
    ("personnalisation", "Personnalisation souhaitée"),
    ("facons_affichees", "Façons de travailler recherchées"),
    ("description_libre", "Précisions du musicien"),
)


def _contexte_atelier(slug: str) -> dict:
    fiche = store.lire_fiche(slug)
    return {
        "slug": slug,
        "fiche": fiche,
        "nom_atelier": fiche.nom if fiche else slug,
        "projets": sa.projets_pour_atelier(slug),
        "acces": sa.acces_de_atelier(slug),
        "credits": sa.credits_disponibles(slug),
        "solde_cents": sa.solde_atelier(slug),
        "solde_affiche": courriel.euros(sa.solde_atelier(slug)),
        "carnets": [
            {"index": i, "libelle": libelle, "paye": courriel.euros(paye),
             "credite": courriel.euros(credite),
             "economie": courriel.euros(credite - paye)}
            for i, (paye, credite, libelle) in enumerate(sa.CARNETS)
        ],
        "tranches": [
            {"nom": nom, "prix": courriel.euros(prix), "libelle": libelle}
            for _plafond, prix, nom, libelle in sa.TRANCHES_PRIX
        ],
        "validite_solde_mois": sa.VALIDITE_SOLDE_MOIS,
        "fenetre_jours": sa.FENETRE_ACCEPTATION_JOURS,
        "plafond_ateliers": sa.PLAFOND_ATELIERS_PAR_PROJET,
        "delai_credit_jours": sa.DELAI_DEMANDE_CREDIT_JOURS,
        "paiement_simule": fournisseur().nom == "simule",
        "libelles_criteres": LIBELLES_CRITERES,
    }


def brancher(app, rendre) -> None:
    """Les routes ont besoin du moteur de gabarits de l'application publique.
    On les enregistre ici plutôt que d'importer web.main (dépendance circulaire)."""

    # ---------------------------- côté atelier ----------------------------- #

    @app.get("/atelier")
    def espace_atelier(request: Request, message: str = "", erreur: str = ""):
        slug = atelier_connecte(request)
        if not slug:
            return rendre(request, "atelier_connexion.html", message=message,
                          erreur=erreur)
        return rendre(request, "atelier.html", message=message, erreur=erreur,
                      **_contexte_atelier(slug))

    @app.post("/atelier/connexion")
    def demander_lien(request: Request, csrf: str = Form(...), email: str = Form(...)):
        verifier_jeton_csrf(csrf)
        limiter(request, "atelier_connexion", maximum=5, fenetre_s=600)
        for atelier in sa.ateliers_par_email(email):
            lien = (f"{courriel.URL_PUBLIQUE}/atelier/entrer?"
                    f"jeton={_jeton_connexion(atelier['slug'])}")
            courriel.lien_connexion_atelier(atelier["email"], lien,
                                            DUREE_LIEN_CONNEXION_S // 60)
        # Réponse identique dans tous les cas : on ne révèle pas qui est inscrit.
        return rendre(request, "atelier_connexion.html", message=MESSAGE_CONNEXION)

    @app.get("/atelier/entrer")
    def entrer(request: Request, jeton: str = ""):
        slug = _verifier_jeton_connexion(jeton)
        if not slug or not sa.lire_atelier(slug):
            raise HTTPException(400, "Lien de connexion expiré ou invalide. "
                                     "Demandez-en un nouveau.")
        sa.marquer_connexion(slug)
        reponse = RedirectResponse("/atelier", status_code=303)
        _ouvrir_session(reponse, slug)
        return reponse

    @app.post("/atelier/deconnexion")
    def sortir(request: Request, csrf: str = Form(...)):
        verifier_jeton_csrf(csrf)
        reponse = RedirectResponse("/", status_code=303)
        reponse.delete_cookie(NOM_COOKIE_ATELIER, path="/")
        return reponse

    @app.post("/atelier/acces")
    def demander_acces(request: Request, csrf: str = Form(...),
                       projet: str = Form(...)):
        """Demande d'accès à un projet. À la sortie de cette route, aucune
        coordonnée n'a été transmise et aucune somme n'a été débitée."""
        verifier_jeton_csrf(csrf)
        slug = _exiger_atelier(request)
        limiter(request, "atelier_acces", maximum=20, fenetre_s=3600)

        brief = sa.lire_brief(projet)
        if brief is None:
            raise HTTPException(404, "Projet introuvable.")
        if not sa.brief_ouvert(brief):
            return RedirectResponse(
                "/atelier?erreur=Ce+projet+n%27est+plus+ouvert+aux+demandes.",
                status_code=303)
        if sa.lire_acces_par_couple(projet, slug):
            return RedirectResponse(
                "/atelier?erreur=Vous+avez+d%C3%A9j%C3%A0+une+demande+sur+ce+projet.",
                status_code=303)
        # L'atelier doit être dans les correspondances du projet.
        recommandes = {r.get("slug") for r in
                       json.loads(brief.get("recommandations") or "[]")}
        if slug not in recommandes:
            raise HTTPException(403, "Ce projet ne correspond pas à votre atelier.")

        jeton = sa.jeton_du_brief(projet)
        fiche = store.lire_fiche(slug)
        nom = fiche.nom if fiche else slug

        # Le prix suit le budget annoncé par le musicien.
        prix = sa.prix_acces_cents(brief)

        # Trois façons de couvrir un accès, dans cet ordre : un crédit de
        # relance (gratuit, il est là pour être utilisé), le solde d'un carnet
        # déjà payé, puis la carte. Dans les trois cas, rien n'est
        # définitivement pris avant l'accord du musicien.
        credit = sa.credits_disponibles(slug) > 0
        autorisation_id, fournisseur_nom, echeance = None, "", ""
        if credit:
            mode, montant, fournisseur_nom = "credit", 0, "credit"
        elif sa.solde_atelier(slug) >= prix:
            mode, montant, fournisseur_nom = "solde", prix, "solde"
        else:
            try:
                autorisation = fournisseur().preautoriser(
                    montant_cents=prix,
                    reference=f"{projet}/{slug}",
                    description=f"Novaluth — accès au projet {projet}",
                )
            except PaiementIndisponible as e:
                store.journaliser("acces_paiement_refuse", slug, str(e)[:200])
                return RedirectResponse(
                    "/atelier?erreur=Le+paiement+n%27a+pas+pu+%C3%AAtre+"
                    "pr%C3%A9par%C3%A9.+Aucune+demande+n%27a+%C3%A9t%C3%A9+"
                    "cr%C3%A9%C3%A9e.", status_code=303)
            mode, montant = "carte", prix
            autorisation_id = autorisation.identifiant
            fournisseur_nom = autorisation.fournisseur
            echeance = autorisation.encaissable_avant

        reference = sa.creer_acces(
            brief_reference=projet, atelier_slug=slug,
            montant_cents=montant,
            autorisation_id=autorisation_id, fournisseur=fournisseur_nom,
            autorisation_echeance_le=echeance, paye_par_credit=credit,
            mode_paiement=mode,
        )
        if credit:
            sa.consommer_credit(slug, reference)
        elif mode == "solde" and not sa.prelever_solde(
                slug, prix, reference, f"accès au projet {projet}"):
            # Solde parti entre-temps : on referme proprement plutôt que de
            # transmettre un accès que personne n'a payé.
            sa.clore_acces(reference, "retire", "solde insuffisant")
            return RedirectResponse(
                "/atelier?erreur=Votre+solde+ne+couvre+plus+cet+acc%C3%A8s.",
                status_code=303)

        courriel.demande_acceptation(brief["email"], jeton, projet, nom,
                                     sa.FENETRE_ACCEPTATION_JOURS,
                                     montant_engage_cents=prix)
        return RedirectResponse(
            "/atelier?message=Demande+envoy%C3%A9e+au+musicien.+Rien+n%27est+"
            "d%C3%A9bit%C3%A9+avant+son+accord.", status_code=303)

    @app.post("/atelier/carnet")
    def acheter_carnet(request: Request, csrf: str = Form(...),
                       carnet: str = Form(...)):
        """Achat d'un carnet d'accès prépayé. Le paiement est immédiat : c'est
        un achat de l'atelier pour lui-même, sans musicien dans la boucle, donc
        sans autorisation en attente."""
        verifier_jeton_csrf(csrf)
        slug = _exiger_atelier(request)
        try:
            index = int(carnet)
            paye, credite, libelle = sa.CARNETS[index]
        except (ValueError, IndexError):
            raise HTTPException(400, "Carnet inconnu.")
        try:
            autorisation = fournisseur().preautoriser(
                montant_cents=paye,
                reference=f"carnet/{slug}/{index}",
                description=f"Novaluth — {libelle}",
            )
            fournisseur().encaisser(autorisation.identifiant)
        except PaiementIndisponible as e:
            store.journaliser("carnet_paiement_refuse", slug, str(e)[:200])
            return RedirectResponse(
                "/atelier?erreur=Le+paiement+du+carnet+n%27a+pas+abouti.+"
                "Rien+ne+vous+a+%C3%A9t%C3%A9+d%C3%A9bit%C3%A9.", status_code=303)
        solde = sa.crediter_solde(slug, credite, libelle)
        atelier = sa.lire_atelier(slug)
        if atelier:
            courriel.rappel_carnet(atelier["email"], libelle, paye, credite, solde)
        return RedirectResponse(
            "/atelier?message=Carnet+enregistr%C3%A9.+Votre+solde+est+"
            "cr%C3%A9dit%C3%A9.", status_code=303)

    @app.post("/atelier/renoncer")
    def renoncer(request: Request, csrf: str = Form(...), acces: str = Form(...)):
        """L'atelier retire sa demande tant que le musicien n'a pas répondu :
        l'autorisation est annulée, rien n'est débité (CGV art. 4)."""
        verifier_jeton_csrf(csrf)
        slug = _exiger_atelier(request)
        dossier = sa.lire_acces(acces)
        if dossier is None or dossier["atelier_slug"] != slug:
            raise HTTPException(404, "Demande introuvable.")
        if dossier["statut"] != "attente_musicien":
            return RedirectResponse(
                "/atelier?erreur=Cette+demande+a+d%C3%A9j%C3%A0+"
                "%C3%A9t%C3%A9+trait%C3%A9e.", status_code=303)
        motif = "demande retirée par l'atelier"
        liberer_engagement(dossier, motif)
        sa.clore_acces(acces, "retire", motif)
        return RedirectResponse(
            "/atelier?message=Demande+retir%C3%A9e.+Rien+ne+vous+a+"
            "%C3%A9t%C3%A9+d%C3%A9bit%C3%A9.", status_code=303)

    @app.post("/atelier/relance")
    def demander_credit(request: Request, csrf: str = Form(...),
                        acces: str = Form(...)):
        """Demande de crédit de relance pour un accès facturé resté sans suite."""
        verifier_jeton_csrf(csrf)
        slug = _exiger_atelier(request)
        limiter(request, "atelier_relance", maximum=10, fenetre_s=3600)

        dossier = sa.lire_acces(acces)
        if dossier is None or dossier["atelier_slug"] != slug:
            raise HTTPException(404, "Accès introuvable.")
        if dossier["statut"] != "accepte":
            raise HTTPException(400, "Cet accès n'a pas été facturé : il n'y a "
                                     "rien à créditer.")
        if sa.lire_relance(acces):
            return RedirectResponse(
                "/atelier?message=Votre+demande+est+d%C3%A9j%C3%A0+en+cours.",
                status_code=303)
        if sa.trop_tard_pour_crediter(dossier):
            return RedirectResponse(
                f"/atelier?erreur=Pass%C3%A9+{sa.DELAI_DEMANDE_CREDIT_JOURS}+"
                f"jours%2C+un+cr%C3%A9dit+de+relance+n%27est+plus+possible.",
                status_code=303)
        if sa.plafond_credits_atteint(slug):
            return RedirectResponse(
                f"/atelier?erreur=Un+cr%C3%A9dit+est+accord%C3%A9+au+maximum+"
                f"par+tranche+de+{sa.ACCES_FACTURES_PAR_CREDIT}+acc%C3%A8s+"
                f"factur%C3%A9s.", status_code=303)

        brief = sa.lire_brief(dossier["brief_reference"])
        sa.creer_relance(acces)
        if brief and brief.get("email"):
            fiche = store.lire_fiche(slug)
            jeton = sa.jeton_du_brief(dossier["brief_reference"])
            courriel.verification_avant_credit(
                brief["email"], jeton, dossier["brief_reference"],
                fiche.nom if fiche else slug, sa.FENETRE_REPONSE_RELANCE_JOURS)
        return RedirectResponse(
            f"/atelier?message=Demande+enregistr%C3%A9e.+Nous+interrogeons+le+"
            f"musicien+et+revenons+vers+vous+sous+"
            f"{sa.FENETRE_REPONSE_RELANCE_JOURS}+jours.", status_code=303)

    # ---------------------------- côté musicien ---------------------------- #

    @app.get("/projet/{jeton}")
    def page_projet(request: Request, jeton: str, message: str = ""):
        """Page de self-service du musicien. Aucun compte, aucun mot de passe :
        un lien signé, reçu par courriel, qui ne donne accès qu'à son projet."""
        brief = sa.brief_par_jeton(jeton)
        if brief is None:
            raise HTTPException(404, "Lien invalide ou projet effacé.")
        demandes = []
        for dossier in sa.acces_en_attente_du_brief(brief["reference"]):
            fiche = store.lire_fiche(dossier["atelier_slug"])
            demandes.append({
                **dossier,
                "nom_atelier": fiche.nom if fiche else dossier["atelier_slug"],
                "ville": fiche.ville if fiche else None,
                "pays": fiche.pays if fiche else None,
                "publiee": bool(fiche and fiche.statut == StatutFiche.publiee),
            })
        verifications = []
        for relance in sa.relances_du_brief(brief["reference"]):
            dossier = sa.lire_acces(relance["acces_reference"])
            fiche = store.lire_fiche(dossier["atelier_slug"]) if dossier else None
            verifications.append({
                **relance,
                "nom_atelier": fiche.nom if fiche else "",
            })
        return rendre(request, "projet_musicien.html", jeton=jeton,
                      brief=brief, criteres=json.loads(brief.get("criteres") or "{}"),
                      demandes=demandes, verifications=verifications,
                      message=message,
                      fenetre_jours=sa.FENETRE_ACCEPTATION_JOURS,
                      prix_affiche=courriel.euros(sa.prix_acces_cents(brief)),
                      libelles_criteres=LIBELLES_CRITERES)

    @app.get("/projet-cloture")
    def projet_cloture(request: Request):
        """Page de confirmation après clôture : le lien du musicien ne mène plus
        à rien puisque son adresse a été effacée."""
        return rendre(request, "projet_cloture.html")

    @app.post("/projet/{jeton}/acces/{reference}")
    def repondre_demande(request: Request, jeton: str, reference: str,
                         csrf: str = Form(...), decision: str = Form(...)):
        verifier_jeton_csrf(csrf)
        limiter(request, "projet_reponse", maximum=30, fenetre_s=600)
        brief = sa.brief_par_jeton(jeton)
        dossier = sa.lire_acces(reference)
        if brief is None or dossier is None or dossier["brief_reference"] != brief["reference"]:
            raise HTTPException(404, "Demande introuvable.")
        if dossier["statut"] != "attente_musicien":
            return RedirectResponse(f"/projet/{jeton}?message=Cette+demande+a+"
                                    f"d%C3%A9j%C3%A0+%C3%A9t%C3%A9+trait%C3%A9e.",
                                    status_code=303)

        atelier = sa.lire_atelier(dossier["atelier_slug"])
        fiche = store.lire_fiche(dossier["atelier_slug"])
        nom = fiche.nom if fiche else dossier["atelier_slug"]

        if decision == "accepter":
            # Encaissement seulement maintenant, et seulement s'il réussit.
            # Un accès pris sur un carnet ou sur un crédit de relance est déjà
            # couvert : il n'y a rien à appeler chez le prestataire.
            mode = dossier.get("mode_paiement") or "carte"
            if mode == "carte" and dossier["autorisation_id"]:
                try:
                    fournisseur().encaisser(dossier["autorisation_id"])
                except PaiementIndisponible as e:
                    store.journaliser("encaissement_echoue", reference, str(e)[:200])
                    return RedirectResponse(
                        f"/projet/{jeton}?message=Un+incident+technique+emp"
                        f"%C3%AAche+la+mise+en+relation.+Merci+de+r%C3%A9essayer.",
                        status_code=303)
            sa.marquer_accepte(reference)
            if atelier:
                courriel.coordonnees_transmises(atelier["email"], reference,
                                                brief["reference"], brief["email"])
            return RedirectResponse(
                f"/projet/{jeton}?message=Vos+coordonn%C3%A9es+ont+%C3%A9t%C3%A9"
                f"+transmises+%C3%A0+{nom.replace(' ', '+')}.", status_code=303)

        if decision in {"decliner", "abandonner"}:
            motif = ("décliné par le musicien" if decision == "decliner"
                     else "projet abandonné par le musicien")
            liberer_engagement(dossier, motif)
            sa.clore_acces(reference, "decline" if decision == "decliner"
                           else "abandonne", motif)
            if atelier:
                courriel.acces_annule(atelier["email"], reference,
                                      brief["reference"], motif)
            if decision == "abandonner":
                annuler_demandes_restantes(brief["reference"],
                                           "projet abandonné par le musicien")
                sa.cloturer_brief(brief["reference"], "abandon signalé par le musicien")
                return RedirectResponse(
                    f"/projet/{jeton}?message=Votre+projet+est+cl%C3%B4tur%C3%A9."
                    f"+Aucun+atelier+ne+peut+plus+vous+contacter.", status_code=303)
            return RedirectResponse(f"/projet/{jeton}?message=Demande+"
                                    f"d%C3%A9clin%C3%A9e.", status_code=303)

        raise HTTPException(400, "Réponse inconnue.")

    @app.post("/projet/{jeton}/etat")
    def changer_etat(request: Request, jeton: str, csrf: str = Form(...),
                     decision: str = Form(...)):
        """Confirmation de fraîcheur, ou clôture en un clic."""
        verifier_jeton_csrf(csrf)
        limiter(request, "projet_etat", maximum=20, fenetre_s=600)
        brief = sa.brief_par_jeton(jeton)
        if brief is None:
            raise HTTPException(404, "Lien invalide ou projet effacé.")

        if decision == "confirmer":
            # Confirmation initiale : c'est ce clic qui rend le projet visible
            # des ateliers.
            if sa.confirmer_brief(brief["reference"]):
                return RedirectResponse(
                    f"/projet/{jeton}?message=Projet+confirm%C3%A9.+Les+ateliers+"
                    f"correspondants+peuvent+d%C3%A9sormais+demander+%C3%A0+vous+"
                    f"r%C3%A9pondre.", status_code=303)
            return RedirectResponse(f"/projet/{jeton}?message=Votre+projet+"
                                    f"%C3%A9tait+d%C3%A9j%C3%A0+confirm%C3%A9.",
                                    status_code=303)
        if decision == "actualite":
            sa.confirmer_fraicheur(brief["reference"])
            return RedirectResponse(f"/projet/{jeton}?message=Merci%2C+votre+"
                                    f"projet+reste+actif.", status_code=303)
        if decision == "cloture":
            annuler_demandes_restantes(brief["reference"],
                                       "projet clôturé par le musicien")
            sa.cloturer_brief(brief["reference"], "clôturé par le musicien")
            return RedirectResponse("/projet-cloture", status_code=303)
        raise HTTPException(400, "Décision inconnue.")

    @app.post("/projet/{jeton}/verification/{reference}")
    def repondre_verification(request: Request, jeton: str, reference: str,
                              csrf: str = Form(...), decision: str = Form(...)):
        """Réponse à la question posée avant l'octroi d'un crédit de relance.
        Aucune conséquence pour le musicien, quelle que soit sa réponse."""
        verifier_jeton_csrf(csrf)
        limiter(request, "projet_verification", maximum=20, fenetre_s=600)
        brief = sa.brief_par_jeton(jeton)
        dossier = sa.lire_acces(reference)
        if brief is None or dossier is None or dossier["brief_reference"] != brief["reference"]:
            raise HTTPException(404, "Demande introuvable.")
        relance = sa.lire_relance(reference)
        if relance is None or relance["statut"] != "en_cours":
            return RedirectResponse(f"/projet/{jeton}?message=Cette+question+a+"
                                    f"d%C3%A9j%C3%A0+%C3%A9t%C3%A9+trait%C3%A9e.",
                                    status_code=303)
        atelier = sa.lire_atelier(dossier["atelier_slug"])
        if decision == "poursuit":
            sa.cloturer_relance(reference, "refusee", "échange en cours")
            return RedirectResponse(f"/projet/{jeton}?message=Merci+pour+votre+"
                                    f"r%C3%A9ponse.", status_code=303)
        if decision == "abandon":
            sa.cloturer_relance(reference, "credit_accorde", "projet abandonné")
            sa.accorder_credit(dossier["atelier_slug"],
                               "projet abandonné, confirmé par le musicien",
                               reference)
            if atelier:
                courriel.credit_accorde(atelier["email"], reference,
                                        "abandon confirmé par le musicien")
            annuler_demandes_restantes(brief["reference"],
                                       "projet abandonné par le musicien")
            sa.cloturer_brief(brief["reference"], "abandon confirmé par le musicien")
            return RedirectResponse("/projet-cloture", status_code=303)
        raise HTTPException(400, "Réponse inconnue.")
