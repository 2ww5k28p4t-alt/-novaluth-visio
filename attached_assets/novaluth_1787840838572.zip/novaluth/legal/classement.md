Dernière mise à jour : 27/08/2026

Cette page explique dans quel ordre les ateliers apparaissent dans l'annuaire de
Novaluth, et pourquoi. Elle répond à l'obligation d'information sur les
principaux paramètres d'un classement en ligne, prévue à l'article 27 du
règlement européen sur les services numériques et à l'article L. 111-7 du code de
la consommation.

## En une phrase

Novaluth ne classe pas les artisans par mérite. Les ateliers qui correspondent à
votre recherche sont présentés dans un ordre remélangé une fois par jour,
identique pour tous les visiteurs de la même journée.

## L'ordre par défaut : une rotation quotidienne

L'ordre d'affichage est tiré au sort une fois par jour, à partir de la date du
jour et de rien d'autre. Trois conséquences :

- Deux visiteurs qui consultent l'annuaire le même jour voient le même ordre.
- L'ordre change le lendemain, si bien qu'aucun atelier n'occupe durablement la
  première place.
- L'ordre est reproductible : à partir de la date, n'importe qui obtient la même
  suite. Vous n'avez pas à nous croire sur parole.

Cet ordre ne dépend ni de l'ancienneté de l'atelier, ni de son chiffre
d'affaires, ni du nombre de demandes de contact qu'il a payées, ni d'aucune
appréciation portée par Novaluth ou par un modèle d'intelligence artificielle.

## Les ordres que vous pouvez choisir

Vous pouvez remplacer la rotation par un ordre explicite : délai annoncé le plus
court, tarif annoncé le plus bas, ordre alphabétique, ou fiches mises à jour
récemment. Chacun repose sur une information déclarée et affichée sur la fiche.
Lorsqu'une donnée est absente — un atelier qui n'a pas annoncé ses tarifs, par
exemple — la fiche est placée en fin de liste, jamais retirée.

## Les filtres

Les filtres de l'annuaire — instrument, style joué, budget, délai, pays, zone de
livraison, façons de travailler, fiche relue par l'artisan — retirent des fiches
de la liste. Ils n'en avantagent aucune et ne modifient pas l'ordre.

Quand une information manque à une fiche, celle-ci est **conservée** dans les
résultats. Un artisan qui n'a pas encore renseigné ses tarifs ou sa zone de
livraison ne disparaît pas de la recherche à cause de ce silence.

Cocher plusieurs façons de travailler restreint la recherche aux ateliers qui
les réunissent toutes.

## Ce que Novaluth ne fait pas

- **Aucune note, aucun niveau, aucune étoile.** Une version antérieure du site
  affichait un « niveau d'innovation sur 10 » et ordonnait l'annuaire selon ce
  nombre. Cette note a été retirée : elle était une estimation produite par un
  modèle à partir de pages web, indéfendable devant l'artisan concerné, et
  dépourvue de sens pour un métier où faire autrement ne veut pas dire faire
  mieux. Un luthier qui construit selon les usages du siècle dernier ne vaut ni
  plus ni moins qu'un atelier qui travaille le carbone.
- **Aucune place achetée.** Il n'existe aucun moyen de payer pour être mieux
  placé, mis en avant, épinglé ou signalé. Les sommes versées par les ateliers
  ne concernent que l'accès aux coordonnées d'un musicien qui a accepté le
  contact, et n'ont aucun effet sur l'annuaire.
- **Aucun ordre personnalisé.** L'annuaire ne tient pas compte de votre
  historique de navigation, et Novaluth ne construit pas de profil publicitaire.

## Les façons de travailler : d'où elles viennent

Chaque façon de travailler est déduite des informations publiées par l'artisan
lui-même : son site, ses fiches produit, ses descriptions de modèles. Tant que
l'artisan n'a pas relu sa fiche, l'annuaire l'indique par la mention « d'après
ses pages publiques ». Une fois la fiche relue, la mention devient « relu par
l'artisan ».

Ces mentions décrivent une pratique déclarée. Novaluth ne se rend pas sur place,
ne contrôle pas les approvisionnements et n'atteste d'aucune allégation
environnementale.

## Corriger ou contester

Un artisan qui estime qu'une façon de travailler lui est attribuée à tort, ou
qu'une façon exacte lui manque, peut demander la correction de sa fiche : la
procédure est décrite dans la [charte des artisans référencés](/legal/charte-luthier)
et les [réclamations et litiges](/legal/litiges). La correction est appliquée
sans condition dès lors qu'elle porte sur un fait relatif à son propre atelier.

## En cas de changement

Toute modification de la manière d'ordonner l'annuaire est reportée sur cette
page, avec sa date. L'historique des versions du site fait foi de la rédaction
applicable à une date donnée.
