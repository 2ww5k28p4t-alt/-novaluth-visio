# Novaluth — L'avenir de l'instrument

Annuaire et moteur de mise en relation entre musiciens, **luthiers innovants** et
**jeunes marques d'instruments**. Novaluth ne référence jamais les géants installés :
la promesse est de faire découvrir ce qui sort des sentiers battus.

Novaluth **n'est ni vendeur, ni fabricant, ni transporteur, ni intermédiaire de
paiement**. Le service référence des informations publiées et met en relation. Rien
de plus — et tous les textes du site le disent explicitement.

---

## 1. Architecture en deux services

Le dépôt contient **deux applications distinctes**, volontairement séparées :

```
┌──────────────────────────────┐        requête signée HMAC        ┌───────────────────────────────┐
│  novaluth-web  (port 8000)   │ ────────────────────────────────► │ novaluth-passerelle (8100)    │
│  site public + PWA + brief   │ ◄──────────────────────────────── │ seul détenteur des clés       │
│  AUCUNE clé de subnet        │            réponse filtrée        │ Bittensor (SN13 / SN64)       │
└──────────────────────────────┘                                   └───────────────┬───────────────┘
                                                                                   │
                                                              ┌────────────────────┴────────────────┐
                                                              │ SN64 Chutes AI  ·  SN13 Data Univ.  │
                                                              └─────────────────────────────────────┘
```

**Pourquoi deux services ?** C'est la réponse directe à l'exigence « serveurs dédiés
pour la sécurité des clés API des subnets ». Le site public est la surface exposée à
Internet : formulaires, visiteurs, robots. Si un jour une faille y apparaît, elle ne
donne accès à **aucune** clé Bittensor, parce que ces clés ne sont jamais présentes
dans son environnement.

Vérification en une requête : `GET /sante` sur le service web renvoie
`"cles_bittensor_dans_ce_service": false`.

### Ce que fait la passerelle (`gateway/main.py`)

| Protection | Détail |
|---|---|
| Isolation des clés | `CHUTES_API_KEY` et `SN13_API_KEY` n'existent que dans ce processus |
| Signature HMAC-SHA256 | sur `timestamp.nonce.corps`, secret partagé `NOVALUTH_GATEWAY_SECRET` |
| Fenêtre temporelle | 120 secondes maximum entre la signature et la réception |
| Anti-rejeu | chaque `nonce` est stocké en base et refusé une seconde fois |
| Listes blanches | seuls les modèles et les sources explicitement autorisés passent |
| Plafonds journaliers | `PLAFOND_APPELS_IA_JOUR`, `PLAFOND_APPELS_SN13_JOUR` |
| Nettoyage des données | e-mails, téléphones, IBAN, adresses retirés avant tout envoi à l'IA |
| Journal d'audit | `gateway/audit_passerelle.db`, sans contenu personnel |
| Surface réduite | ni `/docs`, ni `/redoc`, ni `/openapi.json` (404) |
| Erreurs normalisées | aucun message d'erreur du fournisseur ne remonte au public |

Une requête non signée reçoit `401 {"erreur": "Requête non signée."}`.

---

## 2. Arborescence

```
novaluth/
├── run.py                     lance les deux services (développement)
├── requirements.txt
├── .replit  ·  replit.nix  ·  .env.example  ·  .gitignore
│
├── gateway/main.py            LA PASSERELLE — seule à connaître les clés subnets
├── common/passerelle_client.py client signataire utilisé par le web et le pipeline
│
├── web/
│   ├── main.py                routes du site public
│   ├── schemas.py             modèles Pydantic (fiches, briefs, spécifications)
│   ├── store.py               SQLite : fiches, briefs, consentements, purge
│   ├── matching.py            calcul de correspondance explicable
│   ├── ia.py                  résumés via la passerelle, avec repli local
│   ├── securite.py            CSRF, honeypot, limitation de débit, en-têtes
│   └── legal.py               rendu des documents juridiques en Markdown
│
├── pipeline/
│   ├── collecte.py            jobs : luthiers · marques · momentum · digest
│   └── telegram.py            notifications + arbitrage ✅ 🌱 🏭 ❌
│
├── tools/verifier_conformite.py   contrôle automatisé avant mise en ligne
│
├── legal/                     13 documents juridiques (voir §5)
├── data/fiches_demonstration.json  5 fiches fictives de démonstration
├── static/                    CSS, logo officiel, icônes, police, manifest, SW
│   ├── novaluth-wordmark.png  mot-symbole (en-tête)
│   ├── novaluth-logo.png      logo complet avec baseline (pied de page, partage)
│   ├── novaluth-globe.png     globe seul, détouré (ornement)
│   └── polices/               Space Grotesk auto-hébergée (OFL 1.1)
└── templates/                 12 gabarits Jinja2, mobile-first
```

---

## 3. Démarrage

### En local ou dans un seul Repl (développement)

```bash
pip install -r requirements.txt
python run.py
```

`run.py` démarre la passerelle sur le port 8100 et le site sur le port 8000, et
charge les 5 fiches de démonstration si la base est vide.

### Secrets à définir (onglet Secrets de Replit, jamais dans le code)

Obligatoires dès le premier lancement :

| Secret | Rôle |
|---|---|
| `NOVALUTH_GATEWAY_SECRET` | secret partagé web ↔ passerelle (chaîne longue et aléatoire) |
| `NOVALUTH_APP_SECRET` | signature des jetons CSRF du site |
| `NOVALUTH_ADMIN_TOKEN` | accès à `/admin` |

Pour activer les subnets Bittensor (facultatif au départ : sans eux, l'application
fonctionne avec ses résumés de repli) :

| Secret | Rôle |
|---|---|
| `CHUTES_API_KEY` | SN64 Chutes AI — **passerelle uniquement** |
| `SN13_API_KEY` | SN13 Data Universe — **passerelle uniquement** |
| `CHUTES_MODEL` | modèle par défaut (`Qwen/Qwen3-32B-TEE`) |

Pour le bot de supervision :

| Secret | Rôle |
|---|---|
| `TELEGRAM_BOT_TOKEN` | jeton donné par @BotFather |
| `TELEGRAM_CHAT_ID` | identifiant de votre conversation privée |

Réglages optionnels : `NOVALUTH_GATEWAY_URL`, `NOVALUTH_ENV` (`dev` / `prod`),
`NOVALUTH_URL`, `NOVALUTH_DB`, `PORT`, `PORT_PASSERELLE`,
`PLAFOND_APPELS_IA_JOUR`, `PLAFOND_APPELS_SN13_JOUR`, `NOVALUTH_CLIENT_NAME`.
Tous sont listés dans `.env.example`.

### Vérifier avant toute mise en ligne

```bash
python -m tools.verifier_conformite
```

Le contrôle refuse le vocabulaire interdit (« certifié », « garanti », « labellisé »,
« meilleur », « sans risque »…), vérifie que chaque document juridique existe et est
daté, que le pied de page les référence tous, et signale les champs `[À COMPLÉTER]`
restants. Il doit finir sur **0 anomalie bloquante**.

### Installer la PWA sur iPhone

Ouvrir l'URL du Repl dans Safari → bouton Partager → « Sur l'écran d'accueil ».
Le manifeste et le service worker sont servis à la racine (`/manifest.json`, `/sw.js`)
pour que le cache couvre tout le site.

---

## 4. Pipeline et supervision

```bash
python -m pipeline.collecte luthiers    # candidats artisans
python -m pipeline.collecte marques     # jeunes marques
python -m pipeline.collecte momentum    # recalcul des scores d'émergence
python -m pipeline.collecte digest      # résumé envoyé sur Telegram
python -m pipeline.telegram             # boucle d'arbitrage interactive
```

La collecte passe **toujours** par la passerelle, jamais directement par les subnets.
Un filtre anti-géants écarte automatiquement les grandes marques installées, et un
score d'émergence classe les candidats. **Rien n'est publié sans votre validation**
depuis Telegram : ✅ Publier · 🌱 À suivre · 🏭 Trop établie · ❌ Rejeter.
Commandes disponibles : `/etat`, `/attente`, `/aide`.

Pour l'installation et la mise en ligne, suivez **INSTALLATION-REPLIT.md** :
un seul Repl en Reserved VM, deux processus, secrets, contrôles et tâches
programmées, pas à pas. **DEPLOIEMENT.md** documente la variante en deux Repls
séparés.

Deux commandes utiles à tout moment dans le Shell :

```bash
python -m tools.generer_secrets     # fabrique les secrets internes
python -m tools.verifier_secrets    # contrôle l'installation, sans rien afficher
```

---

## 5. Couverture juridique

13 documents dans `legal/`, rendus sur le site à `/legal` :

`mentions-legales.md` · `cgu.md` · `cgv.md` · `confidentialite.md` · `cookies.md` ·
`charte-luthier.md` · `charte-expedition.md` · `badges.md` · `litiges.md` ·
`propriete-intellectuelle.md` · `accessibilite.md` · `conflits-interets.md` ·
`ia-transparence.md`

Fondements retenus : obligation d'identification de l'éditeur de
l'[article 19 de la LCEN](https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000032236011),
information précontractuelle (C. conso. L111-1 à L111-3), garantie légale de
conformité de deux ans ([art. L217-3 C. conso.](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044142579)),
droit de rétractation étendu aux très petits professionnels
([art. L221-3 C. conso.](https://www.doctrine.fr/l/texts/codes/LEGITEXT000006069565/articles/LEGIARTI000032226882)),
transparence du système de recommandation
([article 27 du DSA](https://dsa-act.eu/fr/article-27-transparence-du-systeme-de-recommandation/)),
RGPD et recommandations de la CNIL.

### À compléter avant le premier euro encaissé

Cherchez `[À COMPLÉTER]` dans `legal/` et remplissez :

1. identité de l'éditeur (nom ou raison sociale, forme juridique, adresse) ;
2. numéro SIRET / RCS et, le cas échéant, numéro de TVA intracommunautaire ;
3. hébergeur (nom, adresse, téléphone) — Replit si vous restez chez eux ;
4. médiateur de la consommation (obligatoire dès la première vente à un particulier).

Un point à traiter dans la même passe :

- **Adresse de contact.** `contact@novaluth.com` est utilisée partout ; vérifiez
  qu'elle est bien active et relevée.

Les pondérations du calcul de correspondance sont publiées dans les CGU (budget 26,
type 14, style 14, zone 12, délai 10, bois 8, sonorité 8, façons de travailler 8).
Si vous les modifiez dans `web/matching.py`, mettez les CGU à jour : c'est ce que
demande l'article 27 du DSA.

L'**ordre d'affichage de l'annuaire** est une question distincte, et il n'utilise
aucune note : rotation équitable tirée une fois par jour, décrite dans
`legal/classement.md` et implémentée dans `web/recherche.py`. Les « façons de
travailler » qui servent de filtres forment un vocabulaire fermé, défini dans
`web/facettes.py` ; c'est là qu'on en ajoute une, et nulle part ailleurs.

Le **son des instruments** suit la même règle : plus aucune échelle chiffrée, un
vocabulaire fermé de trois axes à trois valeurs dans `web/sonorite.py` (couleur
du son, réponse à l'attaque, tenue des notes). Les fiches déjà collectées avec
d'anciennes notes 0-10 sont converties à la lecture par `depuis_chiffres()` :
rien n'est perdu, rien n'est réaffiché en chiffres. Le seul pourcentage encore
visible sur le site est le taux de correspondance entre un projet et une fiche.

---

## 6. Règles à ne jamais enfreindre

- Aucun texte ne dit « certifié », « garanti », « labellisé », « agréé »,
  « 100 % sécurisé », « meilleur », « idéal », « parfait », « sans risque »,
  « investissement », « je vous conseille ».
- Les badges sont **descriptifs et datés**, jamais un label de qualité.
- Les clés de subnet ne quittent jamais la passerelle.
- Aucun compte, aucune donnée personnelle n'est nécessaire pour obtenir une
  correspondance. L'e-mail n'est collecté qu'avec un consentement explicite, non
  précoché, horodaté et conservé comme preuve, puis anonymisé au bout de 12 mois.
- Les fiches de démonstration portent la mention « exemple fictif ». Supprimez-les
  quand vos vraies fiches arrivent.
