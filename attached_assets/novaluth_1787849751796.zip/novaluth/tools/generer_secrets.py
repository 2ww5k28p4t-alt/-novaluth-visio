"""
NOVALUTH — Générateur de secrets
================================

Fabrique les trois secrets internes du projet et les affiche prêts à recopier
dans le panneau Secrets de Replit, un par un.

    python -m tools.generer_secrets

Aucune clé de fournisseur n'est générée ici : CHUTES_API_KEY et SN13_API_KEY
viennent de Chutes AI et de Macrocosmos, vous les récupérez sur leurs sites.

Rien n'est écrit sur le disque. Si vous perdez une valeur, relancez la commande
et remplacez le secret dans Replit : redéfinir NOVALUTH_APP_SECRET déconnecte
simplement les formulaires en cours, sans perte de données.
"""

from __future__ import annotations

import secrets
import sys

# nom du secret, longueur, rôle, où le définir
SECRETS_INTERNES = [
    ("NOVALUTH_GATEWAY_SECRET", 48,
     "signe les appels entre le site et la passerelle",
     "les deux services (même Repl : une seule fois)"),
    ("NOVALUTH_APP_SECRET", 48,
     "protège les formulaires du site (jetons anti-falsification)",
     "application publique"),
    ("NOVALUTH_ADMIN_TOKEN", 18,
     "mot de passe d'accès à la page /admin",
     "application publique"),
]

LARGEUR = 72


def generer() -> list[tuple[str, str, str, str]]:
    return [(nom, secrets.token_urlsafe(longueur), role, ou)
            for nom, longueur, role, ou in SECRETS_INTERNES]


def main() -> int:
    lignes = generer()

    print()
    print("═" * LARGEUR)
    print(" NOVALUTH — secrets internes à recopier dans Replit")
    print("═" * LARGEUR)
    print(" Panneau latéral → Secrets (icône cadenas) → New secret.")
    print(" Copiez le nom dans « Key », la valeur dans « Value ».")
    print(" Après le dernier ajout : Stop puis Run, pour que les secrets")
    print(" soient relus au démarrage.")
    print("═" * LARGEUR)

    for nom, valeur, role, ou in lignes:
        print()
        print(f"  Key    {nom}")
        print(f"  Value  {valeur}")
        print(f"         → {role}")
        print(f"         → à définir sur : {ou}")

    print()
    print("─" * LARGEUR)
    print(" Restent à ajouter, avec vos propres valeurs :")
    print()
    print("  CHUTES_API_KEY        votre clé Chutes AI (subnet 64)")
    print("  SN13_API_KEY          votre clé Macrocosmos (subnet 13)")
    print("  NOVALUTH_URL          l'adresse publique du site")
    print("  TELEGRAM_BOT_TOKEN    facultatif, supervision")
    print("  TELEGRAM_CHAT_ID      facultatif, supervision")
    print()
    print(" Et, dans les secrets du déploiement uniquement :")
    print()
    print("  NOVALUTH_ENV          prod")
    print("─" * LARGEUR)
    print(" Ne recopiez ces valeurs dans aucun fichier du projet : les")
    print(" fichiers sont versionnés et suivent le Repl s'il est dupliqué.")
    print(" Contrôle ensuite : python -m tools.verifier_secrets")
    print("═" * LARGEUR)
    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
