"""
NOVALUTH — Contrôle de conformité automatisé
============================================

À lancer avant chaque mise en ligne :

    python -m tools.verifier_conformite

Ce que le contrôle vérifie :
  1. Vocabulaire interdit dans les pages, les gabarits, les textes juridiques et
     les fiches de démonstration (promesses que le service ne peut pas tenir).
  2. Présence et non-vacuité des 13 documents juridiques attendus.
  3. Absence de clé d'API ou de secret en clair dans le dépôt.
  4. Invariant d'architecture : aucune clé de subnet lue en dehors de gateway/.
  5. Présence des clauses obligatoires (RGPD, garantie légale, DSA art. 27,
     médiation, transparence du classement).
  6. Fiches de démonstration correctement marquées comme fictives.

Sortie : code 0 si tout passe, 1 s'il reste une anomalie bloquante.
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent

# --------------------------------------------------------------------------- #
# 1. Vocabulaire interdit
# --------------------------------------------------------------------------- #

# Formulations qui engageraient une garantie que Novaluth ne peut pas assumer,
# ou qui transformeraient un annuaire en conseil.
INTERDITS = {
    r"\bcertifi(é|e|és|ées?)\b": "aucune certification n'est délivrée",
    r"\bgarant(i|ie|is|ies)\b": "Novaluth ne garantit rien",
    r"\blabellis(é|ée|és|ées)\b": "aucun label n'existe",
    r"\bagré(é|ée|és|ées)\b": "aucun agrément n'est délivré",
    r"100\s*%\s*(sécuris|sûr|fiab)": "promesse de sécurité absolue",
    r"\ble meilleur\b|\bla meilleure\b|\bles meilleurs\b": "jugement de valeur",
    r"\bidéal(e|es|aux)?\b": "jugement de valeur",
    r"\bparfait(e|es|s)?\b": "jugement de valeur",
    r"je vous conseille|nous vous conseillons|nous recommandons": "conseil personnalisé",
    r"\binvestissement\b|\bplacement\b|\bprend de la valeur\b": "conseil en investissement",
    r"\brentab(le|ilité)\b": "promesse financière",
    r"sans risque|risque zéro": "promesse de sécurité absolue",
    r"\bassuré par novaluth\b": "Novaluth n'assure rien",
}

# Contextes où le mot est légitime : négations, renvois au droit applicable et
# passages qui expliquent précisément ce que Novaluth ne fait pas. L'analyse est
# faite sur le paragraphe entier, pour supporter les phrases coupées en
# plusieurs lignes.
EXCEPTIONS_CONTEXTE = [
    r"\bne\W{0,4}(garantit|garantis|certifie|délivre|recommande|constitue|peut"
    r"|conseille|fournit|publie|décerne|vend|détient|prend|s'agit|sera|seront"
    r"|peuvent|signifie|répond)",
    r"\bn'(est|a|assure|engage|exerce|intervient|arbitre|audite|contrôle|existe)",
    r"\bne pas\b|\bne jamais\b|\bjamais\b",
    r"\baucun\w*\s+(certification|label|garantie|agrément|conseil|analyse"
    r"|projection|mention|attestation)",
    r"\binterdit\w*\b|\bproscrit\w*\b|\bprohib\w*\b",
    r"garantie[s]?\s+(légale|des vices|annoncée|de conformité)",
    r"garanties techniques",
    r"garantie_annees",
    r"prestataire de paiement agréé",
    r"ne signifie pas",
    r"sans être tenu",
    r"exclues du droit|exclus du droit",
    r"ne constitue",
    r"n° 2004-575|L\.\s*2\d\d-\d",
]

# Marqueurs volontaires. Une liste de mots proscrits doit forcément contenir ces
# mots : on l'encadre explicitement plutôt que d'affaiblir la règle.
MARQUEUR_LIGNE = "conformite:ok"
MARQUEUR_DEBUT = "conformite:debut-liste-proscrite"
MARQUEUR_FIN = "conformite:fin-liste-proscrite"

CIBLES_TEXTE = [
    ("templates", "*.html"),
    ("legal", "*.md"),
    ("static", "*.js"),
    ("static", "*.css"),
    ("web", "*.py"),
    ("pipeline", "*.py"),
    ("data", "*.json"),
]

# --------------------------------------------------------------------------- #
# 2. Documents juridiques attendus
# --------------------------------------------------------------------------- #

DOCUMENTS_ATTENDUS = [
    "mentions-legales", "cgu", "cgv", "confidentialite", "cookies",
    "charte-luthier", "charte-expedition", "badges", "litiges",
    "propriete-intellectuelle", "accessibilite", "conflits-interets",
    "ia-transparence", "classement", "sources-donnees",
]

# Clauses dont l'absence est bloquante : (fichier, motif, description)
CLAUSES_OBLIGATOIRES = [
    ("mentions-legales.md", r"2004-575", "référence à la LCEN"),
    ("mentions-legales.md", r"[Hh]ébergeur", "identification de l'hébergeur"),
    ("mentions-legales.md", r"SIRE[NT]", "emplacement du numéro d'immatriculation"),
    ("cgu.md", r"27 du règlement \(UE\) 2022/2065|article 27", "transparence DSA art. 27"),
    ("cgu.md", r"\|\s*26\s*%", "publication de la pondération du classement"),
    ("cgu.md", r"ni vendeur, ni fabricant", "clause de non-qualité de vendeur"),
    ("cgv.md", r"L\.\s*221-3", "droit de rétractation des petits professionnels"),
    ("cgv.md", r"293 B", "mention de TVA en franchise"),
    ("confidentialite.md", r"CNIL", "autorité de contrôle"),
    ("confidentialite.md", r"[Cc]onsentement", "base légale du consentement"),
    ("confidentialite.md", r"12 mois", "durée de conservation"),
    ("confidentialite.md", r"portabilité", "droit à la portabilité"),
    ("litiges.md", r"L\.\s*217-3", "garantie légale de conformité"),
    ("litiges.md", r"[Mm]édiateur de la consommation", "médiation de la consommation"),
    ("litiges.md", r"[Ss]ignal[Cc]onso|signal\.conso", "voie de signalement DGCCRF"),
    ("charte-expedition.md", r"CITES", "réglementation des essences protégées"),
    ("badges.md", r"[Mm]entions interdites", "liste des formulations proscrites"),
    ("ia-transparence.md", r"[Hh]umaine", "validation humaine avant publication"),
    ("conflits-interets.md", r"[Ss]ponsorisé", "traitement des mises en avant"),
    ("accessibilite.md", r"[Cc]ontrast", "engagement de contraste"),
    ("sources-donnees.md", r"robots\.txt", "respect du fichier robots.txt"),
    ("sources-donnees.md", r"L\.\s*122-5-3", "exception de fouille de données"),
    ("sources-donnees.md", r"[Ii]ntérêt légitime", "base légale de la collecte"),
    ("sources-donnees.md", r"CNIL", "autorité de contrôle"),
    ("ia-transparence.md", r"cha[îi]ne", "chaînes de prestataires déclarées"),
]

# --------------------------------------------------------------------------- #
# 3. Secrets
# --------------------------------------------------------------------------- #

MOTIFS_SECRETS = [
    (r"cpk_[A-Za-z0-9]{20,}", "clé Chutes en clair"),
    (r"sk-[A-Za-z0-9]{20,}", "clé de type OpenAI en clair"),
    (r"\d{9,10}:AA[A-Za-z0-9_-]{30,}", "jeton de bot Telegram en clair"),
    (r"(CHUTES_API_KEY|SN13_API_KEY|DESEARCH_API_KEY|APEX_API_KEY|"
     r"MISTRAL_API_KEY|NOVALUTH_GATEWAY_SECRET|"
     r"NOVALUTH_APP_SECRET|NOVALUTH_ADMIN_TOKEN|TELEGRAM_BOT_TOKEN)"
     r"\s*=\s*[\"'][^\"'\s]{8,}[\"']", "secret écrit en dur"),
]

FICHIERS_EXEMPTS_SECRETS = {".env.example"}

# Fichiers autorisés à lire les clés de subnet : la passerelle, et elle seule.
CLES_SUBNET = ["CHUTES_API_KEY", "SN13_API_KEY", "DESEARCH_API_KEY",
               "APEX_API_KEY", "MISTRAL_API_KEY"]
DOSSIERS_AUTORISES_CLES = {"gateway", "tools"}


# --------------------------------------------------------------------------- #

anomalies: list[str] = []
avertissements: list[str] = []


def fichiers_texte():
    for dossier, motif in CIBLES_TEXTE:
        chemin = RACINE / dossier
        if chemin.exists():
            yield from sorted(chemin.rglob(motif))


def contexte_exempte(texte: str) -> bool:
    minuscule = texte.lower()
    return any(re.search(exc, minuscule) for exc in EXCEPTIONS_CONTEXTE)


def paragraphes(lignes: list[str]) -> dict[int, str]:
    """Associe chaque numéro de ligne au paragraphe qui la contient : une phrase
    coupée sur trois lignes doit être jugée dans son ensemble."""
    contexte: dict[int, str] = {}
    debut = 0
    tampon: list[str] = []

    def vider() -> None:
        bloc = " ".join(tampon)
        for decalage in range(len(tampon)):
            contexte[debut + decalage] = bloc

    for index, ligne in enumerate(lignes, 1):
        if not ligne.strip():
            if tampon:
                vider()
                tampon.clear()
            continue
        if not tampon:
            debut = index
        tampon.append(ligne)
    if tampon:
        vider()
    return contexte


def controle_vocabulaire() -> None:
    for fichier in fichiers_texte():
        lignes = fichier.read_text(encoding="utf-8",
                                   errors="ignore").splitlines()
        contexte = paragraphes(lignes)
        dans_liste_proscrite = False
        for numero, ligne in enumerate(lignes, 1):
            if MARQUEUR_DEBUT in ligne:
                dans_liste_proscrite = True
                continue
            if MARQUEUR_FIN in ligne:
                dans_liste_proscrite = False
                continue
            if dans_liste_proscrite or MARQUEUR_LIGNE in ligne:
                continue
            if contexte_exempte(contexte.get(numero, ligne)):
                continue
            minuscule = ligne.lower()
            for motif, raison in INTERDITS.items():
                trouve = re.search(motif, minuscule)
                if trouve:
                    anomalies.append(
                        f"vocabulaire · {fichier.relative_to(RACINE)}:{numero} "
                        f"→ « {trouve.group(0)} » ({raison})")


def controle_documents() -> None:
    dossier = RACINE / "legal"
    for cle in DOCUMENTS_ATTENDUS:
        fichier = dossier / f"{cle}.md"
        if not fichier.exists():
            anomalies.append(f"juridique · document manquant : legal/{cle}.md")
            continue
        contenu = fichier.read_text(encoding="utf-8")
        if len(contenu) < 500:
            anomalies.append(f"juridique · legal/{cle}.md trop court "
                             f"({len(contenu)} caractères)")
        if not re.match(r"Dernière mise à jour\s*:", contenu.strip()):
            anomalies.append(f"juridique · legal/{cle}.md doit commencer par "
                             f"« Dernière mise à jour : ... »")
        if "[À COMPLÉTER" in contenu:
            avertissements.append(f"juridique · legal/{cle}.md contient encore des "
                                  f"champs à compléter (identité, SIRET, médiateur)")

    # cohérence avec le module de rendu
    module = (RACINE / "web" / "legal.py").read_text(encoding="utf-8")
    for cle in DOCUMENTS_ATTENDUS:
        if f'"{cle}"' not in module:
            anomalies.append(f"juridique · {cle} absent de DOCUMENTS_LEGAUX "
                             f"dans web/legal.py")


def controle_clauses() -> None:
    for nom, motif, description in CLAUSES_OBLIGATOIRES:
        fichier = RACINE / "legal" / nom
        if not fichier.exists():
            continue
        if not re.search(motif, fichier.read_text(encoding="utf-8")):
            anomalies.append(f"clause · {nom} → {description} introuvable")


def controle_secrets() -> None:
    for fichier in RACINE.rglob("*"):
        if not fichier.is_file():
            continue
        relatif = fichier.relative_to(RACINE)
        if any(p in {".git", "__pycache__", "node_modules", ".venv"}
               for p in relatif.parts):
            continue
        if fichier.name in FICHIERS_EXEMPTS_SECRETS:
            continue
        if fichier.suffix not in {".py", ".json", ".md", ".html", ".js", ".txt",
                                  ".nix", ".toml", ".yml", ".yaml", ".env", ""}:
            continue
        try:
            contenu = fichier.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        for motif, raison in MOTIFS_SECRETS:
            if re.search(motif, contenu):
                anomalies.append(f"secret · {relatif} → {raison}")
    if (RACINE / ".env").exists():
        avertissements.append("secret · un fichier .env existe : vérifiez qu'il est "
                              "bien listé dans .gitignore et jamais publié")


def controle_isolation_cles() -> None:
    """Invariant d'architecture : seule la passerelle touche aux clés de subnet."""
    for fichier in RACINE.rglob("*.py"):
        relatif = fichier.relative_to(RACINE)
        if relatif.parts[0] in DOSSIERS_AUTORISES_CLES or "__pycache__" in relatif.parts:
            continue
        contenu = fichier.read_text(encoding="utf-8", errors="ignore")
        for cle in CLES_SUBNET:
            if cle in contenu:
                anomalies.append(
                    f"isolation · {relatif} référence {cle} alors que seule la "
                    f"passerelle doit détenir les clés de subnet")


def controle_demonstration() -> None:
    fichier = RACINE / "data" / "fiches_demonstration.json"
    if not fichier.exists():
        avertissements.append("données · aucune fiche de démonstration")
        return
    try:
        contenu = json.loads(fichier.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        anomalies.append(f"données · fiches_demonstration.json illisible : {e}")
        return
    for fiche in contenu.get("fiches", []):
        nom = fiche.get("nom", "?")
        if not fiche.get("demonstration"):
            anomalies.append(f"données · « {nom} » n'est pas marquée "
                             f"demonstration=true")
        if "fictif" not in nom.lower():
            avertissements.append(f"données · « {nom} » devrait porter la mention "
                                  f"« exemple fictif » dans son nom")


def controle_invariant_web() -> None:
    """La route /sante de l'application publique doit publier deux informations
    distinctes : l'invariant de code (aucune clé lue) et le fait mesuré (clés
    présentes ou non dans l'environnement du processus). Annoncer la seconde
    comme une certitude serait trompeur en hébergement mutualisé."""
    main = (RACINE / "web" / "main.py").read_text(encoding="utf-8")
    for champ in ("cles_subnet_lues_par_ce_service",
                  "cles_subnet_dans_environnement"):
        if champ not in main:
            anomalies.append(f"isolation · web/main.py doit exposer {champ} "
                             f"sur /sante")
    if "cles_subnet_dans_environnement()" not in main:
        anomalies.append("isolation · cles_subnet_dans_environnement doit être "
                         "mesuré (appel à common.isolation), pas codé en dur")


def controle_liens_legaux() -> None:
    """Le pied de page doit mener aux textes obligatoires."""
    base = RACINE / "templates" / "base.html"
    if not base.exists():
        anomalies.append("gabarit · templates/base.html manquant")
        return
    contenu = base.read_text(encoding="utf-8")
    # Le pied de page peut lister les documents un par un, ou itérer sur le
    # dictionnaire injecté dans tous les gabarits.
    dynamique = ("documents_legaux" in contenu
                 and "/legal/{{ cle }}" in contenu)
    if not dynamique:
        for cle in ["mentions-legales", "cgu", "confidentialite", "cookies"]:
            if cle not in contenu:
                anomalies.append(
                    f"gabarit · lien vers /legal/{cle} absent du pied de page")
    principal = (RACINE / "web" / "main.py").read_text(encoding="utf-8")
    if dynamique and "documents_legaux" not in principal:
        anomalies.append("gabarit · documents_legaux n'est pas injecté dans les "
                         "gabarits par web/main.py")


def controle_fournisseurs() -> None:
    """Aucun fournisseur déclaré sans tarif ni source vérifiable.

    C'est la contrepartie de la page de transparence : ce qu'elle affiche doit
    être adossé à une page publique du fournisseur, pas à un souvenir. Un
    fournisseur ajouté sans URL de source fait échouer le contrôle.
    """
    fichier = RACINE / "gateway" / "fournisseurs.py"
    if not fichier.exists():
        anomalies.append("fournisseurs · gateway/fournisseurs.py est absent")
        return

    import importlib.util
    import sys as _sys
    specification = importlib.util.spec_from_file_location("nv_fournisseurs", fichier)
    module = importlib.util.module_from_spec(specification)
    # Les dataclasses résolvent leur module via sys.modules : sans cet
    # enregistrement, l'import échoue avec une erreur incompréhensible.
    _sys.modules["nv_fournisseurs"] = module
    try:
        specification.loader.exec_module(module)   # type: ignore[union-attr]
    except Exception as e:
        anomalies.append(f"fournisseurs · registre illisible : {e}")
        return

    vus: set[str] = set()
    for besoin, chaine in module.BESOINS.items():
        if not chaine:
            anomalies.append(f"fournisseurs · aucun fournisseur déclaré pour « {besoin} »")
        for f in chaine:
            if f.cle in vus:
                anomalies.append(f"fournisseurs · identifiant en double : {f.cle}")
            vus.add(f.cle)
            if not f.source.startswith("http"):
                anomalies.append(f"fournisseurs · {f.cle} n'a pas d'URL de source "
                                 f"vérifiable pour son tarif ou ses conditions")
            if not f.tarif.strip():
                anomalies.append(f"fournisseurs · {f.cle} n'indique aucun tarif")
            if f.reseau not in {"bittensor", "classique"}:
                anomalies.append(f"fournisseurs · {f.cle} a un réseau inconnu : {f.reseau}")
            if f.entete not in {"bearer", "x-api-key", "authorization-brut"}:
                anomalies.append(f"fournisseurs · {f.cle} a un mode d'en-tête inconnu")

    for ecarte in module.ECARTES:
        if not ecarte.get("raison"):
            anomalies.append(f"fournisseurs · option écartée sans raison écrite : "
                             f"{ecarte.get('sujet')}")

    transparence = (RACINE / "legal" / "ia-transparence.md").read_text(encoding="utf-8")
    for f in module.INFERENCE + module.RECHERCHE + module.COLLECTE:
        if f.cle in module.HORS_PRODUCTION:
            continue
        nom_court = f.nom.split("—")[0].split("(")[0].strip()
        if nom_court and nom_court.lower() not in transparence.lower():
            avertissements.append(
                f"fournisseurs · {nom_court} n'est pas nommé dans "
                f"legal/ia-transparence.md")


def main() -> int:
    controle_vocabulaire()
    controle_fournisseurs()
    controle_documents()
    controle_clauses()
    controle_secrets()
    controle_isolation_cles()
    controle_demonstration()
    controle_invariant_web()
    controle_liens_legaux()

    print("=" * 68)
    print("NOVALUTH — contrôle de conformité")
    print("=" * 68)

    if avertissements:
        print(f"\n⚠️  {len(avertissements)} point(s) à surveiller :")
        for a in avertissements:
            print(f"   · {a}")

    if anomalies:
        print(f"\n❌ {len(anomalies)} anomalie(s) bloquante(s) :")
        for a in anomalies:
            print(f"   · {a}")
        print("\nCorrigez avant toute mise en ligne.")
        return 1

    print("\n✅ Aucune anomalie bloquante.")
    print(f"   · {len(DOCUMENTS_ATTENDUS)} documents juridiques présents et structurés")
    print("   · aucun vocabulaire de garantie ou de conseil")
    print("   · aucune clé de subnet hors de la passerelle")
    print("   · aucun secret en clair dans le dépôt")
    if avertissements:
        print("\nLes points à surveiller ci-dessus restent à traiter avant "
              "d'encaisser le premier paiement.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
