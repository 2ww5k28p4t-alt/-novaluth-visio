"""
NOVALUTH — Vérificateur d'installation
======================================

Contrôle que les secrets sont en place et cohérents, sans jamais afficher leur
valeur. À lancer dans le Shell du Repl, après avoir renseigné les Secrets :

    python -m tools.verifier_secrets

Le code de sortie vaut 0 si aucun point bloquant n'est détecté, 1 sinon — ce qui
permet de l'enchaîner avec le contrôle de conformité :

    python -m tools.verifier_secrets && python -m tools.verifier_conformite

Ce script ne consomme aucun appel de subnet : il interroge seulement la route
/sante de la passerelle, qui indique la présence d'une clé, jamais sa validité.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
PROD = os.environ.get("NOVALUTH_ENV", "dev") == "prod"
LARGEUR = 72

bloquants: list[str] = []
avertissements: list[str] = []


def ligne(etat: str, nom: str, detail: str = "") -> None:
    print(f"  {etat:<11} {nom:<26} {detail}")


def empreinte(valeur: str) -> str:
    """Résume un secret sans le divulguer : longueur et premiers caractères."""
    return f"{len(valeur)} caractères, commence par « {valeur[:3]}… »"


def controler(nom: str, *, requis: bool, longueur_min: int = 0,
             requis_en_prod: bool = False, aide: str = "") -> str:
    valeur = os.environ.get(nom, "")
    obligatoire = requis or (requis_en_prod and PROD)

    if not valeur:
        if obligatoire:
            ligne("MANQUANT", nom, aide)
            bloquants.append(f"{nom} absent — {aide}")
        else:
            ligne("absent", nom, "facultatif")
        return ""

    if longueur_min and len(valeur) < longueur_min:
        ligne("TROP COURT", nom, f"{len(valeur)} caractères, {longueur_min} attendus")
        bloquants.append(f"{nom} trop court ({len(valeur)} < {longueur_min})")
        return valeur

    ligne("présent", nom, empreinte(valeur))
    return valeur


def section(titre: str) -> None:
    print()
    print(f"  {titre}")
    print("  " + "─" * (LARGEUR - 4))


def main() -> int:
    print()
    print("═" * LARGEUR)
    print(" NOVALUTH — vérification de l'installation")
    print("═" * LARGEUR)
    print(f"  Environnement : {'prod' if PROD else 'dev'}"
          f"   (NOVALUTH_ENV={os.environ.get('NOVALUTH_ENV', 'dev')})")

    # ------------------------------------------------------------------ #
    section("Clés de subnet — détenues par la passerelle uniquement")
    chutes = controler("CHUTES_API_KEY", requis=False,
                       aide="sans elle, les résumés IA basculent sur le repli local")
    sn13 = controler("SN13_API_KEY", requis=False,
                     aide="sans elle, la collecte automatique reste inactive")
    controler("CHUTES_MODEL", requis=False)
    if not chutes:
        avertissements.append("CHUTES_API_KEY absente : le site fonctionne, "
                              "les résumés sont rédigés localement")
    if not sn13:
        avertissements.append("SN13_API_KEY absente : la collecte automatique "
                              "ne renverra aucune candidature")

    # ------------------------------------------------------------------ #
    section("Secrets internes")
    partage = controler("NOVALUTH_GATEWAY_SECRET", requis=True, longueur_min=32,
                        aide="signe les appels internes ; "
                             "python -m tools.generer_secrets")
    controler("NOVALUTH_APP_SECRET", requis=False, longueur_min=16,
              requis_en_prod=True,
              aide="obligatoire en prod, protège les formulaires")
    controler("NOVALUTH_ADMIN_TOKEN", requis=False, longueur_min=16,
              requis_en_prod=True,
              aide="obligatoire en prod, protège la page /admin")

    # ------------------------------------------------------------------ #
    section("Liaison site ↔ passerelle")
    url = os.environ.get("NOVALUTH_GATEWAY_URL", "")
    if not url:
        ligne("défaut", "NOVALUTH_GATEWAY_URL", "http://127.0.0.1:8100 (Repl unique)")
        url = "http://127.0.0.1:8100"
    elif url.startswith(("http://127.0.0.1", "http://localhost")):
        ligne("présent", "NOVALUTH_GATEWAY_URL", f"{url} — boucle locale")
    elif url.startswith("https://"):
        ligne("présent", "NOVALUTH_GATEWAY_URL", f"{url} — passerelle distante")
        avertissements.append(
            "La passerelle est joignable depuis Internet (URL en https). "
            "Dans un Repl unique, laissez http://127.0.0.1:8100 : la passerelle "
            "reste alors invisible de l'extérieur.")
    else:
        ligne("À REVOIR", "NOVALUTH_GATEWAY_URL", f"{url} — schéma inattendu")
        bloquants.append("NOVALUTH_GATEWAY_URL doit commencer par http:// ou https://")
    controler("NOVALUTH_CLIENT_NAME", requis=False)

    # ------------------------------------------------------------------ #
    section("Site public")
    controler("NOVALUTH_URL", requis=False, requis_en_prod=True,
              aide="adresse publique du site, utilisée dans les courriels et le plan")
    controler("NOVALUTH_DB", requis=False)
    controler("PORT", requis=False)

    # ------------------------------------------------------------------ #
    section("Supervision Telegram (facultative)")
    jeton = controler("TELEGRAM_BOT_TOKEN", requis=False)
    conv = controler("TELEGRAM_CHAT_ID", requis=False)
    if bool(jeton) != bool(conv):
        avertissements.append("TELEGRAM_BOT_TOKEN et TELEGRAM_CHAT_ID vont "
                              "ensemble : l'un sans l'autre reste sans effet")

    # ------------------------------------------------------------------ #
    section("Fichiers du projet")
    fichier_env = RACINE / ".env"
    if fichier_env.exists():
        contenu = fichier_env.read_text(encoding="utf-8", errors="replace")
        suspect = [l.split("=", 1)[0].strip() for l in contenu.splitlines()
                   if "=" in l and not l.lstrip().startswith("#")
                   and l.split("=", 1)[1].strip() not in {"", '""'}]
        if suspect:
            ligne("À REVOIR", ".env", f"{len(suspect)} valeur(s) renseignée(s)")
            bloquants.append(
                "Le fichier .env contient des valeurs : "
                f"{', '.join(suspect[:4])}. Ce fichier suit le Repl s'il est "
                "dupliqué. Déplacez ces valeurs dans les Secrets, puis "
                "supprimez le fichier : rm .env")
        else:
            ligne("présent", ".env", "aucune valeur renseignée")
    else:
        ligne("absent", ".env", "correct : tout passe par les Secrets")

    # ------------------------------------------------------------------ #
    section("Passerelle en fonctionnement")
    try:
        import httpx
        reponse = httpx.get(url.rstrip("/") + "/sante", timeout=4.0)
        donnees = reponse.json()
        presentes = donnees.get("cles_presentes", {})
        ligne("réponse", "GET /sante", f"code {reponse.status_code}")
        for cle, etiquette in (("chutes", "clé Chutes"),
                               ("sn13", "clé SN13"),
                               ("secret_interne", "secret interne")):
            vu = bool(presentes.get(cle))
            ligne("vue" if vu else "absente", etiquette,
                  "lue par la passerelle" if vu
                  else "non lue — redémarrez le Repl (Stop puis Run)")
        plafonds = donnees.get("plafonds", {})
        ligne("plafonds", "par jour",
              f"IA {plafonds.get('ia_par_jour', '?')} · "
              f"collecte {plafonds.get('collecte_par_jour', '?')}")
        if partage and not presentes.get("secret_interne"):
            bloquants.append(
                "Le secret interne est défini dans le Shell mais pas vu par la "
                "passerelle : redémarrez le Repl pour qu'elle le relise.")
    except Exception as e:
        ligne("injoignable", "GET /sante", f"{type(e).__name__}")
        avertissements.append(
            f"Passerelle injoignable sur {url}. Lancez d'abord « python run.py » "
            "dans un autre onglet du Shell, puis relancez cette vérification.")

    # ------------------------------------------------------------------ #
    print()
    print("═" * LARGEUR)
    if bloquants:
        print(f" {len(bloquants)} point(s) à corriger avant la mise en ligne :")
        for b in bloquants:
            print(f"   · {b}")
    else:
        print(" Aucun point bloquant détecté.")
    if avertissements:
        print()
        print(f" {len(avertissements)} remarque(s) :")
        for a in avertissements:
            print(f"   · {a}")
    print("═" * LARGEUR)
    print(" Cette vérification porte sur la présence et la forme des secrets.")
    print(" Elle ne teste pas la validité des clés auprès des fournisseurs.")
    print("═" * LARGEUR)
    print()
    return 1 if bloquants else 0


if __name__ == "__main__":
    sys.exit(main())
