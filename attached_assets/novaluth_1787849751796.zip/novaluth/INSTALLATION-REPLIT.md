# Installer Novaluth sur Replit depuis un iPhone

Guide unique, à suivre dans l'ordre. Comptez une trentaine de minutes la première
fois. Tout se fait depuis l'application Replit sur téléphone ; aucun ordinateur
n'est nécessaire.

Le principe à garder en tête : **un seul Repl, deux processus**. L'application
publique écoute sur le port exposé à Internet, la passerelle écoute sur
`127.0.0.1:8100` et détient seule les clés des subnets Bittensor. Personne ne
peut joindre la passerelle depuis l'extérieur, et une faille sur une page
publique ne donnerait accès à aucune clé.

---

## 1. Déposer le code

1. Ouvrez l'application Replit → **Create** → **Import** → **Upload a file**.
2. Envoyez `novaluth.zip`. Replit crée le Repl et décompresse l'archive.
3. Si vous partez d'une mise à jour, ouvrez le Shell du Repl existant et
   décompressez par-dessus :

```bash
unzip -o novaluth-maj-replit.zip && rm novaluth-maj-replit.zip
```

4. Vérifiez que les dépendances s'installent :

```bash
pip install -r requirements.txt
```

---

## 2. Fabriquer les secrets internes

Dans le Shell du Repl :

```bash
python -m tools.generer_secrets
```

La commande affiche trois lignes `Key` / `Value` prêtes à recopier. Gardez cet
onglet ouvert le temps de l'étape suivante ; les valeurs ne sont enregistrées
nulle part.

---

## 3. Renseigner les Secrets

Panneau latéral (les trois points ou le bouton **+**) → **Secrets**, l'icône
cadenas. Pour chaque entrée : **New secret**, le nom dans **Key**, la valeur dans
**Value**, puis **Add secret**.

| Key | Value | Rôle |
|---|---|---|
| `NOVALUTH_GATEWAY_SECRET` | valeur affichée à l'étape 2 | signe les appels internes |
| `NOVALUTH_APP_SECRET` | valeur affichée à l'étape 2 | protège les formulaires |
| `NOVALUTH_ADMIN_TOKEN` | valeur affichée à l'étape 2 | mot de passe de `/admin` |
| `CHUTES_API_KEY` | votre clé Chutes AI | accès au subnet 64 |
| `SN13_API_KEY` | votre clé Macrocosmos | accès au subnet 13 |
| `NOVALUTH_URL` | `https://novaluth.com` | adresse publique du site |
| `TELEGRAM_BOT_TOKEN` | facultatif | supervision |
| `TELEGRAM_CHAT_ID` | facultatif | supervision |

Trois règles, les mêmes à chaque fois :

- **Aucun guillemet, aucune espace** autour de la valeur. Replit enregistre la
  chaîne telle quelle, guillemets compris s'il y en a.
- **Jamais dans un fichier.** Ni `.env`, ni la section `[env]` de `.replit` :
  ces fichiers sont versionnés et suivent le Repl si quelqu'un le duplique.
- **Redémarrez après le dernier ajout** : **Stop** puis **Run**. Les variables
  d'environnement sont lues une seule fois, au démarrage du processus.

`NOVALUTH_ENV` reste sur `dev` dans l'éditeur — c'est ce qui permet au projet de
démarrer même si un secret manque. Vous le passerez à `prod` à l'étape 6,
uniquement du côté déploiement.

`NOVALUTH_GATEWAY_URL` n'est pas à définir : sans valeur, le site parle à la
passerelle en boucle locale, ce qui est exactement le comportement voulu.

---

## 4. Contrôler l'installation

Lancez le projet avec **Run**, attendez la ligne
`application publique 0.0.0.0:8000`, puis dans le Shell :

```bash
python -m tools.verifier_secrets
```

Le rapport indique, sans jamais afficher une valeur, ce qui est présent, ce qui
manque et ce que la passerelle a réellement chargé. Vous devez lire
`Aucun point bloquant détecté`, et dans la dernière section :

```
  vue         clé Chutes                 lue par la passerelle
  vue         clé SN13                   lue par la passerelle
  vue         secret interne             lue par la passerelle
```

Si une clé est marquée `non lue` alors que vous l'avez bien saisie, c'est le
redémarrage qui manque : **Stop**, puis **Run**.

Enchaînez avec le contrôle des mentions obligatoires :

```bash
python -m tools.verifier_conformite
```

---

## 5. Publier

Panneau latéral → **Deployments** → **Reserved VM** → **Set up your deployment**.

| Champ | Valeur |
|---|---|
| Machine | la plus petite proposée ; vous augmenterez si besoin |
| Type | **Web server** |
| Build command | `pip install -r requirements.txt` |
| Run command | `python run.py` |
| Port | `8000` |

Le choix de Reserved VM plutôt qu'Autoscale se justifie ici : Autoscale
s'endort quand personne ne visite le site, ce qui interrompt le bot Telegram et
les tâches de collecte. Une Reserved VM est une machine qui ne s'éteint pas, à
prix fixe.

---

## 6. Secrets du déploiement

C'est l'étape la plus souvent oubliée : **les secrets de l'éditeur ne sont pas
ceux du déploiement**. Ouvrez **Deployments → Configuration → Secrets** et
ajoutez-y les mêmes entrées qu'à l'étape 3, plus celle-ci :

| Key | Value |
|---|---|
| `NOVALUTH_ENV` | `prod` |

En mode `prod`, les cookies passent en `Secure`, les en-têtes de sécurité
stricts s'appliquent, `/admin` exige le jeton, et l'absence de
`NOVALUTH_APP_SECRET` ou de `NOVALUTH_ADMIN_TOKEN` empêche le démarrage — c'est
volontaire.

Après publication, ouvrez `https://<votre-app>.replit.app/sante`. Deux champs
méritent une lecture attentive :

- `cles_subnet_lues_par_ce_service` vaut toujours `false`. Aucune fonction du
  dossier `web/` ne lit une clé de subnet : les appels partent tous vers la
  passerelle, qui signe et transmet.
- `cles_subnet_dans_environnement` vaut `true` dans un Repl unique, et c'est
  normal : Replit injecte les secrets pour l'ensemble du Repl, donc les deux
  processus voient les mêmes variables. Ce champ mesure la réalité plutôt que de
  la supposer.

### Ce que l'architecture protège, et ce qu'elle ne protège pas

Elle protège contre le scénario le plus courant : une clé recopiée dans un
fichier, une clé renvoyée par erreur dans une réponse HTTP, une clé écrite dans
un journal, un appel de subnet déclenché directement par une page publique. Tous
les appels sont signés, plafonnés, journalisés, et les données personnelles sont
retirées avant tout envoi à un subnet.

Elle ne protège pas contre une exécution de code arbitraire dans le processus
web : sur une machine unique, un tel accès permettrait de lire l'environnement.
C'est la limite de l'hébergement partagé, et le seul point sur lequel un serveur
séparé apporterait un gain réel. La séparation en deux Repls ne le résout pas :
elle exposerait la passerelle à Internet, ce qui échange un risque contre un
autre. À traiter le jour où le volume ou la valeur des clés le justifie, en
déplaçant la passerelle sur une machine distincte.

En attendant, la mesure la plus utile reste à votre portée : des plafonds bas
(étape 9), et une rotation des clés chez le fournisseur si un doute apparaît.

---

## 7. Nom de domaine

**Deployments → Custom domain** → ajoutez `novaluth.com` et `www.novaluth.com`.
Replit affiche un enregistrement `A` et un `TXT` de vérification, à créer chez
votre registrar. La propagation DNS prend de quelques minutes à quelques heures.

Pensez ensuite à mettre `NOVALUTH_URL` à jour dans les secrets du déploiement,
puis à redéployer : cette valeur alimente le plan du site et les courriels.

---

## 8. Tâches programmées

Panneau **Deployments** → **Scheduled** → une tâche par ligne. Elles tournent
dans le même code, sans clé supplémentaire : la collecte passe par la passerelle.

| Fréquence | Commande |
|---|---|
| chaque jour à 6 h | `python -m pipeline.collecte luthiers` |
| chaque jour à 7 h | `python -m pipeline.collecte marques` |
| chaque lundi à 5 h | `python -m pipeline.collecte momentum` |
| chaque jour à 19 h | `python -m pipeline.collecte digest` |
| chaque jour à 8 h | `python -m web.taches` |

Aucune fiche collectée n'est publiée sans votre validation.

**`python -m web.taches` est indispensable dès que vous encaissez** : c'est cette
tâche qui annule les autorisations de paiement dont le musicien n'a pas répondu,
qui demande aux musiciens si leur projet est toujours d'actualité, qui retire des
listes les projets sans nouvelles, et qui accorde les crédits de relance. Sans
elle, une autorisation resterait suspendue jusqu'à son expiration bancaire.

Pour voir ce qu'elle ferait sans rien modifier&nbsp;:
`python -m web.taches --simulation`.

---

## 8 bis. Ouvrir l'espace atelier à un artisan

L'espace `/atelier` fonctionne sans mot de passe&nbsp;: l'artisan saisit son
adresse et reçoit un lien de connexion valable 30 minutes. Pour que cela
fonctionne, l'adresse doit être rattachée à sa fiche&nbsp;:

1. ouvrez `/admin` ;
2. carte «&nbsp;Adresse de contact d'un atelier&nbsp;» ;
3. choisissez la fiche, saisissez l'adresse **que l'artisan vous a
   communiquée**, validez.

Tant que `NOVALUTH_SMTP_HOTE` n'est pas renseigné, les messages ne partent pas
réellement&nbsp;: ils sont écrits dans `data/courriels/`. Vous pouvez les ouvrir
depuis l'onglet Files du Repl pour récupérer un lien et tester le circuit de bout
en bout.

---

## 8 ter. Passer du paiement simulé à Stripe

Tant que `NOVALUTH_PAIEMENT=simule`, aucun paiement réel n'a lieu&nbsp;: les
autorisations, encaissements et annulations sont enregistrés dans
`data/paiements_simules.jsonl`, ce qui permet de vérifier tout le déroulement.
L'espace atelier affiche alors clairement qu'il s'agit d'une démonstration.

Pour encaisser pour de vrai, deux secrets à changer, **aucune ligne de code** :

| Secret | Valeur |
|---|---|
| `NOVALUTH_PAIEMENT` | `stripe` |
| `STRIPE_SECRET_KEY` | votre clé secrète Stripe |

Redeployez, et les autorisations passent par Stripe en mode
`capture_method=manual` : l'argument est retenu à la demande d'accès, encaissé à
l'acceptation du musicien, annulé sinon. Avant cette bascule, vérifiez que votre
immatriculation est effective et que les CGV sont à jour&nbsp;: elles décrivent
déjà ce déroulement en deux temps.

---

## 9. Surveiller la consommation

Les plafonds journaliers par défaut sont volontairement bas : **200 appels IA**
et **20 collectes** par jour. Ils protègent votre budget de subnet autant que
vos clés, et se lisent dans le rapport de l'étape 4.

Pour les relever, ajoutez `PLAFOND_APPELS_IA_JOUR` et `PLAFOND_APPELS_SN13_JOUR`
dans les secrets, avec vos valeurs, une fois la consommation réelle mesurée.
Un `429` dans les journaux signifie simplement que le plafond du jour est
atteint : le site continue de fonctionner, avec des résumés rédigés localement.

---

## Si quelque chose ne va pas

| Ce que vous voyez | Ce qu'il faut faire |
|---|---|
| `NOVALUTH_GATEWAY_SECRET absent` alors qu'il est saisi | Stop puis Run : les secrets sont lus au démarrage |
| `401 Requête non signée` | le secret partagé diffère entre les deux processus ; un seul Repl suffit, ne le dupliquez pas |
| `403 horodatage` | plus de 120 secondes d'écart d'horloge ; redémarrez le Repl |
| `429` | plafond journalier atteint, voir l'étape 9 |
| « Service temporairement indisponible » sur les résumés | passerelle éteinte ; le site reste utilisable, ses résumés sont rédigés localement |
| L'application déployée démarre puis s'arrête | secrets du déploiement non renseignés (étape 6) |
| Le port n'est pas détecté au déploiement | vérifiez `[[ports]] localPort = 8000` dans `.replit` |

---

## Sauvegardes

`data/novaluth.db` contient les fiches, les briefs et les preuves de
consentement : téléchargez-le régulièrement depuis l'onglet Files. Le journal de
la passerelle (`gateway/audit_passerelle.db`) ne contient aucune donnée
personnelle, seulement des compteurs et des empreintes de requêtes.
