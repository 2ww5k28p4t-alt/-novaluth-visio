/* NOVALUTH — script client
   Aucune bibliothèque externe, aucun traceur, aucun cookie posé par ce fichier.
   Rôle : installer le service worker, activer la case de consentement liée au
   champ e-mail, et proposer la recherche instantanée depuis l'annuaire. */

(function () {
  'use strict';

  // --- PWA -----------------------------------------------------------------
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function () {
      navigator.serviceWorker.register('/sw.js').catch(function () {});
    });
  }

  // --- Consentement : e-mail inactif tant que la case n'est pas cochée ------
  var champEmail = document.getElementById('champ-email');
  var caseConsentement = document.getElementById('case-consentement');
  if (champEmail && caseConsentement) {
    var majEmail = function () {
      champEmail.disabled = !caseConsentement.checked;
      if (!caseConsentement.checked) champEmail.value = '';
    };
    caseConsentement.addEventListener('change', majEmail);
    majEmail();
  }

  // --- Filtre local de l'annuaire (aucune requête réseau) ------------------
  var recherche = document.getElementById('recherche-annuaire');
  if (recherche) {
    recherche.addEventListener('input', function () {
      var terme = recherche.value.trim().toLowerCase();
      document.querySelectorAll('[data-fiche]').forEach(function (carte) {
        var texte = carte.getAttribute('data-fiche').toLowerCase();
        carte.style.display = !terme || texte.indexOf(terme) !== -1 ? '' : 'none';
      });
    });
  }

  // --- Repliage des blocs techniques ---------------------------------------
  document.querySelectorAll('[data-replier]').forEach(function (bouton) {
    bouton.addEventListener('click', function () {
      var cible = document.getElementById(bouton.getAttribute('data-replier'));
      if (!cible) return;
      var ouvert = cible.hasAttribute('hidden') === false;
      if (ouvert) {
        cible.setAttribute('hidden', '');
        bouton.textContent = bouton.getAttribute('data-libelle-ferme') || 'Afficher le détail technique';
      } else {
        cible.removeAttribute('hidden');
        bouton.textContent = bouton.getAttribute('data-libelle-ouvert') || 'Masquer le détail technique';
      }
      bouton.setAttribute('aria-expanded', String(!ouvert));
    });
  });
})();
