# Mise à jour — installation et secrets sur Replit

Cette archive prépare le projet pour une mise en ligne sur **un seul Repl en
Reserved VM**, avec la passerelle en boucle locale. Elle ajoute deux outils de
Shell, un guide pas à pas, et corrige un point de sincérité sur la route
`/sante`.

## À faire dans le Repl

1. Ouvrez le Shell et décompressez l'archive par-dessus le projet :

```bash
unzip -o novaluth-maj-replit.zip && rm novaluth-maj-replit.zip
```

2. Fabriquez vos secrets internes :

```bash
python -m tools.generer_secrets
```

3. Recopiez-les dans **Secrets** (icône cadenas), ajoutez vos clés de subnet,
   puis **Stop** et **Run**.

4. Contrôlez :

```bash
python -m tools.verifier_secrets && python -m tools.verifier_conformite
```

5. Suivez [INSTALLATION-REPLIT.md](INSTALLATION-REPLIT.md) à partir de l'étape 5
   pour publier.

## Ce qui change

### Nouveaux fichiers

| Fichier | Rôle |
|---|---|
| `INSTALLATION-REPLIT.md` | guide complet en 9 étapes, depuis un téléphone |
| `tools/generer_secrets.py` | fabrique les trois secrets internes, affichés prêts à recopier |
| `tools/verifier_secrets.py` | contrôle présence, longueur et cohérence des secrets, sans afficher aucune valeur ; code de sortie 1 s'il reste un point bloquant |
| `common/isolation.py` | mesure si des clés de fournisseur sont visibles depuis un processus, sans nommer aucune clé |

### Configuration

- `.replit` : `deploymentTarget` passe de `cloudrun` à `gce`, soit une **Reserved
  VM** — machine toujours allumée. Autoscale s'endort après un quart d'heure sans
  visite, ce qui interrompt le bot Telegram et les tâches de collecte.
- `.replit` : commentaires ajoutés sur le port unique exposé et sur l'interdiction
  d'y écrire un secret.
- `run.py` : l'application publique démarre maintenant **avant** la passerelle,
  pour que Replit détecte le port 8000 comme port principal du déploiement.
- Plafonds journaliers par défaut abaissés : **200** appels IA au lieu de 1200,
  **20** collectes au lieu de 80. Vous les relèverez une fois la consommation
  réelle mesurée, via les secrets `PLAFOND_APPELS_IA_JOUR` et
  `PLAFOND_APPELS_SN13_JOUR`.

### Route /sante de l'application publique

Le champ `cles_bittensor_dans_ce_service` renvoyait `false` en dur. C'était une
affirmation, pas une mesure : dans un Repl unique, Replit injecte les secrets
pour l'ensemble du Repl, donc les deux processus voient les mêmes variables
d'environnement. Annoncer l'inverse aurait donné une fausse assurance.

Il est remplacé par deux champs :

| Champ | Nature |
|---|---|
| `cles_subnet_lues_par_ce_service` | toujours `false` — invariant de code, aucune fonction de `web/` ne lit une clé de fournisseur |
| `cles_subnet_dans_environnement` | mesuré à chaque appel — `true` dans un Repl unique, `false` si la passerelle tourne sur une machine distincte |

Le contrôle de conformité a été mis à jour en conséquence : il exige désormais
les deux champs, et refuse une valeur codée en dur pour le second.

### Documentation

- `DEPLOIEMENT.md` : renvoie vers le nouveau guide, et se présente comme la
  variante à deux Repls — utile si la passerelle doit servir plusieurs
  applications, mais elle expose la passerelle à Internet.
- `.env.example` : les marqueurs `[P]` / `[W]` / `[B]` ne concernent plus que la
  variante à deux Repls ; `NOVALUTH_GATEWAY_URL` est à laisser vide dans un Repl
  unique.
- `README.md` : nouvelle section d'installation et rappel des deux commandes de
  Shell.

## Contrôles effectués

- Les 7 pages publiques répondent `200`, aucune trace d'erreur au démarrage.
- `python -m tools.verifier_conformite` : aucune anomalie bloquante ; 4 points à
  surveiller, tous connus (identité de l'éditeur, SIRET, hébergeur, médiateur, à
  compléter dans `legal/`).
- `python -m tools.verifier_secrets` : testé sans aucun secret (1 point
  bloquant signalé), puis avec l'ensemble des secrets (aucun point bloquant),
  passerelle interrogée dans les deux cas.
- Ports vérifiés : `0.0.0.0:8000` pour le site, `127.0.0.1:8100` pour la
  passerelle.

## Limite à connaître

Sur une machine unique, un accès en exécution de code au processus web
permettrait de lire l'environnement, donc les clés. La séparation en deux Repls
ne corrige pas ce point : elle rendrait la passerelle joignable depuis Internet.
Le seul remède réel est une machine distincte pour la passerelle, à envisager
quand le volume ou la valeur des clés le justifiera. En attendant, les plafonds
bas et la rotation des clés chez le fournisseur restent les leviers utiles.
