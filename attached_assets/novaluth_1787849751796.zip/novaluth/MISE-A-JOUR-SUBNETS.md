# Mise à jour — les sous-réseaux retenus, et ce qui change

Date : 27/08/2026

Cette mise à jour remplace deux prestataires codés en dur par un **registre de
prestataires** avec chaînes de secours, ajoute la recherche et la lecture de
pages publiques, et publie tout cela sur une page consultable par n'importe qui.

Rien ne casse : le site fonctionne exactement comme avant si vous ne renseignez
aucune nouvelle clé.

---

## 1. Ce qu'il faut faire sur Replit — 5 minutes

### Étape 1 — déposer le dossier

Décompressez l'archive et déposez le dossier `novaluth` dans votre Repl, en
écrasant les fichiers existants. Aucun fichier n'est supprimé par la mise à jour.

### Étape 2 — ouvrir l'onglet Secrets

Dans Replit : icône **cadenas** dans la barre de gauche (onglet « Secrets »).

### Étape 3 — ajouter les clés, une par une

Une seule est indispensable, et vous l'avez déjà : `CHUTES_API_KEY`.
Les autres sont des **maillons de secours**. Ajoutez-les quand vous voulez.

| Nom du secret | À quoi il sert | Où l'obtenir | Indispensable ? |
|---|---|---|---|
| `CHUTES_API_KEY` | Écrire et extraire du texte | [chutes.ai](https://chutes.ai) | Oui |
| `DESEARCH_API_KEY` | Trouver l'adresse des pages d'ateliers | [desearch.ai](https://www.desearch.ai) | Recommandé |
| `SN13_API_KEY` | Relever des publications publiques | [macrocosmos.ai](https://macrocosmos.ai) | Facultatif |
| `APEX_API_KEY` | Secours texte + recherche | [macrocosmos.ai](https://macrocosmos.ai) | Facultatif |
| `MISTRAL_API_KEY` | Secours texte hors Bittensor | [console.mistral.ai](https://console.mistral.ai) | Facultatif |

Pour chacune : **Key** = le nom exact du tableau, **Value** = la clé copiée
depuis le site du fournisseur, puis **Add new secret**.

### Étape 4 — un point d'attention sur Chutes

Sur Chutes, les **abonnements** sont réservés à un usage personnel : leurs
conditions excluent les applications en production. Pour Novaluth, il faut
donc être en **paiement à l'usage** (« pay-as-you-go »), avec une carte
enregistrée. C'est écrit noir sur blanc dans leurs
[conditions d'utilisation](https://chutes.ai/terms).

### Étape 5 — relancer et vérifier

Appuyez sur **Run**, puis ouvrez ces deux adresses :

- `https://votre-site.repl.co/transparence` → la liste des prestataires, avec
  ceux marqués « actif ».
- `https://votre-site.repl.co/sante` → doit répondre `passerelle_ia:
  disponible`.

Si une clé manque, rien ne casse : le prestataire est simplement marqué
« déclaré, non configuré » et le suivant de la chaîne prend le relais.

---

## 2. Les sous-réseaux retenus, et pourquoi

Quatorze sous-réseaux ont été examinés le 27/08/2026. **Six d'entre eux avaient
changé de projet ou de propriétaire** depuis les listes qui circulent, et
57 sous-réseaux inactifs ont été privés d'émissions en juin 2026. Le numéro d'un
sous-réseau ne suffit donc pas à l'identifier durablement : c'est la raison pour
laquelle le code passe désormais par un registre nommé, avec une chaîne de
secours par besoin, plutôt que par un numéro écrit en dur.

### Écrire et extraire du texte

1. **Chutes, sous-réseau 64.** Le seul prêt pour la production : interface
   compatible OpenAI, paiement par carte, licence MIT, tarifs publiés allant de
   0,0245 $ / 0,0978 $ par million de jetons à 3 $ / 15 $ selon le modèle.
2. **Apex, sous-réseau 1** en secours. Deux pages officielles donnent deux
   tarifs différents et 4 mineurs seulement étaient actifs au relevé : utile
   comme filet, pas comme socle.
3. **Mistral AI**, hors Bittensor, en dernier recours. Facturation européenne,
   0,5 $ / 1,5 $ par million de jetons. Sa présence garantit que le service ne
   s'arrête pas si les deux premiers tombent en même temps.

### Trouver l'adresse d'une page d'atelier

1. **Desearch, sous-réseau 22.** Le seul à couvrir à la fois le web et les
   réseaux sociaux, 0,10 $ pour 100 recherches, licence MIT, 113 mineurs.
   **Réserve importante** : ses conditions interdisent de reproduire son
   contenu. Le code n'en retient donc **que des adresses de pages**, jamais du
   texte à republier.
2. **Apex** en secours, via son point d'accès de recherche web.

### Lire une page publique

1. **Notre propre serveur**, en premier. C'est nouveau, et c'est le point le
   plus important juridiquement : le fichier `gateway/moisson.py` refuse
   lui-même de lire une page quand `robots.txt` l'interdit, quand le site a
   déclaré une opposition à la fouille de données, ou quand le domaine est un
   réseau social. Une page par domaine et par heure, jamais plus.
2. **Desearch** en secours, pour les pages que notre serveur n'arrive pas à
   lire.

### Relever des publications publiques

**Data Universe, sous-réseau 13** (Macrocosmos), 0,10 $ pour 1 000 publications,
licence MIT, 240 mineurs. X et Reddit seulement.

### Ce qui a été écarté, et pourquoi

- **Les vecteurs sémantiques.** Aucun sous-réseau n'expose de service
  utilisable. La recherche de l'annuaire reste donc déterministe — un choix
  assumé : on peut expliquer chaque résultat.
- **Les images.** Le sous-réseau image a changé de mains, mais surtout : une
  photo sur une fiche d'artisan doit montrer un instrument qui existe.
- **Le sous-réseau 71 (Leadpoet)**, que vous aviez repéré. Aucune interface
  publique documentée, un seul mineur actif au relevé, et un objet étranger au
  projet : il livre des contacts commerciaux avec des signaux d'achat, quand
  Novaluth a besoin d'un catalogue relu par l'artisan.
- **Le sous-réseau 4 (Targon)** : page de tarifs cassée, 6 mineurs actifs.

---

## 3. Ce qui a changé dans le code

| Fichier | Ce qui change |
|---|---|
| `gateway/fournisseurs.py` | **Nouveau.** Le registre : un prestataire = un nom, un tarif, une source vérifiable, une licence, une réserve. Quatre chaînes de secours |
| `gateway/moisson.py` | **Nouveau.** Lecture de page respectueuse : robots.txt, opposition à la fouille, rythme, taille plafonnée, refus des réseaux sociaux |
| `gateway/main.py` | Réécrit autour du registre. Trois nouvelles routes : `/v1/recherche`, `/v1/page`, `/v1/etat` |
| `pipeline/decouverte.py` | **Nouveau.** Découverte d'ateliers par recherche puis lecture de leur site, sans passer par les réseaux sociaux |
| `common/passerelle_client.py` | Trois nouvelles fonctions côté site |
| `web/main.py` | Nouvelle page publique `/transparence` |
| `templates/transparence.html` | **Nouveau.** Une carte par prestataire, lisible sur téléphone |
| `legal/sources-donnees.md` | **Nouveau document.** D'où viennent les informations, comment une page est lue, vos droits |
| `legal/ia-transparence.md` | Section 4 réécrite : la chaîne complète, avec tarifs et sources |
| `tools/verifier_conformite.py` | Nouveau contrôle : aucun prestataire déclaré sans tarif ni source vérifiable |
| `web/legal.py` | Deux corrections d'affichage : date plus affichée en double, puces sur deux lignes recollées |
| `.env.example` | Les cinq clés documentées, avec l'adresse où les obtenir |

**Les clés restent enfermées dans la passerelle.** L'invariant est vérifié
automatiquement : le contrôle de conformité échoue si un fichier hors
`gateway/` mentionne une clé de sous-réseau.

---

## 4. Vérifier que tout va bien

Dans le Shell du Repl :

```
python -m tools.verifier_conformite
```

Attendu : `✅ Aucune anomalie bloquante` et `15 documents juridiques présents`.

Puis, pour voir l'état réel des chaînes :

```
curl http://127.0.0.1:8100/sante
```

Le champ `chaines_actives` liste, besoin par besoin, les prestataires
réellement configurés.
