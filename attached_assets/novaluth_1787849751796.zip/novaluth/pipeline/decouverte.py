"""
NOVALUTH — Découverte par les sites d'ateliers
===============================================

Le pipeline de collecte existant part des réseaux sociaux. Il a une limite
structurelle : un luthier qui ne publie pas sur X ou Reddit n'existe pas pour
lui. Or c'est le cas de la majorité des ateliers français, qui ont un site, une
page d'atelier, parfois seulement une fiche de chambre de métiers.

Ce pipeline-ci part de l'autre bout :

    recherche d'adresses  →  lecture de la page à la source  →  extraction  →
    fiche candidate en attente d'arbitrage humain  →  proposition à l'artisan

Trois règles tenues de bout en bout
-----------------------------------
1. **La recherche ne sert qu'à trouver des adresses.** Les conditions du
   fournisseur de recherche interdisent de reproduire son contenu ; le texte
   publié plus tard vient de la lecture directe de la page de l'atelier, pas de
   l'index d'un tiers.
2. **La lecture est refusable.** robots.txt et les oppositions à la fouille de
   données sont respectés par la passerelle, sans exception et sans
   contournement. Un refus est journalisé avec son motif, pas retenté.
3. **Rien n'est publié automatiquement.** Toute fiche produite ici arrive en
   statut « candidate ». Elle passe par un arbitrage humain, puis par l'artisan
   lui-même, qui reste la seule personne à pouvoir valider ce que sa fiche dit
   de son travail.

Commandes :
    python -m pipeline.decouverte france        # requêtes régionales
    python -m pipeline.decouverte annuaires     # écoles, associations, salons
    python -m pipeline.decouverte site <url>    # une seule adresse, à la main
"""

from __future__ import annotations

import datetime as dt
import sys
import time
import urllib.parse

from common.passerelle_client import (PasserelleIndisponible, demander_ia,
                                      demander_page, demander_recherche)
from web import store
from web.schemas import StatutFiche

from .collecte import (CONFIANCE_MINIMALE, est_geant, score_emergence,
                       slugifier, vers_fiche, SCHEMA_EXTRACTION)
from .telegram import envoyer_candidate, envoyer_message

# --------------------------------------------------------------------------- #
# 1. Ce qu'on cherche
# --------------------------------------------------------------------------- #
# Les requêtes sont volontairement géographiques plutôt que thématiques : un
# atelier se trouve par sa ville, pas par un mot-clé de tendance. La rotation
# évite de repayer chaque jour les mêmes recherches.

REGIONS = [
    "Auvergne-Rhône-Alpes", "Bourgogne-Franche-Comté", "Bretagne",
    "Centre-Val de Loire", "Corse", "Grand Est", "Hauts-de-France",
    "Île-de-France", "Normandie", "Nouvelle-Aquitaine", "Occitanie",
    "Pays de la Loire", "Provence-Alpes-Côte d'Azur",
]

GABARITS_REGION = [
    "atelier de lutherie guitare {region}",
    "luthier guitare sur mesure {region}",
    "fabricant de guitares artisanales {region}",
]

REQUETES_ANNUAIRES = [
    "annuaire luthiers guitare France association",
    "salon de lutherie guitare France exposants",
    "école de lutherie France anciens élèves atelier",
    "chambre de métiers luthier guitare artisan d'art",
    "atelier lutherie guitare basse électrique France portes ouvertes",
]

# Domaines qui ne sont pas des ateliers : marchands, forums, encyclopédies,
# plateformes. On ne perd pas une lecture payante dessus.
DOMAINES_IGNORES = (
    "wikipedia.org", "reverb.com", "thomann.de", "woodbrass.com", "amazon.",
    "ebay.", "leboncoin.fr", "youtube.com", "pinterest.", "facebook.com",
    "instagram.com", "linkedin.com", "x.com", "twitter.com", "tiktok.com",
    "pagesjaunes.fr", "societe.com", "verif.com", "infogreffe.fr",
    "guitariste.com", "audiofanzine.com", "reddit.com", "quora.com",
)

PAGES_MAX_PAR_PASSAGE = 12
RECHERCHES_MAX_PAR_PASSAGE = 3


SYSTEME_SITE = """Tu lis le site d'un atelier de lutherie et tu en extrais des
informations FACTUELLES pour un annuaire.

Règles strictes :
- N'extrais que ce que la page dit. N'invente aucun prix, aucun délai, aucune
  année, aucune ville. Champ absent = champ vide.
- « luthier » = artisan ou petit atelier qui travaille à la commande.
- Si la page est une boutique de revente, un forum, un blog ou un média, réponds
  pertinent = false.
- Les prix relevés sur un site changent : ne les extrais que s'ils sont écrits
  noir sur blanc, et cite la phrase dans citation.
# conformite:debut-liste-proscrite
- resume_simple : deux phrases factuelles en français, sans superlatif, sans les
  mots garanti, certifié, meilleur, idéal, parfait, recommandé.
# conformite:fin-liste-proscrite
"""


# --------------------------------------------------------------------------- #
# 2. Tri des adresses
# --------------------------------------------------------------------------- #

def adresse_utile(url: str) -> bool:
    """Écarte ce qui n'est manifestement pas le site d'un atelier."""
    minuscule = url.lower()
    if not minuscule.startswith("http"):
        return False
    return not any(ignore in minuscule for ignore in DOMAINES_IGNORES)


def domaine(url: str) -> str:
    return urllib.parse.urlparse(url).netloc.lower().removeprefix("www.")


def deja_connue(url: str) -> bool:
    """Vrai si un domaine identique figure déjà dans les sources d'une fiche.

    On compare le domaine, pas l'adresse exacte : la page « contact » et la page
    « à propos » d'un même atelier ne doivent pas produire deux fiches.
    """
    cible = domaine(url)
    if not cible:
        return False
    with store.connexion() as conn:
        lignes = conn.execute(
            "SELECT site_web, source_donnees FROM fiches").fetchall()
    for ligne in lignes:
        site = (ligne["site_web"] or "")
        if site and domaine(site) == cible:
            return True
        if cible in (ligne["source_donnees"] or ""):
            return True
    return False


# --------------------------------------------------------------------------- #
# 3. Un site → une fiche candidate
# --------------------------------------------------------------------------- #

def traiter_page(url: str, *, alerter: bool = True) -> str:
    """Lit une page et en tire une fiche candidate.

    Retourne un mot d'état lisible dans le journal : "refusée", "hors-sujet",
    "doublon", "faible", "trop-etablie" ou le slug de la fiche créée.
    """
    try:
        page = demander_page(url)
    except PasserelleIndisponible as e:
        print(f"[decouverte] passerelle : {e}")
        return "passerelle-indisponible"

    if not page.get("lue"):
        motif = page.get("motif", "motif non précisé")
        print(f"[decouverte] refus  {url} — {motif}")
        store.journaliser("lecture_refusee", url, str(motif)[:200])
        return "refusée"

    texte = str(page.get("texte") or "")
    if len(texte) < 300:
        return "page-trop-courte"

    entete = f"Adresse de la page : {page.get('url_finale') or url}\n" \
             f"Titre : {page.get('titre') or '(sans titre)'}\n\n"
    try:
        reponse = demander_ia(SYSTEME_SITE, entete + texte[:9000],
                              outil=SCHEMA_EXTRACTION, temperature=0.1,
                              max_tokens=1300)
    except PasserelleIndisponible as e:
        print(f"[decouverte] passerelle : {e}")
        return "passerelle-indisponible"

    donnees = reponse.get("arguments") or {}
    if not donnees.get("pertinent") or not donnees.get("nom"):
        return "hors-sujet"
    if int(donnees.get("confiance") or 0) < CONFIANCE_MINIMALE:
        return "faible"
    if donnees.get("type_entite") not in ("luthier", "marque_emergente"):
        return "hors-sujet"

    # Le site lu fait autorité sur l'adresse : on la fixe ici plutôt que de
    # laisser le modèle recopier une URL vue dans le texte.
    donnees["site_web"] = page.get("url_finale") or url

    if est_geant(donnees["nom"]):
        return "trop-etablie"

    slug = slugifier(donnees["nom"])
    if store.lire_fiche(slug):
        return "doublon"

    fiche = vers_fiche(donnees, donnees["site_web"], StatutFiche.candidate)
    score = score_emergence(donnees)
    store.enregistrer_fiche(fiche, emergence=score)
    store.ajouter_mention(fiche.slug, "site", donnees["site_web"])
    store.journaliser("fiche_decouverte_site", fiche.slug, donnees["site_web"])
    if alerter:
        envoyer_candidate(fiche, score, donnees["site_web"], "site d'atelier")
    return fiche.slug


# --------------------------------------------------------------------------- #
# 4. Les passages
# --------------------------------------------------------------------------- #

def _passage(requetes: list[str], etiquette: str) -> None:
    store.initialiser()
    adresses: list[str] = []
    vues: set[str] = set()

    for requete in requetes[:RECHERCHES_MAX_PAR_PASSAGE]:
        try:
            resultats = demander_recherche(requete, limite=15)
        except PasserelleIndisponible as e:
            envoyer_message(f"⚠️ Découverte {etiquette} impossible : {e}")
            return
        print(f"[decouverte] « {requete} » → {len(resultats)} adresses")
        for resultat in resultats:
            url = resultat.get("url", "")
            if not adresse_utile(url):
                continue
            racine = domaine(url)
            if racine in vues:
                continue
            vues.add(racine)
            if deja_connue(url):
                continue
            adresses.append(url)
        time.sleep(0.5)

    adresses = adresses[:PAGES_MAX_PAR_PASSAGE]
    print(f"[decouverte] {len(adresses)} pages à lire")

    comptes: dict[str, int] = {}
    nouvelles = 0
    for url in adresses:
        etat = traiter_page(url)
        comptes[etat] = comptes.get(etat, 0) + 1
        if etat not in {"refusée", "hors-sujet", "doublon", "faible",
                        "trop-etablie", "page-trop-courte",
                        "passerelle-indisponible"}:
            nouvelles += 1
        time.sleep(1.0)

    detail = " · ".join(f"{etat} : {n}" for etat, n in sorted(comptes.items()))
    envoyer_message(
        f"🔎 Novaluth — découverte {etiquette}\n"
        f"{len(adresses)} pages lues · {nouvelles} fiche(s) en attente "
        f"d'arbitrage\n{detail or 'aucun résultat'}"
    )


def france() -> None:
    """Une région et un gabarit par jour, en rotation. Trois recherches, pas plus."""
    jour = dt.date.today().toordinal()
    region = REGIONS[jour % len(REGIONS)]
    requetes = [gabarit.format(region=region) for gabarit in GABARITS_REGION]
    _passage(requetes, f"France — {region}")


def annuaires() -> None:
    """Écoles, associations, salons : les endroits où les ateliers se listent
    eux-mêmes. Sources plus fiables qu'une recherche générique."""
    jour = dt.date.today().toordinal()
    depart = (jour * RECHERCHES_MAX_PAR_PASSAGE) % len(REQUETES_ANNUAIRES)
    rotation = (REQUETES_ANNUAIRES + REQUETES_ANNUAIRES)[
        depart:depart + RECHERCHES_MAX_PAR_PASSAGE]
    _passage(rotation, "annuaires et écoles")


def site(url: str) -> None:
    """Une adresse donnée à la main, pour vérifier le circuit ou ajouter un
    atelier repéré autrement."""
    store.initialiser()
    etat = traiter_page(url, alerter=True)
    print(f"[decouverte] {url} → {etat}")


JOBS = {"france": france, "annuaires": annuaires}

if __name__ == "__main__":
    nom_job = sys.argv[1] if len(sys.argv) > 1 else "france"
    if nom_job == "site":
        if len(sys.argv) < 3:
            print("Usage : python -m pipeline.decouverte site <url>")
            sys.exit(1)
        site(sys.argv[2])
    elif nom_job in JOBS:
        JOBS[nom_job]()
    else:
        print(f"Jobs disponibles : {', '.join(JOBS)}, site <url>")
        sys.exit(1)
