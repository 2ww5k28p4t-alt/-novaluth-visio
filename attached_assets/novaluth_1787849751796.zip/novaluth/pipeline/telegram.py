"""
NOVALUTH — Bot Telegram de supervision
======================================

Deux usages :

1. Notifications sortantes (`envoyer_message`, `envoyer_candidate`) appelées par
   le pipeline. Silencieux si TELEGRAM_BOT_TOKEN n'est pas défini.
2. Boucle d'arbitrage (`python -m pipeline.telegram`) : réception des clics sur
   les boutons pour publier, suivre, écarter ou rejeter une fiche candidate
   depuis le téléphone.

Aucune clé de subnet n'est utilisée ici.
"""

from __future__ import annotations

import html
import os
import time

import httpx

from web import store
from web.schemas import Fiche, StatutFiche

JETON = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
SALON = os.environ.get("TELEGRAM_CHAT_ID", "").strip()
BASE = f"https://api.telegram.org/bot{JETON}" if JETON else ""

ACTIONS = {
    "pub": (StatutFiche.publiee, "✅ Publiée"),
    "suiv": (StatutFiche.a_suivre, "🌱 À suivre"),
    "etab": (StatutFiche.trop_etablie, "🏭 Trop établie"),
    "rej": (StatutFiche.rejetee, "❌ Rejetée"),
}


def actif() -> bool:
    return bool(JETON and SALON)


def _appeler(methode: str, charge: dict) -> dict | None:
    if not BASE:
        return None
    try:
        reponse = httpx.post(f"{BASE}/{methode}", json=charge, timeout=25)
        if reponse.status_code >= 400:
            print(f"[telegram] {methode} → {reponse.status_code}")
            return None
        return reponse.json()
    except httpx.HTTPError as e:
        print(f"[telegram] réseau : {type(e).__name__}")
        return None


def envoyer_message(texte: str, clavier: list | None = None) -> None:
    if not actif():
        print(f"[telegram inactif] {texte}")
        return
    charge = {"chat_id": SALON, "text": texte[:4000],
              "parse_mode": "HTML", "disable_web_page_preview": True}
    if clavier:
        charge["reply_markup"] = {"inline_keyboard": clavier}
    _appeler("sendMessage", charge)


def envoyer_candidate(fiche: Fiche, score: int, url_source: str,
                      cible: str = "") -> None:
    """Fiche candidate soumise à l'arbitrage humain. Rien n'est publié sans clic."""
    e = html.escape
    lieu = " · ".join(x for x in [fiche.ville, fiche.pays] if x)
    prix = ("—" if not fiche.prix_min_eur
            else f"{fiche.prix_min_eur}–{fiche.prix_max_eur or fiche.prix_min_eur} €")
    marqueurs = ", ".join(fiche.innovation.marqueurs) or "—"
    texte = (
        f"🎸 <b>{e(fiche.nom)}</b>\n"
        f"<i>{e(fiche.type.value)}{' · ' + e(cible) if cible else ''}</i>\n\n"
        f"Émergence : <b>{score}/100</b> · Innovation : "
        f"{fiche.score_innovation or '—'}/10\n"
        f"Lieu : {e(lieu) or '—'}\n"
        f"Création : {fiche.annee_creation or '—'} · Production : "
        f"{fiche.production_annuelle or '—'}/an\n"
        f"Prix : {prix} · Délai : {fiche.delai_moyen_mois or '—'} mois\n"
        f"Signes distinctifs : {e(marqueurs)}\n"
        f"Site : {e(fiche.site_web or '—')}\n\n"
        f"{e(fiche.ia.resume_ia or '')}\n\n"
        f"<a href=\"{e(url_source)}\">publication d'origine</a>\n"
        f"<i>Fiche construite à partir de sources publiques, non encore relue "
        f"par l'artisan.</i>"
    )
    clavier = [
        [{"text": "✅ Publier", "callback_data": f"pub:{fiche.slug}"},
         {"text": "🌱 À suivre", "callback_data": f"suiv:{fiche.slug}"}],
        [{"text": "🏭 Trop établie", "callback_data": f"etab:{fiche.slug}"},
         {"text": "❌ Rejeter", "callback_data": f"rej:{fiche.slug}"}],
    ]
    envoyer_message(texte, clavier)


# --------------------------------------------------------------------------- #
# Boucle d'arbitrage
# --------------------------------------------------------------------------- #

def _repondre_clic(identifiant: str, texte: str) -> None:
    _appeler("answerCallbackQuery", {"callback_query_id": identifiant,
                                     "text": texte})


def _traiter(clic: dict) -> None:
    donnees = clic.get("data") or ""
    if ":" not in donnees:
        return
    code, slug = donnees.split(":", 1)
    if code not in ACTIONS:
        return
    statut, libelle = ACTIONS[code]
    fiche = store.lire_fiche(slug)
    if not fiche:
        _repondre_clic(clic["id"], "Fiche introuvable")
        return
    store.changer_statut(slug, statut.value)
    _repondre_clic(clic["id"], f"{fiche.nom} → {libelle}")
    message = clic.get("message") or {}
    if message.get("message_id"):
        _appeler("editMessageReplyMarkup", {
            "chat_id": message["chat"]["id"],
            "message_id": message["message_id"],
            "reply_markup": {"inline_keyboard": [[{
                "text": f"{libelle} — arbitré", "callback_data": "vu"}]]},
        })


def _traiter_commande(message: dict) -> None:
    texte = (message.get("text") or "").strip().lower()
    if texte in {"/etat", "/état", "/status"}:
        compteurs = store.compter_par_statut()
        lignes = "\n".join(f"· {s} : {n}" for s, n in sorted(compteurs.items()))
        envoyer_message(f"📊 État de la base\n{lignes or 'base vide'}")
    elif texte in {"/attente", "/candidates"}:
        candidates = store.lister_fiches([StatutFiche.candidate.value,
                                          StatutFiche.a_verifier.value], limite=10)
        if not candidates:
            envoyer_message("Aucune fiche en attente d'arbitrage.")
            return
        for fiche in candidates:
            envoyer_candidate(fiche, 0, (fiche.source_donnees or [""])[0])
    elif texte == "/aide":
        envoyer_message("Commandes : /etat · /attente · /aide")


def boucle() -> None:
    if not actif():
        print("TELEGRAM_BOT_TOKEN et TELEGRAM_CHAT_ID requis pour le bot.")
        return
    store.initialiser()
    print("[telegram] bot d'arbitrage démarré")
    dernier = 0
    while True:
        reponse = _appeler("getUpdates", {"offset": dernier + 1, "timeout": 50})
        if not reponse or not reponse.get("ok"):
            time.sleep(5)
            continue
        for maj in reponse.get("result", []):
            dernier = maj["update_id"]
            if "callback_query" in maj:
                _traiter(maj["callback_query"])
            elif "message" in maj:
                _traiter_commande(maj["message"])


if __name__ == "__main__":
    boucle()
