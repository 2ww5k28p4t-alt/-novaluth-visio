"""
NOVALUTH — Pipeline nocturne de découverte
==========================================

Chaîne : subnet 13 (publications publiques) → subnet 64 (structuration) →
score d'émergence → filtre anti-géant → base → digest Telegram.

Point capital : ce script **ne connaît aucune clé de subnet**. Il passe par la
passerelle (gateway/) qui les détient. Il n'a besoin que de
NOVALUTH_GATEWAY_URL, NOVALUTH_GATEWAY_SECRET et des identifiants Telegram.

Commandes :
    python -m pipeline.collecte luthiers    # ateliers individuels
    python -m pipeline.collecte marques     # marques émergentes
    python -m pipeline.collecte momentum    # radar de buzz sur les fiches connues
    python -m pipeline.collecte digest      # résumé du soir + purge RGPD
"""

from __future__ import annotations

import datetime as dt
import os
import re
import sys
import time

from common.passerelle_client import (PasserelleIndisponible, demander_collecte,
                                      demander_ia)
from web import store
from web.schemas import (Fiche, Innovation, Logistique, MetadonneesIA, Modele,
                         ProfilSonore, StatutFiche, TypeEntite)

from .telegram import envoyer_candidate, envoyer_message

# --------------------------------------------------------------------------- #
# 1. Ciblage
# --------------------------------------------------------------------------- #

MOTS_LUTHIERS = [
    "luthier", "custom guitar build", "boutique guitar builder",
    "handmade guitar", "guitar commission build", "atelier de lutherie",
]
MOTS_LANCEMENT = [
    "new guitar brand", "guitar startup", "our first guitar",
    "launching our guitars", "small batch guitars", "boutique guitar company",
    "nouvelle marque de guitare",
]
MOTS_INNOVATION = [
    "headless guitar", "multiscale guitar", "fanned fret guitar",
    "carbon fiber guitar", "aluminium neck guitar", "3d printed guitar",
    "modular guitar", "sustainable tonewood", "hemp composite guitar",
    "bamboo guitar body", "travel guitar brand",
]

# Rotation quotidienne : on ne brûle pas le quota de la clé SN13.
ROTATION_LUTHIERS = [
    ("x", MOTS_LUTHIERS[:3]),
    ("reddit", MOTS_LUTHIERS[3:]),
    ("x", MOTS_INNOVATION[:4]),
    ("reddit", MOTS_INNOVATION[4:8]),
]
ROTATION_MARQUES = [
    ("x", MOTS_LANCEMENT[:4]),
    ("reddit", MOTS_LANCEMENT[4:]),
    ("x", MOTS_INNOVATION[4:8]),
    ("reddit", MOTS_INNOVATION[8:]),
]

# --------------------------------------------------------------------------- #
# 2. Filtre anti-géant — le positionnement Novaluth, appliqué mécaniquement
# --------------------------------------------------------------------------- #

GEANTS = {
    "fender", "gibson", "squier", "epiphone", "ibanez", "prs", "paul reed smith",
    "yamaha", "esp", "ltd", "jackson", "charvel", "schecter", "cort", "gretsch",
    "martin", "taylor", "rickenbacker", "music man", "sterling", "harley benton",
    "eastman", "washburn", "peavey", "dean", "bc rich", "kramer", "godin",
    "takamine", "seagull", "guild", "duesenberg", "reverend", "chapman",
    "solar", "kiesel", "strandberg", "mayones", "aristides", "ormsby",
}
ANNEE_MAX_EMERGENTE = 2014
PRODUCTION_MAX = 800
CONFIANCE_MINIMALE = 45
SCORE_MINIMAL_ALERTE = 35


def est_geant(nom: str) -> bool:
    n = re.sub(r"[^a-z ]", "", (nom or "").lower()).strip()
    return any(g == n or g in n.split() or n.startswith(g + " ") for g in GEANTS)


def slugifier(nom: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", (nom or "").lower()).strip("-")


# --------------------------------------------------------------------------- #
# 3. Extraction structurée (function calling côté passerelle)
# --------------------------------------------------------------------------- #

SCHEMA_EXTRACTION = {
    "name": "extraire_fiche",
    "description": "Extrait un luthier ou une marque de guitare depuis une "
                   "publication publique.",
    "parameters": {
        "type": "object",
        "properties": {
            "pertinent": {"type": "boolean"},
            "type_entite": {"type": "string",
                            "enum": ["luthier", "marque_emergente",
                                     "marque_etablie", "revendeur", "autre"]},
            "nom": {"type": "string"},
            "pays": {"type": "string"},
            "ville": {"type": "string"},
            "site_web": {"type": "string"},
            "instagram": {"type": "string"},
            "annee_creation": {"type": "integer"},
            "production_annuelle": {"type": "integer"},
            "types_instruments": {"type": "array", "items": {"type": "string"}},
            "modeles": {"type": "array", "items": {"type": "string"}},
            "prix_min_eur": {"type": "integer"},
            "prix_max_eur": {"type": "integer"},
            "delai_moyen_mois": {"type": "integer"},
            "bois": {"type": "array", "items": {"type": "string"}},
            "micros": {"type": "array", "items": {"type": "string"}},
            "styles": {"type": "array", "items": {"type": "string"}},
            "marqueurs_innovation": {"type": "array", "items": {"type": "string"},
                                     "description": "headless, multiscale, carbone, "
                                                    "impression 3D, matériau alternatif, "
                                                    "technologie propre à l'atelier"},
            "demarche_ecologique": {"type": "string"},
            "vend_en_direct": {"type": "boolean"},
            "score_innovation": {"type": "integer", "description": "0 à 10"},
            "score_originalite": {"type": "integer", "description": "0 à 10"},
            "confiance": {"type": "integer", "description": "0 à 100"},
            "citation": {"type": "string", "description": "extrait court justifiant "
                                                          "l'extraction"},
            "resume_simple": {"type": "string",
                              "description": "deux phrases en français simple, "
                                             "factuelles, sans superlatif"},
        },
        "required": ["pertinent", "type_entite", "confiance"],
    },
}

SYSTEME_EXTRACTION = """Tu analyses des publications publiques (X, Reddit) pour un
annuaire spécialisé dans les LUTHIERS INNOVANTS et les MARQUES DE GUITARE
ÉMERGENTES.

Règles strictes :
- « luthier » = artisan ou petit atelier travaillant à la commande.
- « marque_emergente » = entreprise récente avec des modèles nommés.
- « marque_etablie » = Fender, Gibson, Ibanez, PRS, Strandberg, Kiesel, Mayones
  et toute marque à distribution mondiale installée.
- N'invente jamais un site, un pays, une année, un prix ou un délai. Laisse le
  champ vide si l'information est absente de la publication.
- score_innovation élevé seulement si un élément technique sort réellement des
  sentiers battus (forme, matériau, électronique, ergonomie, procédé).
- confiance basse si la publication est vague, ironique, ou promotionnelle sans
  substance.
# conformite:debut-liste-proscrite
- resume_simple : factuel, sans superlatif, sans les mots garanti, certifié,
  meilleur, idéal, parfait, recommandé.
# conformite:fin-liste-proscrite
"""


def extraire(texte: str) -> dict | None:
    try:
        reponse = demander_ia(SYSTEME_EXTRACTION, texte[:4000],
                              outil=SCHEMA_EXTRACTION, temperature=0.1,
                              max_tokens=1200)
    except PasserelleIndisponible as e:
        print(f"[passerelle] {e}")
        return None
    return reponse.get("arguments")


# --------------------------------------------------------------------------- #
# 4. Score d'émergence
# --------------------------------------------------------------------------- #

def score_emergence(donnees: dict, mentions_7j: int = 0) -> int:
    """0-100. Récompense la nouveauté, l'innovation et le buzz naissant ;
    pénalise la taille et la distribution déjà installée."""
    score = 0
    annee = donnees.get("annee_creation") or 0
    if annee >= 2022:
        score += 25
    elif annee >= 2018:
        score += 18
    elif annee >= ANNEE_MAX_EMERGENTE:
        score += 10

    production = donnees.get("production_annuelle") or 0
    if 0 < production <= 100:
        score += 20
    elif production <= 400:
        score += 14
    elif production <= PRODUCTION_MAX:
        score += 7

    score += min(20, 5 * len(donnees.get("marqueurs_innovation") or []))
    score += min(15, int(donnees.get("score_innovation") or 0)
                 + int(donnees.get("score_originalite") or 0))
    if donnees.get("demarche_ecologique"):
        score += 5
    if donnees.get("vend_en_direct"):
        score += 5
    score += min(10, mentions_7j * 2)
    return max(0, min(100, score))


# --------------------------------------------------------------------------- #
# 5. Conversion en fiche du schéma des 7 blocs
# --------------------------------------------------------------------------- #

def vers_fiche(donnees: dict, url_source: str, statut: StatutFiche) -> Fiche:
    modeles = [
        Modele(nom=nom, type="electrique",
               personnalisable=donnees.get("type_entite") == "luthier")
        for nom in (donnees.get("modeles") or [])[:6] if nom
    ]
    if not modeles and donnees.get("types_instruments"):
        modeles = [Modele(nom="Modèle non nommé",
                          type=("basse" if "bass" in " ".join(
                              donnees["types_instruments"]).lower() else "electrique"))]

    return Fiche(
        slug=slugifier(donnees.get("nom") or "sans-nom"),
        nom=(donnees.get("nom") or "Sans nom").strip()[:120],
        type=(TypeEntite.marque_emergente
              if donnees.get("type_entite") == "marque_emergente"
              else TypeEntite.luthier),
        annee_creation=donnees.get("annee_creation") or None,
        pays=(donnees.get("pays") or None),
        ville=(donnees.get("ville") or None),
        site_web=(donnees.get("site_web") or None),
        reseaux={"instagram": donnees["instagram"]} if donnees.get("instagram") else {},
        delai_moyen_mois=donnees.get("delai_moyen_mois") or None,
        prix_min_eur=donnees.get("prix_min_eur") or None,
        prix_max_eur=donnees.get("prix_max_eur") or None,
        production_annuelle=donnees.get("production_annuelle") or None,
        score_innovation=donnees.get("score_innovation") or None,
        score_originalite=donnees.get("score_originalite") or None,
        modeles=modeles,
        profil_sonore=ProfilSonore(styles=(donnees.get("styles") or [])[:8]),
        logistique=Logistique(),
        innovation=Innovation(
            niveau=donnees.get("score_innovation") or None,
            materiaux_alternatifs=(donnees.get("bois") or [])[:6],
            demarche_ecologique=(donnees.get("demarche_ecologique") or None),
            marqueurs=(donnees.get("marqueurs_innovation") or [])[:6],
        ),
        ia=MetadonneesIA(
            resume_ia=(donnees.get("resume_simple") or None),
            modele_utilise=os.environ.get("CHUTES_MODEL", "subnet 64"),
            genere_le=store.maintenant(),
            mots_cles=(donnees.get("styles") or [])[:8],
        ),
        statut=statut,
        source_donnees=[url_source] if url_source else [],
        valide_par_artisan=False,
        demonstration=False,
    )


# --------------------------------------------------------------------------- #
# 6. Les jobs
# --------------------------------------------------------------------------- #

def _decouvrir(rotation, cible: str) -> None:
    store.initialiser()
    source, mots = rotation[dt.date.today().toordinal() % len(rotation)]
    print(f"[collecte] {cible} — source {source}, mots : {mots}")

    try:
        publications = demander_collecte(source, mots, jours=3, limite=400)
    except PasserelleIndisponible as e:
        envoyer_message(f"⚠️ Collecte {cible} impossible : {e}")
        return

    vues = retenues = 0
    for publication in publications:
        texte = publication.get("content") or publication.get("text") or ""
        url = publication.get("url") or publication.get("uri") or ""
        if len(texte) < 40:
            continue
        vues += 1

        donnees = extraire(texte)
        if not donnees or not donnees.get("pertinent"):
            continue
        if int(donnees.get("confiance") or 0) < CONFIANCE_MINIMALE:
            continue
        if not donnees.get("nom"):
            continue

        type_attendu = "marque_emergente" if cible == "marques" else "luthier"
        if donnees.get("type_entite") != type_attendu:
            continue

        trop_grande = (
            est_geant(donnees["nom"])
            or (donnees.get("annee_creation") or 9999) < ANNEE_MAX_EMERGENTE
            or (donnees.get("production_annuelle") or 0) > PRODUCTION_MAX
        )
        statut = StatutFiche.trop_etablie if trop_grande else StatutFiche.candidate
        score = 0 if trop_grande else score_emergence(donnees)

        fiche = vers_fiche(donnees, url, statut)
        existante = store.lire_fiche(fiche.slug)
        if existante:
            # Fusion : on complète les champs vides, on ne rase jamais une
            # information déjà validée, on ne repasse pas une fiche publiée en
            # candidate.
            fusion = existante.model_dump()
            nouveau = fiche.model_dump()
            for cle, valeur in nouveau.items():
                if cle in {"statut", "valide_par_artisan", "demonstration",
                           "verification_identite_le", "cree_le"}:
                    continue
                if valeur in (None, "", [], {}) or fusion.get(cle) not in (None, "", [], {}):
                    continue
                fusion[cle] = valeur
            fusion["source_donnees"] = sorted(
                set(existante.source_donnees) | set(fiche.source_donnees))[:10]
            fiche = Fiche(**fusion)
            store.enregistrer_fiche(fiche, emergence=score)
            store.ajouter_mention(fiche.slug, source, url)
            continue

        store.enregistrer_fiche(fiche, emergence=score)
        store.ajouter_mention(fiche.slug, source, url)
        retenues += 1
        if statut == StatutFiche.candidate and score >= SCORE_MINIMAL_ALERTE:
            envoyer_candidate(fiche, score, url, cible)
        time.sleep(0.4)

    envoyer_message(f"🌙 Novaluth — {cible}\n{vues} publications analysées · "
                    f"{retenues} nouvelles fiches en attente d'arbitrage")


def luthiers() -> None:
    _decouvrir(ROTATION_LUTHIERS, "luthiers")


def marques() -> None:
    _decouvrir(ROTATION_MARQUES, "marques")


def momentum() -> None:
    """Radar de buzz : on surveille les fiches connues et on alerte quand une
    décolle. Utile pour repérer une marque qui monte avant tout le monde."""
    store.initialiser()
    connues = store.lister_fiches(
        [StatutFiche.publiee.value, StatutFiche.a_suivre.value], limite=40)
    alertes = []
    with store.connexion() as conn:
        for fiche in connues:
            try:
                publications = demander_collecte("x", [fiche.nom], jours=7, limite=200)
            except PasserelleIndisponible as e:
                print(f"[momentum] arrêt : {e}")
                break
            actuel = len(publications)
            ligne = conn.execute("SELECT mentions_7j FROM fiches WHERE slug=?",
                                 (fiche.slug,)).fetchone()
            precedent = (ligne["mentions_7j"] if ligne else 0) or 0
            conn.execute("UPDATE fiches SET mentions_7j=? WHERE slug=?",
                         (actuel, fiche.slug))
            if actuel >= 5 and actuel >= 2 * max(precedent, 1):
                alertes.append((fiche.nom, precedent, actuel))
            time.sleep(0.5)

    if alertes:
        lignes = "\n".join(f"📈 {nom} : {avant} → {apres} mentions/7 j"
                           for nom, avant, apres in alertes)
        envoyer_message(f"🚀 Fiches qui décollent\n\n{lignes}")


def digest() -> None:
    """Résumé du soir + hygiène RGPD quotidienne."""
    store.initialiser()
    anonymises = store.purger_briefs_expires()
    compteurs = store.compter_par_statut()
    lignes = "\n".join(f"· {statut} : {n}" for statut, n in sorted(compteurs.items()))
    envoyer_message(
        f"📊 Novaluth — état de la base\n{lignes}\n\n"
        f"🧹 {anonymises} brief(s) anonymisé(s) automatiquement (conservation "
        f"12 mois)\n\nArbitrage : {os.environ.get('NOVALUTH_URL', '')}/admin"
    )


JOBS = {"luthiers": luthiers, "marques": marques, "momentum": momentum,
        "digest": digest}

if __name__ == "__main__":
    nom_job = sys.argv[1] if len(sys.argv) > 1 else "digest"
    if nom_job not in JOBS:
        print(f"Jobs disponibles : {', '.join(JOBS)}")
        raise SystemExit(1)
    JOBS[nom_job]()
