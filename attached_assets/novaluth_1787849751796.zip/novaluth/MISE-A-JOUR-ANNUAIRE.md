# Mise à jour — annuaire, recherche et son décrit en mots

Cette mise à jour supprime le curseur « niveau d'innovation » de la partie
publique du site et le remplace par une recherche descriptive. À déposer sur
Replit par-dessus le projet existant : les fichiers listés ci-dessous écrasent
les anciens, aucun fichier n'est à supprimer à la main.

## Pourquoi ce changement

Le curseur ne servait pas seulement de filtre. Dans `web/store.py`, l'annuaire
était trié `ORDER BY COALESCE(score_innovation, 0) DESC` : Novaluth classait
donc publiquement les luthiers du plus « innovant » au moins « innovant »,
selon une note estimée par une IA.

Trois raisons de l'enlever :

1. **Indéfendable sur le fond.** Un atelier qui fabrique une guitare classique
   au rabot n'est pas « moins bon » qu'un atelier qui imprime un chevalet en
   titane. Ce sont deux métiers, pas deux niveaux.
2. **Exposé juridiquement.** Un classement affiché doit expliquer ses critères
   principaux (DSA art. 27, code de la consommation L. 111-7). Expliquer
   « nous les avons notés de 0 à 10 sur l'innovation » revient à assumer un
   jugement de valeur sur des artisans nommément identifiés.
3. **Inutile pour chercher.** Un musicien ne cherche pas « du 7/10
   d'innovation ». Il cherche du bois local, une guitare sans tête, un atelier
   d'une seule personne, une finition à l'huile.

## Ce qui remplace le curseur

### Un vocabulaire fermé de 21 « façons de travailler »

Nouveau fichier `web/facettes.py`. Quatre familles :

| Famille | Façons |
| --- | --- |
| Matières et bois | essences locales · bois de réemploi · matières biosourcées · carbone ou composite · bois thermotraité · aucune essence protégée |
| Construction | sans tête · multi-diapason · table voûtée · modulaire · diapason court · sans frette · pensé pour être réparé |
| Manière de travailler | atelier d'une seule personne · vingt instruments par an au plus · uniquement sur commande · personnalisation acceptée · série limitée |
| Finition | huile-cire · vernis traditionnel · finition brute |

Chaque façon est une **description**, jamais une note. Chacune porte un libellé,
une phrase d'aide affichée sous la case, et les motifs qui permettent de la
repérer dans les informations publiques de l'atelier.

Deux garde-fous techniques :

- la reconnaissance se fait **sur les mots entiers** (`(?<![\w-])motif(?![\w-])`
  sur un texte débarrassé de ses accents). Sans cela « mat » se déclenchait à
  l'intérieur de « matériau » et un atelier se retrouvait étiqueté « finition
  brute » à tort ;
- `normaliser()` referme le vocabulaire : une façon inventée dans l'URL est
  ignorée au lieu de traverser l'application.

### Une provenance affichée pour chaque atelier

`facettes.provenance(fiche)` retourne « relu par l'artisan » ou « d'après ses
pages publiques ». Les façons sont d'abord déduites des sources publiques, puis
l'artisan les relit et les corrige depuis son espace. La fiche et la carte
d'annuaire disent toujours laquelle des deux situations s'applique, et une case
« seulement les fiches relues par l'artisan » permet de n'afficher que les
secondes.

### Des filtres qui n'excluent jamais sur une information manquante

Nouveau fichier `web/recherche.py`. Filtres disponibles : instrument, style,
pays, zone d'expédition, budget, délai maximum, fiches relues, façons de
travailler (combinées en ET). **Règle appliquée partout : une information
absente ne fait jamais disparaître un atelier.** Un atelier qui n'a pas annoncé
ses tarifs reste visible quand on saisit un budget ; il est simplement présenté
sans tarif.

### Une rotation équitable comme ordre par défaut

`recherche.ordre_equitable()` trie les fiches par identifiant, puis les mélange
avec une graine tirée de la date du jour. Conséquences :

- l'ordre est **le même pour tous les visiteurs d'une même journée**, donc
  reproductible et vérifiable ;
- il **change chaque jour**, donc personne n'est installé en tête ;
- il ne dépend pas de l'ordre d'insertion en base, donc s'inscrire tôt ne donne
  aucun avantage.

Les autres tris restent au choix du visiteur : délai le plus court, budget le
plus bas, ordre alphabétique, mise à jour la plus récente.

### Une page publique qui explique l'ordre

Nouveau document `legal/classement.md`, servi sur `/legal/classement` sous le
titre « Comment l'annuaire est ordonné ». Il décrit la rotation, les tris
disponibles, les critères de la recommandation et énonce qu'aucun paiement ne
modifie la position dans l'annuaire. Un encadré en haut de l'annuaire y renvoie.

## Ce que devient le score d'innovation

Il est **conservé en interne** et **retiré de tout affichage public**. Il ne
sert plus qu'à la veille : repérer quels ateliers documenter en priorité. Les
champs `score_innovation`, `score_originalite` et `Innovation.niveau` sont
marqués comme internes dans `web/schemas.py`.

## Effet sur la recommandation

Dans `web/matching.py`, le poids « niveau d'innovation documenté » (8 %) devient
« façons de travailler recherchées » (8 %). Le calcul ne compare plus deux
notes : il compare deux listes, et l'explication devient vérifiable par le
musicien. Exemples réellement produits par le moteur :

- « Correspond à ce que vous cherchez : essences locales, finition huile-cire »
- « Non documenté chez cet atelier : sans tête (headless) »

Le second est affiché dans « Ce que cela ne dit pas ». Un atelier n'est pas
écarté parce qu'une façon manque : on dit simplement qu'elle n'est pas
documentée.

## Le son passe aussi en mots

Les dernières échelles chiffrées du site étaient celles du profil sonore
(« chaleur 8/10, brillance 5/10, dynamique 7/10 »). Elles sont remplacées par un
vocabulaire fermé, dans `web/sonorite.py` : trois axes, trois valeurs chacun.

| Axe | Valeurs |
| --- | --- |
| Couleur du son | plutôt chaud et rond · plutôt équilibré · plutôt clair et brillant |
| Réponse à l'attaque | douce et progressive · franche · percussive et immédiate |
| Tenue des notes | courte et nette · moyenne · longue et chantante |

Chaque valeur porte une phrase d'explication, affichée sous elle sur la fiche et
regroupée dans un dépliant « Que veulent dire ces mots ? » du formulaire de
projet. Aucune valeur n'est au-dessus d'une autre : ce sont trois façons de
sonner, pas trois niveaux.

Trois conséquences dans le code :

- **La fiche** affiche des phrases à la place des jauges, avec un rappel : ce
  sont des mots, pas des mesures, et le son dépend aussi des cordes, du réglage,
  de l'amplification et du jeu du musicien.
- **Le brief** propose trois listes déroulantes, « peu importe » par défaut.
  Choisir n'écarte aucun atelier ; cela sert à expliquer la proposition.
- **La recommandation** compare des mots, pas des écarts de notes. Sur un axe :
  même valeur = plein poids, valeur voisine = moitié, valeur opposée = rien.
  L'explication devient lisible — « Couleur du son annoncée "plutôt chaud et
  rond", comme vous le cherchez », ou « Réponse à l'attaque annoncée "douce et
  progressive" alors que vous cherchez "percussive et immédiate" ». Quand
  personne n'a rien déclaré, l'axe n'intervient ni en faveur ni en défaveur de
  la fiche.

**Aucune fiche déjà collectée n'est perdue.** `sonorite.depuis_chiffres()`
traduit les anciennes notes à la lecture : la couleur se déduit de l'écart entre
chaleur et brillance (moins de deux points d'écart = équilibré, parce qu'un
point sur une note déclarée ne veut rien dire), la réponse à l'attaque se déduit
de la dynamique, et la tenue reste vide jusqu'à ce que l'artisan la renseigne.
Les trois colonnes chiffrées restent en base, marquées comme historiques, et ne
sont plus affichées nulle part.

L'annuaire gagne un filtre « couleur du son annoncée ». Il ne propose que les
valeurs réellement présentes chez au moins un atelier, et il conserve les fiches
qui ne disent rien de leur son : les écarter reviendrait à vider l'annuaire pour
punir un silence.

Le seul pourcentage encore affiché sur le site est le taux de correspondance
entre un projet et une fiche. Il mesure l'accord entre deux demandes, jamais la
valeur d'un artisan.

## Fichiers de la mise à jour

| Fichier | Nature |
| --- | --- |
| `web/facettes.py` | nouveau — vocabulaire des façons, détection, provenance |
| `web/sonorite.py` | nouveau — vocabulaire du son, reprise des anciennes notes |
| `web/recherche.py` | nouveau — critères, filtres, tris, rotation du jour |
| `legal/classement.md` | nouveau — transparence de l'ordre d'affichage |
| `web/main.py` | route `/annuaire` réécrite, accueil et fiche adaptés, brief accepte `facon` |
| `web/store.py` | tri en base par identifiant au lieu du score |
| `web/matching.py` | poids et explications basés sur les façons |
| `web/schemas.py` | scores marqués internes, `facons_recherchees` dans le brief |
| `web/acces.py` | libellé du critère dans le récapitulatif de l'atelier |
| `web/legal.py` | enregistrement de la page classement |
| `templates/annuaire.html` | filtres, cases groupées, tri, recherche rapide, cartes |
| `templates/brief.html` | cases facultatives à la place du curseur |
| `templates/fiche.html` | section « Façons de travailler », son décrit en phrases |
| `static/novaluth.css` | bloc `.nv-son` à la place des jauges de sonorité |
| `data/fiches_demonstration.json` | son des cinq exemples décrit en mots |
| `templates/accueil.html` | cartes avec façons au lieu des marqueurs bruts |
| `legal/cgu.md` | tableau des poids et paragraphe « pas de note ni de niveau » |
| `tools/verifier_conformite.py` | la page classement devient obligatoire |
| `README.md` | poids et description des deux nouveaux modules |

## Après le dépôt sur Replit

Rien à installer : aucune dépendance nouvelle. Redémarrez simplement le Repl,
puis vérifiez trois choses :

1. `/annuaire` affiche l'encadré « À sélectionner, affiner » et le bloc
   « Façons de travailler » avec les cases.
2. `/legal/classement` s'ouvre depuis cet encadré.
3. Plus aucun « /10 » ni « niveau d'innovation » sur `/annuaire`, `/brief`,
   `/fiche/...` ni sur l'accueil. La fiche d'un atelier affiche « Son annoncé »
   avec des phrases, et le formulaire de projet propose trois listes
   déroulantes réglées sur « peu importe ».

Sources citées dans le document de classement :
[DSA art. 27](https://dsa-act.eu/fr/article-27-transparence-du-systeme-de-recommandation/) ·
[code de la consommation L. 111-7](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032227319) ·
[LCEN art. 19](https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000032236011)
