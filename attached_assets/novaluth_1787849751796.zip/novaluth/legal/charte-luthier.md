Dernière mise à jour : 26/08/2026

Cette charte s'applique à tout luthier ou marque référencé sur Novaluth. Elle
protège les musiciens, les artisans eux-mêmes et la crédibilité de l'annuaire.

## 1. Comment une fiche apparaît

1. Les informations sont collectées à partir de sources **publiques** (site de
   l'atelier, réseaux sociaux, publications publiques).
2. Une fiche candidate est générée puis **arbitrée manuellement** par l'éditeur.
   Aucune publication automatique.
3. L'artisan est contacté et invité à relire, corriger ou compléter sa fiche.
4. Une fiche non encore relue par l'artisan porte la mention explicite
   « Fiche construite à partir de sources publiques, non encore relue par
   l'artisan ».

## 2. Engagements de l'artisan référencé

- Fournir des informations exactes, notamment sur les prix, délais, matériaux et
  zones d'expédition, et signaler tout changement significatif.
- Ne pas se présenter comme certifié, labellisé ou garanti par Novaluth : aucune
  certification n'existe.
- Répondre aux projets qualifiés reçus dans un délai raisonnable, même par un
  refus.
- Respecter ses obligations légales de vendeur professionnel envers un
  consommateur : information précontractuelle, garantie légale de conformité de
  deux ans, garantie des vices cachés, droit de rétractation lorsqu'il
  s'applique, médiation de la consommation.
- Ne pas réutiliser les coordonnées d'un musicien reçues via Novaluth pour autre
  chose que le projet concerné, et notamment pas pour de la prospection de masse.
- Respecter la réglementation applicable aux matériaux, notamment CITES pour les
  essences protégées.

## 3. Engagements de Novaluth envers l'artisan

- Inscription gratuite, sans commission sur les ventes.
- Contrôle de l'artisan sur le contenu de sa fiche : correction et retrait sur
  simple demande, traités en priorité et sans justification à fournir.
- Aucune dénaturation du travail présenté, aucune comparaison dévalorisante.
- Aucune mise en avant payante dissimulée : toute mise en avant est étiquetée.
- Transparence sur les paramètres du moteur de correspondance, publiés dans les
  [CGU](/legal/cgu).
- Aucune revente des données de l'atelier.

## 4. Retrait

Un artisan peut demander à tout moment le retrait complet de sa fiche par e-mail
à contact@novaluth.com. Le retrait est effectué sans délai, sans condition et
sans frais.

## 5. Ce que la charte n'est pas

Cette charte est un engagement déclaratif. Novaluth ne contrôle pas les ateliers,
n'audite pas les processus de fabrication, ne vérifie pas les allégations
environnementales et ne délivre aucune attestation de qualité.
