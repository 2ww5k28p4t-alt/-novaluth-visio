Dernière mise à jour : 26/08/2026

## 1. Objet

Les présentes conditions générales d'utilisation (CGU) régissent l'accès et
l'utilisation du service Novaluth, accessible à l'adresse novaluth.com et via
son application web installable.

L'utilisation du service suppose l'acceptation des présentes CGU. Un utilisateur
qui ne les accepte pas doit cesser d'utiliser le service.

## 2. Description du service

Novaluth publie des fiches descriptives de luthiers et de marques d'instruments
émergentes, et propose un moteur de correspondance : un musicien décrit son
projet, le service affiche les fiches dont les informations publiées
correspondent le mieux, avec l'explication détaillée de cette correspondance.

Novaluth agit exclusivement comme **service de référencement et de mise en
relation**. Novaluth n'est ni vendeur, ni fabricant, ni transporteur, ni
intermédiaire de paiement.

## 3. Ce que Novaluth ne fait pas et ne garantit pas

Novaluth ne garantit pas :

- la qualité, la conformité, la valeur, la durabilité ou la sonorité d'un instrument ;
- l'exactitude, l'exhaustivité ou l'actualité des informations d'une fiche, dès
  lors qu'elles proviennent de sources publiques ou de l'artisan lui-même ;
- la disponibilité d'un artisan, ses délais de fabrication, ses prix, ni la bonne
  exécution d'une commande ;
- la solvabilité, l'assurance, l'immatriculation ou la compétence d'un artisan ;
- l'obtention d'un résultat quelconque à la suite d'un projet déposé.

Novaluth ne délivre **aucune certification** et ne décerne **aucun label de
qualité**. Les mentions affichées sur les fiches sont descriptives et datées
(voir [Signification des badges](/legal/badges)).

Novaluth ne fournit aucun conseil en investissement, aucun conseil patrimonial,
et ne recommande pas d'acheter un instrument déterminé.

## 4. Fonctionnement du moteur de correspondance (transparence)

Conformément à l'article 27 du règlement (UE) 2022/2065 sur les services
numériques (DSA), les principaux paramètres du système de recommandation sont
publiés en langage clair.

Le classement est **déterministe** : il est calculé par un programme, sans
intervention humaine sur l'ordre des résultats, à partir des critères déclarés
par le musicien et des informations publiées de chaque fiche, avec la
pondération suivante :

| Paramètre | Poids |
|---|---|
| Compatibilité de budget | 26 % |
| Type d'instrument fabriqué | 14 % |
| Styles de jeu associés | 14 % |
| Zone de livraison desservie | 12 % |
| Délai de fabrication annoncé | 10 % |
| Essences de bois demandées | 8 % |
| Son annoncé par l'atelier | 8 % |
| Façons de travailler recherchées | 8 % |

Le son annoncé est décrit en mots, pris dans une liste fermée : couleur du son
(plutôt chaud et rond, plutôt équilibré, plutôt clair et brillant), réponse à
l'attaque (douce et progressive, franche, percussive et immédiate), tenue des
notes (courte et nette, moyenne, longue et chantante). Ce sont des déclarations
de l'atelier sur le son qu'il cherche à obtenir, pas des mesures acoustiques et
pas des notes : aucune de ces valeurs n'est au-dessus d'une autre. Novaluth
reprend ces déclarations sans les vérifier.

Les façons de travailler sont des éléments descriptifs, présents ou absents :
essences locales, bois de réemploi, sans tête, table voûtée, finition huile-cire,
et ainsi de suite. Novaluth n'attribue aux artisans aucune note, aucun niveau et
aucune étoile, et ne les ordonne jamais par mérite. L'ordre d'affichage de
l'annuaire, distinct de ce calcul de correspondance, est décrit dans
[Comment l'annuaire est ordonné](/legal/classement).

Aucun paiement, aucune commission et aucune contrepartie ne modifie ce
classement. Si une mise en avant payante est introduite à l'avenir, elle sera
présentée séparément et étiquetée « Sponsorisé », sans influencer le classement
organique.

Un modèle d'intelligence artificielle est utilisé uniquement pour reformuler en
français clair un résultat déjà calculé. Il ne décide d'aucun classement. Voir
[Transparence sur l'usage de l'IA](/legal/ia-transparence).

## 5. Accès au service

L'accès est gratuit pour les musiciens et ne nécessite aucun compte. Novaluth
s'efforce d'assurer la disponibilité du service sans y être tenu : des
interruptions pour maintenance, incident technique ou dépendance à un
prestataire tiers peuvent survenir.

## 6. Obligations de l'utilisateur

L'utilisateur s'engage à :

- fournir des informations exactes dans son projet ;
- ne pas déposer de contenu illicite, diffamatoire, discriminatoire, ni de
  données personnelles concernant un tiers ;
- ne pas tenter d'extraire massivement la base de données, de la copier, de la
  réutiliser à des fins commerciales, ni d'entraver le fonctionnement du service ;
- ne pas utiliser le service pour adresser des sollicitations commerciales non
  désirées aux artisans référencés.

## 7. Contenus des artisans

Les fiches sont établies à partir d'informations publiques puis soumises à
l'artisan concerné, qui peut les corriger, les compléter ou en demander le
retrait. Une fiche non encore relue par l'artisan est signalée comme telle.
Les artisans conservent leurs droits sur leurs contenus et concèdent à Novaluth
une licence non exclusive et gratuite d'affichage aux seules fins du service,
révocable sur demande de retrait.

## 8. Responsabilité

Novaluth répond des dommages directs qui résulteraient d'un manquement à ses
obligations propres, dans les conditions du droit commun. Novaluth n'est pas
responsable des relations contractuelles nouées entre un musicien et un artisan,
ni de l'exécution, de l'inexécution ou de la mauvaise exécution d'une commande.

Aucune clause des présentes CGU ne peut avoir pour effet d'exclure ou de limiter
les droits que la loi reconnaît à un consommateur, notamment la garantie légale
de conformité et la garantie des vices cachés dues par le vendeur, ni de priver
l'utilisateur de son droit d'agir en justice.

## 9. Modification des CGU

Les CGU peuvent évoluer. Toute modification substantielle est annoncée sur le
site au moins quinze jours avant son entrée en vigueur, et les versions
antérieures sont conservées et communiquées sur demande. La version applicable à
une relation est celle en vigueur à la date de son établissement.

## 10. Droit applicable et litiges

Les présentes CGU sont soumises au droit français. En cas de litige, une solution
amiable est recherchée en priorité (contact@novaluth.com). Le consommateur peut
recourir gratuitement à un médiateur de la consommation et saisir la juridiction
de son choix parmi celles que la loi lui ouvre, notamment celle de son lieu de
résidence. Voir [Réclamations et litiges](/legal/litiges).
