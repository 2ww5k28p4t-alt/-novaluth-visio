Dernière mise à jour : 26/08/2026

## 1. Engagement

Novaluth veut rester lisible par tout le monde, y compris avec un lecteur d'écran
ou une vision réduite. Cet engagement est volontaire : à ce stade, le service
n'est pas soumis à l'obligation légale d'accessibilité des services publics.

## 2. Ce qui est déjà en place

- Structure de titres hiérarchisée, un seul titre de niveau 1 par page.
- Contrastes conformes au niveau AA sur les textes courants.
- Taille de police de base de 16 pixels, jamais bloquée au zoom.
- Champs de formulaire tous associés à une étiquette explicite.
- Navigation complète au clavier avec indicateur de focus visible.
- Réduction des animations lorsque le système le demande.
- Images décoratives sans texte alternatif superflu, logo décrit.
- Aucune information transmise par la couleur seule.

## 3. Limites connues

- Les jauges de profil sonore sont accompagnées de leur valeur chiffrée, mais
  restent une représentation visuelle.
- Certaines fiches dépendent de descriptions fournies par les artisans, dont la
  lisibilité n'est pas maîtrisée.
- Aucun audit d'accessibilité externe n'a encore été réalisé.

## 4. Signaler un obstacle

Écrivez à contact@novaluth.com en décrivant la page et la difficulté rencontrée.
Une réponse est apportée sous quinze jours ouvrés, avec une solution ou une
alternative permettant d'accéder à l'information.
