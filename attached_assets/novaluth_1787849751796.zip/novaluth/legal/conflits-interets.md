Dernière mise à jour : 26/08/2026

Cette déclaration est publiée volontairement. Un annuaire qui classe des artisans
doit dire ce qui pourrait influencer son classement.

## 1. Ce qui n'influence jamais le classement

- Aucun paiement, aucune commission, aucun abonnement ne modifie l'ordre des
  résultats du moteur de correspondance.
- Aucune rémunération n'est perçue sur la vente d'un instrument.
- Aucun lien d'affiliation vers un site marchand.
- Aucune publicité de fabricant, de revendeur ou de marque d'accessoires.
- Aucune contrepartie en nature acceptée d'un artisan référencé.

## 2. Sources de revenus, présentes et prévues

| Source | Statut à ce jour | Effet sur le classement |
|---|---|---|
| Accès à un projet qualifié, payé par l'artisan | Prévu, non actif | Aucun : l'artisan paie après avoir été sélectionné par le calcul |
| Abonnement professionnel | Prévu, non actif | Aucun : outils de gestion seulement |
| Mise en avant identifiée « Sponsorisé » | Éventuel, non actif | Emplacement distinct, hors classement organique |
| API de données | Éventuel, non actif | Aucun |

## 3. Intérêts personnels de l'éditeur

| Élément | Déclaration |
|---|---|
| Participation dans un atelier ou une marque de lutherie | Aucune |
| Lien familial ou d'affaires avec un artisan référencé | [À COMPLÉTER — déclarer tout lien, ou indiquer « aucun »] |
| Activité de vente d'instruments | Aucune |
| Détention d'actifs numériques liés aux réseaux utilisés | L'éditeur peut détenir des jetons du réseau Bittensor, utilisé comme prestataire technique. Cette détention est étrangère au fonctionnement du service et n'a aucun effet sur les fiches ni sur le classement. Novaluth ne publie aucune analyse d'investissement, aucun conseil et aucune projection de rendement sur ce réseau |

## 4. Modération éditoriale

Une fiche peut être écartée pour trois raisons seulement : elle concerne un
fabricant déjà largement installé, ce qui est hors du positionnement du service ;
les informations ne sont pas vérifiables ; l'artisan a demandé son retrait.
Aucune fiche n'est écartée en raison d'un refus de payer.
