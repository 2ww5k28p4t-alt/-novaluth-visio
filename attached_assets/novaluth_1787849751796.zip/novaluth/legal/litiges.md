Dernière mise à jour : 26/08/2026

## 1. Un litige avec un artisan

Novaluth n'est pas partie au contrat de vente ou de fabrication. Novaluth
**oriente** et n'arbitre jamais. Parcours recommandé, dans cet ordre :

1. **Réclamation écrite à l'artisan**, par e-mail, décrivant précisément le
   problème et la solution demandée, avec un délai de réponse raisonnable.
2. **Recherche d'une solution amiable** : réparation, remplacement, réduction de
   prix, résolution de la vente.
3. **SignalConso** — signalement auprès de la DGCCRF :
   [signal.conso.gouv.fr](https://signal.conso.gouv.fr).
4. **Médiateur de la consommation** dont relève l'artisan : tout professionnel
   vendant à des consommateurs doit en désigner un et en communiquer les
   coordonnées. La saisine est gratuite pour le consommateur.
5. **Juridiction compétente** : tribunal judiciaire, avec une procédure allégée
   devant le juge des contentieux de la protection pour les petits litiges. Le
   consommateur peut saisir la juridiction de son lieu de résidence.

## 2. Vos droits face au vendeur

| Droit | Contenu | Référence |
|---|---|---|
| Garantie légale de conformité | Le vendeur professionnel répond des défauts de conformité qui apparaissent dans les deux ans suivant la délivrance du bien, y compris pour un instrument fabriqué sur mesure | Article L. 217-3 du code de la consommation ([Légifrance](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000044142579)) |
| Mise en conformité | Réparation ou remplacement sans frais, dans un délai raisonnable ne pouvant excéder trente jours ; à défaut, réduction du prix ou résolution du contrat | Articles L. 217-8 et suivants |
| Garantie des vices cachés | Action distincte contre le vendeur pour un défaut caché rendant le bien inutilisable ou diminuant fortement son usage | Articles 1641 et suivants du code civil |
| Suspension du paiement | Le client peut suspendre le paiement du solde tant que le vendeur n'a pas satisfait à ses obligations | Article L. 217-6 |
| Rétractation | Quatorze jours pour un achat à distance, avec des exceptions pour les biens confectionnés selon des spécifications personnalisées | Articles L. 221-18 et L. 221-28 |

Un bien fabriqué sur mesure reste couvert par la garantie légale de conformité :
le caractère personnalisé ne prive pas le consommateur de ses droits.

## 3. Un litige avec Novaluth

Réclamation par e-mail à contact@novaluth.com. Réponse sous quinze jours ouvrés.
En cas d'échec, médiation possible :

| Élément | Valeur |
|---|---|
| Médiateur de la consommation désigné | [À COMPLÉTER — obligatoire dès l'activité professionnelle envers des consommateurs] |
| Plateforme européenne de règlement en ligne | [ec.europa.eu/consumers/odr](https://ec.europa.eu/consumers/odr) |

## 4. Signalement d'un contenu illicite

Voir [Propriété intellectuelle et signalement](/legal/propriete-intellectuelle).
