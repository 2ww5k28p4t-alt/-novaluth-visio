Dernière mise à jour : 26/08/2026

## 1. Éditeur du site

Le présent service est édité par :

| Élément | Valeur |
|---|---|
| Nom / dénomination | [À COMPLÉTER — nom et prénom, ou dénomination sociale] |
| Statut | [À COMPLÉTER — particulier non professionnel / micro-entreprise / société] |
| Adresse du siège ou de domiciliation | [À COMPLÉTER] |
| Adresse électronique de contact | contact@novaluth.com |
| Téléphone | [À COMPLÉTER — facultatif si l'e-mail permet un contact effectif] |
| Numéro SIREN / SIRET | [À COMPLÉTER dès l'immatriculation] |
| Numéro de TVA intracommunautaire | [À COMPLÉTER si applicable — mention « TVA non applicable, article 293 B du CGI » en franchise] |
| Responsable de la publication | [À COMPLÉTER] |
| Inscription à un ordre ou registre professionnel | Sans objet |

Ces mentions sont exigées par l'article 19 de la loi n° 2004-575 du 21 juin 2004
pour la confiance dans l'économie numérique
([texte officiel](https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000032236011))
et par les articles L. 111-1 et suivants du code de la consommation.

**Tant que le service est exploité sans activité commerciale**, l'éditeur agit
en qualité de personne physique éditant un site à titre non professionnel. Dans
ce cas, l'article 6 III 2 de la LCEN permet de ne pas publier l'adresse
personnelle, à condition d'avoir communiqué les éléments d'identification à
l'hébergeur, qui reste tenu de les conserver. **Dès la première somme encaissée,
le service devient professionnel et l'identification complète ci-dessus devient
obligatoire.**

## 2. Hébergement

| Élément | Valeur |
|---|---|
| Hébergeur de l'application | Replit, Inc. |
| Adresse | 767 Bryant St. #203, San Francisco, CA 94107, États-Unis |
| Site | [replit.com](https://replit.com) |
| Hébergeur du nom de domaine | [À COMPLÉTER — registrar] |

## 3. Nature du service

Novaluth est un **service de référencement et de mise en relation**. Novaluth :

- n'est pas vendeur des instruments présentés ;
- n'est pas fabricant, luthier, ni sous-traitant d'un fabricant ;
- n'est pas transporteur ni commissionnaire de transport ;
- n'est pas intermédiaire de paiement, ni prestataire de services de paiement ;
- ne détient aucun stock, ne prend aucune commande, n'encaisse aucun prix de vente.

La vente, la fabrication, l'expédition et le paiement d'un instrument se nouent
**directement et exclusivement** entre le musicien et l'artisan.

## 4. Propriété intellectuelle

La marque Novaluth, le logotype, la charte graphique, la structure de la base de
données et les textes du site sont protégés. Toute reproduction non autorisée est
interdite. Les noms, marques et visuels des artisans référencés demeurent la
propriété de leurs titulaires et sont cités à des fins d'information.

Le nom « Novaluth » n'a pas encore fait l'objet d'un dépôt. Recherches
d'antériorité à réaliser avant tout usage commercial : INPI (marques françaises)
et TMview / EUIPO (marques de l'Union européenne).

## 5. Signalement

Toute demande de correction, de retrait ou de signalement de contenu illicite :
contact@novaluth.com. Voir la page
[Propriété intellectuelle et signalement](/legal/propriete-intellectuelle).
