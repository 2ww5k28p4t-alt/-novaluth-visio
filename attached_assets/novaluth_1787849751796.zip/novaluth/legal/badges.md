Dernière mise à jour : 26/08/2026

Novaluth affiche des **mentions descriptives et datées**. Aucune mention ne
constitue une garantie, une certification, un label ou une caution.

## 1. Mentions utilisées

| Mention affichée | Signification exacte | Ce qu'elle ne signifie pas |
|---|---|---|
| « Fiche relue et confirmée par l'artisan » | L'artisan a lu la fiche et confirmé son contenu à la date indiquée | Que le contenu est vérifié par Novaluth |
| « Fiche construite à partir de sources publiques, non encore relue par l'artisan » | Les informations proviennent de publications publiques | Que l'artisan approuve ou conteste la fiche |
| « Identité professionnelle vérifiée le [date] » | Un numéro d'immatriculation public a été retrouvé et rapproché de l'atelier à cette date | Que l'activité est toujours en cours, ni que l'artisan est compétent |
| « Informations de commande renseignées » | Les champs prix, délais et expédition sont remplis | Que ces informations sont exactes ou à jour |
| « Exemple fictif » | Fiche de démonstration, artisan inexistant | Rien d'autre : aucune donnée réelle |
| « Innovation documentée : n/10 » | Nombre de caractéristiques techniques inhabituelles relevées dans les sources | Un jugement de valeur sur la qualité de l'instrument |

## 2. Mentions interdites

Les formulations suivantes ne seront jamais employées par Novaluth, sur aucun
support, parce qu'elles engageraient une garantie que le service ne peut pas
assumer :

<!-- conformite:debut-liste-proscrite -->
- « Luthier certifié », « atelier agréé », « artisan labellisé Novaluth »
- « Expédition garantie », « livraison assurée par Novaluth »
- « Commande 100 % sécurisée », « paiement protégé »
- « Meilleur luthier », « le choix idéal », « valeur sûre »
- « Investissement », « placement », « prend de la valeur »
<!-- conformite:fin-liste-proscrite -->

## 3. Contestation

Un artisan ou un musicien qui estime une mention inexacte peut en demander la
correction ou la suppression à contact@novaluth.com. Toute mention contestée est
retirée le temps de la vérification.
