Dernière mise à jour : 27/08/2026

## 1. Où l'IA intervient, où elle n'intervient pas

| Étape | Rôle de l'IA | Décision finale |
|---|---|---|
| Recherche d'adresses de pages d'ateliers | Aucune. Le service de recherche ne renvoie que des adresses, jamais du contenu à republier | — |
| Lecture de la page publique d'un atelier | Aucune. Lecture directe par notre serveur, robots.txt et opposition à la fouille respectés ([détail](/legal/sources-donnees)) | — |
| Collecte de publications publiques | Aucune. Simple récupération de contenus publics | — |
| Extraction d'une fiche candidate | Structuration du texte brut en champs, par un modèle de langage | Aucune publication automatique |
| Notation de fiabilité de la fiche candidate | Note indicative de complétude et de vérifiabilité | Indicative uniquement |
| Publication d'une fiche | Aucune | **Humaine, systématique** |
| Classement des correspondances | **Aucune.** Le classement est calculé par un programme déterministe et publié dans les [CGU](/legal/cgu) | Programme, non modifiable par paiement |
| Résumé en français clair | Reformulation d'un résultat déjà calculé | Filtré et affiché avec sa mention d'origine |

**Aucune décision produisant un effet juridique n'est prise de façon
automatisée.** Une fiche n'est jamais publiée sans relecture humaine.

## 2. Ce qui est envoyé aux modèles

Uniquement des contenus publics et des critères anonymes. Avant tout envoi, un
filtre serveur retire automatiquement : adresses e-mail, numéros de téléphone,
adresses postales, IBAN et identifiants de portefeuille. Les coordonnées d'un
musicien ne sont **jamais** transmises à un modèle.

## 3. Limites assumées

Un modèle de langage peut se tromper, mal interpréter une source ou produire une
formulation imprécise. En conséquence :

- tout résumé automatique est signalé comme tel et daté ;
- les informations d'une fiche prévalent sur le résumé ;
- les informations fournies par l'artisan prévalent sur les informations
  collectées ;
- le vocabulaire promotionnel ou juridiquement risqué est retiré
  automatiquement du texte généré avant affichage.

## 4. Prestataires techniques

Chaque besoin technique est confié à une **chaîne ordonnée** de prestataires.
Le premier qui répond fait le travail ; si un prestataire disparaît, le suivant
prend le relais sans changement de code, et le site continue de fonctionner même
quand aucun ne répond. Ce point n'est pas théorique : plusieurs sous-réseaux du
réseau Bittensor ont changé de projet ou de propriétaire au cours de l'année
2026, et le numéro d'un sous-réseau ne suffit pas à l'identifier durablement.

| Besoin | Prestataires, dans l'ordre d'essai | Réserve connue |
|---|---|---|
| Écrire et extraire du texte | Chutes ([subnet 64](https://chutes.ai/pricing)), puis Apex ([subnet 1](https://docs.macrocosmos.ai/developers/api-documentation/sn1-apex/endpoints)), puis [Mistral AI](https://mistral.ai/pricing) hors Bittensor | Chutes réserve les abonnements à l'usage personnel : Novaluth est au paiement à l'usage |
| Trouver des adresses de pages | Desearch ([subnet 22](https://www.desearch.ai/pricing)), puis Apex | Les conditions de Desearch interdisent de reproduire son contenu : nous n'en retenons que des adresses |
| Lire une page | Notre propre serveur, puis Desearch en secours | Refus automatique si robots.txt ou une opposition à la fouille s'y opposent |
| Publications publiques | Data Universe ([subnet 13](https://docs.macrocosmos.ai/pricing)) | X et Reddit seulement |

L'état réel de ces chaînes — quels prestataires sont actifs aujourd'hui — est
visible sur la [page de transparence technique](/transparence).

Ce qui n'est **pas** utilisé, et pourquoi : aucun sous-réseau ne propose de
service de vecteurs sémantiques directement exploitable, et la recherche de
l'annuaire est donc déterministe, par choix autant que par contrainte ; aucune
image d'instrument n'est produite par un modèle, parce qu'une photo sur une
fiche d'artisan doit montrer un instrument qui existe.

## 5. Signaler une erreur produite par l'IA

contact@novaluth.com, en précisant la page concernée. Correction ou retrait sous
quinze jours ouvrés, et retrait immédiat du texte contesté en cas de doute.
