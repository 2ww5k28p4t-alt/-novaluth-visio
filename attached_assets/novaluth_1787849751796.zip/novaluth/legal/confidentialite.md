Dernière mise à jour : 27/08/2026

## 1. Principe directeur

Novaluth est conçu pour fonctionner avec le minimum de données personnelles
possible. La recherche et la correspondance fonctionnent **sans compte et sans
identification**. Une adresse e-mail n'est demandée que si l'utilisateur souhaite
être mis en relation avec un artisan, et uniquement à ce moment-là.

## 2. Responsable de traitement

| Élément | Valeur |
|---|---|
| Responsable de traitement | [À COMPLÉTER — identité de l'éditeur, voir mentions légales] |
| Contact | contact@novaluth.com |
| Délégué à la protection des données | Non désigné (désignation non obligatoire à ce stade) |
| Autorité de contrôle | CNIL — [cnil.fr](https://www.cnil.fr) |

## 3. Traitements réalisés

| Traitement | Données | Base légale | Conservation |
|---|---|---|---|
| Correspondance sans mise en relation | Critères du projet (budget, style, zone, essences, texte libre). Aucune donnée identifiante | Intérêt légitime : fournir le service demandé | Enregistrement anonyme conservé à des fins statistiques |
| Mise en relation avec un artisan | Adresse e-mail + critères du projet | Consentement explicite (art. 6.1.a RGPD) | 12 mois maximum, puis anonymisation automatique. Effacement immédiat de l'adresse en cas de clôture du projet |
| Suivi de votre projet (page personnelle) | Jeton aléatoire rattaché à votre projet, dates de vos réponses | Exécution du service demandé et consentement | Même durée que le projet |
| Demande d'accès d'un atelier | Référence du projet, atelier demandeur, dates, état du paiement | Exécution du contrat conclu avec l'atelier | 10 ans pour les accès facturés (comptabilité), 12 mois pour les demandes annulées |
| Réponse à une demande de contact | Adresse e-mail, contenu du message | Intérêt légitime : répondre à une sollicitation | 24 mois |
| Fiches des artisans | Données professionnelles publiques : nom d'atelier, ville, site, réseaux | Intérêt légitime : information du public, avec droit d'opposition et de retrait | Jusqu'à demande de retrait |
| Journal technique et sécurité | Horodatage, type d'événement, empreinte technique non nominative | Intérêt légitime : sécurité du service | 12 mois |
| Facturation (dès activité payante) | Identité et coordonnées professionnelles de l'artisan, factures | Obligation légale comptable | 10 ans |

Aucun profilage publicitaire, aucune décision entièrement automatisée produisant
un effet juridique, aucune revente de données, aucun échange de données à des
fins commerciales.

## 4. Destinataires

| Destinataire | Rôle | Localisation |
|---|---|---|
| Replit, Inc. | Hébergement de l'application et de la base | États-Unis — clauses contractuelles types |
| Artisan sélectionné | Destinataire de votre adresse, **uniquement après votre accord explicite sur sa demande** | UE et hors UE selon l'atelier |
| Chutes (subnet 64 du réseau Bittensor) | Rédaction automatique de résumés | Voir point 5 |
| Macrocosmos (subnet 13 du réseau Bittensor) | Collecte de publications publiques sur les réseaux | Voir point 5 |
| Prestataire de paiement (dès activité payante) | Encaissement | UE |

## 5. Usage de l'intelligence artificielle et transferts

Deux garanties techniques encadrent l'usage des subnets Bittensor :

1. **Aucune donnée personnelle n'est envoyée.** Seuls des critères anonymes
   (budget, style, zone, délai) sont transmis. Un filtre serveur retire
   automatiquement adresses e-mail, numéros de téléphone, adresses postales,
   IBAN et identifiants de portefeuille du texte avant tout envoi, y compris du
   champ de description libre.
2. **Les clés d'accès sont isolées.** Elles sont détenues par un service dédié,
   séparé de l'application publique, accessible uniquement par des requêtes
   signées, plafonné en volume et journalisé.

Ces traitements peuvent impliquer un transfert hors de l'Union européenne. Comme
seules des données non identifiantes sont transmises, aucun transfert de données
personnelles n'est réalisé à ce titre.

## 6. Vos droits

Vous disposez des droits d'accès, de rectification, d'effacement, de limitation,
d'opposition, de portabilité, et du droit de retirer votre consentement à tout
moment.

- Exercice immédiat en ligne : page [Mes données](/donnees).
- Par e-mail : contact@novaluth.com.
- Réponse sous un mois maximum.
- Réclamation possible auprès de la CNIL.

Le retrait du consentement n'affecte pas les transmissions déjà réalisées, mais
interrompt toute transmission ultérieure.

## 6 bis. Votre adresse n'est transmise qu'après votre accord

Cocher la case de mise en relation ne transmet rien. Elle autorise seulement les
ateliers correspondant à votre projet à **demander** à vous répondre.

Avant cela, une étape de confirmation : après le dépôt de votre projet, vous
recevez un courriel contenant un lien. **Tant que vous n'avez pas cliqué ce
lien, votre projet n'est proposé à aucun atelier** et votre adresse n'est
utilisée que pour vous envoyer ce message. Cette vérification poursuit deux
finalités : s'assurer que l'adresse saisie est bien la vôtre, et ne mobiliser
des artisans que sur des projets réels. Elle repose sur notre intérêt légitime à
prévenir les dépôts erronés ou abusifs, et n'entraîne aucun frais pour vous.

Une seule demande peut être ouverte à la fois par adresse électronique. Si vous
déposez un second projet avec la même adresse, nous vous renvoyons vers la page
de suivi du projet déjà en cours plutôt que d'en créer un doublon.

Pour chaque demande, vous recevez un message et décidez vous-même :

- **accepter** : votre adresse est transmise à cet atelier, et à lui seul ;
- **décliner** : rien n'est transmis, et l'atelier n'apparaît plus ;
- **signaler l'abandon de votre projet** : rien n'est transmis, votre projet est
  clôturé et votre adresse est effacée ;
- **ne rien faire** : au bout de cinq jours, la demande s'annule d'elle-même.

Votre projet est proposé à **trois ateliers au maximum**. Vous pouvez à tout
moment, depuis votre page de suivi, confirmer que votre projet est d'actualité ou
le **clôturer en un clic** : la clôture efface immédiatement votre adresse et
empêche tout nouveau contact.

Sans signe de votre part pendant vingt-et-un jours, nous vous écrivons une fois
pour vous le demander ; sans réponse sous sept jours, votre projet cesse d'être
proposé aux ateliers. Vous pouvez le réactiver depuis la même page.

Le lien de cette page contient un jeton aléatoire qui ne donne accès qu'à votre
seul projet et n'est jamais communiqué aux ateliers. Il n'y a ni compte, ni mot de
passe à créer.

Lorsqu'un atelier nous signale un échange resté sans suite, nous pouvons vous
poser une question unique à ce sujet. Votre réponse, ou votre silence, n'a aucune
conséquence pour vous et ne donne lieu à aucun frais.

## 7. Sécurité

Mesures mises en œuvre : chiffrement des échanges (HTTPS), clés d'API stockées
uniquement en variables d'environnement d'un service dédié, jamais dans le code
ni dans le dépôt ; authentification signée entre services ; limitation du débit
des routes sensibles ; en-têtes de sécurité stricts ; protection anti-CSRF des
formulaires ; anonymisation automatique des données expirées ; journalisation
sans donnée personnelle.

## 8. Cookies

Le service ne dépose **aucun cookie de mesure d'audience ni de publicité**. Voir
[Gestion des cookies](/legal/cookies).

## 9. Mineurs

Le service n'est pas destiné aux personnes de moins de quinze ans et ne collecte
sciemment aucune donnée les concernant.
