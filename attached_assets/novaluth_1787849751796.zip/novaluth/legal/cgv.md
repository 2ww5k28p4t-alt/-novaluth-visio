Dernière mise à jour : 27/08/2026

> **Ce document ne s'applique qu'à partir du moment où Novaluth facture un
> service.** À la date ci-dessus, aucune prestation n'est payante et aucune somme
> n'est encaissée. Les CGV doivent être publiées et acceptées **avant** le premier
> euro encaissé, et l'immatriculation (micro-entreprise ou société) doit être
> effective à ce moment-là.

## 1. Objet et champ d'application

Les présentes conditions générales de vente (CGV) régissent la fourniture, par
l'éditeur de Novaluth, de services payants destinés **aux artisans et marques
référencés** :

| Prestation | Description | Prix indicatif |
|---|---|---|
| Accès à un projet qualifié | Transmission des coordonnées d'un musicien dont le projet correspond à l'atelier, **après l'accord de ce musicien** | 9,99 à 24,99 € par projet, selon le budget annoncé par le musicien |
| Carnet d'accès prépayé | Solde d'accès, exprimé en euros, payé d'avance et utilisable uniquement sur Novaluth | 69 € (79,95 € de solde) ou 119 € (159,90 € de solde) |
| Abonnement professionnel | Tableau de bord, statistiques de fiche, outils de gestion | 19 à 29 € par mois |
| Mise en avant | Emplacement identifié « Sponsorisé », sans effet sur le classement organique | Sur devis |

Les prix sont indiqués en euros. La mention de TVA applicable est précisée sur
chaque facture (« TVA non applicable, article 293 B du CGI » en cas de franchise
en base).

**Aucun service payant n'est proposé aux musiciens.** La recherche, le dépôt d'un
projet et la consultation des fiches restent gratuits.

## 2. Ce qui est vendu, et ce qui ne l'est pas

L'objet du contrat est un **accès à une demande qualifiée** ou un **service
logiciel**. Il ne s'agit en aucun cas :

- d'une promesse d'obtenir une commande, une réponse ou un chiffre
  d'affaires ;
- d'un mandat d'agent commercial ni d'un contrat de courtage sur la vente
  d'instruments ;
- d'une prestation de conseil, de certification ou d'audit de l'atelier.

Aucune commission n'est perçue sur le prix des instruments vendus.

## 3. Commande et paiement de l'accès à un projet

La commande est passée en ligne par l'artisan, qui reconnaît avoir pris
connaissance des présentes CGV. Le paiement est traité par un prestataire de
paiement autorisé à exercer cette activité ; Novaluth ne conserve aucune donnée
bancaire et n'intermédie aucun paiement entre le musicien et l'artisan.

Pour l'accès à un projet, le paiement se déroule en deux temps :

1. **À la demande d'accès** : une **autorisation de paiement** est enregistrée sur
   le moyen de paiement de l'artisan. Aucune somme n'est débitée et aucune
   coordonnée n'est transmise. Le musicien est informé qu'un atelier souhaite lui
   répondre.
2. **À l'acceptation par le musicien** : les coordonnées sont transmises à
   l'artisan et l'autorisation est **encaissée** à ce moment-là. C'est le fait
   générateur du prix.

Si le musicien décline, signale que son projet est abandonné, ou ne répond pas
dans la **fenêtre de cinq jours** ouverte par la demande, l'autorisation est
annulée et **aucune somme n'est débitée**. Il en va de même si le musicien
clôture son projet avant d'avoir répondu. L'autorisation reste valable sept jours
au plus, délai fixé par le prestataire de paiement ; si elle expire avant
l'acceptation, elle est annulée sans débit et la demande est close.

Une facture conforme est émise pour chaque **encaissement**. Une autorisation
annulée ne donne lieu à aucune facture. Selon l'établissement bancaire de
l'artisan, une autorisation annulée peut apparaître quelques jours comme montant
en attente sur son relevé avant de disparaître : aucun débit n'intervient.

Le prix d'un accès dépend du budget maximum annoncé par le musicien dans son
projet, selon trois tranches affichées dans l'espace atelier avant toute
demande : moins de 1 500 € (9,99 €), de 1 500 € à 4 000 € inclus (15,99 €),
plus de 4 000 € (24,99 €). Lorsque le musicien n'a pas renseigné de budget, la tranche
intermédiaire s'applique. Le prix retenu est celui affiché sur le projet au
moment de la demande.

Un projet est ouvert à **trois ateliers au maximum**. Un même artisan ne peut
demander qu'un seul accès par projet. Un projet n'est proposé aux ateliers
qu'après que le musicien a confirmé son dépôt en cliquant le lien reçu par
courriel, et un seul projet peut être ouvert à la fois par adresse électronique.

### 3 bis. Carnets d'accès prépayés

L'artisan peut acheter un carnet d'accès : une somme payée d'avance, portée à un
**solde exprimé en euros** dans son espace. Le solde est majoré par rapport au
prix payé (69 € payés pour 79,95 € de solde ; 119 € payés pour 159,90 € de
solde) : c'est une remise de volume.

Chaque demande d'accès réserve sur ce solde le prix de la tranche du projet
concerné, et cette somme est rendue au solde si la demande n'aboutit pas. Le
solde n'est utilisable que pour les prestations de Novaluth. Il est valable
**vingt-quatre mois** à compter de son achat.

Le solde n'est pas reversé en argent et n'est pas transmissible à un tiers. Il
est en revanche remboursé, pour sa part non utilisée et au prorata de la somme
effectivement payée, si Novaluth interrompt le service ou supprime cette
prestation avant l'expiration du solde. Le carnet étant acheté par un
professionnel pour les besoins de son activité, l'article L. 221-3 du code de la
consommation est sans objet le concernant.

Les autres prestations (abonnement, mise en avant) sont fournies après
encaissement, selon les modalités indiquées lors de la souscription.

## 4. Droit de rétractation

Le professionnel employant cinq salariés au plus, qui souscrit à distance un
contrat dont l'objet n'entre pas dans le champ de son activité principale,
bénéficie du droit de rétractation de quatorze jours prévu par l'article
L. 221-3 du code de la consommation.

Par prudence, **Novaluth accorde contractuellement un droit de rétractation de
quatorze jours à tout artisan souscripteur**, à compter de la conclusion du
contrat, exercé par simple e-mail à contact@novaluth.com.

Pour l'accès à un projet, la prestation n'est exécutée — et le prix n'est
encaissé — qu'au moment où le musicien accepte le contact et où ses coordonnées
sont transmises. En demandant l'accès, l'artisan demande expressément que cette
exécution ait lieu dès l'accord du musicien, sans attendre la fin du délai de
rétractation, et reconnaît qu'un accès déjà transmis ne peut plus être restitué.
Tant que le musicien n'a pas répondu, l'artisan peut renoncer à sa demande depuis
son espace, sans frais : l'autorisation est alors annulée. Le reste du contrat
demeure rétractable dans les conditions ci-dessus.

## 5. Qualité du projet transmis et remboursement

Un projet est dit « qualifié » lorsqu'il comporte au minimum un budget, un type
d'instrument, une zone de livraison et une adresse de contact valide, transmise
avec le consentement explicite du musicien.

### 5.1 Ce qui n'est jamais facturé

Parce que l'encaissement n'intervient qu'à l'acceptation du musicien (article 3),
les situations suivantes ne donnent lieu à **aucun débit** et n'ont donc pas à
être remboursées :

- le musicien ne répond pas dans la fenêtre de cinq jours ;
- il décline le contact, ou signale que son projet est abandonné ;
- il clôture son projet avant d'avoir répondu ;
- l'adresse de contact s'avère invalide et la demande ne peut pas lui parvenir.

### 5.2 Remboursement d'un accès encaissé

Novaluth remplace ou rembourse un accès encaissé lorsque :

- l'adresse de contact transmise est manifestement invalide ou inexistante ;
- le projet est un doublon d'un projet déjà facturé au même artisan ;
- le projet a été déposé de façon frauduleuse ou automatisée.

### 5.3 Crédit de relance

Il reste un cas où l'artisan a payé sans rien obtenir : le musicien a accepté le
contact, puis l'échange s'est éteint. Dans ce cas, l'artisan peut demander depuis
son espace un **crédit de relance**, dans les **trente jours** suivant
l'encaissement.

Novaluth interroge alors le musicien. Si celui-ci confirme l'abandon, ou reste
sans réponse pendant **sept jours**, le crédit est accordé. Un crédit dispense du
paiement d'un prochain accès ; il n'est **jamais versé en argent**, ne se cumule
pas avec un remboursement au titre de l'article 5.2, et est accordé dans la limite
d'un crédit par tranche de quatre accès encaissés. Un crédit utilisé pour une
demande qui n'aboutit pas est restitué à l'artisan.

### 5.4 Ce qui n'ouvre pas droit à remboursement

Novaluth ne rembourse pas au motif que le musicien a changé d'avis, a choisi un
autre atelier, a repoussé son projet ou n'a pas passé commande : Novaluth vend un
accès, pas un résultat.

Demandes à adresser à contact@novaluth.com, ou depuis l'espace atelier.

## 6. Durée, résiliation

L'abonnement professionnel est mensuel, sans engagement de durée, résiliable à
tout moment depuis l'espace de l'artisan ou par e-mail, avec effet à la fin de la
période en cours. Aucun frais de résiliation n'est appliqué.

Novaluth peut suspendre ou résilier l'accès d'un artisan, après mise en demeure
restée sans effet pendant quinze jours, en cas de manquement grave : informations
sciemment inexactes, non-respect de la [charte des artisans](/legal/charte-luthier),
comportement illicite. Les sommes correspondant à une période non exécutée sont
remboursées au prorata.

## 7. Responsabilité

Novaluth répond des manquements à ses obligations dans les conditions du droit
commun. Novaluth n'est pas responsable de l'exécution du contrat de vente ou de
fabrication conclu entre l'artisan et le musicien, ni des litiges qui en
découlent.

## 8. Données personnelles

Les données transmises dans le cadre d'un projet qualifié sont communiquées au
seul artisan destinataire, sur la base du consentement explicite du musicien, et
pour la seule finalité de la prise de contact. L'artisan agit en qualité de
responsable de traitement pour l'usage qu'il en fait et s'engage à ne pas les
réutiliser à d'autres fins, notamment de prospection de masse. Voir la
[politique de confidentialité](/legal/confidentialite).

## 9. Droit applicable et litiges

Droit français. En cas de litige, une solution amiable est recherchée en
priorité. À défaut, le litige est porté devant la juridiction compétente selon
les règles de droit commun ; aucune clause du présent document n'impose une
juridiction déterminée.
