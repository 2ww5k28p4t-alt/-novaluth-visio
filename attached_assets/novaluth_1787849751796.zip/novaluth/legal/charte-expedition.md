Dernière mise à jour : 26/08/2026

Recommandations d'emballage et d'expédition proposées aux artisans référencés.
Il s'agit de **bonnes pratiques déclaratives** : elles ne créent aucune
obligation contractuelle envers Novaluth et n'apportent aucune garantie au
musicien.

## 1. Emballage recommandé

- Étui rigide adapté à l'instrument, verrouillé.
- Cordes détendues, chevalet et tête calés, protection du manche.
- Double carton avec calage, sans contact direct entre l'étui et la paroi.
- Mention « fragile » et sens de manutention indiqués.

## 2. Expédition recommandée

- Envoi avec suivi et remise contre signature.
- Assurance ad valorem couvrant la valeur réelle de l'instrument.
- Communication du numéro de suivi au client dès l'expédition.
- Photographies de l'instrument et de l'emballage avant fermeture du colis.

## 3. Réglementation des matériaux

Depuis 2019, les instruments finis contenant du palissandre sont exemptés des
formalités CITES, **à l'exception du palissandre de Rio (Dalbergia nigra)**, qui
reste inscrit à l'annexe I. À l'intérieur de l'Union européenne, aucun certificat
n'est requis. Pour une expédition hors Union européenne, un certificat de
réexportation délivré par la DREAL peut être nécessaire ; la vérification incombe
à l'expéditeur.

## 4. Ce que Novaluth affiche

Novaluth affiche uniquement, et de façon filtrable, ce que l'artisan déclare :
zones desservies, transporteur, garantie annoncée, politique de retour. Ces
informations sont reprises telles quelles.

Novaluth ne garantit ni l'expédition, ni les délais, ni l'intégrité du colis, et
n'intervient pas dans un litige de transport, qui relève de la relation entre
l'expéditeur, le transporteur et le destinataire.
