Dernière mise à jour : 27/08/2026

## 1. Les trois origines possibles

Une fiche Novaluth peut être alimentée par trois voies, et une seule fait foi.

| Voie | Ce qu'elle apporte | Statut |
|---|---|---|
| L'artisan lui-même | Tout : prix, délais, façons de travailler, description du son | **Fait foi.** Prévaut sur tout le reste |
| Le site public de l'atelier, lu à la source | Nom, ville, types d'instruments, éléments techniques écrits sur la page | Provisoire, en attente de relecture par l'artisan |
| Des publications publiques (X, Reddit) | Signal d'existence, mention d'un atelier | Provisoire, jamais publié seul |

Une information collectée sans l'artisan est marquée comme telle sur la fiche.
Dès que l'artisan reprend la main sur sa fiche, sa version remplace la nôtre.

## 2. Comment une page est lue

Avant de lire la page d'un atelier, notre serveur vérifie trois choses, dans cet
ordre, et renonce dès que l'une d'elles s'y oppose :

1. **Le fichier robots.txt du site.** S'il interdit l'accès à notre agent ou à
   tous les agents, la lecture n'a pas lieu. Aucun contournement, aucun agent
   déguisé en navigateur.
2. **L'opposition à la fouille de textes et de données**, telle que prévue par
   l'article 4 de la directive (UE) 2019/790 et par l'article L. 122-5-3 du code
   de la propriété intellectuelle. Trois signaux sont vérifiés : le fichier
   `/.well-known/tdmrep.json`, l'en-tête `X-Robots-Tag`, et les balises `noai`,
   `noimageai` et `tdm-reservation` de la page.
3. **Le rythme.** Une page par domaine et par heure au maximum, et le délai de
   politesse déclaré dans robots.txt est respecté.

Notre agent s'identifie sous le nom `NovaluthBot/1.0`, avec une adresse de
contact. Les réseaux sociaux ne sont jamais lus directement par ce moyen : leurs
conditions l'interdisent.

## 3. Ce que nous ne faisons pas

- Nous ne republions pas le texte, les photographies ni les logos d'un site
  d'atelier. L'exception de fouille de données autorise l'analyse, pas la
  reproduction. Les fiches sont rédigées par nos soins à partir d'informations
  factuelles, avec un lien vers la source.
- Nous ne reprenons pas une part significative d'un annuaire tiers : un
  producteur de base de données dispose d'un droit propre sur sa base, prévu à
  l'article L. 341-1 du code de la propriété intellectuelle.
- Nous ne collectons pas de contenus à visibilité restreinte, réservés à des
  membres ou à des personnes connectées.
- Nous n'envoyons jamais à un modèle de langage les coordonnées d'un musicien.
  Un filtre serveur retire adresses e-mail, téléphones, adresses postales, IBAN
  et identifiants de portefeuille avant tout envoi.

## 4. Vos droits, si vous êtes artisan

Un luthier exerçant en nom propre est une personne physique, même lorsque ses
coordonnées sont professionnelles. Le règlement général sur la protection des
données s'applique donc pleinement à sa fiche.

- **Être informé.** Cette page vaut information au sens de l'article 14 du
  règlement, pour les données que nous n'avons pas obtenues auprès de vous.
  Elle indique l'origine des informations et la façon dont elles sont traitées.
- **Reprendre la main.** Vous pouvez demander à devenir l'auteur de votre fiche.
  Elle passe alors sous votre contrôle éditorial.
- **Corriger.** Toute inexactitude signalée est corrigée sous quinze jours
  ouvrés, et la mention contestée est retirée immédiatement en cas de doute.
- **Vous opposer.** Vous pouvez demander le retrait complet de votre fiche, sans
  avoir à vous justifier ni à créer de compte. Le retrait est définitif et le
  domaine de votre site est ajouté à une liste d'exclusion pour éviter qu'une
  fiche ne soit reconstituée plus tard.
- **Réclamer.** Vous pouvez saisir la CNIL à tout moment.

Une seule adresse pour tout cela : contact@novaluth.com.

## 5. Base légale et durées

La constitution des fiches repose sur l'intérêt légitime, au sens de l'article
6, paragraphe 1, point f, du règlement général sur la protection des données :
rendre visibles des ateliers qui le sont peu, sans démarchage et sans notation.

- Les informations d'une fiche publiée sont conservées tant que la fiche existe.
- Une fiche candidate qui n'est pas retenue est supprimée sous six mois.
- Les motifs de refus de lecture d'une page sont conservés douze mois, pour
  pouvoir démontrer que l'opposition d'un site a bien été respectée.
- Les demandes de retrait sont conservées sans limite de durée, car c'est ce qui
  garantit qu'une fiche retirée ne revienne pas.

## 6. Prestataires techniques

La liste des prestataires effectivement utilisés, avec leur rôle, leur tarif
relevé et les réserves qui les accompagnent, figure sur la page
[Transparence sur l'usage de l'IA](/legal/ia-transparence). Elle est mise à jour
à chaque changement de prestataire.
