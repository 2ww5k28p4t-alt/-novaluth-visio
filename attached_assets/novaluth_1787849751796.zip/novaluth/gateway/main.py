"""
NOVALUTH — PASSERELLE IA (service dédié, port 8100)
===================================================

Rôle unique : détenir les clés des fournisseurs d'IA et de données, et ne
jamais les exposer. C'est le seul processus du projet qui connaît
CHUTES_API_KEY, DESEARCH_API_KEY, APEX_API_KEY, MISTRAL_API_KEY et SN13_API_KEY.

Principes de sécurité appliqués ici :
  1. Séparation des privilèges  — l'application web publique ne possède
     AUCUNE clé. Elle ne peut que demander un travail à la passerelle.
  2. Authentification HMAC-SHA256 — chaque appel entrant est signé avec un
     secret partagé (NOVALUTH_GATEWAY_SECRET) + horodatage + nonce.
     Une signature rejouée ou vieille de plus de 120 s est refusée.
  3. Liste blanche stricte — seuls les modèles et les opérations déclarés dans
     gateway/fournisseurs.py sont autorisés. Impossible d'utiliser la clé pour
     autre chose.
  4. Plafond de dépense — compteur d'appels journalier, la passerelle se coupe
     d'elle-même au-delà.
  5. Anonymisation en entrée — e-mails, téléphones, adresses postales et
     numéros longs sont retirés du texte AVANT tout envoi vers un tiers.
     Aucune donnée personnelle de musicien ne sort jamais du serveur.
  6. Journal d'audit sans secret — on journalise qui, quand, quoi, combien
     de jetons, et QUEL fournisseur a répondu. Jamais la clé, jamais le
     contenu personnel.
  7. Aucune route de lecture des secrets. La passerelle n'a pas d'endpoint
     capable de renvoyer une clé, même à un appelant authentifié.

Ce qui change avec le registre de fournisseurs
----------------------------------------------
Un numéro de sous-réseau Bittensor n'est pas une adresse stable : plusieurs
netuids ont changé de projet en 2026. Aucune route n'écrit donc un fournisseur
en dur : chaque besoin lit une CHAÎNE ORDONNÉE dans gateway/fournisseurs.py et
essaie les fournisseurs l'un après l'autre. Si aucun ne répond, l'appelant
reçoit une erreur propre et le site continue de fonctionner sans IA.

Lancement local :  python gateway/main.py
En production   : Repl séparé, privé, non indexé, seul détenteur des Secrets.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import re
import sqlite3
import time
import datetime as dt
from pathlib import Path
from typing import Any

import httpx
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

try:                                    # exécution en module (uvicorn gateway.main)
    from gateway import fournisseurs, moisson
except ImportError:                     # exécution directe (python gateway/main.py)
    import fournisseurs                 # type: ignore[no-redef]
    import moisson                      # type: ignore[no-redef]

# --------------------------------------------------------------------------- #
# 1. Configuration — tout vient de l'environnement, rien n'est écrit en dur
# --------------------------------------------------------------------------- #

GATEWAY_SECRET = os.environ.get("NOVALUTH_GATEWAY_SECRET", "")

# Liste blanche des sources de collecte sociale.
SOURCES_AUTORISEES = {"x", "reddit", "youtube"}

# Plafonds anti-dérive (protègent le portefeuille autant que la clé)
PLAFOND_APPELS_IA_JOUR = int(os.environ.get("PLAFOND_APPELS_IA_JOUR", "200"))
PLAFOND_APPELS_SN13_JOUR = int(os.environ.get("PLAFOND_APPELS_SN13_JOUR", "20"))
PLAFOND_RECHERCHES_JOUR = int(os.environ.get("PLAFOND_RECHERCHES_JOUR", "100"))
PLAFOND_PAGES_JOUR = int(os.environ.get("PLAFOND_PAGES_JOUR", "150"))
FENETRE_SIGNATURE_S = 120
MAX_CORPS_OCTETS = 200_000

RACINE = Path(__file__).resolve().parent
DB_AUDIT = RACINE / "audit_passerelle.db"

app = FastAPI(
    title="Novaluth — Passerelle IA",
    description="Service interne. Détient les clés des fournisseurs d'IA et de "
                "données. Aucune route publique, aucune interface.",
    docs_url=None,          # pas de /docs : la passerelle n'est pas explorable
    redoc_url=None,
    openapi_url=None,
)


# --------------------------------------------------------------------------- #
# 2. Journal d'audit
# --------------------------------------------------------------------------- #

def _db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_AUDIT)
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS audit(
            id INTEGER PRIMARY KEY,
            horodatage TEXT NOT NULL,
            appelant TEXT,
            operation TEXT,
            cible TEXT,
            statut INTEGER,
            duree_ms INTEGER,
            jetons INTEGER,
            note TEXT
        );
        CREATE TABLE IF NOT EXISTS compteurs(
            jour TEXT NOT NULL,
            operation TEXT NOT NULL,
            n INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY (jour, operation)
        );
        CREATE TABLE IF NOT EXISTS nonces(
            nonce TEXT PRIMARY KEY,
            vu_a INTEGER NOT NULL
        );
        """
    )
    return conn


def journaliser(appelant: str, operation: str, cible: str, statut: int,
                duree_ms: int, jetons: int = 0, note: str = "") -> None:
    """Journalise un appel. Ne reçoit jamais de secret ni de donnée personnelle."""
    with _db() as conn:
        conn.execute(
            "INSERT INTO audit(horodatage,appelant,operation,cible,statut,duree_ms,jetons,note)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (dt.datetime.now(dt.timezone.utc).isoformat(), appelant, operation,
             cible, statut, duree_ms, jetons, note[:300]),
        )


def incrementer_et_verifier(operation: str, plafond: int) -> int:
    jour = dt.date.today().isoformat()
    with _db() as conn:
        conn.execute(
            "INSERT INTO compteurs(jour,operation,n) VALUES(?,?,1) "
            "ON CONFLICT(jour,operation) DO UPDATE SET n = n + 1",
            (jour, operation),
        )
        n = conn.execute(
            "SELECT n FROM compteurs WHERE jour=? AND operation=?", (jour, operation)
        ).fetchone()[0]
    if n > plafond:
        raise HTTPException(429, f"Plafond journalier atteint pour {operation} "
                                 f"({plafond}). Reprise demain.")
    return n


def nonce_deja_vu(nonce: str) -> bool:
    maintenant = int(time.time())
    with _db() as conn:
        conn.execute("DELETE FROM nonces WHERE vu_a < ?", (maintenant - 600,))
        deja = conn.execute("SELECT 1 FROM nonces WHERE nonce=?", (nonce,)).fetchone()
        if deja:
            return True
        conn.execute("INSERT INTO nonces(nonce,vu_a) VALUES(?,?)", (nonce, maintenant))
    return False


# --------------------------------------------------------------------------- #
# 3. Authentification HMAC des appelants internes
# --------------------------------------------------------------------------- #

def signature_attendue(corps: bytes, horodatage: str, nonce: str) -> str:
    message = horodatage.encode() + b"." + nonce.encode() + b"." + corps
    return hmac.new(GATEWAY_SECRET.encode(), message, hashlib.sha256).hexdigest()


async def verifier_appelant(request: Request) -> tuple[bytes, str]:
    if not GATEWAY_SECRET or len(GATEWAY_SECRET) < 32:
        raise HTTPException(500, "NOVALUTH_GATEWAY_SECRET absent ou trop court "
                                "(32 caractères minimum).")
    corps = await request.body()
    if len(corps) > MAX_CORPS_OCTETS:
        raise HTTPException(413, "Corps de requête trop volumineux.")

    horodatage = request.headers.get("x-novaluth-timestamp", "")
    nonce = request.headers.get("x-novaluth-nonce", "")
    signature = request.headers.get("x-novaluth-signature", "")
    appelant = request.headers.get("x-novaluth-client", "inconnu")[:40]

    if not (horodatage and nonce and signature):
        raise HTTPException(401, "Requête non signée.")
    try:
        ecart = abs(time.time() - float(horodatage))
    except ValueError:
        raise HTTPException(401, "Horodatage invalide.")
    if ecart > FENETRE_SIGNATURE_S:
        raise HTTPException(401, "Signature expirée.")
    if not hmac.compare_digest(signature, signature_attendue(corps, horodatage, nonce)):
        raise HTTPException(401, "Signature invalide.")
    if nonce_deja_vu(nonce):
        raise HTTPException(401, "Rejeu détecté.")
    return corps, appelant


# --------------------------------------------------------------------------- #
# 4. Anonymisation — barrière RGPD avant tout envoi vers un tiers
# --------------------------------------------------------------------------- #

MOTIFS_PII = [
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.]{2,}"), "[email retiré]"),
    (re.compile(r"(?:(?:\+|00)\d{1,3}[\s.-]?)?(?:\d[\s.-]?){9,13}"), "[téléphone retiré]"),
    (re.compile(r"\b\d{1,4}\s+(?:rue|avenue|av\.|boulevard|bd|impasse|chemin|route|place)\b[^,\n]{0,60}",
                re.I), "[adresse retirée]"),
    (re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b"), "[IBAN retiré]"),
    (re.compile(r"\b(?:0x[a-fA-F0-9]{40})\b"), "[adresse crypto retirée]"),
]


def anonymiser(texte: str) -> tuple[str, int]:
    """Retire toute donnée directement identifiante. Retourne (texte, nb_retraits)."""
    retraits = 0
    for motif, remplacement in MOTIFS_PII:
        texte, n = motif.subn(remplacement, texte)
        retraits += n
    return texte, retraits


# --------------------------------------------------------------------------- #
# 5. Schémas d'entrée — l'appelant ne choisit ni l'URL, ni la clé, ni le
#    fournisseur. Il déclare un BESOIN, la passerelle choisit et bascule.
# --------------------------------------------------------------------------- #

class DemandeIA(BaseModel):
    """Travail d'extraction ou de rédaction confié à la chaîne d'inférence."""
    systeme: str = Field(min_length=1, max_length=8000)
    utilisateur: str = Field(min_length=1, max_length=12000)
    modele: str | None = None
    temperature: float = Field(default=0.1, ge=0.0, le=1.0)
    max_tokens: int = Field(default=900, ge=32, le=4000)
    outil: dict[str, Any] | None = None   # schéma de function calling optionnel


class DemandeCollecte(BaseModel):
    """Collecte de mentions publiques via la chaîne de collecte sociale."""
    source: str
    mots_cles: list[str] = Field(min_length=1, max_length=12)
    jours: int = Field(default=3, ge=1, le=30)
    limite: int = Field(default=300, ge=10, le=1000)


class DemandeRecherche(BaseModel):
    """Recherche d'adresses de pages. Ne renvoie jamais un contenu à republier."""
    requete: str = Field(min_length=3, max_length=300)
    limite: int = Field(default=10, ge=1, le=30)


class DemandePage(BaseModel):
    """Lecture d'une page publique, robots.txt et opposition à la fouille respectés."""
    url: str = Field(min_length=8, max_length=2000)


# --------------------------------------------------------------------------- #
# 6. Chaîne de secours — le cœur du dispositif
# --------------------------------------------------------------------------- #

def _fournisseurs_pour(besoin: str, exiger_modele: str | None = None
                       ) -> list[fournisseurs.Fournisseur]:
    liste = fournisseurs.disponibles(besoin)
    if exiger_modele:
        liste = [f for f in liste if exiger_modele in f.modeles]
    return liste


async def _essayer_inference(f: fournisseurs.Fournisseur, charge: dict[str, Any]
                             ) -> httpx.Response:
    async with httpx.AsyncClient(timeout=120) as client:
        return await client.post(f.url, headers=f.entetes(), json=charge)


# --------------------------------------------------------------------------- #
# 7. Routes
# --------------------------------------------------------------------------- #

@app.get("/sante")
def sante():
    """Vérification de vie. Ne révèle jamais si une clé est valide, seulement
    si elle est présente — utile au diagnostic sans fuite d'information."""
    return {
        "service": "novaluth-passerelle",
        "cles_presentes": {
            f.cle: f.configure
            for besoin in fournisseurs.BESOINS
            for f in fournisseurs.chaine(besoin)
            if f.cle != "directe"
        },
        "secret_interne": len(GATEWAY_SECRET) >= 32,
        "modeles_autorises": sorted(fournisseurs.modeles_autorises()),
        "chaines_actives": {
            besoin: [f.cle for f in fournisseurs.disponibles(besoin)]
            for besoin in fournisseurs.BESOINS
        },
        "plafonds": {
            "ia_par_jour": PLAFOND_APPELS_IA_JOUR,
            "collecte_par_jour": PLAFOND_APPELS_SN13_JOUR,
            "recherches_par_jour": PLAFOND_RECHERCHES_JOUR,
            "pages_par_jour": PLAFOND_PAGES_JOUR,
        },
    }


@app.get("/v1/etat")
def etat():
    """État complet de la chaîne technique, sans aucun secret.

    C'est cette vue qui alimente la page publique de transparence : le visiteur
    y lit quels fournisseurs sont déclarés, à quel tarif, sous quelle licence,
    avec quelle réserve, et lesquels sont réellement actifs aujourd'hui.
    """
    donnees = fournisseurs.etat_public()
    donnees["actifs"] = {
        besoin: [f.cle for f in fournisseurs.disponibles(besoin)]
        for besoin in fournisseurs.BESOINS
    }
    return donnees


@app.post("/v1/ia")
async def appel_ia(request: Request):
    corps_brut, appelant = await verifier_appelant(request)
    try:
        demande = DemandeIA(**json.loads(corps_brut))
    except Exception as e:
        raise HTTPException(422, f"Demande invalide : {e}")

    if demande.modele and demande.modele not in fournisseurs.modeles_autorises():
        raise HTTPException(403, f"Modèle non autorisé : {demande.modele}")

    candidats = _fournisseurs_pour("inference", demande.modele)
    if not candidats:
        raise HTTPException(503, "Aucun fournisseur d'inférence configuré.")

    incrementer_et_verifier("ia", PLAFOND_APPELS_IA_JOUR)

    texte_propre, retraits = anonymiser(demande.utilisateur)
    systeme_propre, _ = anonymiser(demande.systeme)

    echecs: list[str] = []
    for f in candidats:
        modele = demande.modele or (f.modeles[0] if f.modeles else "")
        if not modele:
            continue
        charge: dict[str, Any] = {
            "model": modele,
            "temperature": demande.temperature,
            "max_tokens": demande.max_tokens,
            "messages": [
                {"role": "system", "content": systeme_propre},
                {"role": "user", "content": texte_propre},
            ],
        }
        if demande.outil:
            charge["tools"] = [{"type": "function", "function": demande.outil}]
            charge["tool_choice"] = {
                "type": "function",
                "function": {"name": demande.outil.get("name", "")},
            }

        debut = time.perf_counter()
        try:
            reponse = await _essayer_inference(f, charge)
        except httpx.HTTPError as e:
            duree = int((time.perf_counter() - debut) * 1000)
            journaliser(appelant, "ia", f"{f.cle}:{modele}", 502, duree, 0,
                        f"injoignable {type(e).__name__}")
            echecs.append(f.cle)
            continue

        duree = int((time.perf_counter() - debut) * 1000)
        if reponse.status_code >= 400:
            # On ne renvoie jamais le corps d'erreur brut du fournisseur : il
            # peut contenir un écho d'en-tête d'authentification.
            journaliser(appelant, "ia", f"{f.cle}:{modele}", reponse.status_code,
                        duree, 0, "erreur amont")
            echecs.append(f.cle)
            continue

        try:
            donnees = reponse.json()
        except ValueError:
            journaliser(appelant, "ia", f"{f.cle}:{modele}", 502, duree, 0,
                        "réponse illisible")
            echecs.append(f.cle)
            continue

        jetons = int((donnees.get("usage") or {}).get("total_tokens") or 0)
        journaliser(appelant, "ia", f"{f.cle}:{modele}", 200, duree, jetons,
                    f"pii_retirees={retraits} secours={len(echecs)}")

        message = (donnees.get("choices") or [{}])[0].get("message", {})
        resultat: dict[str, Any] = {"contenu": message.get("content")}
        appels_outil = message.get("tool_calls") or []
        if appels_outil:
            try:
                resultat["arguments"] = json.loads(
                    appels_outil[0]["function"]["arguments"])
            except Exception:
                resultat["arguments"] = None
        resultat["jetons"] = jetons
        resultat["pii_retirees"] = retraits
        resultat["fournisseur"] = f.cle
        resultat["netuid"] = f.netuid
        resultat["secours"] = echecs
        return resultat

    raise HTTPException(502, "Aucun fournisseur d'inférence n'a répondu "
                             f"({', '.join(echecs) or 'aucun candidat'}).")


@app.post("/v1/recherche")
async def appel_recherche(request: Request):
    """Trouve des ADRESSES de pages, pas du contenu.

    La distinction n'est pas cosmétique : les conditions du fournisseur de
    recherche interdisent de reproduire ou de diffuser son contenu sans
    autorisation écrite. On ne conserve donc que l'adresse, le titre et un
    extrait court servant uniquement à décider s'il faut aller lire la page à
    la source. Ce qui sera publié plus tard vient de la lecture directe.
    """
    corps_brut, appelant = await verifier_appelant(request)
    try:
        demande = DemandeRecherche(**json.loads(corps_brut))
    except Exception as e:
        raise HTTPException(422, f"Demande invalide : {e}")

    candidats = _fournisseurs_pour("recherche")
    if not candidats:
        raise HTTPException(503, "Aucun fournisseur de recherche configuré.")

    incrementer_et_verifier("recherche", PLAFOND_RECHERCHES_JOUR)

    echecs: list[str] = []
    for f in candidats:
        if f.cle == "desearch":
            charge = {"query": demande.requete, "num": demande.limite,
                      "start": 1}
        else:
            charge = {"search_query": demande.requete, "n_results": demande.limite}

        debut = time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=90) as client:
                reponse = await client.post(f.url, headers=f.entetes(), json=charge)
        except httpx.HTTPError as e:
            journaliser(appelant, "recherche", f.cle, 502,
                        int((time.perf_counter() - debut) * 1000), 0,
                        f"injoignable {type(e).__name__}")
            echecs.append(f.cle)
            continue

        duree = int((time.perf_counter() - debut) * 1000)
        if reponse.status_code >= 400:
            journaliser(appelant, "recherche", f.cle, reponse.status_code, duree,
                        0, "erreur amont")
            echecs.append(f.cle)
            continue

        try:
            brut = reponse.json()
        except ValueError:
            echecs.append(f.cle)
            continue

        resultats = _normaliser_recherche(brut)[: demande.limite]
        journaliser(appelant, "recherche", f.cle, 200, duree, 0,
                    f"{len(resultats)} adresses")
        return {"resultats": resultats, "nombre": len(resultats),
                "fournisseur": f.cle, "netuid": f.netuid, "secours": echecs}

    raise HTTPException(502, "Aucun fournisseur de recherche n'a répondu "
                             f"({', '.join(echecs)}).")


def _normaliser_recherche(brut: Any) -> list[dict[str, str]]:
    """Ramène des formats de réponse différents à trois champs et rien de plus.

    On coupe volontairement l'extrait à 300 caractères : il sert à trier, pas à
    être publié.
    """
    if isinstance(brut, dict):
        for cle in ("data", "results", "organic_results", "web"):
            if isinstance(brut.get(cle), list):
                brut = brut[cle]
                break
    if not isinstance(brut, list):
        return []
    sortie: list[dict[str, str]] = []
    vus: set[str] = set()
    for element in brut:
        if not isinstance(element, dict):
            continue
        url = str(element.get("link") or element.get("url") or "").strip()
        if not url.startswith("http") or url in vus:
            continue
        vus.add(url)
        sortie.append({
            "url": url,
            "titre": str(element.get("title") or "")[:200],
            "extrait": str(element.get("snippet") or element.get("description")
                           or "")[:300],
        })
    return sortie


@app.post("/v1/page")
async def appel_page(request: Request):
    """Lit une page publique, ou refuse en expliquant pourquoi.

    Le refus est une réponse normale, pas une panne : robots.txt et les
    réservations de fouille de données sont respectés sans exception, et le
    motif exact est renvoyé pour pouvoir être montré à l'artisan.
    """
    corps_brut, appelant = await verifier_appelant(request)
    try:
        demande = DemandePage(**json.loads(corps_brut))
    except Exception as e:
        raise HTTPException(422, f"Demande invalide : {e}")

    if not fournisseurs.disponibles("lecture"):
        raise HTTPException(503, "Aucun fournisseur de lecture configuré.")

    incrementer_et_verifier("page", PLAFOND_PAGES_JOUR)

    debut = time.perf_counter()
    try:
        resultat = moisson.lire(demande.url)
    except moisson.LectureRefusee as e:
        duree = int((time.perf_counter() - debut) * 1000)
        journaliser(appelant, "page", "directe", 200, duree, 0, f"refus : {e}")
        return {"lue": False, "motif": str(e), "url": demande.url,
                "fournisseur": "directe"}

    duree = int((time.perf_counter() - debut) * 1000)
    journaliser(appelant, "page", "directe", 200, duree, 0,
                f"{resultat['octets']} octets")
    resultat["lue"] = True
    resultat["fournisseur"] = "directe"
    return resultat


@app.post("/v1/collecte")
async def appel_collecte(request: Request):
    corps_brut, appelant = await verifier_appelant(request)
    try:
        demande = DemandeCollecte(**json.loads(corps_brut))
    except Exception as e:
        raise HTTPException(422, f"Demande invalide : {e}")

    if demande.source not in SOURCES_AUTORISEES:
        raise HTTPException(403, f"Source non autorisée : {demande.source}")

    candidats = _fournisseurs_pour("collecte")
    if not candidats:
        raise HTTPException(503, "Aucun fournisseur de collecte configuré.")

    incrementer_et_verifier("collecte", PLAFOND_APPELS_SN13_JOUR)

    debut_periode = (dt.datetime.now(dt.timezone.utc)
                     - dt.timedelta(days=demande.jours)).strftime("%Y-%m-%dT%H:%M:%SZ")

    echecs: list[str] = []
    for f in candidats:
        charge = {
            "source": demande.source,
            "keywords": demande.mots_cles,
            "limit": demande.limite,
            "start_date": debut_periode,
        }
        debut = time.perf_counter()
        try:
            async with httpx.AsyncClient(timeout=180) as client:
                reponse = await client.post(f.url, headers=f.entetes(), json=charge)
        except httpx.HTTPError as e:
            journaliser(appelant, "collecte", f"{f.cle}:{demande.source}", 502,
                        int((time.perf_counter() - debut) * 1000), 0,
                        f"injoignable {type(e).__name__}")
            echecs.append(f.cle)
            continue

        duree = int((time.perf_counter() - debut) * 1000)
        if reponse.status_code >= 400:
            journaliser(appelant, "collecte", f"{f.cle}:{demande.source}",
                        reponse.status_code, duree, 0, "erreur amont")
            echecs.append(f.cle)
            continue

        try:
            donnees = reponse.json().get("data") or []
        except ValueError:
            echecs.append(f.cle)
            continue

        journaliser(appelant, "collecte", f"{f.cle}:{demande.source}", 200, duree,
                    0, f"{len(donnees)} publications")
        return {"publications": donnees, "nombre": len(donnees),
                "fournisseur": f.cle, "netuid": f.netuid, "secours": echecs}

    raise HTTPException(502, "Aucun fournisseur de collecte n'a répondu "
                             f"({', '.join(echecs)}).")


@app.get("/v1/audit/resume")
async def resume_audit(x_novaluth_signature: str | None = Header(default=None)):
    """Résumé chiffré d'usage du jour, pour le digest Telegram. Lecture seule."""
    jour = dt.date.today().isoformat()
    with _db() as conn:
        lignes = conn.execute(
            "SELECT operation, n FROM compteurs WHERE jour=?", (jour,)
        ).fetchall()
        jetons = conn.execute(
            "SELECT COALESCE(SUM(jetons),0) FROM audit WHERE horodatage LIKE ?",
            (f"{jour}%",),
        ).fetchone()[0]
        par_fournisseur = conn.execute(
            "SELECT cible, COUNT(*) FROM audit WHERE horodatage LIKE ? AND statut=200"
            " GROUP BY cible", (f"{jour}%",),
        ).fetchall()
    return {"jour": jour, "appels": dict(lignes), "jetons": jetons,
            "par_cible": dict(par_fournisseur)}


@app.exception_handler(HTTPException)
async def erreur_propre(request: Request, exc: HTTPException):
    """Toutes les erreurs sortent normalisées : pas de trace, pas de secret."""
    return JSONResponse(status_code=exc.status_code, content={"erreur": exc.detail})


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT_PASSERELLE", 8100)))
