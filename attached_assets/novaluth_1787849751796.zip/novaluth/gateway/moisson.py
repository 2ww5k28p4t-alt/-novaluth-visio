"""
NOVALUTH — LECTURE POLIE D'UNE PAGE PUBLIQUE
============================================

Lire la page d'un atelier est un acte technique banal et un acte juridique qui ne
l'est pas. Ce module fait les deux vérifications qu'un artisan pourrait nous
reprocher de ne pas avoir faites, AVANT d'aller chercher la page :

1. **robots.txt** — si le fichier interdit l'accès à notre agent ou à tous les
   agents, on renonce. Pas de contournement, pas d'agent déguisé en navigateur.
   Le délai de politesse (`Crawl-delay`) est lu et respecté.

2. **Réservation de fouille de données** — l'exception de fouille de textes et de
   données ne s'applique pas quand le titulaire des droits s'y est opposé de
   manière lisible par une machine. Trois signaux sont vérifiés :
   `/.well-known/tdmrep.json`, l'en-tête `X-Robots-Tag`, et les balises `noai`,
   `noimageai` ou `tdm-reservation` de la page. Un seul suffit pour renoncer.

3. **Un seul passage par domaine et par heure**, quoi qu'il arrive. Un annuaire
   d'artisans n'a aucune raison de marteler le site d'un artisan.

Le texte extrait n'est jamais republié tel quel : il alimente une fiche
candidate qui doit être relue par un humain, puis proposée à l'artisan.
"""

from __future__ import annotations

import html as html_mod
import re
import time
import urllib.parse
import urllib.robotparser

import httpx

AGENT = ("NovaluthBot/1.0 (annuaire d'ateliers de lutherie ; "
         "contact@novaluth.com ; respecte robots.txt)")

DELAI_MINIMAL_S = 1.5
FENETRE_DOMAINE_S = 3600
TAILLE_MAX_OCTETS = 1_500_000

# Domaines qu'on ne lit jamais directement : leurs conditions l'interdisent, et
# une plateforme n'est de toute façon pas la source d'un artisan.
DOMAINES_REFUSES = {
    "instagram.com", "www.instagram.com", "facebook.com", "www.facebook.com",
    "x.com", "twitter.com", "www.x.com", "tiktok.com", "www.tiktok.com",
    "linkedin.com", "www.linkedin.com",
}

_derniere_visite: dict[str, float] = {}
_cache_robots: dict[str, tuple[float, urllib.robotparser.RobotFileParser | None, float]] = {}


class LectureRefusee(RuntimeError):
    """Levée quand la page ne doit pas être lue. Le motif est explicite et
    journalisé : il pourra être montré à un artisan qui demande des comptes."""


# --------------------------------------------------------------------------- #
# 1. Vérifications préalables
# --------------------------------------------------------------------------- #

def _domaine(url: str) -> str:
    return urllib.parse.urlparse(url).netloc.lower()


def _racine(url: str) -> str:
    p = urllib.parse.urlparse(url)
    return f"{p.scheme}://{p.netloc}"


def robots_autorise(url: str) -> tuple[bool, float]:
    """Retourne (autorisé, délai de politesse en secondes).

    Un robots.txt absent ou illisible vaut autorisation : c'est la lecture
    habituelle de la norme. Un robots.txt qui interdit vaut refus, sans appel.
    """
    racine = _racine(url)
    maintenant = time.time()
    en_cache = _cache_robots.get(racine)
    if en_cache and maintenant - en_cache[0] < 86400:
        lecteur, delai = en_cache[1], en_cache[2]
    else:
        lecteur = urllib.robotparser.RobotFileParser()
        delai = DELAI_MINIMAL_S
        try:
            reponse = httpx.get(racine + "/robots.txt", timeout=10,
                                headers={"User-Agent": AGENT},
                                follow_redirects=True)
            if reponse.status_code == 200:
                lecteur.parse(reponse.text.splitlines())
                declare = lecteur.crawl_delay(AGENT) or lecteur.crawl_delay("*")
                if declare:
                    delai = max(DELAI_MINIMAL_S, float(declare))
            else:
                lecteur = None
        except (httpx.HTTPError, ValueError):
            lecteur = None
        _cache_robots[racine] = (maintenant, lecteur, delai)

    if lecteur is None:
        return True, delai
    return bool(lecteur.can_fetch(AGENT, url)), delai


MOTIFS_RESERVE = (
    re.compile(r"<meta[^>]+name=[\"']?robots[\"']?[^>]*content=[\"'][^\"']*\bnoai\b",
               re.I),
    re.compile(r"<meta[^>]+name=[\"']?robots[\"']?[^>]*content=[\"'][^\"']*\bnoimageai\b",
               re.I),
    re.compile(r"<meta[^>]+name=[\"']?tdm-reservation[\"']?[^>]*content=[\"']\s*1",
               re.I),
)


def fouille_reservee(url: str) -> str:
    """Retourne le motif de réservation trouvé, ou une chaîne vide.

    Ne fait qu'une seule requête supplémentaire, sur le fichier de réservation
    normalisé. Les balises de page sont vérifiées ensuite, sur le corps déjà
    téléchargé, sans coût réseau supplémentaire.
    """
    try:
        reponse = httpx.get(_racine(url) + "/.well-known/tdmrep.json", timeout=8,
                            headers={"User-Agent": AGENT}, follow_redirects=True)
        if reponse.status_code == 200 and '"tdm-reservation": 1' in \
                reponse.text.replace(" ", " ").replace('"tdm-reservation":1',
                                                       '"tdm-reservation": 1'):
            return "réservation de fouille déclarée dans /.well-known/tdmrep.json"
    except httpx.HTTPError:
        pass
    return ""


def _reserve_dans_reponse(reponse: httpx.Response) -> str:
    entete = reponse.headers.get("x-robots-tag", "").lower()
    if "noai" in entete:
        return "en-tête X-Robots-Tag: noai"
    if "noindex" in entete:
        return "en-tête X-Robots-Tag: noindex"
    for motif in MOTIFS_RESERVE:
        if motif.search(reponse.text[:20000]):
            return "balise de réservation dans la page"
    return ""


# --------------------------------------------------------------------------- #
# 2. Extraction du texte
# --------------------------------------------------------------------------- #

_BLOCS_A_JETER = re.compile(
    r"<(script|style|noscript|svg|template|iframe)\b.*?</\1>", re.I | re.S)
_BALISES = re.compile(r"<[^>]+>")
_ESPACES = re.compile(r"[ \t\r\f\v]+")
_LIGNES = re.compile(r"\n{3,}")


def texte_lisible(html: str, limite: int = 12000) -> str:
    """HTML → texte, sans dépendance externe et sans exécuter quoi que ce soit."""
    sans_script = _BLOCS_A_JETER.sub(" ", html)
    avec_sauts = re.sub(r"</(p|div|li|h[1-6]|tr|section|article|br)\s*>", "\n",
                        sans_script, flags=re.I)
    brut = _BALISES.sub(" ", avec_sauts)
    propre = html_mod.unescape(brut)
    propre = _ESPACES.sub(" ", propre)
    propre = "\n".join(ligne.strip() for ligne in propre.split("\n"))
    propre = _LIGNES.sub("\n\n", propre).strip()
    return propre[:limite]


def titre_de(html: str) -> str:
    m = re.search(r"<title[^>]*>(.*?)</title>", html, re.I | re.S)
    return html_mod.unescape(_BALISES.sub("", m.group(1))).strip()[:200] if m else ""


# --------------------------------------------------------------------------- #
# 3. Lecture
# --------------------------------------------------------------------------- #

def lire(url: str) -> dict[str, object]:
    """Lit une page publique, ou refuse en expliquant pourquoi.

    Retourne {url, url_finale, titre, texte, octets, motif_delai}.
    Lève LectureRefusee avec un motif lisible dans tous les cas de refus.
    """
    partie = urllib.parse.urlparse(url)
    if partie.scheme not in ("http", "https"):
        raise LectureRefusee("seules les adresses http et https sont lues")
    domaine = _domaine(url)
    if not domaine:
        raise LectureRefusee("adresse sans domaine")
    if domaine in DOMAINES_REFUSES:
        raise LectureRefusee(
            f"{domaine} n'est pas lu directement : les conditions de la "
            f"plateforme l'interdisent, et une plateforme n'est pas la source "
            f"de l'artisan")

    maintenant = time.time()
    precedente = _derniere_visite.get(domaine)
    if precedente and maintenant - precedente < FENETRE_DOMAINE_S:
        reste = int(FENETRE_DOMAINE_S - (maintenant - precedente))
        raise LectureRefusee(
            f"{domaine} a déjà été lu il y a moins d'une heure "
            f"(nouvelle lecture possible dans {reste} s)")

    autorise, delai = robots_autorise(url)
    if not autorise:
        raise LectureRefusee(f"robots.txt de {domaine} interdit cette lecture")

    reserve = fouille_reservee(url)
    if reserve:
        raise LectureRefusee(f"{domaine} : {reserve}")

    time.sleep(min(delai, 5.0))
    try:
        reponse = httpx.get(url, timeout=25, follow_redirects=True,
                            headers={"User-Agent": AGENT,
                                     "Accept": "text/html,application/xhtml+xml"})
    except httpx.HTTPError as e:
        raise LectureRefusee(f"page injoignable ({type(e).__name__})") from e

    _derniere_visite[domaine] = time.time()

    if reponse.status_code >= 400:
        raise LectureRefusee(f"la page a répondu {reponse.status_code}")
    type_contenu = reponse.headers.get("content-type", "")
    if "html" not in type_contenu and "text" not in type_contenu:
        raise LectureRefusee(f"contenu non textuel ({type_contenu or 'inconnu'})")
    if len(reponse.content) > TAILLE_MAX_OCTETS:
        raise LectureRefusee("page trop volumineuse")

    reserve = _reserve_dans_reponse(reponse)
    if reserve:
        raise LectureRefusee(f"{domaine} : {reserve}")

    html = reponse.text
    return {
        "url": url,
        "url_finale": str(reponse.url),
        "titre": titre_de(html),
        "texte": texte_lisible(html),
        "octets": len(reponse.content),
        "delai_respecte_s": round(min(delai, 5.0), 2),
    }
