"""
NOVALUTH — REGISTRE DES FOURNISSEURS D'IA ET DE DONNÉES
=======================================================

Un seul endroit décrit QUI fait QUOI, à quel prix, sous quelle licence, et avec
quelle source vérifiable. Le reste de la passerelle ne fait que lire ce registre.

Pourquoi ce fichier existe
--------------------------
Un netuid Bittensor n'est pas une adresse stable : un sous-réseau peut être
vendu, renommé ou privé d'émissions d'une semaine à l'autre. Relevé du
27/08/2026 : le subnet 5 n'est plus OpenKaito, le 19 n'est plus Nineteen, le 27
n'est plus Neural Internet, le 42 n'affiche plus de nom, le 45 n'est plus Gen42.
Un projet qui écrit « subnet 19 » en dur dans son code se casse sans prévenir.

Conséquence de conception : chaque BESOIN (inférence, recherche, lecture de page,
collecte sociale) est déclaré avec une CHAÎNE ORDONNÉE de fournisseurs. Le
premier qui répond gagne. Si le premier disparaît, le suivant prend le relais
sans modification de code, et l'application continue de fonctionner même quand
tous échouent — c'est la règle du projet : aucune fonctionnalité ne dépend d'un
sous-réseau.

Aucune clé n'est écrite ici. Seulement le NOM de la variable d'environnement qui
la porte, et cette variable n'est lue que dans ce processus.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field


# --------------------------------------------------------------------------- #
# 1. Description d'un fournisseur
# --------------------------------------------------------------------------- #

@dataclass(frozen=True)
class Fournisseur:
    """Un fournisseur pour un besoin donné.

    cle          identifiant court utilisé dans les journaux d'audit
    nom          nom lisible, affiché dans la page de transparence
    reseau       "bittensor" ou "classique"
    netuid       numéro du sous-réseau, None hors Bittensor
    url          endpoint appelé
    variable_cle nom de la variable d'environnement contenant la clé
    entete       "bearer" | "x-api-key" | "authorization-brut"
    tarif        prix relevé, en clair, avec sa date de relevé
    source       URL de la page qui énonce le tarif ou les conditions
    licence      licence du code du sous-réseau, quand elle est publiée
    reserve      réserve juridique ou opérationnelle connue, sinon ""
    """
    cle: str
    nom: str
    reseau: str
    netuid: int | None
    url: str
    variable_cle: str
    entete: str
    tarif: str
    source: str
    licence: str = "n.a."
    reserve: str = ""
    modeles: tuple[str, ...] = field(default_factory=tuple)

    @property
    def configure(self) -> bool:
        """Vrai si la clé est présente dans l'environnement de la passerelle."""
        return bool(os.environ.get(self.variable_cle, "").strip())

    def cle_api(self) -> str:
        return os.environ.get(self.variable_cle, "").strip()

    def entetes(self) -> dict[str, str]:
        valeur = self.cle_api()
        if self.entete == "bearer":
            return {"Authorization": f"Bearer {valeur}", "Content-Type": "application/json"}
        if self.entete == "x-api-key":
            return {"X-API-KEY": valeur, "Content-Type": "application/json"}
        return {"Authorization": valeur, "Content-Type": "application/json"}

    def public(self) -> dict[str, object]:
        """Vue exposable : jamais la clé, seulement sa présence."""
        return {
            "cle": self.cle,
            "nom": self.nom,
            "reseau": self.reseau,
            "netuid": self.netuid,
            "tarif": self.tarif,
            "source": self.source,
            "licence": self.licence,
            "reserve": self.reserve,
            "configure": self.configure,
        }


# --------------------------------------------------------------------------- #
# 2. Inférence — écrire et extraire du texte structuré
# --------------------------------------------------------------------------- #
# Relevé du 27/08/2026 : Chutes est le seul sous-réseau à réunir une grille
# tarifaire complète, un paiement par carte, une API compatible OpenAI et une
# clause autorisant explicitement la production — à condition d'être au paiement
# à l'usage et non à l'abonnement. Les abonnements y sont réservés à l'usage
# personnel.
# Apex (subnet 1) est conservé en second : même interface, mais tarif contradictoire
# entre deux pages officielles et 4 mineurs actifs seulement. Bon secours,
# mauvais chemin principal.
# Mistral ferme la chaîne : facturation européenne classique, tarif stable. C'est
# le filet qui évite qu'une panne de sous-réseau devienne une panne de site.

INFERENCE: tuple[Fournisseur, ...] = (
    Fournisseur(
        cle="chutes",
        nom="Chutes — subnet 64 du réseau Bittensor",
        reseau="bittensor",
        netuid=64,
        url="https://llm.chutes.ai/v1/chat/completions",
        variable_cle="CHUTES_API_KEY",
        entete="bearer",
        tarif="0,0245 $ / 0,0978 $ par million de jetons (Mistral-Nemo) "
              "à 3,00 $ / 15,00 $ (Kimi-K3) — relevé du 27/08/2026",
        source="https://chutes.ai/pricing",
        licence="MIT",
        reserve="Le paiement à l'usage est obligatoire : les abonnements "
                "excluent les applications en production.",
        modeles=(
            "deepseek-ai/DeepSeek-V3-0324",
            "Qwen/Qwen3-32B-TEE",
            "mistralai/Mistral-Nemo-Instruct-2407-TEE",
        ),
    ),
    Fournisseur(
        cle="apex",
        nom="Apex — subnet 1 du réseau Bittensor (Macrocosmos)",
        reseau="bittensor",
        netuid=1,
        url="https://sn1.api.macrocosmos.ai/v1/chat/completions",
        variable_cle="APEX_API_KEY",
        entete="bearer",
        tarif="2 $ par million de jetons annoncés sur la page produit, "
              "gratuité annoncée en bêta sur la FAQ — relevé du 27/08/2026",
        source="https://docs.macrocosmos.ai/developers/api-documentation/sn1-apex/endpoints",
        licence="MIT",
        reserve="Deux pages officielles donnent deux tarifs différents, et "
                "4 mineurs seulement étaient actifs au relevé. Secours, pas socle.",
        modeles=("apex-1",),
    ),
    Fournisseur(
        cle="mistral",
        nom="Mistral AI (hors Bittensor, facturation européenne)",
        reseau="classique",
        netuid=None,
        url="https://api.mistral.ai/v1/chat/completions",
        variable_cle="MISTRAL_API_KEY",
        entete="bearer",
        tarif="0,5 $ / 1,5 $ par million de jetons (Mistral Large) "
              "— relevé du 27/08/2026",
        source="https://mistral.ai/pricing",
        licence="n.a. (service propriétaire)",
        reserve="",
        modeles=("mistral-large-latest", "mistral-small-latest"),
    ),
)


# --------------------------------------------------------------------------- #
# 3. Recherche web — trouver des ateliers qu'on ne connaît pas encore
# --------------------------------------------------------------------------- #
# Desearch est ici le meilleur rapport prix-couverture relevé : 0,10 $ pour cent
# recherches, soit dix fois moins cher que la recherche web d'un grand
# fournisseur. Sa réserve est sérieuse et elle est écrite noir sur blanc plus bas :
# ses conditions interdisent de reproduire du contenu sans autorisation écrite.
# Novaluth ne s'en sert donc QUE pour obtenir des adresses de pages, jamais pour
# republier un contenu récupéré par lui.

RECHERCHE: tuple[Fournisseur, ...] = (
    Fournisseur(
        cle="desearch",
        nom="Desearch — subnet 22 du réseau Bittensor",
        reseau="bittensor",
        netuid=22,
        url="https://api.desearch.ai/web",
        variable_cle="DESEARCH_API_KEY",
        entete="authorization-brut",
        tarif="0,10 $ pour 100 recherches web ; 0,50 $ pour 1 000 pages lues "
              "— relevé du 27/08/2026",
        source="https://www.desearch.ai/pricing",
        licence="MIT",
        reserve="Ses conditions interdisent de reproduire ou de diffuser du "
                "contenu sans autorisation écrite. Novaluth n'en retient donc "
                "que des adresses de pages, à lire ensuite à la source.",
    ),
    Fournisseur(
        cle="apex-web",
        nom="Apex — recherche web répartie, subnet 1 du réseau Bittensor",
        reseau="bittensor",
        netuid=1,
        url="https://sn1.api.macrocosmos.ai/web_retrieval",
        variable_cle="APEX_API_KEY",
        entete="bearer",
        tarif="compris dans les crédits Apex — relevé du 27/08/2026",
        source="https://docs.macrocosmos.ai/developers/api-documentation/sn1-apex/endpoints",
        licence="MIT",
        reserve="4 mineurs actifs au relevé du 27/08/2026.",
    ),
)


# --------------------------------------------------------------------------- #
# 4. Lecture d'une page — lire le site de l'atelier, à la source
# --------------------------------------------------------------------------- #
# Le premier fournisseur ici n'est pas un sous-réseau : c'est le serveur de
# Novaluth lui-même, qui va lire la page directement en respectant robots.txt et
# les réservations de fouille de données (voir moisson.py). C'est délibéré :
# lire la page publique d'un artisan à la source, sans intermédiaire, est plus
# simple à expliquer à cet artisan, moins cher, et juridiquement plus net que de
# passer par un tiers dont les conditions restreignent la réutilisation.
# Desearch reste en secours pour les pages que le serveur n'arrive pas à lire.

LECTURE: tuple[Fournisseur, ...] = (
    Fournisseur(
        cle="directe",
        nom="Lecture directe par le serveur Novaluth, robots.txt respecté",
        reseau="classique",
        netuid=None,
        url="(aucun tiers)",
        variable_cle="NOVALUTH_LECTURE_DIRECTE",
        entete="bearer",
        tarif="aucun coût par page",
        source="https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000037388886",
        licence="—",
        reserve="Refuse d'elle-même toute page interdite par robots.txt ou par "
                "une réservation de fouille de données.",
    ),
    Fournisseur(
        cle="desearch-crawl",
        nom="Desearch — lecture de page, subnet 22 du réseau Bittensor",
        reseau="bittensor",
        netuid=22,
        url="https://api.desearch.ai/web/crawl",
        variable_cle="DESEARCH_API_KEY",
        entete="authorization-brut",
        tarif="0,50 $ pour 1 000 pages — relevé du 27/08/2026",
        source="https://www.desearch.ai/pricing",
        licence="MIT",
        reserve="Utilisé seulement en secours, et jamais pour republier un "
                "contenu tel quel.",
    ),
)


# --------------------------------------------------------------------------- #
# 5. Collecte de publications sociales
# --------------------------------------------------------------------------- #
# Data Universe reste le socle : 240 mineurs actifs au relevé, facturation en
# euros, licence MIT. Sa limite est nette et il faut la connaître : X et Reddit
# uniquement. Ni Instagram, ni sites d'ateliers.
# Desearch est le seul relevé à mentionner Instagram. Il est déclaré ici mais
# laissé NON ACTIF par défaut : voir la réserve.

COLLECTE: tuple[Fournisseur, ...] = (
    Fournisseur(
        cle="sn13",
        nom="Data Universe — subnet 13 du réseau Bittensor (Macrocosmos)",
        reseau="bittensor",
        netuid=13,
        url="https://sn13.api.macrocosmos.ai/api/v1/on_demand_data_request",
        variable_cle="SN13_API_KEY",
        entete="x-api-key",
        tarif="0,10 $ pour 1 000 publications — relevé du 27/08/2026",
        source="https://docs.macrocosmos.ai/pricing",
        licence="MIT",
        reserve="Sources incitées : X et Reddit seulement.",
    ),
    Fournisseur(
        cle="desearch-social",
        nom="Desearch — publications sociales, subnet 22 du réseau Bittensor",
        reseau="bittensor",
        netuid=22,
        url="https://api.desearch.ai/twitter",
        variable_cle="DESEARCH_API_KEY",
        entete="authorization-brut",
        tarif="0,15 $ pour 1 000 publications, minimum 10 facturées par requête "
              "même sans résultat — relevé du 27/08/2026",
        source="https://www.desearch.ai/docs/guide/apis/pricing-and-billing",
        licence="MIT",
        reserve="Reste hors production tant que l'autorisation écrite de "
                "réutilisation n'est pas obtenue.",
    ),
)


# --------------------------------------------------------------------------- #
# 6. Ce que Novaluth n'utilise pas, et pourquoi
# --------------------------------------------------------------------------- #
# Écrit ici plutôt que dans une note perdue : la prochaine personne qui reprend
# ce code doit savoir ce qui a déjà été écarté, et sur quelle base.

ECARTES: tuple[dict[str, str], ...] = (
    {
        "sujet": "Vecteurs sémantiques (embeddings) sur Bittensor",
        "raison": "Aucun sous-réseau relevé n'expose d'endpoint dédié. Sur "
                  "Chutes il faudrait déployer et payer son propre GPU à "
                  "l'heure. Novaluth s'en passe : la recherche de l'annuaire "
                  "est déterministe, et c'est un choix, pas un pis-aller.",
        "source": "https://apis.io/apis/chutes/chutes-image-other-models-api/",
    },
    {
        "sujet": "Images d'instruments produites par un modèle",
        "raison": "Deux raisons. Technique : l'ancien sous-réseau image a changé "
                  "de mains et il n'existe plus d'API image branchable. "
                  "Éditoriale, et c'est la vraie : une photo d'instrument doit "
                  "montrer un instrument qui existe. Une image fabriquée sur une "
                  "fiche d'artisan serait une tromperie.",
        "source": "https://x.com/mogmachine/status/1963177686047625716",
    },
    {
        "sujet": "Subnet 71 (Leadpoet) et prospection commerciale",
        "raison": "Aucune API publique documentée, un seul mineur actif au "
                  "relevé, et surtout un objet étranger au projet : il livre des "
                  "contacts avec des signaux d'achat, quand Novaluth a besoin "
                  "d'un catalogue relu par l'artisan.",
        "source": "https://github.com/leadpoet/leadpoet/blob/main/README.md",
    },
    {
        "sujet": "Location de GPU (subnet 51, subnet 12)",
        "raison": "Louer une machine et opérer un modèle soi-même n'est pas un "
                  "service d'IA prêt à l'emploi. Hors de portée d'un projet géré "
                  "depuis un téléphone.",
        "source": "https://docs.lium.io/providers/rewards/rental-fees",
    },
)


# --------------------------------------------------------------------------- #
# 7. Accès
# --------------------------------------------------------------------------- #

BESOINS: dict[str, tuple[Fournisseur, ...]] = {
    "inference": INFERENCE,
    "recherche": RECHERCHE,
    "lecture": LECTURE,
    "collecte": COLLECTE,
}

# Fournisseurs volontairement laissés hors production, même si leur clé est
# présente. Les retirer de cet ensemble est une décision, pas un réglage.
HORS_PRODUCTION: frozenset[str] = frozenset({"desearch-social"})


def chaine(besoin: str) -> tuple[Fournisseur, ...]:
    """Chaîne complète déclarée pour un besoin, ordre de préférence conservé."""
    if besoin not in BESOINS:
        raise KeyError(f"Besoin inconnu : {besoin}")
    return BESOINS[besoin]


def disponibles(besoin: str) -> list[Fournisseur]:
    """Fournisseurs réellement utilisables : configurés et non écartés.

    La lecture directe est toujours utilisable : elle n'a pas besoin de clé.
    """
    utilisables = []
    for f in chaine(besoin):
        if f.cle in HORS_PRODUCTION:
            continue
        if f.cle == "directe" or f.configure:
            utilisables.append(f)
    return utilisables


def par_cle(cle: str) -> Fournisseur | None:
    for fournisseurs in BESOINS.values():
        for f in fournisseurs:
            if f.cle == cle:
                return f
    return None


def modeles_autorises() -> set[str]:
    """Liste blanche globale des modèles. Toute autre valeur est refusée."""
    autorises: set[str] = set()
    for f in INFERENCE:
        autorises.update(f.modeles)
    return autorises


def etat_public() -> dict[str, object]:
    """État exposable de la chaîne technique, sans aucun secret.

    Sert à la page publique de transparence et au diagnostic depuis le téléphone.
    """
    return {
        "besoins": {
            besoin: [f.public() for f in fournisseurs]
            for besoin, fournisseurs in BESOINS.items()
        },
        "hors_production": sorted(HORS_PRODUCTION),
        "ecartes": [dict(e) for e in ECARTES],
    }
