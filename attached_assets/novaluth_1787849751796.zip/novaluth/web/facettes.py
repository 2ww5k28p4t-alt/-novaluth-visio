"""
NOVALUTH — Façons de travailler (vocabulaire de recherche de l'annuaire)
=======================================================================

Ce module remplace l'ancien « niveau d'innovation sur 10 ». Le principe est
l'inverse : on ne note pas un artisan, on décrit ce qu'il fait.

Pourquoi ce changement
----------------------
Un score d'innovation sur 10 pose trois problèmes. Il est indéfendable — on ne
peut expliquer à un artisan pourquoi il est à 4 plutôt qu'à 8. Il est exposé :
publier un classement d'artisans oblige à en expliquer les paramètres, et un
luthier mal noté par une machine a un grief légitime. Et il ne sert pas à
chercher : personne ne cherche « innovation ≥ 7 », on cherche « qui travaille
des bois locaux » ou « qui fait du sans-tête ».

Une façon de travailler est donc un fait, pas un jugement :
présente ou absente, jamais une quantité, jamais un rang.

Le score reste calculé par le pipeline de veille (`pipeline/collecte.py`) pour
décider quels ateliers vous allez rechercher en priorité. Il n'est jamais
affiché sur le site public et n'est jamais un critère de tri ni de filtre.

Provenance
----------
Une façon de travailler est déduite des pages publiques de l'artisan, puis
confirmée par lui quand il relit sa fiche. Les deux états sont distingués à
l'écran : tant que la fiche n'est pas relue, l'annuaire écrit « d'après ses
pages publiques ». Voir `provenance()`.

Ajouter une façon de travailler
-------------------------------
Ajoutez une entrée dans FAMILLES. `motifs` liste des fragments de texte en
minuscules cherchés dans les champs déclaratifs de la fiche ; `regle` est une
fonction optionnelle pour les cas calculés (un diapason, une production
annuelle). Le vocabulaire est fermé volontairement : sans cela « sans tête » et
« headless » deviennent deux cases différentes et les filtres ne trouvent plus
rien.
"""

from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass, field
from typing import Callable, Iterable

from .schemas import Fiche


# --------------------------------------------------------------------------- #
# Normalisation — « Bois de réemploi » et « bois de reemploi » doivent coïncider
# --------------------------------------------------------------------------- #

def _sans_accents(texte: str) -> str:
    decompose = unicodedata.normalize("NFD", texte.lower())
    return "".join(c for c in decompose if unicodedata.category(c) != "Mn")


# Les motifs sont cherchés en MOTS ENTIERS, jamais en fragments. Sans cela
# « mat » se déclenche sur « matériau » et « lin » sur « collines » : la fiche
# d'un artisan reçoit alors une mention qu'il n'a jamais déclarée. Ce n'est pas
# une erreur théorique, elle s'est produite ici même à la première exécution.
_CACHE_MOTIFS: dict[str, re.Pattern[str]] = {}


def _expression(motif: str) -> re.Pattern[str]:
    if motif not in _CACHE_MOTIFS:
        _CACHE_MOTIFS[motif] = re.compile(
            r"(?<![\w-])" + re.escape(_sans_accents(motif)) + r"(?![\w-])")
    return _CACHE_MOTIFS[motif]


def _contient(texte: str, motif: str) -> bool:
    return _expression(motif).search(texte) is not None


@dataclass(frozen=True)
class Facon:
    cle: str
    libelle: str
    aide: str
    motifs: tuple[str, ...] = ()
    regle: Callable[[Fiche], bool] | None = field(default=None, compare=False)


# --------------------------------------------------------------------------- #
# Règles calculées
# --------------------------------------------------------------------------- #

def _diapason_court(fiche: Fiche) -> bool:
    for modele in fiche.modeles:
        d = modele.specifications.diapason_mm
        if d and modele.type == "basse" and d <= 815:
            return True
        if d and modele.type != "basse" and d <= 630:
            return True
    return False


def _personnalisation(fiche: Fiche) -> bool:
    return any(m.personnalisable for m in fiche.modeles)


def _serie_limitee(fiche: Fiche) -> bool:
    return bool(fiche.innovation.edition_limitee)


def _petite_production(fiche: Fiche) -> bool:
    return fiche.production_annuelle is not None and fiche.production_annuelle <= 20


# --------------------------------------------------------------------------- #
# Le vocabulaire
# --------------------------------------------------------------------------- #

FAMILLES: tuple[tuple[str, str, tuple[Facon, ...]], ...] = (
    ("matieres", "Matières et bois", (
        Facon("essences_locales", "Essences locales",
              "Bois achetés à des scieries proches de l'atelier.",
              ("essences locales", "bois locaux", "bois local", "circuit court",
               "essences françaises", "bois français")),
        Facon("bois_reemploi", "Bois de réemploi",
              "Bois récupérés : anciennes charpentes, mobilier, chutes d'ébénisterie.",
              ("bois de reemploi", "reemploi", "bois recycle", "recuperation",
               "bois de recuperation", "seconde vie")),
        Facon("biosource", "Matières biosourcées",
              "Lin, chanvre, résines végétales en remplacement de matériaux pétroliers.",
              ("biosource", "lin", "chanvre", "resine vegetale")),
        Facon("composite", "Carbone ou composite",
              "Structure ou renforts en fibre de carbone, lin composite, matériaux techniques.",
              ("carbone", "composite", "fibre de verre")),
        Facon("bois_thermotraite", "Bois thermotraité",
              "Bois chauffé pour le stabiliser, sans traitement chimique.",
              ("thermotraite", "thermo traite", "torrefie", "thermochauffe")),
        Facon("sans_essence_protegee", "Aucune essence protégée",
              "L'atelier déclare n'employer aucune essence menacée ou soumise à la CITES.",
              ("aucune essence protegee", "sans essence protegee", "hors cites",
               "aucune essence menacee", "sans essence menacee")),
    )),
    ("construction", "Construction", (
        Facon("sans_tete", "Sans tête (headless)",
              "Mécaniques déplacées au chevalet, instrument plus court et plus léger.",
              ("headless", "sans tete")),
        Facon("multidiapason", "Multi-diapason (multiscale)",
              "Frettes en éventail, longueur de corde différente du grave à l'aigu.",
              ("multiscale", "multi diapason", "multidiapason", "fan fret",
               "frettes en eventail", "diapason multiple")),
        Facon("table_voutee", "Table voûtée ou sculptée",
              "Table travaillée dans l'épaisseur plutôt que collée à plat : archtop, table bombée.",
              ("archtop", "table voutee", "table sculptee", "table bombee",
               "table barree en eventail")),
        Facon("modulaire", "Modulaire ou évolutif",
              "Éléments démontables ou remplaçables : micros, électronique, parfois le manche.",
              ("modulaire", "interchangeable", "evolutif")),
        Facon("diapason_court", "Diapason court",
              "Longueur de corde réduite : jeu plus souple, utile aux petites mains.",
              ("diapason court", "short scale"), _diapason_court),
        Facon("sans_frette", "Sans frette",
              "Touche lisse, courante sur les basses.",
              ("fretless", "sans frette")),
        Facon("reparable", "Pensé pour être réparé",
              "Pièces d'usure remplaçables, plans ou références disponibles.",
              ("reparable", "reparabilite", "pieces detachees", "demontable")),
    )),
    ("maniere", "Manière de travailler", (
        Facon("atelier_une_personne", "Atelier d'une seule personne",
              "Un artisan fait tout, de la découpe au réglage final.",
              ("atelier d'une personne", "seul artisan", "travaille seul",
               "une seule personne", "atelier individuel")),
        Facon("petite_production", "Vingt instruments par an au plus",
              "Production déclarée très réduite : chaque instrument reste suivi.",
              (), _petite_production),
        Facon("tout_a_la_commande", "Uniquement sur commande",
              "Rien n'est fabriqué à l'avance ; l'instrument démarre après votre accord.",
              ("tout a la commande", "sur commande", "a la commande",
               "sur mesure uniquement")),
        Facon("personnalisation_complete", "Personnalisation acceptée",
              "Bois, dimensions, électronique ou finition modifiables sur au moins un modèle.",
              ("personnalisation", "sur mesure"), _personnalisation),
        Facon("serie_limitee", "Série limitée",
              "Nombre d'exemplaires annoncé à l'avance.",
              (), _serie_limitee),
    )),
    ("finition", "Finition", (
        Facon("huile_cire", "Finition huile-cire",
              "Finition fine, réparable localement, sans film plastique.",
              ("huile cire", "huile-cire", "finition a l'huile", "cire d'abeille")),
        Facon("vernis_traditionnel", "Vernis traditionnel",
              "Gomme-laque au tampon, nitrocellulose : film mince, retouchable.",
              ("gomme laque", "gomme-laque", "nitrocellulose", "nitro",
               "vernis au tampon", "vernis a l'alcool")),
        Facon("finition_brute", "Bois laissé brut ou satiné",
              "Aucun film brillant : toucher du bois conservé.",
              ("brut", "brute", "satine", "satinee", "mat", "mate",
               "sans vernis", "non verni", "finition naturelle")),
    )),
)

FACONS: dict[str, Facon] = {
    f.cle: f for _, _, facons in FAMILLES for f in facons
}


def libelle(cle: str) -> str:
    facon = FACONS.get(cle)
    return facon.libelle if facon else cle


def libelles(cles: Iterable[str]) -> list[str]:
    return [libelle(c) for c in cles]


def normaliser(cles: Iterable[str]) -> list[str]:
    """Ne garde que les clés du vocabulaire, dans l'ordre d'affichage.

    Indispensable : les clés arrivent d'un formulaire public, donc de
    l'extérieur. Aucune clé inconnue ne doit traverser.
    """
    demandees = {c.strip() for c in cles if c and c.strip()}
    return [c for c in FACONS if c in demandees]


# --------------------------------------------------------------------------- #
# Détection à partir des champs déclaratifs de la fiche
# --------------------------------------------------------------------------- #

def _texte_declaratif(fiche: Fiche) -> str:
    morceaux: list[str] = [
        fiche.approche_artisanale or "",
        fiche.innovation.demarche_ecologique or "",
        fiche.innovation.technologie_proprietaire or "",
        " ".join(fiche.innovation.materiaux_alternatifs),
        " ".join(fiche.innovation.marqueurs),
        " ".join(fiche.ia.tags),
        " ".join(fiche.ia.mots_cles),
    ]
    for modele in fiche.modeles:
        s = modele.specifications
        morceaux += [modele.nom, modele.inspiration or "",
                     s.bois_corps or "", s.bois_manche or "", s.touche or "",
                     s.chevalet or "", s.type_micros or ""]
    return _sans_accents(" · ".join(m for m in morceaux if m))


def facons_de(fiche: Fiche) -> list[str]:
    """Façons de travailler qu'on peut rattacher à cette fiche."""
    texte = _texte_declaratif(fiche)
    trouvees: list[str] = []
    for cle, facon in FACONS.items():
        touche = any(_contient(texte, m) for m in facon.motifs)
        if not touche and facon.regle is not None:
            touche = facon.regle(fiche)
        if touche:
            trouvees.append(cle)
    return trouvees


def provenance(fiche: Fiche) -> str:
    """Origine des façons affichées, à écrire à côté d'elles."""
    if fiche.valide_par_artisan:
        return "relu par l'artisan"
    return "d'après ses pages publiques"


def facons_disponibles(fiches: Iterable[Fiche]) -> set[str]:
    """Façons réellement présentes dans un lot de fiches.

    Sert à ne pas proposer une case qui ne renverrait jamais personne.
    """
    presentes: set[str] = set()
    for f in fiches:
        presentes.update(facons_de(f))
    return presentes
