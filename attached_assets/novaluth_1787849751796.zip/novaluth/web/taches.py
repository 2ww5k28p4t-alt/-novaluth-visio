"""
NOVALUTH — Tâches automatiques du circuit d'accès
=================================================

À programmer une fois par jour (Deployments → Scheduled) :

    python -m web.taches

Quatre traitements, dans cet ordre :

  1. **Accès non aboutis** — la fenêtre de réponse du musicien est écoulée, ou
     l'autorisation de carte arrive à expiration : on annule l'autorisation,
     rien n'est débité, l'atelier est prévenu.
  2. **Fraîcheur des projets** — un projet sans signe depuis trois semaines : on
     demande au musicien s'il est toujours d'actualité.
  3. **Mise en sommeil** — sans réponse à cette question, le projet n'est plus
     proposé aux ateliers.
  4. **Crédits de relance** — une vérification restée sans réponse vaut abandon :
     le crédit est accordé à l'atelier.

Chaque traitement est idempotent : relancer la tâche deux fois le même jour ne
produit ni double annulation, ni double crédit.

    python -m web.taches --simulation   affiche ce qui serait fait, sans agir
"""

from __future__ import annotations

import sys

from common.paiement import PaiementIndisponible, fournisseur

from . import courriel, store, store_acces as sa
from .acces import liberer_engagement


def expirer_acces(simulation: bool = False) -> int:
    traites = 0
    for dossier in sa.acces_expires():
        motif = "sans réponse du musicien dans le délai prévu"
        print(f"  · accès {dossier['reference']} → annulation ({motif})")
        if simulation:
            traites += 1
            continue
        liberer_engagement(dossier, motif)
        sa.clore_acces(dossier["reference"], "expire", motif)
        atelier = sa.lire_atelier(dossier["atelier_slug"])
        if atelier:
            courriel.acces_annule(atelier["email"], dossier["reference"],
                                  dossier["brief_reference"], motif)
        traites += 1
    return traites


def relancer_fraicheur(simulation: bool = False) -> int:
    traites = 0
    for brief in sa.briefs_a_relancer():
        print(f"  · projet {brief['reference']} → question de fraîcheur")
        if simulation:
            traites += 1
            continue
        jeton = sa.jeton_du_brief(brief["reference"])
        if jeton and brief.get("email"):
            courriel.relance_fraicheur(brief["email"], jeton, brief["reference"],
                                       sa.DELAI_SOMMEIL_JOURS)
            sa.marquer_relance_envoyee(brief["reference"])
            traites += 1
    return traites


def endormir_projets(simulation: bool = False) -> int:
    traites = 0
    for brief in sa.briefs_a_endormir():
        print(f"  · projet {brief['reference']} → mise en sommeil")
        if simulation:
            traites += 1
            continue
        sa.mettre_en_sommeil(brief["reference"])
        traites += 1
    return traites


def traiter_credits(simulation: bool = False) -> int:
    traites = 0
    for relance in sa.relances_echues():
        reference = relance["acces_reference"]
        print(f"  · vérification {reference} sans réponse → crédit de relance")
        if simulation:
            traites += 1
            continue
        sa.cloturer_relance(reference, "credit_accorde",
                            "sans réponse du musicien")
        sa.accorder_credit(relance["atelier_slug"],
                           "échange resté sans suite, musicien sans réponse",
                           reference)
        atelier = sa.lire_atelier(relance["atelier_slug"])
        if atelier:
            courriel.credit_accorde(atelier["email"], reference,
                                    "musicien resté sans réponse")
        traites += 1
    return traites


def executer(simulation: bool = False) -> dict[str, int]:
    store.initialiser()
    sa.initialiser()
    print("→ accès non aboutis")
    acces = expirer_acces(simulation)
    print("→ fraîcheur des projets")
    fraicheur = relancer_fraicheur(simulation)
    print("→ mise en sommeil")
    sommeil = endormir_projets(simulation)
    print("→ crédits de relance")
    credits = traiter_credits(simulation)
    resultat = {"acces_annules": acces, "questions_fraicheur": fraicheur,
                "projets_en_sommeil": sommeil, "credits_accordes": credits}
    print(f"\nBilan : {resultat}")
    if not simulation:
        store.journaliser("taches_acces", "quotidien", str(resultat))
    return resultat


if __name__ == "__main__":
    executer(simulation="--simulation" in sys.argv)
