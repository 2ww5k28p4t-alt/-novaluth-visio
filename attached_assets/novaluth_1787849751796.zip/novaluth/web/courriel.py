"""
NOVALUTH — Envoi des courriels du circuit d'accès
=================================================

Trois destinataires, jamais plus :

  · le musicien   — demande d'acceptation, relance de fraîcheur, vérification
                    avant l'octroi d'un crédit de relance ;
  · l'atelier     — lien de connexion à son espace, coordonnées transmises,
                    accès annulé, crédit accordé ;
  · l'exploitant  — rien : aucun courriel automatique ne part vers Novaluth.

Deux modes, choisis par l'environnement :

  · sans réglage SMTP → mode **écriture locale** : chaque message est écrit dans
    data/courriels/ et tracé dans le journal. Le circuit est ainsi jouable
    entièrement, y compris depuis un iPhone, sans compte d'envoi.
  · avec `NOVALUTH_SMTP_HOTE`, `NOVALUTH_SMTP_UTILISATEUR`,
    `NOVALUTH_SMTP_MOTDEPASSE` → envoi réel en SMTP + TLS.

Aucun contenu de courriel ne comporte de promesse de résultat : on décrit ce qui
s'est passé et ce que la personne peut faire.
"""

from __future__ import annotations

import datetime as dt
import os
import re
import smtplib
import ssl
from email.message import EmailMessage
from pathlib import Path

from . import store

RACINE = Path(__file__).resolve().parent.parent
DOSSIER_LOCAL = RACINE / "data" / "courriels"

EXPEDITEUR = os.environ.get("NOVALUTH_EXPEDITEUR", "contact@novaluth.com")
URL_PUBLIQUE = os.environ.get("NOVALUTH_URL", "http://127.0.0.1:8000").rstrip("/")

SMTP_HOTE = os.environ.get("NOVALUTH_SMTP_HOTE", "")
SMTP_PORT = int(os.environ.get("NOVALUTH_SMTP_PORT", "587"))
SMTP_UTILISATEUR = os.environ.get("NOVALUTH_SMTP_UTILISATEUR", "")
SMTP_MOTDEPASSE = os.environ.get("NOVALUTH_SMTP_MOTDEPASSE", "")

PIED = (
    "\n\n—\n"
    "Novaluth référence des luthiers et des marques émergentes et met les "
    "musiciens en relation avec eux.\n"
    "Novaluth n'est ni vendeur, ni fabricant, ni transporteur, ni "
    "intermédiaire de paiement : la vente, l'expédition et le paiement de "
    "l'instrument se font directement entre le musicien et l'artisan.\n"
    f"{URL_PUBLIQUE}/legal · {EXPEDITEUR}\n"
)


def envoi_reel_actif() -> bool:
    return bool(SMTP_HOTE and SMTP_UTILISATEUR and SMTP_MOTDEPASSE)


def _ecrire_localement(destinataire: str, sujet: str, corps: str) -> Path:
    DOSSIER_LOCAL.mkdir(parents=True, exist_ok=True)
    horodatage = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
    etiquette = re.sub(r"[^a-z0-9]+", "-", destinataire.lower())[:40]
    fichier = DOSSIER_LOCAL / f"{horodatage}-{etiquette}.txt"
    fichier.write_text(
        f"À : {destinataire}\nDe : {EXPEDITEUR}\nSujet : {sujet}\n\n{corps}",
        encoding="utf-8",
    )
    return fichier


def envoyer(destinataire: str, sujet: str, corps: str,
            evenement: str = "courriel") -> bool:
    """Renvoie True si le message est parti (ou a été écrit localement).
    N'interrompt jamais l'appelant : un échec d'envoi est tracé, pas fatal."""
    corps_complet = corps.rstrip() + PIED
    if not destinataire or "@" not in destinataire:
        store.journaliser(evenement, "adresse_invalide", destinataire[:80])
        return False

    if not envoi_reel_actif():
        fichier = _ecrire_localement(destinataire, sujet, corps_complet)
        store.journaliser(evenement, "ecrit_localement", fichier.name)
        return True

    message = EmailMessage()
    message["From"] = EXPEDITEUR
    message["To"] = destinataire
    message["Subject"] = sujet
    message.set_content(corps_complet)
    try:
        with smtplib.SMTP(SMTP_HOTE, SMTP_PORT, timeout=20) as serveur:
            serveur.starttls(context=ssl.create_default_context())
            serveur.login(SMTP_UTILISATEUR, SMTP_MOTDEPASSE)
            serveur.send_message(message)
    except Exception as e:  # panne d'envoi : on trace et on continue
        store.journaliser(evenement, "echec_envoi", f"{type(e).__name__}")
        return False
    store.journaliser(evenement, "envoye", destinataire.split("@")[-1])
    return True


# --------------------------------------------------------------------------- #
# Messages du circuit — un par situation
# --------------------------------------------------------------------------- #

def lien_musicien(jeton: str, suffixe: str = "") -> str:
    return f"{URL_PUBLIQUE}/projet/{jeton}{suffixe}"


def euros(cents: int) -> str:
    """Montant en euros, écrit comme en France."""
    return f"{cents / 100:.2f}".replace(".", ",") + " €"


def confirmation_projet(email: str, jeton: str, reference_projet: str) -> bool:
    """Double confirmation : le projet n'est proposé aux ateliers qu'après ce
    clic. Écarte les adresses erronées et les dépôts sans intention."""
    corps = (
        f"Bonjour,\n\n"
        f"Votre projet {reference_projet} est enregistré sur Novaluth.\n\n"
        f"Une dernière étape : confirmez qu'il est bien d'actualité, en ouvrant "
        f"cette page et en cliquant sur le bouton de confirmation.\n\n"
        f"  {lien_musicien(jeton)}\n\n"
        f"Tant que ce clic n'a pas eu lieu, votre projet n'est proposé à aucun "
        f"atelier et votre adresse reste inutilisée.\n\n"
        f"Conservez ce lien : c'est votre page de suivi. Vous y répondrez aux "
        f"ateliers qui souhaitent vous écrire, et vous pourrez clôturer votre "
        f"projet en un clic quand vous le voudrez.\n\n"
        f"Le service est gratuit pour les musiciens, sans exception."
    )
    return envoyer(email, f"Confirmez votre projet {reference_projet}",
                   corps, "courriel_confirmation_projet")


def rappel_carnet(email_atelier: str, libelle: str, paye_cents: int,
                  credit_cents: int, solde_cents: int) -> bool:
    corps = (
        f"Bonjour,\n\n"
        f"Votre {libelle} est enregistré : {euros(paye_cents)} payés, "
        f"{euros(credit_cents)} portés à votre solde d'accès.\n\n"
        f"Solde disponible : {euros(solde_cents)}.\n\n"
        f"Chaque demande d'accès est décomptée de ce solde, et vous est rendue "
        f"si le musicien ne donne pas suite.\n\n"
        f"Votre facture est disponible sur demande à contact@novaluth.com."
    )
    return envoyer(email_atelier, "Votre carnet d'accès Novaluth",
                   corps, "courriel_carnet")


def demande_acceptation(email: str, jeton: str, reference_projet: str,
                        nom_atelier: str, jours: int,
                        montant_engage_cents: int = 0) -> bool:
    corps = (
        f"Bonjour,\n\n"
        f"Vous avez déposé le projet {reference_projet} sur Novaluth.\n\n"
        f"L'atelier {nom_atelier} souhaite vous répondre.\n\n"
        f"Vos coordonnées ne lui sont pas encore transmises : rien ne part sans "
        f"votre accord. Trois réponses sont possibles depuis cette page :\n\n"
        f"  {lien_musicien(jeton)}\n\n"
        f"  · j'accepte d'être contacté par cet atelier ;\n"
        f"  · je décline pour cet atelier ;\n"
        f"  · mon projet est abandonné, je ne souhaite plus être contacté.\n\n"
        f"Sans réponse de votre part sous {jours} jours, la demande s'annule "
        f"d'elle-même et l'atelier n'est pas facturé.\n\n"
        + (f"Une précision, pour que vous sachiez ce qui se joue : cet atelier "
           f"engage {euros(montant_engage_cents)} pour obtenir vos coordonnées, "
           f"et cette somme ne lui est prélevée que si vous acceptez. Un mot de "
           f"votre part, même pour décliner, lui est utile.\n\n"
           if montant_engage_cents else "")
        +
        f"Vous ne payez rien, à aucun moment : le service est gratuit pour les "
        f"musiciens."
    )
    return envoyer(email, f"Un atelier souhaite répondre à votre projet "
                          f"{reference_projet}", corps, "courriel_acceptation")


def coordonnees_transmises(email_atelier: str, reference_acces: str,
                           reference_projet: str, email_musicien: str) -> bool:
    corps = (
        f"Bonjour,\n\n"
        f"Le musicien du projet {reference_projet} a accepté votre demande de "
        f"contact. Vos coordonnées ont été échangées et l'accès "
        f"{reference_acces} est facturé.\n\n"
        f"Adresse du musicien : {email_musicien}\n\n"
        f"Votre facture et l'historique de vos accès sont dans votre espace :\n"
        f"  {URL_PUBLIQUE}/atelier\n\n"
        f"Si l'échange reste sans suite malgré vos relances, vous pouvez "
        f"demander un crédit de relance depuis cet espace. Les conditions sont "
        f"décrites dans les conditions de vente."
    )
    return envoyer(email_atelier, f"Contact accepté — projet {reference_projet}",
                   corps, "courriel_coordonnees")


def acces_annule(email_atelier: str, reference_acces: str,
                 reference_projet: str, motif: str) -> bool:
    corps = (
        f"Bonjour,\n\n"
        f"Votre demande d'accès {reference_acces} au projet {reference_projet} "
        f"n'a pas abouti : {motif}.\n\n"
        f"L'autorisation de paiement a été annulée : aucune somme n'a été "
        f"débitée. Selon votre banque, l'empreinte affichée sur votre relevé "
        f"peut disparaître sous quelques jours.\n\n"
        f"D'autres projets correspondant à votre atelier sont visibles ici :\n"
        f"  {URL_PUBLIQUE}/atelier"
    )
    return envoyer(email_atelier, f"Accès non abouti — projet {reference_projet}",
                   corps, "courriel_acces_annule")


def relance_fraicheur(email: str, jeton: str, reference_projet: str,
                      jours_avant_sommeil: int) -> bool:
    corps = (
        f"Bonjour,\n\n"
        f"Votre projet {reference_projet} a été déposé il y a quelques "
        f"semaines. Est-il toujours d'actualité ?\n\n"
        f"  {lien_musicien(jeton)}\n\n"
        f"  · oui, je souhaite toujours recevoir des réponses d'ateliers ;\n"
        f"  · non, mon projet est terminé ou abandonné.\n\n"
        f"Sans réponse sous {jours_avant_sommeil} jours, votre projet est mis "
        f"en sommeil : plus aucun atelier ne pourra vous contacter, et vos "
        f"coordonnées restent chez nous jusqu'à leur effacement automatique. "
        f"Vous pouvez le réactiver à tout moment depuis la même page."
    )
    return envoyer(email, f"Votre projet {reference_projet} est-il toujours "
                          f"d'actualité ?", corps, "courriel_fraicheur")


def verification_avant_credit(email: str, jeton: str, reference_projet: str,
                              nom_atelier: str, jours: int) -> bool:
    corps = (
        f"Bonjour,\n\n"
        f"L'atelier {nom_atelier} nous indique que votre échange au sujet du "
        f"projet {reference_projet} est resté sans suite.\n\n"
        f"Où en êtes-vous ?\n\n"
        f"  {lien_musicien(jeton)}\n\n"
        f"  · l'échange se poursuit ;\n"
        f"  · mon projet est abandonné.\n\n"
        f"Cette question ne vous engage à rien et n'a aucune conséquence pour "
        f"vous. Sans réponse sous {jours} jours, nous considérons le projet "
        f"comme abandonné et l'atelier reçoit un crédit pour un prochain accès."
    )
    return envoyer(email, f"Votre projet {reference_projet} : où en êtes-vous ?",
                   corps, "courriel_verification")


def credit_accorde(email_atelier: str, reference_acces: str, motif: str) -> bool:
    corps = (
        f"Bonjour,\n\n"
        f"Un crédit de relance vous est accordé à la suite de l'accès "
        f"{reference_acces} ({motif}).\n\n"
        f"Ce crédit couvre le prix d'un prochain accès à un projet. Il "
        f"s'applique automatiquement à votre prochaine demande, sans rien "
        f"saisir. Il n'est pas convertible en somme d'argent.\n\n"
        f"  {URL_PUBLIQUE}/atelier"
    )
    return envoyer(email_atelier, "Un crédit de relance vous est accordé",
                   corps, "courriel_credit")


def lien_connexion_atelier(email_atelier: str, lien: str, minutes: int) -> bool:
    corps = (
        f"Bonjour,\n\n"
        f"Voici votre lien de connexion à l'espace atelier Novaluth :\n\n"
        f"  {lien}\n\n"
        f"Il est valable {minutes} minutes et ne fonctionne qu'une fois. "
        f"Si vous n'êtes pas à l'origine de cette demande, ignorez ce message : "
        f"aucun accès n'est ouvert sans clic sur ce lien."
    )
    return envoyer(email_atelier, "Votre lien de connexion Novaluth", corps,
                   "courriel_connexion")
