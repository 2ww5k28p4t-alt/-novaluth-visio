"""
NOVALUTH — Usage de l'IA côté application
=========================================

Règle du projet : l'IA ne décide jamais, elle reformule. Le classement est
produit par matching.py de façon déterministe ; le subnet 64 sert uniquement à
écrire deux phrases en français clair au-dessus du résultat.

Trois garde-fous :
  1. Aucune donnée personnelle n'est envoyée — on ne transmet que des critères
     (budget, style, zone) déjà anonymes, et la passerelle re-filtre par
     sécurité.
  2. Si la passerelle est indisponible, l'application affiche une explication
     écrite localement. Aucune fonctionnalité ne dépend d'un subnet.
  conformite:debut-liste-proscrite
  3. Le vocabulaire interdit est retiré du texte généré avant affichage
     (« garanti », « certifié », « meilleur », « je vous conseille »…).
"""

from __future__ import annotations

import re

from common.passerelle_client import PasserelleIndisponible, demander_ia

from .schemas import Brief

SYSTEME = """Tu écris pour Novaluth, un annuaire de luthiers innovants et de
marques émergentes. Tu ne vends rien et tu ne conseilles pas d'achat.

Règles absolues :
- Deux à trois phrases maximum, en français simple, sans jargon.
- Tu résumes uniquement les correspondances qui te sont fournies. Tu n'inventes
  aucun nom, aucun prix, aucun délai, aucune information technique.
- Tu n'emploies jamais les mots : garanti, certifié, meilleur, parfait, idéal,
  sûr, sécurisé, recommandé par nous, investissement.
- Tu ne promets aucun résultat, aucune qualité, aucune disponibilité.
- Tu rappelles en une demi-phrase que ces informations proviennent de sources
  publiques et restent à confirmer directement avec l'artisan.
"""
# conformite:fin-liste-proscrite

# conformite:debut-liste-proscrite
MOTS_INTERDITS = [
    "garanti", "garantie totale", "certifié", "certifiée", "le meilleur",
    "la meilleure", "parfait", "parfaite", "idéal", "idéale",
    "100 % sécurisé", "sans risque", "nous recommandons", "je vous conseille",
    "investissement", "placement",
]
# conformite:fin-liste-proscrite


def nettoyer(texte: str) -> str:
    """Retire le vocabulaire juridiquement risqué même si le modèle dérape."""
    propre = texte
    for mot in MOTS_INTERDITS:
        propre = re.sub(re.escape(mot), "[terme retiré]", propre, flags=re.I)
    return propre.strip()


def explication_locale(brief: Brief, resultats: list[dict]) -> str:
    """Repli sans IA — toujours disponible."""
    if not resultats:
        return ("Aucune fiche publiée ne correspond encore à ces critères. "
                "La base est en cours de constitution : élargissez le budget ou "
                "la zone de livraison, ou revenez dans quelques semaines.")
    noms = ", ".join(r["nom"] for r in resultats)
    return (f"{len(resultats)} fiche(s) correspondent le mieux à votre projet "
            f"({noms}), d'après le budget, le type d'instrument, la zone de "
            f"livraison et le délai que vous avez indiqués. Ces informations "
            f"proviennent de sources publiques et restent à confirmer "
            f"directement avec l'artisan.")


def resumer_correspondances(brief: Brief, resultats: list[dict]) -> tuple[str, str]:
    """Retourne (texte, origine) où origine vaut 'subnet64' ou 'local'."""
    if not resultats:
        return explication_locale(brief, resultats), "local"

    lignes = []
    for r in resultats:
        lignes.append(
            f"- {r['nom']} ({r.get('ville') or '?'}, {r.get('pays') or '?'}) : "
            f"correspondance {r['correspondance']}/100 ; "
            f"points forts : {'; '.join(r['points_correspondance'][:3]) or 'aucun documenté'} ; "
            f"vigilance : {'; '.join(r['points_vigilance'][:2]) or 'aucune'}"
        )
    contexte = (
        f"Projet du musicien (aucune donnée personnelle) : instrument "
        f"{brief.type_instrument}, budget {brief.budget_min_eur}–{brief.budget_max_eur} €, "
        f"styles {', '.join(brief.styles) or 'non précisés'}, zone "
        f"{brief.zone_preferee}, délai maximum "
        f"{brief.delai_max_mois if brief.delai_max_mois is not None else 'non précisé'} mois.\n\n"
        "Correspondances calculées :\n" + "\n".join(lignes)
    )
    try:
        reponse = demander_ia(SYSTEME, contexte, temperature=0.2, max_tokens=320)
        contenu = (reponse.get("contenu") or "").strip()
        if len(contenu) < 40:
            raise PasserelleIndisponible("réponse trop courte")
        return nettoyer(contenu), "subnet64"
    except PasserelleIndisponible:
        return explication_locale(brief, resultats), "local"
