"""
NOVALUTH — Moteur de recommandation
===================================

Déterministe, explicable, sans IA. L'IA n'intervient qu'ensuite, et seulement
pour reformuler en français clair ce que ce moteur a déjà décidé. Deux raisons :

  1. Un musicien doit pouvoir comprendre POURQUOI un artisan lui est proposé.
  2. Aucun résultat ne dépend de la disponibilité d'un subnet.

Vocabulaire imposé : on « propose » et on « explique la correspondance ».
On ne « garantit » rien, on ne « certifie » personne, on ne « conseille » pas
un achat. Voir tools/verifier_conformite.py.
"""

from __future__ import annotations

from . import facettes, sonorite
from .schemas import Brief, Fiche

# Pondération des critères. Somme = 100.
POIDS = {
    "budget": 26,
    "type_instrument": 14,
    "style": 14,
    "zone_livraison": 12,
    "delai": 10,
    "bois": 8,
    "sonorite": 8,
    "facons": 8,
}


def _chevauchement(a: list[str], b: list[str]) -> float:
    if not a or not b:
        return 0.0
    ea = {x.lower().strip() for x in a if x}
    eb = {x.lower().strip() for x in b if x}
    if not ea or not eb:
        return 0.0
    return len(ea & eb) / len(ea)


def evaluer(brief: Brief, fiche: Fiche) -> tuple[int, list[str], list[str]]:
    """Retourne (score 0-100, points de correspondance, points de vigilance)."""
    score = 0.0
    pour: list[str] = []
    contre: list[str] = []

    # --- Budget ------------------------------------------------------------ #
    prix_min = fiche.prix_min_eur
    prix_max = fiche.prix_max_eur
    if prix_min is None and prix_max is None:
        contre.append("Fourchette de prix non renseignée sur la fiche")
    else:
        bas = prix_min if prix_min is not None else 0
        haut = prix_max if prix_max is not None else bas
        if bas <= brief.budget_max_eur and haut >= brief.budget_min_eur:
            score += POIDS["budget"]
            pour.append(f"Tarifs annoncés {bas}–{haut} € compatibles avec votre budget")
        elif bas <= brief.budget_max_eur * 1.2:
            score += POIDS["budget"] * 0.4
            contre.append(f"Tarifs {bas}–{haut} € légèrement au-dessus de votre budget")
        else:
            contre.append(f"Tarifs {bas}–{haut} € au-dessus de votre budget")

    # --- Type d'instrument ------------------------------------------------- #
    types_proposes = {m.type for m in fiche.modeles}
    if brief.type_instrument in types_proposes:
        score += POIDS["type_instrument"]
        pour.append(f"Fabrique des instruments de type {brief.type_instrument}")
    elif not types_proposes:
        contre.append("Aucun modèle documenté sur la fiche")
    else:
        contre.append("Type d'instrument demandé non documenté chez cet artisan")

    # --- Styles ------------------------------------------------------------ #
    part_styles = _chevauchement(brief.styles, fiche.profil_sonore.styles)
    if part_styles:
        score += POIDS["style"] * part_styles
        communs = sorted({s.lower() for s in brief.styles}
                         & {s.lower() for s in fiche.profil_sonore.styles})
        pour.append("Styles en commun : " + ", ".join(communs))
    elif brief.styles:
        contre.append("Styles annoncés différents des vôtres")

    # --- Zone de livraison ------------------------------------------------- #
    logistique = fiche.logistique
    zone_ok = {
        "france": logistique.expedie_france,
        "europe": logistique.expedie_europe or logistique.expedie_monde,
        "monde": logistique.expedie_monde,
    }.get(brief.zone_preferee, False)
    if zone_ok:
        score += POIDS["zone_livraison"]
        pour.append(f"Expédition déclarée vers la zone {brief.zone_preferee}")
    else:
        contre.append(f"Expédition vers la zone {brief.zone_preferee} non renseignée")

    # --- Délai ------------------------------------------------------------- #
    if brief.delai_max_mois is None:
        score += POIDS["delai"] * 0.5
    elif fiche.delai_moyen_mois is None:
        contre.append("Délai de fabrication non renseigné")
    elif fiche.delai_moyen_mois <= brief.delai_max_mois:
        score += POIDS["delai"]
        pour.append(f"Délai moyen annoncé de {fiche.delai_moyen_mois} mois")
    else:
        contre.append(f"Délai moyen annoncé de {fiche.delai_moyen_mois} mois, "
                      f"au-delà de votre limite")

    # --- Bois -------------------------------------------------------------- #
    bois_fiche = [
        v for m in fiche.modeles
        for v in (m.specifications.bois_corps, m.specifications.bois_manche,
                  m.specifications.touche) if v
    ]
    part_bois = _chevauchement(brief.bois_souhaites, bois_fiche)
    if part_bois:
        score += POIDS["bois"] * part_bois
        pour.append("Essences de bois demandées présentes au catalogue")
    elif brief.bois_souhaites:
        contre.append("Essences demandées non documentées")

    # --- Sonorité ---------------------------------------------------------- #
    # Ancienne version : écart moyen entre deux notes sur 10 (« chaleur
    # souhaitée 6 » contre « chaleur annoncée 8 »), qui produisait la phrase
    # « profil sonore proche de ce que vous décrivez » sans jamais pouvoir dire
    # en quoi. Version actuelle : on compare des mots issus du même
    # vocabulaire, et on nomme l'écart quand il existe.
    proximite, pour_son, contre_son = sonorite.comparer(
        fiche.profil_sonore,
        {"couleur": brief.couleur_souhaitee,
         "attaque": brief.attaque_souhaitee,
         "tenue": brief.tenue_souhaitee},
    )
    if proximite is not None:
        score += POIDS["sonorite"] * proximite
    pour.extend(pour_son)
    contre.extend(contre_son)

    # --- Façons de travailler ---------------------------------------------- #
    # Ancienne version : proximité entre un « niveau d'innovation » de l'atelier
    # et un « niveau recherché » par le musicien, tous deux sur 10. Deux notes
    # subjectives comparées l'une à l'autre ne produisaient rien d'explicable.
    # Version actuelle : on compte les façons de travailler réellement
    # communes, et on les nomme dans l'explication.
    facons_atelier = set(facettes.facons_de(fiche))
    if brief.facons_recherchees:
        voulues = set(facettes.normaliser(brief.facons_recherchees))
        communes = [c for c in facettes.normaliser(facons_atelier & voulues)]
        score += POIDS["facons"] * (len(communes) / len(voulues))
        if communes:
            pour.append("Correspond à ce que vous cherchez : "
                        + ", ".join(facettes.libelles(communes)).lower())
        manquantes = voulues - facons_atelier
        if manquantes:
            contre.append("Non documenté chez cet atelier : "
                          + ", ".join(facettes.libelles(
                              facettes.normaliser(manquantes))).lower())
    elif facons_atelier:
        # Aucune demande particulière : on ne départage pas les ateliers
        # là-dessus, on se contente de citer leur manière de faire.
        score += POIDS["facons"] * 0.6
        pour.append("Manière de travailler documentée : "
                    + ", ".join(facettes.libelles(
                        facettes.normaliser(facons_atelier)[:3])).lower())

    # --- Personnalisation -------------------------------------------------- #
    if brief.personnalisation:
        if any(m.personnalisable for m in fiche.modeles):
            pour.append("Accepte les instruments personnalisés")
        else:
            contre.append("Personnalisation non documentée")

    # --- Transparence obligatoire ----------------------------------------- #
    if not fiche.valide_par_artisan:
        contre.append("Fiche construite à partir de sources publiques, "
                      "pas encore relue par l'artisan")
    if fiche.demonstration:
        contre.append("Fiche de démonstration : artisan fictif, "
                      "présent uniquement pour illustrer le fonctionnement")

    return int(round(min(100.0, score))), pour, contre


def recommander(brief: Brief, fiches: list[Fiche], nombre: int = 3) -> list[dict]:
    """Classe les fiches et retourne les meilleures avec leur explication."""
    resultats = []
    for fiche in fiches:
        score, pour, contre = evaluer(brief, fiche)
        if score <= 0:
            continue
        resultats.append({
            "slug": fiche.slug,
            "nom": fiche.nom,
            "type": fiche.type.value,
            "ville": fiche.ville,
            "pays": fiche.pays,
            "prix_min_eur": fiche.prix_min_eur,
            "prix_max_eur": fiche.prix_max_eur,
            "delai_moyen_mois": fiche.delai_moyen_mois,
            "site_web": fiche.site_web,
            "demonstration": fiche.demonstration,
            "valide_par_artisan": fiche.valide_par_artisan,
            "correspondance": score,
            "points_correspondance": pour,
            "points_vigilance": contre,
        })
    resultats.sort(key=lambda r: r["correspondance"], reverse=True)
    return resultats[:nombre]
