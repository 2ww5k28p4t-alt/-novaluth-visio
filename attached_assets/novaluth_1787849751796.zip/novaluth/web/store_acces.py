"""
NOVALUTH — Persistance du circuit d'accès aux projets
=====================================================

Quatre tables, plus quelques colonnes ajoutées aux projets existants :

  · `ateliers`  — l'adresse de contact d'un atelier référencé, seule donnée
                  nécessaire pour lui ouvrir un espace (connexion par lien).
  · `acces`     — une demande d'accès d'un atelier à un projet, son autorisation
                  de paiement et sa réponse.
  · `credits`   — les crédits de relance, accordés puis consommés.
  · `relances`  — les demandes de crédit en cours de vérification.

Colonnes ajoutées à `briefs` : dernière confirmation de fraîcheur, mise en
sommeil, clôture par le musicien, jeton de self-service et compteur d'accès
facturés. La migration est faite au démarrage, sans perte de données.

Aucune donnée bancaire n'est stockée : uniquement l'identifiant d'autorisation
renvoyé par le prestataire de paiement, et les dates.
"""

from __future__ import annotations

import datetime as dt
import json
import secrets
from typing import Any

from .store import connexion, journaliser, maintenant

# --------------------------------------------------------------------------- #
# Règles chiffrées du dispositif — un seul endroit pour les relire ou les régler
# --------------------------------------------------------------------------- #

#: Prix d'un accès selon le budget maximum annoncé par le musicien. Un contact
#: sur une commande à 6 000 € ne vaut pas le même prix qu'un contact sur une
#: commande à 900 € : le prix suit l'enjeu. Chaque tranche s'écrit
#: (budget maximum inclus en euros — None pour la dernière, prix en centimes,
#: nom court, libellé affiché).
TRANCHES_PRIX: tuple[tuple[int | None, int, str, str], ...] = (
    (1499, 999, "petit projet", "budget annoncé de moins de 1 500 €"),
    (4000, 1599, "projet courant", "budget annoncé de 1 500 € à 4 000 €"),
    (None, 2499, "grande commande", "budget annoncé de plus de 4 000 €"),
)

#: Prix retenu quand le musicien n'a pas renseigné de budget.
PRIX_ACCES_CENTS = 1599

#: Carnets d'accès prépayés : (nombre d'accès courants annoncé, prix payé en
#: centimes, crédit porté au solde en centimes). Le crédit est supérieur au prix
#: payé : c'est la remise de volume, exprimée en euros pour qu'elle s'applique
#: quelle que soit la tranche du projet. Un atelier ne peut donc pas acheter au
#: tarif dégressif pour ne s'en servir que sur les grosses commandes.
CARNETS: tuple[tuple[int, int, str], ...] = (
    (6900, 7995, "carnet de 5"),
    (11900, 15990, "carnet de 10"),
)

#: Durée de validité d'un solde d'accès prépayé, en mois.
VALIDITE_SOLDE_MOIS = 24

#: Délai laissé au musicien pour accepter ou décliner. Doit rester nettement
#: inférieur à la validité d'une autorisation de carte (7 jours en ligne).
FENETRE_ACCEPTATION_JOURS = 5

#: Nombre maximal d'ateliers pouvant obtenir l'accès à un même projet.
PLAFOND_ATELIERS_PAR_PROJET = 3

#: Au-delà de ce délai sans signe du musicien, on lui demande si son projet est
#: toujours d'actualité.
CONFIRMATION_FRAICHEUR_JOURS = 21

#: Sans réponse à cette question, le projet passe en sommeil.
DELAI_SOMMEIL_JOURS = 7

#: Délai pendant lequel un atelier peut demander un crédit de relance.
DELAI_DEMANDE_CREDIT_JOURS = 30

#: Délai laissé au musicien pour répondre à la vérification avant crédit.
FENETRE_REPONSE_RELANCE_JOURS = 7

#: Un crédit accordé au maximum pour ce nombre d'accès facturés.
ACCES_FACTURES_PAR_CREDIT = 4

STATUTS_ACCES_VIVANTS = ("attente_musicien", "accepte")


def prix_acces_cents(brief: dict[str, Any] | None) -> int:
    """Prix d'un accès à ce projet, en centimes, selon le budget annoncé."""
    budget = 0
    if brief:
        criteres = brief.get("criteres")
        if isinstance(criteres, str):
            try:
                criteres = json.loads(criteres or "{}")
            except json.JSONDecodeError:
                criteres = {}
        if isinstance(criteres, dict):
            try:
                budget = int(criteres.get("budget_max_eur") or 0)
            except (TypeError, ValueError):
                budget = 0
    if budget <= 0:
        return PRIX_ACCES_CENTS
    for plafond, prix, _nom, _libelle in TRANCHES_PRIX:
        if plafond is None or budget <= plafond:
            return prix
    return PRIX_ACCES_CENTS


def nom_tranche(brief: dict[str, Any] | None) -> str:
    """Nom lisible de la tranche de prix d'un projet."""
    prix = prix_acces_cents(brief)
    for _plafond, tarif, nom, _libelle in TRANCHES_PRIX:
        if tarif == prix:
            return nom
    return "projet courant"


def _plus(jours: int) -> str:
    return (dt.datetime.now(dt.timezone.utc)
            + dt.timedelta(days=jours)).isoformat(timespec="seconds")


def _moins(jours: int) -> str:
    return (dt.datetime.now(dt.timezone.utc)
            - dt.timedelta(days=jours)).isoformat(timespec="seconds")


def _colonnes(conn, table: str) -> set[str]:
    return {l["name"] for l in conn.execute(f"PRAGMA table_info({table})")}


def initialiser() -> None:
    with connexion() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS ateliers(
                slug TEXT PRIMARY KEY,
                email TEXT NOT NULL,
                cree_le TEXT NOT NULL,
                derniere_connexion_le TEXT,
                actif INTEGER DEFAULT 1,
                solde_cents INTEGER DEFAULT 0
            );

            CREATE TABLE IF NOT EXISTS mouvements_solde(
                id INTEGER PRIMARY KEY,
                atelier_slug TEXT NOT NULL,
                cree_le TEXT NOT NULL,
                sens TEXT NOT NULL,
                montant_cents INTEGER NOT NULL,
                solde_apres_cents INTEGER NOT NULL,
                libelle TEXT,
                acces_reference TEXT,
                expire_le TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_mouvements_atelier
                ON mouvements_solde(atelier_slug);

            CREATE TABLE IF NOT EXISTS acces(
                id INTEGER PRIMARY KEY,
                reference TEXT UNIQUE NOT NULL,
                brief_reference TEXT NOT NULL,
                atelier_slug TEXT NOT NULL,
                cree_le TEXT NOT NULL,
                montant_cents INTEGER NOT NULL,
                paye_par_credit INTEGER DEFAULT 0,
                statut TEXT NOT NULL DEFAULT 'attente_musicien',
                echeance_reponse_le TEXT NOT NULL,
                autorisation_id TEXT,
                autorisation_fournisseur TEXT,
                autorisation_echeance_le TEXT,
                mode_paiement TEXT DEFAULT 'carte',
                repondu_le TEXT,
                encaisse_le TEXT,
                annule_le TEXT,
                motif_fin TEXT,
                UNIQUE(brief_reference, atelier_slug)
            );
            CREATE INDEX IF NOT EXISTS idx_acces_statut ON acces(statut);
            CREATE INDEX IF NOT EXISTS idx_acces_atelier ON acces(atelier_slug);

            CREATE TABLE IF NOT EXISTS credits(
                id INTEGER PRIMARY KEY,
                atelier_slug TEXT NOT NULL,
                cree_le TEXT NOT NULL,
                motif TEXT,
                origine_acces TEXT,
                consomme_le TEXT,
                consomme_par TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_credits_atelier ON credits(atelier_slug);

            CREATE TABLE IF NOT EXISTS relances(
                id INTEGER PRIMARY KEY,
                acces_reference TEXT UNIQUE NOT NULL,
                demandee_le TEXT NOT NULL,
                echeance_le TEXT NOT NULL,
                statut TEXT NOT NULL DEFAULT 'en_cours',
                reponse_musicien TEXT,
                traitee_le TEXT
            );
            """
        )
        if "mode_paiement" not in _colonnes(conn, "acces"):
            conn.execute("ALTER TABLE acces ADD COLUMN mode_paiement TEXT "
                         "DEFAULT 'carte'")
        if "solde_cents" not in _colonnes(conn, "ateliers"):
            conn.execute("ALTER TABLE ateliers ADD COLUMN solde_cents INTEGER DEFAULT 0")
        existantes = _colonnes(conn, "briefs")
        ajouts = {
            "jeton": "TEXT",
            "derniere_confirmation_le": "TEXT",
            "sommeil_le": "TEXT",
            "cloture_le": "TEXT",
            "motif_cloture": "TEXT",
            "acces_factures": "INTEGER DEFAULT 0",
            "relance_envoyee_le": "TEXT",
            "confirme_le": "TEXT",
        }
        for nom, type_sql in ajouts.items():
            if nom not in existantes:
                conn.execute(f"ALTER TABLE briefs ADD COLUMN {nom} {type_sql}")
                if nom == "confirme_le":
                    # Les projets déposés avant l'arrivée de la double
                    # confirmation sont réputés confirmés : sans cela ils
                    # disparaîtraient des listes du jour au lendemain.
                    conn.execute(
                        "UPDATE briefs SET confirme_le = cree_le "
                        "WHERE email IS NOT NULL AND consentement = 1")


# --------------------------------------------------------------------------- #
# Solde d'accès prépayé (carnets)
# --------------------------------------------------------------------------- #

def solde_atelier(slug: str) -> int:
    """Solde d'accès de l'atelier, en centimes."""
    with connexion() as conn:
        ligne = conn.execute(
            "SELECT solde_cents FROM ateliers WHERE slug=?", (slug,)).fetchone()
    return int((ligne["solde_cents"] if ligne else 0) or 0)


def crediter_solde(slug: str, montant_cents: int, libelle: str) -> int:
    """Porte un carnet au solde de l'atelier. Renvoie le nouveau solde."""
    horizon = (dt.datetime.now(dt.timezone.utc)
               + dt.timedelta(days=VALIDITE_SOLDE_MOIS * 30)).isoformat()
    with connexion() as conn:
        conn.execute(
            "UPDATE ateliers SET solde_cents = COALESCE(solde_cents, 0) + ? "
            "WHERE slug=?", (montant_cents, slug))
        apres = int(conn.execute(
            "SELECT solde_cents FROM ateliers WHERE slug=?", (slug,)
        ).fetchone()["solde_cents"] or 0)
        conn.execute(
            """INSERT INTO mouvements_solde(atelier_slug, cree_le, sens,
                   montant_cents, solde_apres_cents, libelle, expire_le)
               VALUES(?,?,'credit',?,?,?,?)""",
            (slug, maintenant(), montant_cents, apres, libelle, horizon))
    journaliser("solde_credite", slug, f"{montant_cents} c — {libelle}")
    return apres


def prelever_solde(slug: str, montant_cents: int,
                   acces_reference: str, libelle: str) -> bool:
    """Retire un accès du solde si celui-ci le couvre entièrement.

    Volontairement tout ou rien : on ne mélange jamais un prélèvement partiel
    sur le solde et une autorisation de carte pour le reste, ce qui rendrait la
    facture illisible pour l'atelier."""
    with connexion() as conn:
        ligne = conn.execute(
            "SELECT solde_cents FROM ateliers WHERE slug=?", (slug,)).fetchone()
        disponible = int((ligne["solde_cents"] if ligne else 0) or 0)
        if disponible < montant_cents:
            return False
        apres = disponible - montant_cents
        conn.execute("UPDATE ateliers SET solde_cents=? WHERE slug=?",
                     (apres, slug))
        conn.execute(
            """INSERT INTO mouvements_solde(atelier_slug, cree_le, sens,
                   montant_cents, solde_apres_cents, libelle, acces_reference)
               VALUES(?,?,'debit',?,?,?,?)""",
            (slug, maintenant(), montant_cents, apres, libelle, acces_reference))
    journaliser("solde_preleve", slug, f"{montant_cents} c — {acces_reference}")
    return True


def rendre_au_solde(slug: str, montant_cents: int,
                    acces_reference: str, libelle: str) -> None:
    """Remet au solde un accès prélevé puis annulé."""
    with connexion() as conn:
        conn.execute(
            "UPDATE ateliers SET solde_cents = COALESCE(solde_cents, 0) + ? "
            "WHERE slug=?", (montant_cents, slug))
        apres = int(conn.execute(
            "SELECT solde_cents FROM ateliers WHERE slug=?", (slug,)
        ).fetchone()["solde_cents"] or 0)
        conn.execute(
            """INSERT INTO mouvements_solde(atelier_slug, cree_le, sens,
                   montant_cents, solde_apres_cents, libelle, acces_reference)
               VALUES(?,?,'credit',?,?,?,?)""",
            (slug, maintenant(), montant_cents, apres, libelle, acces_reference))
    journaliser("solde_rendu", slug, f"{montant_cents} c — {acces_reference}")


def mouvements_solde(slug: str, limite: int = 30) -> list[dict[str, Any]]:
    with connexion() as conn:
        lignes = conn.execute(
            """SELECT * FROM mouvements_solde WHERE atelier_slug=?
               ORDER BY id DESC LIMIT ?""", (slug, limite)).fetchall()
    return [dict(l) for l in lignes]


# --------------------------------------------------------------------------- #
# Ateliers
# --------------------------------------------------------------------------- #

def enregistrer_atelier(slug: str, email: str) -> None:
    with connexion() as conn:
        conn.execute(
            """INSERT INTO ateliers(slug,email,cree_le) VALUES(?,?,?)
               ON CONFLICT(slug) DO UPDATE SET email=excluded.email""",
            (slug, email.strip().lower(), maintenant()),
        )
    journaliser("atelier_enregistre", slug)


def lire_atelier(slug: str) -> dict[str, Any] | None:
    with connexion() as conn:
        ligne = conn.execute("SELECT * FROM ateliers WHERE slug=?", (slug,)).fetchone()
    return dict(ligne) if ligne else None


def ateliers_par_email(email: str) -> list[dict[str, Any]]:
    with connexion() as conn:
        lignes = conn.execute(
            "SELECT * FROM ateliers WHERE email=? AND actif=1", (email.strip().lower(),)
        ).fetchall()
    return [dict(l) for l in lignes]


def marquer_connexion(slug: str) -> None:
    with connexion() as conn:
        conn.execute("UPDATE ateliers SET derniere_connexion_le=? WHERE slug=?",
                     (maintenant(), slug))


# --------------------------------------------------------------------------- #
# Projets — fraîcheur, clôture, jeton de self-service
# --------------------------------------------------------------------------- #

def jeton_du_brief(reference: str) -> str | None:
    """Jeton unique et durable, qui sert tous les liens envoyés au musicien
    (acceptation, confirmation de fraîcheur, clôture). Créé à la demande."""
    with connexion() as conn:
        ligne = conn.execute("SELECT jeton FROM briefs WHERE reference=?",
                             (reference,)).fetchone()
        if ligne is None:
            return None
        if ligne["jeton"]:
            return ligne["jeton"]
        jeton = secrets.token_urlsafe(24)
        conn.execute("UPDATE briefs SET jeton=? WHERE reference=?", (jeton, reference))
    return jeton


def brief_par_jeton(jeton: str) -> dict[str, Any] | None:
    with connexion() as conn:
        ligne = conn.execute("SELECT * FROM briefs WHERE jeton=?", (jeton,)).fetchone()
    return dict(ligne) if ligne else None


def lire_brief(reference: str) -> dict[str, Any] | None:
    with connexion() as conn:
        ligne = conn.execute("SELECT * FROM briefs WHERE reference=?",
                             (reference,)).fetchone()
    return dict(ligne) if ligne else None


def places_occupees(reference: str) -> int:
    """Nombre de places d'atelier déjà prises sur un projet : les accès
    encaissés, plus les demandes en attente de réponse du musicien. Compter
    les demandes en attente évite deux écueils : noyer le musicien sous les
    sollicitations, et laisser plus de trois ateliers être facturés si le
    musicien accepte tout le monde. Une demande annulée libère sa place."""
    with connexion() as conn:
        ligne = conn.execute(
            """SELECT COUNT(*) AS n FROM acces
               WHERE brief_reference=? AND statut IN ('attente_musicien', 'accepte')""",
            (reference,),
        ).fetchone()
    return int(ligne["n"] or 0)


def places_restantes(reference: str, brief: dict[str, Any] | None = None) -> int:
    """On retient le plus prudent des deux comptages : les demandes réellement
    en cours, et le compteur d'accès facturés tenu sur le projet."""
    factures = (brief or lire_brief(reference) or {}).get("acces_factures") or 0
    prises = max(places_occupees(reference), int(factures))
    return max(0, PLAFOND_ATELIERS_PAR_PROJET - prises)


def brief_confirme(brief: dict[str, Any]) -> bool:
    """Le musicien a-t-il confirmé son projet en cliquant le lien reçu ?

    Cette confirmation est la première barrière de sérieux : elle écarte les
    adresses erronées et les dépôts sans intention, sans rien facturer au
    musicien."""
    return bool(brief.get("confirme_le"))


def confirmer_brief(reference: str) -> bool:
    """Enregistre la confirmation initiale. Renvoie True au premier appel."""
    with connexion() as conn:
        ligne = conn.execute(
            "SELECT confirme_le FROM briefs WHERE reference=?",
            (reference,)).fetchone()
        if ligne is None or ligne["confirme_le"]:
            return False
        conn.execute(
            "UPDATE briefs SET confirme_le=?, derniere_confirmation_le=? "
            "WHERE reference=?", (maintenant(), maintenant(), reference))
    journaliser("projet_confirme", reference, "confirmation initiale du musicien")
    return True


def projet_ouvert_de_email(email: str) -> dict[str, Any] | None:
    """Projet encore vivant déjà déposé par cette adresse, s'il en existe un.

    Sert à n'autoriser qu'un projet ouvert par adresse : plutôt que de refuser
    sèchement, on renvoie le musicien vers sa page de suivi."""
    if not email:
        return None
    with connexion() as conn:
        ligne = conn.execute(
            """SELECT * FROM briefs
               WHERE email = ? AND cloture_le IS NULL AND anonymise_le IS NULL
               ORDER BY id DESC LIMIT 1""", (email.strip().lower(),)).fetchone()
    return dict(ligne) if ligne else None


def brief_ouvert(brief: dict[str, Any]) -> bool:
    """Un projet n'est proposé aux ateliers que s'il est vivant : consentement
    donné, confirmation cliquée, adresse encore présente, ni clôturé, ni en
    sommeil, et sous le plafond d'ateliers."""
    return bool(
        brief.get("consentement")
        and brief.get("email")
        and brief.get("confirme_le")
        and not brief.get("cloture_le")
        and not brief.get("sommeil_le")
        and places_restantes(brief["reference"], brief) > 0
    )


def confirmer_fraicheur(reference: str) -> None:
    with connexion() as conn:
        conn.execute(
            """UPDATE briefs SET derniere_confirmation_le=?, sommeil_le=NULL,
                                 relance_envoyee_le=NULL
               WHERE reference=?""",
            (maintenant(), reference),
        )
    journaliser("projet_confirme", reference)


def cloturer_brief(reference: str, motif: str) -> None:
    """Clôture à l'initiative du musicien : plus aucun atelier ne peut le
    contacter. L'adresse est effacée immédiatement — il n'y a plus de raison de
    la conserver (minimisation)."""
    with connexion() as conn:
        conn.execute(
            """UPDATE briefs SET cloture_le=?, motif_cloture=?, email=NULL,
                                 statut='anonymise', anonymise_le=?
               WHERE reference=?""",
            (maintenant(), motif[:120], maintenant(), reference),
        )
    journaliser("projet_cloture", reference, motif[:120])


def mettre_en_sommeil(reference: str) -> None:
    with connexion() as conn:
        conn.execute("UPDATE briefs SET sommeil_le=? WHERE reference=?",
                     (maintenant(), reference))
    journaliser("projet_sommeil", reference)


def briefs_a_relancer() -> list[dict[str, Any]]:
    """Projets vivants sans signe depuis CONFIRMATION_FRAICHEUR_JOURS et pas
    encore relancés."""
    limite = _moins(CONFIRMATION_FRAICHEUR_JOURS)
    with connexion() as conn:
        lignes = conn.execute(
            """SELECT * FROM briefs
               WHERE email IS NOT NULL AND consentement=1
                 AND cloture_le IS NULL AND sommeil_le IS NULL
                 AND relance_envoyee_le IS NULL
                 AND COALESCE(derniere_confirmation_le, cree_le) < ?""",
            (limite,),
        ).fetchall()
    return [dict(l) for l in lignes]


def marquer_relance_envoyee(reference: str) -> None:
    with connexion() as conn:
        conn.execute("UPDATE briefs SET relance_envoyee_le=? WHERE reference=?",
                     (maintenant(), reference))


def briefs_a_endormir() -> list[dict[str, Any]]:
    limite = _moins(DELAI_SOMMEIL_JOURS)
    with connexion() as conn:
        lignes = conn.execute(
            """SELECT * FROM briefs
               WHERE relance_envoyee_le IS NOT NULL AND relance_envoyee_le < ?
                 AND sommeil_le IS NULL AND cloture_le IS NULL""",
            (limite,),
        ).fetchall()
    return [dict(l) for l in lignes]


def projets_pour_atelier(slug: str, limite: int = 40) -> list[dict[str, Any]]:
    """Projets ouverts dont l'atelier fait partie des correspondances, avec le
    nombre de places restantes et l'état de la demande de l'atelier."""
    with connexion() as conn:
        lignes = conn.execute(
            """SELECT b.*, a.reference AS acces_reference, a.statut AS acces_statut
               FROM briefs b
               LEFT JOIN acces a
                      ON a.brief_reference = b.reference AND a.atelier_slug = ?
               WHERE b.email IS NOT NULL AND b.consentement=1
                 AND b.confirme_le IS NOT NULL
                 AND b.cloture_le IS NULL AND b.sommeil_le IS NULL
               ORDER BY b.cree_le DESC LIMIT ?""",
            (slug, limite),
        ).fetchall()

    resultats = []
    for ligne in lignes:
        brief = dict(ligne)
        recommandations = json.loads(brief.get("recommandations") or "[]")
        correspondance = next(
            (r for r in recommandations if r.get("slug") == slug), None)
        if correspondance is None:
            continue
        brief["criteres"] = json.loads(brief.get("criteres") or "{}")
        brief["correspondance"] = correspondance.get("correspondance")
        brief["places_restantes"] = places_restantes(brief["reference"], brief)
        brief["prix_cents"] = prix_acces_cents(brief)
        brief["tranche"] = nom_tranche(brief)
        brief.pop("email", None)          # jamais exposé avant acceptation
        brief.pop("jeton", None)          # jeton du musicien, jamais côté atelier
        resultats.append(brief)
    return resultats


# --------------------------------------------------------------------------- #
# Accès
# --------------------------------------------------------------------------- #

def creer_acces(brief_reference: str, atelier_slug: str, montant_cents: int,
                autorisation_id: str | None, fournisseur: str,
                autorisation_echeance_le: str, paye_par_credit: bool,
                mode_paiement: str = "carte") -> str:
    reference = "AC-" + secrets.token_hex(3).upper()
    with connexion() as conn:
        conn.execute(
            """INSERT INTO acces(reference,brief_reference,atelier_slug,cree_le,
                                 montant_cents,paye_par_credit,statut,
                                 echeance_reponse_le,autorisation_id,
                                 autorisation_fournisseur,autorisation_echeance_le,
                                 mode_paiement)
               VALUES(?,?,?,?,?,?,'attente_musicien',?,?,?,?,?)""",
            (reference, brief_reference, atelier_slug, maintenant(), montant_cents,
             1 if paye_par_credit else 0, _plus(FENETRE_ACCEPTATION_JOURS),
             autorisation_id, fournisseur, autorisation_echeance_le, mode_paiement),
        )
    journaliser("acces_demande", reference, f"{atelier_slug} → {brief_reference}")
    return reference


def lire_acces(reference: str) -> dict[str, Any] | None:
    with connexion() as conn:
        ligne = conn.execute("SELECT * FROM acces WHERE reference=?",
                             (reference,)).fetchone()
    return dict(ligne) if ligne else None


def lire_acces_par_couple(brief_reference: str, atelier_slug: str) -> dict[str, Any] | None:
    """Un atelier ne peut avoir qu'une demande par projet : cette lecture sert de
    garde-fou contre les doubles facturations."""
    with connexion() as conn:
        ligne = conn.execute(
            "SELECT * FROM acces WHERE brief_reference=? AND atelier_slug=?",
            (brief_reference, atelier_slug),
        ).fetchone()
    return dict(ligne) if ligne else None


def acces_en_attente_du_brief(brief_reference: str) -> list[dict[str, Any]]:
    with connexion() as conn:
        lignes = conn.execute(
            "SELECT * FROM acces WHERE brief_reference=? AND statut='attente_musicien'"
            " ORDER BY cree_le",
            (brief_reference,),
        ).fetchall()
    return [dict(l) for l in lignes]


def acces_de_atelier(slug: str, limite: int = 60) -> list[dict[str, Any]]:
    with connexion() as conn:
        lignes = conn.execute(
            """SELECT a.*, b.email AS email_musicien, b.criteres, b.cloture_le,
                      b.motif_cloture
               FROM acces a JOIN briefs b ON b.reference = a.brief_reference
               WHERE a.atelier_slug=? ORDER BY a.cree_le DESC LIMIT ?""",
            (slug, limite),
        ).fetchall()
    resultats = []
    for ligne in lignes:
        acces = dict(ligne)
        acces["criteres"] = json.loads(acces.get("criteres") or "{}")
        # L'adresse n'est lisible que si l'accès a été accepté et encaissé.
        if acces["statut"] != "accepte":
            acces["email_musicien"] = None
        acces["relance"] = lire_relance(acces["reference"])
        resultats.append(acces)
    return resultats


def marquer_accepte(reference: str) -> None:
    with connexion() as conn:
        conn.execute(
            """UPDATE acces SET statut='accepte', repondu_le=?, encaisse_le=?
               WHERE reference=? AND statut='attente_musicien'""",
            (maintenant(), maintenant(), reference),
        )
        conn.execute(
            """UPDATE briefs SET acces_factures=COALESCE(acces_factures,0)+1,
                                 statut='transmis', derniere_confirmation_le=?
               WHERE reference=(SELECT brief_reference FROM acces WHERE reference=?)""",
            (maintenant(), reference),
        )
    journaliser("acces_accepte", reference)


def clore_acces(reference: str, statut: str, motif: str) -> None:
    """Fin d'un accès non facturé : décliné, abandonné ou expiré."""
    with connexion() as conn:
        conn.execute(
            """UPDATE acces SET statut=?, repondu_le=COALESCE(repondu_le,?),
                                annule_le=?, motif_fin=?
               WHERE reference=?""",
            (statut, maintenant(), maintenant(), motif[:200], reference),
        )
    journaliser("acces_clos", reference, f"{statut} · {motif[:120]}")


def acces_expires() -> list[dict[str, Any]]:
    """Accès dont la fenêtre de réponse est écoulée, ou dont l'autorisation de
    paiement arrive à expiration : dans les deux cas on annule."""
    with connexion() as conn:
        lignes = conn.execute(
            """SELECT * FROM acces
               WHERE statut='attente_musicien'
                 AND (echeance_reponse_le < ?
                      OR (autorisation_echeance_le IS NOT NULL
                          AND autorisation_echeance_le < ?))""",
            (maintenant(), maintenant()),
        ).fetchall()
    return [dict(l) for l in lignes]


# --------------------------------------------------------------------------- #
# Crédits de relance
# --------------------------------------------------------------------------- #

def credits_disponibles(slug: str) -> int:
    with connexion() as conn:
        return conn.execute(
            "SELECT COUNT(*) n FROM credits WHERE atelier_slug=? AND consomme_le IS NULL",
            (slug,),
        ).fetchone()["n"]


def accorder_credit(slug: str, motif: str, origine_acces: str | None) -> None:
    with connexion() as conn:
        conn.execute(
            "INSERT INTO credits(atelier_slug,cree_le,motif,origine_acces) VALUES(?,?,?,?)",
            (slug, maintenant(), motif[:200], origine_acces),
        )
    journaliser("credit_accorde", slug, motif[:120])


def consommer_credit(slug: str, acces_reference: str) -> bool:
    with connexion() as conn:
        ligne = conn.execute(
            "SELECT id FROM credits WHERE atelier_slug=? AND consomme_le IS NULL "
            "ORDER BY cree_le LIMIT 1", (slug,),
        ).fetchone()
        if ligne is None:
            return False
        conn.execute("UPDATE credits SET consomme_le=?, consomme_par=? WHERE id=?",
                     (maintenant(), acces_reference, ligne["id"]))
    journaliser("credit_consomme", slug, acces_reference)
    return True


def rendre_credit(slug: str, acces_reference: str) -> None:
    """Un accès payé avec un crédit et qui n'aboutit pas rend le crédit : le
    crédit n'est consommé que si la mise en relation a lieu."""
    with connexion() as conn:
        conn.execute(
            "UPDATE credits SET consomme_le=NULL, consomme_par=NULL "
            "WHERE atelier_slug=? AND consomme_par=?",
            (slug, acces_reference),
        )
    journaliser("credit_rendu", slug, acces_reference)


def trop_tard_pour_crediter(acces: dict[str, Any]) -> bool:
    """Un crédit de relance se demande dans les DELAI_DEMANDE_CREDIT_JOURS qui
    suivent l'encaissement de l'accès."""
    reference_date = acces.get("encaisse_le") or acces.get("cree_le") or ""
    return bool(reference_date) and reference_date < _moins(DELAI_DEMANDE_CREDIT_JOURS)


def compter_acces_factures(slug: str) -> int:
    with connexion() as conn:
        return conn.execute(
            "SELECT COUNT(*) n FROM acces WHERE atelier_slug=? AND statut='accepte' "
            "AND paye_par_credit=0", (slug,),
        ).fetchone()["n"]


def compter_credits_accordes(slug: str) -> int:
    with connexion() as conn:
        return conn.execute("SELECT COUNT(*) n FROM credits WHERE atelier_slug=?",
                            (slug,)).fetchone()["n"]


def plafond_credits_atteint(slug: str) -> bool:
    """Un crédit au maximum par tranche de ACCES_FACTURES_PAR_CREDIT accès
    facturés. Le premier crédit est accordé dès le premier accès facturé."""
    factures = compter_acces_factures(slug)
    accordes = compter_credits_accordes(slug)
    droits = max(1, (factures + ACCES_FACTURES_PAR_CREDIT - 1) // ACCES_FACTURES_PAR_CREDIT)
    return accordes >= droits


# --------------------------------------------------------------------------- #
# Demandes de vérification (crédit de relance)
# --------------------------------------------------------------------------- #

def creer_relance(acces_reference: str) -> None:
    with connexion() as conn:
        conn.execute(
            """INSERT OR IGNORE INTO relances(acces_reference,demandee_le,echeance_le)
               VALUES(?,?,?)""",
            (acces_reference, maintenant(), _plus(FENETRE_REPONSE_RELANCE_JOURS)),
        )
    journaliser("relance_demandee", acces_reference)


def lire_relance(acces_reference: str) -> dict[str, Any] | None:
    with connexion() as conn:
        ligne = conn.execute("SELECT * FROM relances WHERE acces_reference=?",
                             (acces_reference,)).fetchone()
    return dict(ligne) if ligne else None


def relances_du_brief(brief_reference: str) -> list[dict[str, Any]]:
    with connexion() as conn:
        lignes = conn.execute(
            """SELECT r.* FROM relances r JOIN acces a ON a.reference = r.acces_reference
               WHERE a.brief_reference=? AND r.statut='en_cours'""",
            (brief_reference,),
        ).fetchall()
    return [dict(l) for l in lignes]


def relances_echues() -> list[dict[str, Any]]:
    with connexion() as conn:
        lignes = conn.execute(
            """SELECT r.*, a.atelier_slug FROM relances r
               JOIN acces a ON a.reference = r.acces_reference
               WHERE r.statut='en_cours' AND r.echeance_le < ?""",
            (maintenant(),),
        ).fetchall()
    return [dict(l) for l in lignes]


def cloturer_relance(acces_reference: str, statut: str, reponse: str = "") -> None:
    with connexion() as conn:
        conn.execute(
            """UPDATE relances SET statut=?, reponse_musicien=?, traitee_le=?
               WHERE acces_reference=?""",
            (statut, reponse[:200], maintenant(), acces_reference),
        )
    journaliser("relance_traitee", acces_reference, statut)


# --------------------------------------------------------------------------- #
# Tableau de bord de supervision
# --------------------------------------------------------------------------- #

def statistiques() -> dict[str, Any]:
    with connexion() as conn:
        par_statut = {l["statut"]: l["n"] for l in conn.execute(
            "SELECT statut, COUNT(*) n FROM acces GROUP BY statut")}
        credits = conn.execute(
            "SELECT COUNT(*) total, SUM(consomme_le IS NULL) restants FROM credits"
        ).fetchone()
        projets = conn.execute(
            """SELECT SUM(cloture_le IS NOT NULL) clotures,
                      SUM(sommeil_le IS NOT NULL) sommeil,
                      COUNT(*) total FROM briefs"""
        ).fetchone()
    factures = par_statut.get("accepte", 0)
    demandes = sum(par_statut.values())
    return {
        "acces_par_statut": par_statut,
        "acces_demandes": demandes,
        "acces_factures": factures,
        "taux_facturation": round(100 * factures / demandes) if demandes else None,
        "credits_accordes": credits["total"] or 0,
        "credits_restants": credits["restants"] or 0,
        "projets_total": projets["total"] or 0,
        "projets_clotures": projets["clotures"] or 0,
        "projets_en_sommeil": projets["sommeil"] or 0,
    }
