"""
NOVALUTH — Schémas de données
=============================

Traduction directe des 7 blocs du dossier de projet. C'est l'actif
stratégique : la structure de la fiche. Toute écriture en base passe par ces
modèles, donc une fiche mal formée ne peut pas entrer.
"""

from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field, field_validator


class TypeEntite(str, Enum):
    luthier = "luthier"
    marque_emergente = "marque_emergente"


class StatutFiche(str, Enum):
    candidate = "candidate"      # sortie du pipeline, en attente de validation humaine
    a_verifier = "a_verifier"    # doute, à recontrôler
    a_suivre = "a_suivre"        # intéressante mais incomplète
    trop_etablie = "trop_etablie"  # hors positionnement Novaluth
    rejetee = "rejetee"
    publiee = "publiee"          # visible du public


# --------------------------------------------------------------------------- #
# Bloc 3 — Spécifications techniques
# --------------------------------------------------------------------------- #

class Specifications(BaseModel):
    bois_corps: str | None = None
    bois_manche: str | None = None
    touche: str | None = None
    profil_manche: str | None = None
    # Jusqu'à 950 mm : une basse 35 pouces atteint 889 mm.
    diapason_mm: int | None = Field(default=None, ge=400, le=950)
    nombre_cases: int | None = Field(default=None, ge=12, le=36)
    type_micros: str | None = None
    configuration_micros: str | None = None
    chevalet: str | None = None
    poids_kg: float | None = Field(default=None, ge=0.5, le=8.0)


# --------------------------------------------------------------------------- #
# Bloc 2 — Modèles
# --------------------------------------------------------------------------- #

class Modele(BaseModel):
    nom: str
    type: Literal["electrique", "acoustique", "basse", "autre"] = "electrique"
    inspiration: str | None = None
    prix_base_eur: int | None = Field(default=None, ge=0, le=200_000)
    personnalisable: bool = False
    specifications: Specifications = Field(default_factory=Specifications)


# --------------------------------------------------------------------------- #
# Bloc 4 — Profil sonore (structuré pour la recommandation)
# --------------------------------------------------------------------------- #

class ProfilSonore(BaseModel):
    styles: list[str] = Field(default_factory=list)
    niveau_sortie: Literal["faible", "moyen", "eleve"] | None = None

    # Description du son en mots, vocabulaire fermé de web/sonorite.py.
    # Remplace les anciennes échelles 0-10 : un « 8/10 de chaleur » ressemblait
    # à une mesure alors que c'est une déclaration de l'atelier.
    couleur: Literal["chaud", "equilibre", "clair"] | None = None
    attaque: Literal["douce", "franche", "percussive"] | None = None
    tenue: Literal["courte", "moyenne", "longue"] | None = None

    # INTERNE / HISTORIQUE — anciennes notes des fiches déjà collectées.
    # Plus affichées nulle part ; converties à la lecture par
    # sonorite.depuis_chiffres() pour ne perdre aucune fiche existante.
    chaleur: int | None = Field(default=None, ge=0, le=10)
    brillance: int | None = Field(default=None, ge=0, le=10)
    dynamique: int | None = Field(default=None, ge=0, le=10)

    type_grain: str | None = None
    description: str | None = Field(default=None, max_length=600)


# --------------------------------------------------------------------------- #
# Bloc 5 — Logistique
# --------------------------------------------------------------------------- #

class Logistique(BaseModel):
    expedie_france: bool = False
    expedie_europe: bool = False
    expedie_monde: bool = False
    transporteur: str | None = None
    garantie_annees: int | None = Field(default=None, ge=0, le=99)
    politique_retour: str | None = Field(default=None, max_length=600)


# --------------------------------------------------------------------------- #
# Bloc 6 — Innovation / identité
# --------------------------------------------------------------------------- #

class Innovation(BaseModel):
    # `niveau` est également un signal interne de veille, jamais publié.
    niveau: int | None = Field(default=None, ge=0, le=10)
    materiaux_alternatifs: list[str] = Field(default_factory=list)
    demarche_ecologique: str | None = Field(default=None, max_length=600)
    technologie_proprietaire: str | None = None
    edition_limitee: bool = False
    marqueurs: list[str] = Field(default_factory=list)  # headless, multiscale, carbone…


# --------------------------------------------------------------------------- #
# Bloc 7 — Métadonnées IA
# --------------------------------------------------------------------------- #

class MetadonneesIA(BaseModel):
    tags: list[str] = Field(default_factory=list)
    mots_cles: list[str] = Field(default_factory=list)
    resume_ia: str | None = Field(default=None, max_length=1200)
    modele_utilise: str | None = None
    genere_le: str | None = None


# --------------------------------------------------------------------------- #
# Bloc 1 — Fiche
# --------------------------------------------------------------------------- #

class Fiche(BaseModel):
    slug: str
    nom: str
    type: TypeEntite = TypeEntite.luthier
    annee_creation: int | None = Field(default=None, ge=1500, le=2100)
    pays: str | None = None
    ville: str | None = None
    site_web: str | None = None
    reseaux: dict[str, str] = Field(default_factory=dict)
    expedition_internationale: bool = False
    delai_moyen_mois: int | None = Field(default=None, ge=0, le=120)
    prix_min_eur: int | None = Field(default=None, ge=0, le=200_000)
    prix_max_eur: int | None = Field(default=None, ge=0, le=200_000)
    production_annuelle: int | None = Field(default=None, ge=0, le=100_000)
    approche_artisanale: str | None = Field(default=None, max_length=800)
    # Signaux INTERNES de veille : ils servent à choisir quels ateliers
    # rechercher en priorité. Ils ne sont jamais affichés sur le site public,
    # jamais un filtre et jamais un critère de tri — voir web/facettes.py.
    score_originalite: int | None = Field(default=None, ge=0, le=10)
    score_innovation: int | None = Field(default=None, ge=0, le=10)

    modeles: list[Modele] = Field(default_factory=list)
    profil_sonore: ProfilSonore = Field(default_factory=ProfilSonore)
    logistique: Logistique = Field(default_factory=Logistique)
    innovation: Innovation = Field(default_factory=Innovation)
    ia: MetadonneesIA = Field(default_factory=MetadonneesIA)

    statut: StatutFiche = StatutFiche.candidate
    source_donnees: list[str] = Field(default_factory=list)  # URLs publiques d'origine
    valide_par_artisan: bool = False        # l'artisan a relu et confirmé sa fiche
    verification_identite_le: str | None = None  # date, jamais « certifié »
    demonstration: bool = False             # fiche d'exemple, non réelle
    cree_le: str | None = None
    maj_le: str | None = None

    @field_validator("slug")
    @classmethod
    def slug_propre(cls, v: str) -> str:
        import re
        v = re.sub(r"[^a-z0-9-]+", "-", v.lower()).strip("-")
        if not v:
            raise ValueError("slug vide")
        return v


# --------------------------------------------------------------------------- #
# Brief musicien — volontairement minimal (principe de minimisation RGPD)
# --------------------------------------------------------------------------- #

class Brief(BaseModel):
    """Ce que le musicien décrit. Aucune donnée personnelle n'est obligatoire
    pour obtenir une recommandation : l'e-mail n'est demandé que si le musicien
    veut être mis en relation."""
    type_instrument: Literal["electrique", "acoustique", "basse", "autre"] = "electrique"
    budget_min_eur: int = Field(default=0, ge=0, le=200_000)
    budget_max_eur: int = Field(default=5000, ge=0, le=200_000)
    styles: list[str] = Field(default_factory=list, max_length=8)
    bois_souhaites: list[str] = Field(default_factory=list, max_length=8)
    delai_max_mois: int | None = Field(default=None, ge=0, le=120)
    pays_livraison: str | None = Field(default=None, max_length=60)
    zone_preferee: Literal["france", "europe", "monde"] = "europe"
    # Son recherché, dans les mêmes mots que ceux affichés sur les fiches.
    couleur_souhaitee: Literal["chaud", "equilibre", "clair"] | None = None
    attaque_souhaitee: Literal["douce", "franche", "percussive"] | None = None
    tenue_souhaitee: Literal["courte", "moyenne", "longue"] | None = None
    # Façons de travailler qui intéressent le musicien (clés de web/facettes.py).
    # Remplace l'ancien curseur « innovation recherchée sur 10 » : on demande ce
    # qui l'intéresse, pas de noter l'audace des artisans.
    facons_recherchees: list[str] = Field(default_factory=list, max_length=12)
    personnalisation: bool = False
    description_libre: str = Field(default="", max_length=1500)

    # Mise en relation — uniquement sur consentement explicite
    email: str | None = Field(default=None, max_length=180)
    consentement_transmission: bool = False
    consentement_horodatage: str | None = None

    @field_validator("email")
    @classmethod
    def email_plausible(cls, v: str | None) -> str | None:
        if v is None or v == "":
            return None
        import re
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[A-Za-z]{2,}", v):
            raise ValueError("adresse e-mail invalide")
        return v.lower()
