"""
NOVALUTH — Service des documents juridiques
===========================================

Les documents vivent en Markdown dans legal/. Avantages : vous les relisez et
les corrigez depuis l'iPhone sans toucher au code, et l'historique Git fait
office de preuve de version — utile en cas de litige sur la version des CGU
applicable à une date donnée.

Le rendu est fait par un convertisseur minimal maison (aucune dépendance),
volontairement limité aux titres, listes, tableaux, gras, italique et liens :
moins de surface d'attaque qu'une bibliothèque complète, et tout est échappé.
"""

from __future__ import annotations

import datetime as dt
import html
import re
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
DOSSIER = RACINE / "legal"

# Ordre d'affichage dans le pied de page et sur /legal
DOCUMENTS_LEGAUX: dict[str, str] = {
    "mentions-legales": "Mentions légales",
    "cgu": "Conditions générales d'utilisation",
    "cgv": "Conditions générales de vente",
    "confidentialite": "Politique de confidentialité",
    "cookies": "Gestion des cookies",
    "charte-luthier": "Charte des artisans référencés",
    "charte-expedition": "Charte d'expédition",
    "badges": "Signification des badges",
    "litiges": "Réclamations et litiges",
    "propriete-intellectuelle": "Propriété intellectuelle et signalement",
    "accessibilite": "Accessibilité",
    "conflits-interets": "Déclaration de conflits d'intérêts",
    "ia-transparence": "Transparence sur l'usage de l'IA",
    "sources-donnees": "D'où viennent les informations d'une fiche",
    "classement": "Comment l'annuaire est ordonné",
}


def _inline(texte: str) -> str:
    """Échappe puis applique gras, italique, code et liens."""
    t = html.escape(texte, quote=False)
    t = re.sub(r"\*\*(.+?)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)", r"<em>\1</em>", t)
    t = re.sub(r"`(.+?)`", r"<code>\1</code>", t)

    def lien(m: re.Match) -> str:
        libelle, cible = m.group(1), m.group(2)
        if not re.match(r"^(https?://|mailto:|/)", cible):
            return libelle
        externe = cible.startswith("http")
        attrs = ' target="_blank" rel="noopener noreferrer"' if externe else ""
        return f'<a href="{html.escape(cible, quote=True)}"{attrs}>{libelle}</a>'

    return re.sub(r"\[([^\]]+)\]\(([^)]+)\)", lien, t)


def _puce_complete(lignes: list[str], i: int, debut: str) -> tuple[str, int]:
    """Recolle les lignes de continuation d'une puce.

    Sans cela, une puce écrite sur deux lignes — le cas normal dans nos
    documents, où l'on retourne à la ligne à 79 caractères — se coupait en
    deux : le début en puce, la suite en paragraphe orphelin sous la liste.
    Une ligne est une continuation si elle est indentée et ne commence
    ni une nouvelle puce, ni un titre, ni un tableau.
    """
    morceaux = [debut]
    j = i + 1
    while j < len(lignes):
        suite = lignes[j]
        if not suite.strip():
            break
        if not (suite.startswith(" ") or suite.startswith("\t")):
            break
        nu = suite.strip()
        if re.match(r"^([-*+]\s|\d+[.)]\s|#|\|)", nu):
            break
        morceaux.append(nu)
        j += 1
    return " ".join(morceaux), j


def markdown_vers_html(source: str) -> str:
    # Les commentaires HTML servent de marqueurs pour le contrôle de conformité
    # (tools/verifier_conformite.py) : ils ne doivent jamais s'afficher.
    source = re.sub(r"<!--.*?-->", "", source, flags=re.DOTALL)
    lignes = source.splitlines()
    sortie: list[str] = []
    i = 0
    dans_liste = False

    def fermer_liste() -> None:
        nonlocal dans_liste
        if dans_liste:
            sortie.append("</ul>")
            dans_liste = False

    while i < len(lignes):
        ligne = lignes[i].rstrip()

        if not ligne.strip():
            fermer_liste()
            i += 1
            continue

        if ligne.strip() in {"---", "***", "___"}:
            fermer_liste()
            sortie.append("<hr>")
            i += 1
            continue

        titre = re.match(r"^(#{1,4})\s+(.*)$", ligne)
        if titre:
            fermer_liste()
            niveau = len(titre.group(1)) + 1  # h1 réservé au gabarit
            sortie.append(f"<h{min(niveau, 5)}>{_inline(titre.group(2))}</h{min(niveau, 5)}>")
            i += 1
            continue

        # Tableau Markdown
        if ligne.lstrip().startswith("|") and i + 1 < len(lignes) \
                and set(lignes[i + 1].replace("|", "").strip()) <= set("-: "):
            fermer_liste()
            entetes = [c.strip() for c in ligne.strip().strip("|").split("|")]
            sortie.append("<div class='nv-table-wrap'><table><thead><tr>"
                          + "".join(f"<th>{_inline(c)}</th>" for c in entetes)
                          + "</tr></thead><tbody>")
            i += 2
            while i < len(lignes) and lignes[i].lstrip().startswith("|"):
                cellules = [c.strip() for c in lignes[i].strip().strip("|").split("|")]
                sortie.append("<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in cellules)
                              + "</tr>")
                i += 1
            sortie.append("</tbody></table></div>")
            continue

        puce = re.match(r"^\s*[-*+]\s+(.*)$", ligne)
        if puce:
            if not dans_liste:
                sortie.append("<ul>")
                dans_liste = True
            texte, i = _puce_complete(lignes, i, puce.group(1))
            sortie.append(f"<li>{_inline(texte)}</li>")
            continue

        numerote = re.match(r"^\s*\d+[.)]\s+(.*)$", ligne)
        if numerote:
            if not dans_liste:
                sortie.append("<ul>")
                dans_liste = True
            texte, i = _puce_complete(lignes, i, numerote.group(1))
            sortie.append(f"<li>{_inline(texte)}</li>")
            continue

        fermer_liste()
        paragraphe = [ligne]
        i += 1
        while i < len(lignes) and lignes[i].strip() and not re.match(
                r"^(#{1,4}\s|\s*[-*+]\s|\s*\d+[.)]\s|\|)", lignes[i]):
            paragraphe.append(lignes[i].rstrip())
            i += 1
        sortie.append("<p>" + _inline(" ".join(paragraphe)) + "</p>")

    fermer_liste()
    return "\n".join(sortie)


def rendre_document(cle: str) -> tuple[str, str, str]:
    """Retourne (titre, html, date de dernière modification)."""
    chemin = DOSSIER / f"{cle}.md"
    titre = DOCUMENTS_LEGAUX.get(cle, cle)
    if not chemin.exists():
        return titre, "<p>Document en cours de rédaction.</p>", "—"
    source = chemin.read_text(encoding="utf-8")
    maj = dt.datetime.fromtimestamp(chemin.stat().st_mtime).strftime("%d/%m/%Y")
    # Une éventuelle ligne « Dernière mise à jour : » dans le fichier prime.
    trouve = re.search(r"Dernière mise à jour\s*:\s*([^\n]+)", source)
    if trouve:
        maj = trouve.group(1).strip()
    # La date est déjà affichée en tête de page par le gabarit : la laisser aussi
    # dans le corps la ferait apparaître deux fois de suite.
    corps = re.sub(r"^\s*Dernière mise à jour\s*:[^\n]*\n?", "", source, count=1)
    return titre, markdown_vers_html(corps), maj
