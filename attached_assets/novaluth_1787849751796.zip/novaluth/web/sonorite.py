"""
NOVALUTH — Vocabulaire du profil sonore
=======================================

Avant, une fiche annonçait « chaleur 8/10, brillance 5/10, dynamique 7/10 ».
Trois problèmes :

1. **Personne ne parle comme ça.** Un musicien ne cherche pas « du 8 de
   chaleur », il cherche un son chaud et rond, ou au contraire claquant.
2. **Le chiffre paraît mesuré alors qu'il est déclaré.** Un 8/10 ressemble à
   un relevé acoustique. C'est une appréciation, souvent reformulée par un
   modèle depuis une page de présentation.
3. **Deux chiffres comparés ne s'expliquent pas.** Le moteur de recommandation
   calculait un écart entre le souhait du musicien et la fiche, puis affichait
   « profil sonore proche » sans pouvoir dire en quoi.

On remplace donc les échelles par trois axes fermés, à trois valeurs chacun.
Ce sont des **descriptions**, pas des notes : « plutôt chaud » n'est ni
au-dessus ni en dessous de « plutôt clair », c'est autre chose. Les valeurs
d'un même axe forment cependant un continuum (chaud – équilibré – clair), ce
qui permet à la recommandation de reconnaître un voisinage sans jamais
prétendre à un classement.

Les anciennes valeurs chiffrées restent lisibles en base et sont converties par
`depuis_chiffres()` : aucune fiche déjà collectée n'est perdue. Elles ne sont
plus affichées nulle part.
"""

from __future__ import annotations

from dataclasses import dataclass

# --------------------------------------------------------------------------- #
# Le vocabulaire
# --------------------------------------------------------------------------- #


@dataclass(frozen=True)
class Valeur:
    cle: str
    libelle: str        # ce que voit le visiteur
    aide: str           # une phrase pour ceux qui ne connaissent pas le jargon


@dataclass(frozen=True)
class Axe:
    cle: str
    titre: str          # intitulé de l'axe sur la fiche
    question: str       # la même chose formulée pour le musicien
    valeurs: tuple[Valeur, ...]

    def valeur(self, cle: str | None) -> Valeur | None:
        for v in self.valeurs:
            if v.cle == cle:
                return v
        return None

    def rang(self, cle: str) -> int | None:
        """Position sur le continuum de l'axe (0, 1, 2). None si inconnue."""
        for i, v in enumerate(self.valeurs):
            if v.cle == cle:
                return i
        return None


AXES: tuple[Axe, ...] = (
    Axe(
        cle="couleur",
        titre="Couleur du son",
        question="Couleur du son recherchée",
        valeurs=(
            Valeur("chaud", "Plutôt chaud et rond",
                   "Graves présents, aigus adoucis. Souvent recherché en jazz, "
                   "en blues, pour la voix et le jeu aux doigts."),
            Valeur("equilibre", "Plutôt équilibré",
                   "Aucun registre ne domine. Passe-partout, s'adapte à "
                   "plusieurs styles et se traite bien au mixage."),
            Valeur("clair", "Plutôt clair et brillant",
                   "Aigus en avant, définition nette. Souvent recherché en "
                   "folk, en country, en pop et pour le jeu au médiator."),
        ),
    ),
    Axe(
        cle="attaque",
        titre="Réponse à l'attaque",
        question="Réponse à l'attaque souhaitée",
        valeurs=(
            Valeur("douce", "Douce et progressive",
                   "Le son s'installe. Pardonne les irrégularités de la main "
                   "droite, agréable en accompagnement."),
            Valeur("franche", "Franche",
                   "Le son répond sans traîner ni claquer. Le comportement le "
                   "plus courant."),
            Valeur("percussive", "Percussive et immédiate",
                   "Attaque marquée, très lisible. Utile en rythmique, en "
                   "funk, en percussif et pour le jeu rapide."),
        ),
    ),
    Axe(
        cle="tenue",
        titre="Tenue des notes",
        question="Tenue des notes souhaitée",
        valeurs=(
            Valeur("courte", "Courte et nette",
                   "La note s'arrête vite. Les accords restent lisibles, "
                   "l'articulation ressort."),
            Valeur("moyenne", "Moyenne",
                   "Tenue habituelle, sans caractère particulier dans un sens "
                   "ou dans l'autre."),
            Valeur("longue", "Longue et chantante",
                   "La note se prolonge. Utile pour les solos tenus et le jeu "
                   "en son saturé."),
        ),
    ),
)

PAR_CLE: dict[str, Axe] = {a.cle: a for a in AXES}


def axe(cle: str) -> Axe | None:
    return PAR_CLE.get(cle)


def libelle(axe_cle: str, valeur_cle: str | None) -> str | None:
    """Libellé affichable, ou None si l'axe ou la valeur est inconnu."""
    a = PAR_CLE.get(axe_cle)
    if a is None or not valeur_cle:
        return None
    v = a.valeur(valeur_cle)
    return v.libelle if v else None


def normaliser(axe_cle: str, valeur: str | None) -> str | None:
    """Referme le vocabulaire : une valeur inventée dans une URL est ignorée."""
    a = PAR_CLE.get(axe_cle)
    if a is None or not valeur:
        return None
    valeur = valeur.strip().lower()
    return valeur if a.valeur(valeur) else None


# --------------------------------------------------------------------------- #
# Reprise des anciennes fiches chiffrées
# --------------------------------------------------------------------------- #

def depuis_chiffres(chaleur: int | None,
                    brillance: int | None,
                    dynamique: int | None) -> dict[str, str | None]:
    """Traduit d'anciennes notes 0-10 en valeurs du vocabulaire.

    La couleur se lit dans l'écart entre chaleur et brillance : c'est le
    rapport entre les deux qui portait du sens, pas leur niveau absolu. Un
    écart de moins de deux points est traité comme un équilibre, parce qu'un
    point d'écart sur une note déclarée ne veut rien dire.

    La tenue n'est pas déductible de ces trois nombres : elle reste vide, à
    renseigner par l'artisan quand il relit sa fiche.
    """
    couleur = None
    if chaleur is not None and brillance is not None:
        ecart = chaleur - brillance
        couleur = "chaud" if ecart >= 2 else "clair" if ecart <= -2 else "equilibre"
    elif chaleur is not None:
        couleur = "chaud" if chaleur >= 7 else "equilibre"
    elif brillance is not None:
        couleur = "clair" if brillance >= 7 else "equilibre"

    attaque = None
    if dynamique is not None:
        attaque = ("percussive" if dynamique >= 7
                   else "douce" if dynamique <= 4 else "franche")

    return {"couleur": couleur, "attaque": attaque, "tenue": None}


# --------------------------------------------------------------------------- #
# Lecture d'une fiche
# --------------------------------------------------------------------------- #

def declare(profil) -> dict[str, str]:
    """`{cle_axe: cle_valeur}` pour les axes réellement renseignés.

    Les valeurs textuelles ont la priorité. Si elles sont absentes mais que la
    fiche porte encore d'anciennes notes, on les convertit à la volée.
    """
    brut = {
        "couleur": normaliser("couleur", getattr(profil, "couleur", None)),
        "attaque": normaliser("attaque", getattr(profil, "attaque", None)),
        "tenue": normaliser("tenue", getattr(profil, "tenue", None)),
    }
    if not any(brut.values()):
        brut = depuis_chiffres(
            getattr(profil, "chaleur", None),
            getattr(profil, "brillance", None),
            getattr(profil, "dynamique", None),
        )
    return {k: v for k, v in brut.items() if v}


def phrases(profil) -> list[tuple[str, str, str]]:
    """`[(titre_axe, libellé_valeur, aide)]` pour l'affichage sur la fiche."""
    sorties = []
    for a in AXES:
        cle = declare(profil).get(a.cle)
        v = a.valeur(cle) if cle else None
        if v:
            sorties.append((a.titre, v.libelle, v.aide))
    return sorties


def resume(profil) -> str | None:
    """Une ligne courte pour les cartes d'annuaire, ou None si rien n'est dit."""
    dit = declare(profil)
    morceaux = [libelle(a.cle, dit[a.cle]) for a in AXES if a.cle in dit]
    return " · ".join(m for m in morceaux if m) or None


# --------------------------------------------------------------------------- #
# Rapprochement avec un souhait
# --------------------------------------------------------------------------- #

def comparer(profil, souhaits: dict[str, str | None]
             ) -> tuple[float | None, list[str], list[str]]:
    """Compare un profil déclaré aux souhaits du musicien.

    Retourne `(proximite, pour, contre)`. `proximite` vaut None quand la
    comparaison est impossible — soit le musicien n'a rien demandé, soit
    l'atelier n'a rien déclaré sur les axes demandés. Dans ce cas la
    recommandation ne doit ni récompenser ni pénaliser la fiche.

    Sur un axe donné : même valeur = 1, valeur voisine = 0,5, valeur opposée
    = 0. Le voisinage n'est pas un classement, seulement la reconnaissance que
    « équilibré » est plus proche de « chaud » que « clair » ne l'est.
    """
    dit = declare(profil)
    scores: list[float] = []
    pour: list[str] = []
    contre: list[str] = []

    for a in AXES:
        voulu = normaliser(a.cle, souhaits.get(a.cle))
        if not voulu:
            continue
        obtenu = dit.get(a.cle)
        if not obtenu:
            contre.append(f"{a.titre} non renseignée par cet atelier")
            continue
        ra, rb = a.rang(obtenu), a.rang(voulu)
        assert ra is not None and rb is not None
        distance = abs(ra - rb)
        scores.append(1.0 if distance == 0 else 0.5 if distance == 1 else 0.0)
        libelle_obtenu = a.valeur(obtenu).libelle.lower()
        libelle_voulu = a.valeur(voulu).libelle.lower()
        if distance == 0:
            pour.append(f"{a.titre} annoncée « {libelle_obtenu} », "
                        f"comme vous le cherchez")
        elif distance == 1:
            pour.append(f"{a.titre} annoncée « {libelle_obtenu} », "
                        f"proche de « {libelle_voulu} »")
        else:
            contre.append(f"{a.titre} annoncée « {libelle_obtenu} » alors que "
                          f"vous cherchez « {libelle_voulu} »")

    if not scores:
        return None, pour, contre
    return sum(scores) / len(scores), pour, contre


def timbres_disponibles(fiches) -> list[tuple[str, str]]:
    """Valeurs de couleur réellement présentes dans l'annuaire.

    Sert à ne pas proposer un filtre qui ne renverrait jamais rien.
    """
    presentes = {declare(f.profil_sonore).get("couleur") for f in fiches}
    a = PAR_CLE["couleur"]
    return [(v.cle, v.libelle) for v in a.valeurs if v.cle in presentes]
