"""
NOVALUTH — Persistance
======================

SQLite avec la fiche complète stockée en JSON (le dossier de projet prévoit
« base JSON structurée au départ »), plus des colonnes indexées pour filtrer
vite. Migration vers PostgreSQL possible plus tard sans toucher aux schémas.

Registre RGPD intégré : chaque brief conserve la trace de son consentement, sa
date de purge automatique et son statut d'anonymisation.
"""

from __future__ import annotations

import datetime as dt
import json
import sqlite3
from pathlib import Path
from typing import Any, Iterable

from .schemas import Fiche, StatutFiche

RACINE = Path(__file__).resolve().parent.parent
CHEMIN_DB = Path(__import__("os").environ.get("NOVALUTH_DB", RACINE / "data" / "novaluth.db"))
FICHIER_SEED = RACINE / "data" / "fiches_demonstration.json"

# Durée de conservation des briefs (RGPD, minimisation) : 12 mois maximum.
CONSERVATION_BRIEF_JOURS = 365


def maintenant() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


class _Connexion(sqlite3.Connection):
    """Connexion qui se referme en sortant du bloc `with`.

    Le comportement par défaut de sqlite3 ne ferme rien : `with connexion()`
    valide la transaction mais laisse la connexion ouverte. En mode WAL chaque
    connexion consomme trois descripteurs de fichier ; sur un service qui tourne
    des semaines, cela finit par épuiser la limite du système et toute écriture
    échoue. On referme donc explicitement."""

    def __exit__(self, *exc: Any) -> None:
        try:
            super().__exit__(*exc)
        finally:
            self.close()


def connexion() -> sqlite3.Connection:
    CHEMIN_DB.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(CHEMIN_DB, timeout=15, factory=_Connexion)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def initialiser() -> None:
    with connexion() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS fiches(
                slug TEXT PRIMARY KEY,
                nom TEXT NOT NULL,
                type TEXT NOT NULL,
                pays TEXT,
                ville TEXT,
                statut TEXT NOT NULL DEFAULT 'candidate',
                prix_min_eur INTEGER,
                prix_max_eur INTEGER,
                score_innovation INTEGER,
                score_originalite INTEGER,
                emergence INTEGER DEFAULT 0,
                donnees TEXT NOT NULL,
                cree_le TEXT,
                maj_le TEXT,
                mentions_7j INTEGER DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_fiches_statut ON fiches(statut);
            CREATE INDEX IF NOT EXISTS idx_fiches_pays ON fiches(pays);

            CREATE TABLE IF NOT EXISTS mentions(
                id INTEGER PRIMARY KEY,
                slug TEXT NOT NULL,
                source TEXT,
                url TEXT,
                vue_le TEXT,
                UNIQUE(slug, url)
            );

            CREATE TABLE IF NOT EXISTS briefs(
                id INTEGER PRIMARY KEY,
                reference TEXT UNIQUE,
                cree_le TEXT NOT NULL,
                purge_prevue_le TEXT NOT NULL,
                criteres TEXT NOT NULL,         -- brief SANS e-mail : anonyme
                email TEXT,                     -- NULL si pas de mise en relation
                consentement INTEGER DEFAULT 0,
                consentement_le TEXT,
                consentement_preuve TEXT,       -- libellé exact affiché à la case
                recommandations TEXT,
                statut TEXT DEFAULT 'nouveau',  -- nouveau | transmis | anonymise
                anonymise_le TEXT
            );

            CREATE TABLE IF NOT EXISTS journal(
                id INTEGER PRIMARY KEY,
                horodatage TEXT NOT NULL,
                evenement TEXT NOT NULL,
                objet TEXT,
                detail TEXT
            );
            """
        )
    charger_seed_si_vide()


def journaliser(evenement: str, objet: str = "", detail: str = "") -> None:
    with connexion() as conn:
        conn.execute(
            "INSERT INTO journal(horodatage,evenement,objet,detail) VALUES(?,?,?,?)",
            (maintenant(), evenement, objet[:120], detail[:500]),
        )


# --------------------------------------------------------------------------- #
# Fiches
# --------------------------------------------------------------------------- #

def enregistrer_fiche(fiche: Fiche, emergence: int | None = None) -> None:
    """emergence=None conserve le score d'émergence déjà enregistré."""
    donnees = fiche.model_dump(mode="json")
    donnees["maj_le"] = maintenant()
    donnees.setdefault("cree_le", donnees["maj_le"])
    with connexion() as conn:
        conn.execute(
            """
            INSERT INTO fiches(slug,nom,type,pays,ville,statut,prix_min_eur,prix_max_eur,
                               score_innovation,score_originalite,emergence,donnees,
                               cree_le,maj_le)
            VALUES(:slug,:nom,:type,:pays,:ville,:statut,:prix_min,:prix_max,
                   :s_inno,:s_orig,COALESCE(:emergence,0),:donnees,:cree_le,:maj_le)
            ON CONFLICT(slug) DO UPDATE SET
                nom=excluded.nom, type=excluded.type, pays=excluded.pays,
                ville=excluded.ville, statut=excluded.statut,
                prix_min_eur=excluded.prix_min_eur, prix_max_eur=excluded.prix_max_eur,
                score_innovation=excluded.score_innovation,
                score_originalite=excluded.score_originalite,
                emergence=CASE WHEN :emergence IS NULL THEN fiches.emergence
                               ELSE excluded.emergence END,
                donnees=excluded.donnees,
                maj_le=excluded.maj_le
            """,
            {
                "slug": fiche.slug, "nom": fiche.nom, "type": fiche.type.value,
                "pays": fiche.pays, "ville": fiche.ville, "statut": fiche.statut.value,
                "prix_min": fiche.prix_min_eur, "prix_max": fiche.prix_max_eur,
                "s_inno": fiche.score_innovation, "s_orig": fiche.score_originalite,
                "emergence": emergence,
                "donnees": json.dumps(donnees, ensure_ascii=False),
                "cree_le": donnees["cree_le"], "maj_le": donnees["maj_le"],
            },
        )


def lire_fiche(slug: str) -> Fiche | None:
    with connexion() as conn:
        ligne = conn.execute("SELECT donnees FROM fiches WHERE slug=?", (slug,)).fetchone()
    return Fiche(**json.loads(ligne["donnees"])) if ligne else None


def lister_fiches(statut: str | Iterable[str] = StatutFiche.publiee.value,
                  limite: int = 200) -> list[Fiche]:
    statuts = [statut] if isinstance(statut, str) else list(statut)
    marques = ",".join("?" * len(statuts))
    with connexion() as conn:
        lignes = conn.execute(
            # Ordre neutre et déterminé : l'ordre d'affichage public est
            # décidé par web/recherche.ordonner(), pas par la base, et surtout
            # pas par un score d'innovation.
            f"SELECT donnees FROM fiches WHERE statut IN ({marques}) "
            f"ORDER BY slug ASC LIMIT ?",
            (*statuts, limite),
        ).fetchall()
    return [Fiche(**json.loads(l["donnees"])) for l in lignes]


def changer_statut(slug: str, statut: str) -> bool:
    if statut not in {s.value for s in StatutFiche}:
        return False
    with connexion() as conn:
        curseur = conn.execute(
            "UPDATE fiches SET statut=?, maj_le=? WHERE slug=?",
            (statut, maintenant(), slug),
        )
        touche = curseur.rowcount > 0
    if touche:
        # On garde aussi le statut dans le JSON pour rester cohérent.
        fiche = lire_fiche(slug)
        if fiche:
            fiche.statut = StatutFiche(statut)
            enregistrer_fiche(fiche)
        journaliser("statut_fiche", slug, statut)
    return touche


def compter_par_statut() -> dict[str, int]:
    with connexion() as conn:
        lignes = conn.execute(
            "SELECT statut, COUNT(*) n FROM fiches GROUP BY statut"
        ).fetchall()
    return {l["statut"]: l["n"] for l in lignes}


def ajouter_mention(slug: str, source: str, url: str) -> None:
    with connexion() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO mentions(slug,source,url,vue_le) VALUES(?,?,?,?)",
            (slug, source, url, maintenant()),
        )


# --------------------------------------------------------------------------- #
# Briefs + registre de consentement
# --------------------------------------------------------------------------- #

LIBELLE_CONSENTEMENT = (
    "J'autorise les artisans correspondant à ce projet à demander à me répondre. "
    "Mon adresse e-mail ne leur est transmise qu'après mon accord, demande par "
    "demande, et pour ce seul projet. Trois ateliers au maximum. Je peux "
    "décliner chaque demande, clôturer mon projet en un clic, et retirer ce "
    "consentement à tout moment."
)


def enregistrer_brief(reference: str, criteres: dict[str, Any],
                      recommandations: list[dict[str, Any]],
                      email: str | None, consentement: bool) -> None:
    criteres_anonymes = {k: v for k, v in criteres.items() if k != "email"}
    purge = (dt.datetime.now(dt.timezone.utc)
             + dt.timedelta(days=CONSERVATION_BRIEF_JOURS)).isoformat(timespec="seconds")
    with connexion() as conn:
        conn.execute(
            """INSERT INTO briefs(reference,cree_le,purge_prevue_le,criteres,email,
                                  consentement,consentement_le,consentement_preuve,
                                  recommandations)
               VALUES(?,?,?,?,?,?,?,?,?)""",
            (reference, maintenant(), purge,
             json.dumps(criteres_anonymes, ensure_ascii=False),
             email if (email and consentement) else None,
             1 if consentement else 0,
             maintenant() if consentement else None,
             LIBELLE_CONSENTEMENT if consentement else None,
             json.dumps(recommandations, ensure_ascii=False)),
        )
    journaliser("brief", reference, f"consentement={consentement}")


def purger_briefs_expires() -> int:
    """Anonymisation automatique : on efface l'e-mail, on garde les critères
    statistiques. À appeler par le cron quotidien."""
    with connexion() as conn:
        curseur = conn.execute(
            """UPDATE briefs SET email=NULL, statut='anonymise', anonymise_le=?
               WHERE email IS NOT NULL AND purge_prevue_le < ?""",
            (maintenant(), maintenant()),
        )
        n = curseur.rowcount
    if n:
        journaliser("purge_rgpd", "briefs", f"{n} briefs anonymisés")
    return n


def effacer_donnees_email(email: str) -> int:
    """Droit à l'effacement (art. 17 RGPD) : suppression sur simple demande."""
    with connexion() as conn:
        curseur = conn.execute(
            "UPDATE briefs SET email=NULL, statut='anonymise', anonymise_le=? WHERE email=?",
            (maintenant(), email.lower()),
        )
        n = curseur.rowcount
    journaliser("droit_effacement", "brief", f"{n} enregistrements anonymisés")
    return n


def exporter_donnees_email(email: str) -> list[dict[str, Any]]:
    """Droit d'accès et de portabilité (art. 15 et 20 RGPD)."""
    with connexion() as conn:
        lignes = conn.execute(
            "SELECT reference,cree_le,criteres,recommandations,consentement_le,"
            "consentement_preuve,purge_prevue_le FROM briefs WHERE email=?",
            (email.lower(),),
        ).fetchall()
    return [dict(l) for l in lignes]


# --------------------------------------------------------------------------- #
# Amorçage
# --------------------------------------------------------------------------- #

def charger_seed_si_vide() -> None:
    with connexion() as conn:
        deja = conn.execute("SELECT COUNT(*) n FROM fiches").fetchone()["n"]
    if deja or not FICHIER_SEED.exists():
        return
    contenu = json.loads(FICHIER_SEED.read_text(encoding="utf-8"))
    for brut in contenu.get("fiches", []):
        try:
            enregistrer_fiche(Fiche(**brut))
        except Exception as e:  # une fiche mal formée ne bloque pas le démarrage
            print(f"[seed] fiche ignorée : {e}")
    journaliser("seed", "fiches_demonstration", f"{len(contenu.get('fiches', []))} fiches")
