# Mise à jour — le paiement n'a lieu qu'à l'acceptation du musicien

Cette mise à jour répond au problème suivant : un atelier payait 19 € pour
obtenir des coordonnées, puis découvrait que le projet était déjà abandonné.
L'argent était parti, la commande n'existait plus.

Le principe retenu : **rien n'est débité avant que le musicien ait dit oui.**

---

## 1. Ce qui change concrètement

| Avant | Maintenant |
|---|---|
| L'atelier paie, puis reçoit l'adresse | L'atelier demande, le musicien accepte, **puis** le paiement est encaissé |
| Le musicien découvre un message d'un inconnu | Le musicien reçoit une demande et décide lui-même |
| Un projet mort pouvait être vendu plusieurs fois | Un projet ouvert à **3 ateliers maximum**, demandes en attente comprises |
| Rien ne signalait un projet dormant | Relance automatique à 21 jours, mise en sommeil sans réponse |
| Un échange qui s'éteint après paiement était perdu | **Crédit de relance** sur demande |

Cinq états de sortie, et un seul est facturé :

1. le musicien accepte → coordonnées transmises, **19 € encaissés** ;
2. il décline → 0 € ;
3. il signale son projet abandonné → 0 €, projet clôturé ;
4. il ne répond pas sous 5 jours → 0 €, autorisation annulée ;
5. l'atelier retire sa demande avant réponse → 0 €.

---

## 2. Fichiers ajoutés

| Fichier | Rôle |
|---|---|
| `common/paiement.py` | Autorisation / encaissement / annulation. Deux moteurs : simulé et Stripe |
| `web/courriel.py` | Les huit messages du circuit. Écrit dans `data/courriels/` tant qu'aucun SMTP n'est configuré |
| `web/store_acces.py` | Tables `ateliers`, `acces`, `credits`, `relances` + colonnes ajoutées aux projets |
| `web/acces.py` | Espace atelier, page de suivi du musicien, toutes les décisions |
| `web/taches.py` | Tâche quotidienne : expirations, relances, mises en sommeil, crédits |
| `templates/atelier_connexion.html` | Connexion de l'atelier par lien e-mail, sans mot de passe |
| `templates/atelier.html` | Tableau de bord de l'atelier |
| `templates/projet_musicien.html` | Page personnelle du musicien : accepter, décliner, clôturer |
| `templates/projet_cloture.html` | Confirmation après clôture |

## 3. Fichiers modifiés

`web/main.py` · `web/store.py` (texte du consentement) · `templates/base.html` ·
`templates/brief.html` · `templates/resultat.html` · `templates/admin.html` ·
`legal/cgv.md` (articles 1, 3, 4, 5) · `legal/confidentialite.md` (article 6 bis) ·
`.env.example` · `INSTALLATION-REPLIT.md` (sections 8, 8 bis, 8 ter).

---

## 4. Installation sur Replit — depuis un iPhone

### a. Déposer les fichiers

Ouvrez le Repl, onglet **Files**, menu ⋮ → **Upload folder**, et déposez le
contenu du dossier `novaluth` de cette archive. Répondez **Replace / Overwrite**
si la question est posée : seuls les fichiers listés ci-dessus sont touchés.

### b. Ajouter trois secrets

Onglet **Secrets** (cadenas), bouton **New secret** :

| Clé | Valeur à coller |
|---|---|
| `NOVALUTH_PAIEMENT` | `simule` |
| `NOVALUTH_EXPEDITEUR` | `contact@novaluth.com` |
| `NOVALUTH_URL` | `https://novaluth.com` |

`NOVALUTH_URL` est indispensable : c'est elle qui fabrique les liens envoyés aux
musiciens et aux ateliers.

### c. Redémarrer

Bouton **Run**. La base se met à jour toute seule au démarrage : les nouvelles
tables et colonnes sont créées si elles manquent. Vos fiches et vos projets
existants sont conservés.

### d. Programmer la tâche quotidienne

**Deployments** → **Scheduled** → **New scheduled job** :

- commande : `python -m web.taches`
- fréquence : une fois par jour, par exemple 8 h

C'est cette tâche qui annule les autorisations sans réponse, envoie les relances
et accorde les crédits. Sans elle, une demande resterait suspendue jusqu'à son
expiration bancaire.

---

## 5. Essayer le circuit sans payer quoi que ce soit

Avec `NOVALUTH_PAIEMENT=simule`, aucune carte n'est appelée : chaque mouvement
est écrit dans `data/paiements_simules.jsonl`. Tant que `NOVALUTH_SMTP_HOTE`
n'est pas renseigné, les messages ne partent pas non plus : ils sont écrits dans
`data/courriels/`, lisibles depuis l'onglet Files.

1. **Rattachez une adresse à un atelier** : `/admin` → carte « Adresse de contact
   d'un atelier » → choisissez une fiche, saisissez l'adresse.
2. **Déposez un projet de test** depuis `/brief`, en cochant la mise en relation.
3. **Ouvrez `/atelier`**, saisissez l'adresse de l'atelier. Un message est écrit
   dans `data/courriels/` : ouvrez-le, copiez le lien de connexion.
4. **Demandez l'accès** au projet. Rien n'est débité, et un message part vers le
   musicien.
5. **Ouvrez le message du musicien**, suivez son lien, et essayez les trois
   boutons : accepter, décliner, projet abandonné.
6. **Vérifiez** `data/paiements_simules.jsonl` : vous devez y voir
   `preautorisation` puis `encaissement` en cas d'acceptation, ou
   `preautorisation` puis `annulation` dans tous les autres cas.

---

## 6. Passer à Stripe plus tard, sans retoucher le code

| Secret | Valeur |
|---|---|
| `NOVALUTH_PAIEMENT` | `stripe` |
| `STRIPE_SECRET_KEY` | votre clé secrète Stripe |

Redéployez, c'est tout. Les autorisations passent alors par Stripe en mode
`capture_method=manual` : l'argent est retenu à la demande, encaissé à
l'acceptation, libéré sinon
([documentation Stripe](https://docs.stripe.com/payments/place-a-hold-on-a-payment-method)).
La fenêtre de réponse est fixée à cinq jours pour rester à l'intérieur de la
durée de validité d'une autorisation, généralement sept jours
([autorisation étendue](https://docs.stripe.com/payments/extended-authorization)).

Avant cette bascule : immatriculation effective, mentions légales complétées, et
les quatre champs `[À COMPLÉTER]` signalés par `python -m tools.verifier_conformite`
renseignés.

---

## 7. Réglages, si vous voulez les changer

Tout est en haut de `web/store_acces.py` :

```python
TRANCHES_PRIX = (                    # (budget max inclus, prix en centimes, …)
    (1499, 999,  "petit projet",     "budget annoncé de moins de 1 500 €"),
    (4000, 1599, "projet courant",   "budget annoncé de 1 500 € à 4 000 €"),
    (None, 2499, "grande commande",  "budget annoncé de plus de 4 000 €"),
)
PRIX_ACCES_CENTS = 1599              # tarif retenu si le budget n'est pas rempli
CARNETS = (                          # (prix payé, solde crédité, libellé)
    (6900,  7995,  "carnet de 5"),
    (11900, 15990, "carnet de 10"),
)
VALIDITE_SOLDE_MOIS = 24             # validité d'un solde d'accès prépayé
FENETRE_ACCEPTATION_JOURS = 5        # délai de réponse du musicien
PLAFOND_ATELIERS_PAR_PROJET = 3      # ateliers par projet
CONFIRMATION_FRAICHEUR_JOURS = 21    # relance « toujours d'actualité ? »
DELAI_SOMMEIL_JOURS = 7              # sans réponse à la relance → sommeil
DELAI_DEMANDE_CREDIT_JOURS = 30      # délai pour demander un crédit
FENETRE_REPONSE_RELANCE_JOURS = 7    # silence du musicien → crédit accordé
ACCES_FACTURES_PAR_CREDIT = 4        # 1 crédit par tranche de 4 accès payés
```

Les CGV annoncent la fourchette 9,99 à 24,99 € et détaillent les trois tranches :
si vous changez un montant ou une borne, corrigez aussi l'article 3 de
`legal/cgv.md`. Les carnets y figurent à l'article 3 bis.

---

## 8. Vérifications passées avant livraison

- `python -m tools.verifier_conformite` : aucune anomalie bloquante ; les quatre
  points restants sont les champs d'identité à compléter.
- Jeu de tests du circuit complet : 101 vérifications, dont l'expiration à cinq
  jours, le déclin, l'abandon, la clôture, la mise en sommeil, la réactivation,
  le retrait de demande, le plafond de trois ateliers, l'attribution d'un
  crédit de relance, les bornes des trois tranches de prix, l'achat d'un carnet,
  le prélèvement puis la restitution du solde, et la règle d'un seul projet par
  adresse.
- Pages relues sur écran de téléphone (390 × 844) : espace atelier, page de suivi
  du musicien avant et après confirmation, formulaire de projet.

---

## 9. Trois mécanismes ajoutés dans cette version

### a. Le prix suit le budget du projet

Un contact sur une commande à 6 000 € n'a pas la même valeur qu'un contact sur
une commande à 900 €. Le prix de l'accès dépend donc du budget maximum annoncé
par le musicien : **9,99 €** en dessous de 1 500 €, **15,99 €** de 1 500 à
4 000 €, **24,99 €** au-delà. Le prix est affiché sur chaque projet, dans
l'espace atelier, avant toute demande. Si le musicien n'a pas rempli de budget,
c'est la tranche intermédiaire qui s'applique.

### b. Les carnets d'accès sont un solde en euros, pas un nombre d'accès

Point important, et c'est pourquoi le carnet n'est **pas** vendu comme
« 10 accès » : avec un prix variable, un carnet de dix accès acheté à 11,90 €
l'unité puis dépensé uniquement sur des projets à 24,99 € coûterait environ
130 € de perte. Le carnet est donc une somme payée d'avance, majorée :

| Carnet | Payé | Solde crédité | Coût d'un accès courant |
|---|---|---|---|
| Carnet de 5 | 69,00 € | 79,95 € | 13,80 € |
| Carnet de 10 | 119,00 € | 159,90 € | 11,90 € |

Chaque demande réserve sur le solde le prix de sa tranche, et cette somme
revient au solde si la demande n'aboutit pas. Le solde est valable
vingt-quatre mois, utilisable uniquement sur Novaluth, jamais reversé en argent —
sauf si Novaluth arrête le service, auquel cas la part non utilisée est
remboursée au prorata de la somme réellement payée. C'est ce cadre qui permet de
rester sur un titre à usage restreint, sans relever de la monnaie électronique.

Attention au vocabulaire, il y a maintenant deux choses distinctes :

- le **crédit de relance**, gratuit, accordé quand un échange reste sans suite ;
- le **carnet d'accès** et son **solde**, achetés d'avance.

Un crédit de relance passe toujours avant le solde : il est là pour être utilisé.

### c. Le sérieux du musicien, sans rien lui facturer

Trois garde-fous, aucun ne coûte un centime au musicien :

1. **Double confirmation par courriel.** Après le dépôt, le musicien reçoit un
   lien et doit cliquer « Je confirme mon projet ». Tant qu'il ne l'a pas fait,
   le projet **n'apparaît dans aucun espace atelier**. Une adresse mal saisie ne
   mobilise donc plus personne.
2. **Un seul projet ouvert par adresse.** Un second dépôt avec la même adresse
   renvoie vers la page de suivi du projet en cours, avec un renvoi du lien par
   courriel, au lieu de créer un doublon.
3. **La réciprocité est affichée.** Le courriel de demande et la page de suivi
   indiquent la somme que l'atelier engage pour écrire — « cet atelier engage
   15,99 € », montant réel de la tranche. Un musicien qui sait qu'il y a un
   engagement en face répond davantage, y compris pour décliner.

### d. Un défaut corrigé au passage

Les connexions à la base de données n'étaient jamais refermées : `with
connexion()` valide la transaction mais laisse la connexion ouverte, et en mode
WAL chacune consomme trois descripteurs de fichier. Sur un service qui tourne
plusieurs semaines, la limite du système finit par être atteinte et toute
écriture échoue. C'est corrigé dans `web/store.py` : la connexion se referme
en sortant du bloc.
