"""
NOVALUTH — Mesure de l'isolation des clés
=========================================

L'application publique ne doit jamais nommer, lire ni transmettre une clé de
subnet. Elle a pourtant besoin de pouvoir dire honnêtement, sur sa route
/sante, si de telles clés se trouvent dans l'environnement du processus.

Ce module répond à cette seule question, sans citer aucun nom de clé : il
recherche les variables d'environnement dont le nom se termine par `_API_KEY`
et qui n'appartiennent pas au projet lui-même. C'est volontairement générique :
toute clé de fournisseur ajoutée plus tard sera détectée sans modification.

Distinction importante, souvent confondue :

  · « lues par ce service »   → invariant de code. Aucune fonction de web/ ne
    lit une clé de fournisseur ; les appels passent tous par la passerelle.
  · « dans l'environnement »  → fait d'hébergement. Dans un Repl unique, Replit
    injecte les secrets pour l'ensemble du Repl : les deux processus voient donc
    les mêmes variables. Le mesurer évite d'annoncer une isolation que
    l'hébergement ne fournit pas.
"""

from __future__ import annotations

import os

SUFFIXE_CLE_FOURNISSEUR = "_API_KEY"
PREFIXE_PROJET = "NOVALUTH_"


def noms_cles_fournisseur_presentes() -> list[str]:
    """Noms — jamais les valeurs — des clés de fournisseur trouvées dans
    l'environnement du processus courant."""
    return sorted(
        nom for nom, valeur in os.environ.items()
        if valeur
        and nom.endswith(SUFFIXE_CLE_FOURNISSEUR)
        and not nom.startswith(PREFIXE_PROJET)
    )


def cles_subnet_dans_environnement() -> bool:
    """Vrai si au moins une clé de fournisseur est visible depuis ce processus."""
    return bool(noms_cles_fournisseur_presentes())
