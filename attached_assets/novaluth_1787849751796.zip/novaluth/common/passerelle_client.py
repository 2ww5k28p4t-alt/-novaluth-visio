"""
NOVALUTH — Client de la passerelle IA
=====================================

Le seul moyen, pour l'application web et pour le pipeline, d'utiliser les
subnets Bittensor. Ce client ne connaît AUCUNE clé de subnet : il connaît
seulement l'URL de la passerelle et le secret interne partagé.

Conséquence directe : même si le code de l'application publique fuitait
entièrement, aucune clé Chutes ni SN13 ne serait exposée.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from typing import Any

import httpx

URL_PASSERELLE = os.environ.get("NOVALUTH_GATEWAY_URL", "http://127.0.0.1:8100")
SECRET_INTERNE = os.environ.get("NOVALUTH_GATEWAY_SECRET", "")
NOM_CLIENT = os.environ.get("NOVALUTH_CLIENT_NAME", "web")


class PasserelleIndisponible(RuntimeError):
    """Lancée quand la passerelle refuse ou ne répond pas. Toujours rattrapée
    par l'appelant : l'application doit rester utilisable sans IA."""


def _signer(corps: bytes) -> dict[str, str]:
    if not SECRET_INTERNE or len(SECRET_INTERNE) < 32:
        raise PasserelleIndisponible(
            "NOVALUTH_GATEWAY_SECRET manquant côté client (32 caractères minimum)."
        )
    horodatage = f"{time.time():.3f}"
    nonce = secrets.token_hex(16)
    message = horodatage.encode() + b"." + nonce.encode() + b"." + corps
    signature = hmac.new(SECRET_INTERNE.encode(), message, hashlib.sha256).hexdigest()
    return {
        "Content-Type": "application/json",
        "X-Novaluth-Timestamp": horodatage,
        "X-Novaluth-Nonce": nonce,
        "X-Novaluth-Signature": signature,
        "X-Novaluth-Client": NOM_CLIENT,
    }


def _appeler(chemin: str, charge: dict[str, Any], timeout: float) -> dict[str, Any]:
    corps = json.dumps(charge, ensure_ascii=False).encode()
    try:
        reponse = httpx.post(URL_PASSERELLE + chemin, content=corps,
                             headers=_signer(corps), timeout=timeout)
    except httpx.HTTPError as e:
        raise PasserelleIndisponible(f"Passerelle injoignable : {type(e).__name__}") from e
    if reponse.status_code >= 400:
        detail = ""
        try:
            detail = reponse.json().get("erreur", "")
        except Exception:
            pass
        raise PasserelleIndisponible(f"Passerelle {reponse.status_code} : {detail}")
    return reponse.json()


# --------------------------------------------------------------------------- #
# API publique du client
# --------------------------------------------------------------------------- #

def demander_recherche(requete: str, *, limite: int = 10) -> list[dict[str, Any]]:
    """Demande des ADRESSES de pages à la chaîne de recherche.

    Ce que renvoie cette fonction n'est jamais publiable tel quel : c'est une
    liste de pistes (url, titre, extrait court) servant uniquement à décider
    quelles pages aller lire à la source.
    """
    reponse = _appeler("/v1/recherche", {"requete": requete, "limite": limite},
                       timeout=100)
    return reponse.get("resultats") or []


def demander_page(url: str) -> dict[str, Any]:
    """Demande la lecture d'une page publique.

    Retourne toujours un dictionnaire. Quand la lecture est refusée — robots.txt,
    opposition à la fouille de données, domaine exclu — la clé ``lue`` vaut False
    et ``motif`` explique pourquoi, en français, de façon montrable à l'artisan.
    """
    return _appeler("/v1/page", {"url": url}, timeout=90)


def demander_ia(systeme: str, utilisateur: str, *, modele: str | None = None,
                outil: dict[str, Any] | None = None, temperature: float = 0.1,
                max_tokens: int = 900) -> dict[str, Any]:
    """Confie un travail de rédaction ou d'extraction à la chaîne d'inférence.

    L'appelant ne choisit pas le fournisseur : il décrit le travail. La
    passerelle essaie les fournisseurs déclarés dans l'ordre et indique dans sa
    réponse lequel a répondu, sous la clé ``fournisseur``.
    """
    charge: dict[str, Any] = {
        "systeme": systeme,
        "utilisateur": utilisateur,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }
    if modele:
        charge["modele"] = modele
    if outil:
        charge["outil"] = outil
    return _appeler("/v1/ia", charge, timeout=130)


def demander_collecte(source: str, mots_cles: list[str], *, jours: int = 3,
                      limite: int = 300) -> list[dict[str, Any]]:
    """Demande des mentions publiques à la chaîne de collecte sociale."""
    reponse = _appeler("/v1/collecte",
                       {"source": source, "mots_cles": mots_cles,
                        "jours": jours, "limite": limite},
                       timeout=200)
    return reponse.get("publications") or []


def passerelle_en_vie() -> dict[str, Any] | None:
    try:
        reponse = httpx.get(URL_PASSERELLE + "/sante", timeout=5)
        return reponse.json() if reponse.status_code == 200 else None
    except httpx.HTTPError:
        return None


def etat_fournisseurs() -> dict[str, Any] | None:
    """État déclaré de la chaîne technique : qui, à quel tarif, sous quelle
    licence, avec quelle réserve. Sert la page publique de transparence.

    Retourne None si la passerelle ne répond pas : la page doit rester lisible
    même sans passerelle, avec la mention correspondante.
    """
    try:
        reponse = httpx.get(URL_PASSERELLE + "/v1/etat", timeout=6)
        return reponse.json() if reponse.status_code == 200 else None
    except httpx.HTTPError:
        return None
