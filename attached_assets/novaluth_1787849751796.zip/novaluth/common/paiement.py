"""
NOVALUTH — Paiement en deux temps (pré-autorisation, puis encaissement)
=======================================================================

Pourquoi ce module existe
-------------------------
Un atelier ne doit jamais payer pour une adresse qui ne répondra jamais. Le
paiement d'un accès à un projet est donc découpé en deux :

  1. **pré-autorisation** au moment où l'atelier demande l'accès — la somme est
     réservée sur la carte, rien n'est débité, aucune coordonnée n'est
     transmise ;
  2. **encaissement** uniquement quand le musicien confirme qu'il souhaite être
     contacté. S'il décline, signale l'abandon de son projet ou ne répond pas
     dans la fenêtre prévue, l'autorisation est **annulée** et rien n'est
     débité.

Il n'y a donc aucun remboursement à traiter dans le cas le plus fréquent.

Contrainte technique à connaître
--------------------------------
Une autorisation de carte en ligne n'est pas éternelle. Chez Stripe, la durée
de validité par défaut est de 7 jours pour un paiement en ligne, et la date
exacte est portée par le champ `capture_before` de la charge. C'est la raison
pour laquelle la fenêtre laissée au musicien est plus courte (5 jours par
défaut) : il faut encaisser avant l'expiration de l'autorisation.
Voir https://docs.stripe.com/payments/place-a-hold-on-a-payment-method

Deux fournisseurs
-----------------
  · `simule`  — aucun mouvement d'argent. Le circuit complet est jouable de bout
                en bout, y compris les tâches automatiques. C'est le réglage par
                défaut, tant qu'aucun compte de paiement n'est ouvert.
  · `stripe`  — appels réels à l'API Stripe (PaymentIntent en capture manuelle).

On bascule d'un fournisseur à l'autre avec la variable d'environnement
`NOVALUTH_PAIEMENT` (`simule` ou `stripe`). Aucun autre fichier n'a à changer :
le reste du code ne connaît que les trois méthodes ci-dessous.

Novaluth n'est pas intermédiaire de paiement au sens du code monétaire et
financier : les sommes encaissées ici sont le prix de son propre service
(l'accès à un projet), jamais le prix d'un instrument. Le prix de l'instrument
se règle directement entre le musicien et l'artisan, sans passer par Novaluth.
"""

from __future__ import annotations

import datetime as dt
import json
import os
import secrets
from dataclasses import dataclass, field
from pathlib import Path

import httpx

RACINE = Path(__file__).resolve().parent.parent

# Durée de validité retenue par défaut pour une autorisation en ligne.
VALIDITE_AUTORISATION_JOURS = 7


class PaiementIndisponible(RuntimeError):
    """Le fournisseur de paiement refuse ou ne répond pas. Toujours rattrapée
    par l'appelant : une panne de paiement ne doit pas transmettre de
    coordonnées ni casser la page."""


def _maintenant() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _iso(instant: dt.datetime) -> str:
    return instant.isoformat(timespec="seconds")


@dataclass
class Autorisation:
    """Ce que le reste de l'application manipule. Volontairement pauvre : aucune
    donnée bancaire n'y figure, et rien de tout cela n'est stocké chez nous
    au-delà de l'identifiant et des dates."""

    identifiant: str
    montant_cents: int
    devise: str = "eur"
    fournisseur: str = "simule"
    etat: str = "autorisee"          # autorisee | encaissee | annulee
    encaissable_avant: str = ""      # ISO — au-delà, l'autorisation tombe
    # Renseigné seulement si le fournisseur exige une saisie de carte par
    # l'atelier : la route redirige alors vers cette étape.
    secret_client: str | None = None
    details: dict = field(default_factory=dict)


class FournisseurPaiement:
    """Contrat commun. Trois opérations, pas une de plus."""

    nom = "abstrait"
    exige_saisie_carte = False

    def preautoriser(self, montant_cents: int, reference: str,
                     description: str, email: str | None = None) -> Autorisation:
        raise NotImplementedError

    def encaisser(self, identifiant: str) -> Autorisation:
        raise NotImplementedError

    def annuler(self, identifiant: str, motif: str = "") -> Autorisation:
        raise NotImplementedError


# --------------------------------------------------------------------------- #
# Fournisseur simulé — aucun mouvement d'argent
# --------------------------------------------------------------------------- #

class PaiementSimule(FournisseurPaiement):
    """Écrit un journal lisible dans data/paiements_simules.jsonl et rien
    d'autre. Sert à jouer le circuit complet avant l'ouverture d'un compte de
    paiement, et à le rejouer ensuite en développement."""

    nom = "simule"
    exige_saisie_carte = False

    def __init__(self) -> None:
        self.journal = RACINE / "data" / "paiements_simules.jsonl"

    def _tracer(self, operation: str, autorisation: Autorisation) -> None:
        self.journal.parent.mkdir(parents=True, exist_ok=True)
        ligne = {
            "horodatage": _iso(_maintenant()),
            "operation": operation,
            "identifiant": autorisation.identifiant,
            "montant_cents": autorisation.montant_cents,
            "etat": autorisation.etat,
        }
        with self.journal.open("a", encoding="utf-8") as f:
            f.write(json.dumps(ligne, ensure_ascii=False) + "\n")

    def preautoriser(self, montant_cents: int, reference: str,
                     description: str, email: str | None = None) -> Autorisation:
        if montant_cents <= 0:
            raise PaiementIndisponible("Montant invalide.")
        autorisation = Autorisation(
            identifiant="sim_" + secrets.token_hex(8),
            montant_cents=montant_cents,
            fournisseur=self.nom,
            etat="autorisee",
            encaissable_avant=_iso(
                _maintenant() + dt.timedelta(days=VALIDITE_AUTORISATION_JOURS)
            ),
            details={"reference": reference, "description": description},
        )
        self._tracer("preautorisation", autorisation)
        return autorisation

    def encaisser(self, identifiant: str) -> Autorisation:
        autorisation = Autorisation(identifiant=identifiant, montant_cents=0,
                                    fournisseur=self.nom, etat="encaissee")
        self._tracer("encaissement", autorisation)
        return autorisation

    def annuler(self, identifiant: str, motif: str = "") -> Autorisation:
        autorisation = Autorisation(identifiant=identifiant, montant_cents=0,
                                    fournisseur=self.nom, etat="annulee",
                                    details={"motif": motif})
        self._tracer("annulation", autorisation)
        return autorisation


# --------------------------------------------------------------------------- #
# Fournisseur Stripe — PaymentIntent en capture manuelle
# --------------------------------------------------------------------------- #

class PaiementStripe(FournisseurPaiement):
    """Trois appels à l'API Stripe, en formulaire encodé, sans dépendance
    supplémentaire.

      · création  : POST /v1/payment_intents avec capture_method=manual
      · capture   : POST /v1/payment_intents/{id}/capture
      · annulation: POST /v1/payment_intents/{id}/cancel

    La clé secrète vit dans les Secrets du Repl (`STRIPE_SECRET_KEY`) et n'est
    lue qu'ici. Le `secret_client` renvoyé sert à la saisie de la carte côté
    navigateur : Novaluth ne voit jamais le numéro.
    """

    nom = "stripe"
    exige_saisie_carte = True
    BASE = "https://api.stripe.com/v1"

    def __init__(self) -> None:
        self.cle = os.environ.get("STRIPE_SECRET_KEY", "")
        if not self.cle:
            raise PaiementIndisponible(
                "STRIPE_SECRET_KEY absent des secrets : le fournisseur Stripe "
                "ne peut pas être utilisé. Repassez à NOVALUTH_PAIEMENT=simule."
            )

    def _appeler(self, chemin: str, donnees: dict[str, str]) -> dict:
        try:
            reponse = httpx.post(f"{self.BASE}{chemin}", data=donnees,
                                 auth=(self.cle, ""), timeout=20.0)
        except httpx.HTTPError as e:
            raise PaiementIndisponible(f"Stripe injoignable : {type(e).__name__}") from e
        charge = reponse.json() if reponse.content else {}
        if reponse.status_code >= 400:
            message = (charge.get("error") or {}).get("message", "erreur inconnue")
            raise PaiementIndisponible(f"Stripe a refusé la demande : {message}")
        return charge

    @staticmethod
    def _echeance(charge: dict) -> str:
        """Date réelle d'expiration de l'autorisation, telle que Stripe la
        renvoie. On ne la déduit jamais d'une règle mémorisée : elle dépend du
        réseau de la carte."""
        for tentative in (charge.get("latest_charge") or {}, charge):
            details = ((tentative.get("payment_method_details") or {}).get("card") or {})
            horodatage = details.get("capture_before")
            if horodatage:
                return _iso(dt.datetime.fromtimestamp(int(horodatage), dt.timezone.utc))
        return _iso(_maintenant() + dt.timedelta(days=VALIDITE_AUTORISATION_JOURS))

    def preautoriser(self, montant_cents: int, reference: str,
                     description: str, email: str | None = None) -> Autorisation:
        donnees = {
            "amount": str(montant_cents),
            "currency": "eur",
            "capture_method": "manual",
            "description": description[:300],
            "automatic_payment_methods[enabled]": "true",
            "metadata[reference_novaluth]": reference,
        }
        if email:
            donnees["receipt_email"] = email
        charge = self._appeler("/payment_intents", donnees)
        return Autorisation(
            identifiant=charge["id"],
            montant_cents=montant_cents,
            fournisseur=self.nom,
            etat="autorisee",
            encaissable_avant=self._echeance(charge),
            secret_client=charge.get("client_secret"),
            details={"reference": reference},
        )

    def encaisser(self, identifiant: str) -> Autorisation:
        charge = self._appeler(f"/payment_intents/{identifiant}/capture", {})
        return Autorisation(identifiant=identifiant,
                            montant_cents=int(charge.get("amount_received") or 0),
                            fournisseur=self.nom, etat="encaissee")

    def annuler(self, identifiant: str, motif: str = "") -> Autorisation:
        donnees = {"cancellation_reason": "abandoned"} if motif else {}
        self._appeler(f"/payment_intents/{identifiant}/cancel", donnees)
        return Autorisation(identifiant=identifiant, montant_cents=0,
                            fournisseur=self.nom, etat="annulee",
                            details={"motif": motif})


# --------------------------------------------------------------------------- #
# Sélection
# --------------------------------------------------------------------------- #

_cache: dict[str, FournisseurPaiement] = {}


def fournisseur() -> FournisseurPaiement:
    """Renvoie le fournisseur configuré. En cas de configuration Stripe
    incomplète, on retombe explicitement sur la simulation avec un message dans
    les journaux : mieux vaut un circuit sans argent qu'un circuit cassé."""
    demande = os.environ.get("NOVALUTH_PAIEMENT", "simule").strip().lower()
    if demande in _cache:
        return _cache[demande]
    if demande == "stripe":
        try:
            _cache[demande] = PaiementStripe()
        except PaiementIndisponible as e:
            print(f"[paiement] {e}")
            _cache[demande] = PaiementSimule()
    else:
        _cache[demande] = PaiementSimule()
    return _cache[demande]


def paiement_simule_actif() -> bool:
    return fournisseur().nom == "simule"
