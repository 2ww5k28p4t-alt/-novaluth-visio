"""
NOVALUTH — Lanceur unique (développement et production)
=======================================================

Démarre les deux services dans un seul Repl :
  · l'application publique sur 0.0.0.0:$PORT — elle ne détient aucune clé ;
  · la passerelle sur 127.0.0.1:8100 — elle seule détient les clés de subnet,
    et n'est joignable que depuis l'intérieur de la machine.

C'est la configuration recommandée, y compris en production : voir
INSTALLATION-REPLIT.md. La séparation en deux Repls reste documentée dans
DEPLOIEMENT.md, mais elle expose la passerelle à Internet.

L'application publique démarre en premier, pour que Replit détecte le port 8000
comme port principal du déploiement.

    python run.py            les deux services
    python run.py web        l'application publique seule
    python run.py passerelle la passerelle seule
"""

from __future__ import annotations

import os
import secrets
import signal
import subprocess
import sys
import time
from pathlib import Path

RACINE = Path(__file__).resolve().parent
PORT_WEB = int(os.environ.get("PORT", "8000"))
PORT_PASSERELLE = int(os.environ.get("PORT_PASSERELLE", "8100"))
DEV = os.environ.get("NOVALUTH_ENV", "dev") != "prod"


def preparer_secrets_developpement() -> None:
    """En développement uniquement, on génère les secrets manquants pour que
    l'application démarre du premier coup. En production, l'absence d'un secret
    doit rester bloquante : les services refusent alors de démarrer."""
    if not DEV:
        return
    fabriques = []
    for nom, longueur in (("NOVALUTH_GATEWAY_SECRET", 48),
                          ("NOVALUTH_APP_SECRET", 48),
                          ("NOVALUTH_ADMIN_TOKEN", 12)):
        if not os.environ.get(nom):
            os.environ[nom] = secrets.token_urlsafe(longueur)
            fabriques.append(nom)
    if fabriques:
        print("┌" + "─" * 66)
        print("│ Mode développement : secrets temporaires générés")
        for nom in fabriques:
            valeur = os.environ[nom]
            affichage = valeur if nom == "NOVALUTH_ADMIN_TOKEN" else valeur[:8] + "…"
            print(f"│   {nom} = {affichage}")
        print("│ Ils changent à chaque redémarrage. Définissez-les dans les")
        print("│ Secrets du Repl pour les rendre stables.")
        print("└" + "─" * 66)


def lancer(cible: str, port: int) -> subprocess.Popen:
    commande = [sys.executable, "-m", "uvicorn", cible,
                "--host", "127.0.0.1" if "gateway" in cible else "0.0.0.0",
                "--port", str(port), "--no-access-log"]
    return subprocess.Popen(commande, cwd=RACINE, env=os.environ.copy())


def main() -> int:
    quoi = sys.argv[1] if len(sys.argv) > 1 else "tout"
    preparer_secrets_developpement()
    os.environ.setdefault("NOVALUTH_GATEWAY_URL",
                          f"http://127.0.0.1:{PORT_PASSERELLE}")

    processus: list[subprocess.Popen] = []
    try:
        if quoi in {"tout", "web"}:
            print(f"→ application publique         0.0.0.0:{PORT_WEB}")
            processus.append(lancer("web.main:app", PORT_WEB))
            time.sleep(1.5)
        if quoi in {"tout", "passerelle"}:
            print(f"→ passerelle (coffre à clés)   127.0.0.1:{PORT_PASSERELLE}")
            processus.append(lancer("gateway.main:app", PORT_PASSERELLE))

        if not processus:
            print("Usage : python run.py [tout|web|passerelle]")
            return 1

        while True:
            for p in processus:
                code = p.poll()
                if code is not None:
                    print(f"\n⚠️  un service s'est arrêté (code {code}), "
                          f"arrêt de l'ensemble")
                    return code or 1
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nArrêt demandé.")
        return 0
    finally:
        for p in processus:
            if p.poll() is None:
                p.send_signal(signal.SIGTERM)
        time.sleep(1)
        for p in processus:
            if p.poll() is None:
                p.kill()


if __name__ == "__main__":
    raise SystemExit(main())
