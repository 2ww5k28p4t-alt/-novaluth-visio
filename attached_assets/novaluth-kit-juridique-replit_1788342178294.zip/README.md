# Kit juridique NovaLuth — devis, contrat, notice

Trois outils web prêts à l’emploi, conformes au Code de la consommation français :

- `public/devis.html` — générateur de devis avec mentions obligatoires automatiques
- `public/contrat.html` — contrat de prestation de services en 19 articles + 2 annexes
- `public/notice.html` — explication de chaque clause, base légale et risque en cas d’omission

Aucune dépendance, aucune base de données, aucune donnée envoyée sur Internet : tout est calculé
dans le navigateur. Impression et enregistrement en PDF via le bouton dédié sur chaque page.

## Installation sur Replit, étape par étape

1. Sur [replit.com](https://replit.com), cliquez sur **Create Repl**, choisissez le modèle
   **Node.js**, nommez-le `kit-juridique`, puis **Create Repl**.
2. Dans le panneau de gauche (Files), utilisez le menu **⋮ → Upload folder** et déposez ce dossier,
   ou recréez les fichiers un par un en respectant exactement l’arborescence ci-dessous.
3. Cliquez sur **Run**. La fenêtre de prévisualisation (Webview) affiche l’accueil du kit.
4. Ouvrez `public/assets/js/config.js`. Tout est déjà pré-rempli pour NovaLuth. Il ne reste
   qu’à remplacer les valeurs marquées `A_COMPLETER` (voir la liste ci-dessous). Enregistrez,
   puis rechargez la prévisualisation : le bandeau orange disparaît quand tout est rempli.
5. Pour publier une adresse permanente : bouton **Deploy** en haut à droite, type
   **Autoscale** ou **Static**, puis **Deploy**.

## Les 8 valeurs à compléter dans `config.js`

Ce sont les seules informations que personne d’autre que vous ne peut connaître. Chacune est
marquée `A_COMPLETER` dans le fichier, et le bandeau orange en haut du site les rappelle.

| Champ | Où le trouver |
| --- | --- |
| `entreprise.adresse` | adresse de l’établissement déclarée à l’INPI |
| `entreprise.siren` | 9 chiffres, sur votre avis de situation INSEE |
| `entreprise.siret` | 14 chiffres, même document |
| `entreprise.telephone` | votre numéro professionnel |
| `entreprise.representant` | vos prénom et nom |
| `entreprise.iban` | IBAN du compte professionnel |
| `mediateur.nom` / `mediateur.adresse` / `mediateur.site` | après adhésion à un médiateur agréé (obligatoire, art. L612-1) |
| `assurance.assureur` / `assurance.numeroContrat` | votre contrat de responsabilité civile professionnelle |

Deux réglages à vérifier selon votre situation :

- **TVA.** Le kit part du principe que NovaLuth est en franchise de TVA
  (`TVA non applicable, art. 293 B du CGI`, `tauxTvaDefaut: 0`). Si vous êtes assujetti,
  mettez votre numéro de TVA intracommunautaire et passez `tauxTvaDefaut` à `20`.
- **Forme juridique.** En entreprise individuelle, la dénomination légale doit comporter votre
  nom civil suivi ou précédé de `EI` ; NovaLuth n’est alors qu’un nom commercial. En société,
  remplacez `formeJuridique` par `SASU` ou `SARL`, renseignez `capital` et `rcs`.

## Modèles de prestation NovaLuth

Les montants sont regroupés dans `config.tarifs` : les modifier là met à jour la grille affichée
sur la page d’accueil et les dix modèles de `config.prestations` en même temps.

| Prestation | Payée par | Montant |
| --- | --- | --- |
| Accès à un projet — petit projet (budget < 1 500 €) | Atelier | 9,99 € |
| Accès à un projet — projet courant (1 500 € à 4 000 €) | Atelier | 15,99 € |
| Accès à un projet — grande commande (> 4 000 €) | Atelier | 24,99 € |
| Carnet d’accès prépayé — solde de 79,95 € | Atelier | 69,00 € |
| Carnet d’accès prépayé — solde de 159,90 € | Atelier | 119,00 € |
| Dépôt et diffusion d’un projet | Musicien | Gratuit |
| Option — création et vérification d’une fiche annuaire | Atelier | 90,00 € |
| Option — mise à jour de fiche (par intervention) | Atelier | 25,00 € |
| Option — abonnement atelier mensuel | Atelier | 19,00 € / mois |
| Option — mise en avant éditoriale d’une marque | Marque | 400,00 € |

Les cinq premières lignes et la gratuité côté musicien correspondent au modèle économique de
NovaLuth. Les lignes « Option » sont des offres non lancées, avec des montants d’exemple à
ajuster ou à supprimer. Un onzième modèle, le pack lancement, combine la fiche vérifiée et le
carnet de 69 € avec une remise de 10 %.

Choisir un modèle remplit la qualité du client, le mode de conclusion, l’objet, les livrables, le
délai, le lieu, les lignes du décompte et, le cas échéant, la remise. Les modèles destinés aux
ateliers et aux marques basculent le devis en « professionnel » : les mentions consommateur
(rétractation, médiation, garantie de conformité) laissent alors place à la mention de délai de
paiement de l’article L441-10 du Code de commerce. Le modèle « Musicien » repasse en
« consommateur » et fait réapparaître les trois mentions protectrices.

## Points juridiques propres à NovaLuth

- **Service numérique.** La plateforme relève de la garantie légale de conformité des services
  numériques (art. L217-3 et suivants), qui s’applique pendant toute la durée de fourniture.
- **Rôle d’intermédiaire.** L’article 2 du contrat précise que NovaLuth n’est pas partie au
  contrat conclu entre le musicien et l’atelier, et ne garantit pas les travaux de lutherie.
- **Absence de classement.** L’article 2 acte l’absence de note, d’étoile et de classement de
  mérite, ainsi que le signalement des contenus rémunérés comme communications commerciales.
- **Rétractation.** Les prestations vendues à distance ouvrent 14 jours de rétractation ; pour
  une activation immédiate, la demande expresse d’exécution anticipée doit être recueillie
  (art. L221-25 et L221-28), ce que le devis mentionne automatiquement.
- **Plateforme européenne RLL/ODR.** Fermée depuis le 20 juillet 2025, le lien n’est plus
  obligatoire et ne doit plus figurer sur vos documents.

## Arborescence

```
kit-juridique/
├─ .replit                  configuration du bouton Run de Replit
├─ package.json             métadonnées du projet (aucune dépendance)
├─ server.js                mini serveur Node.js, sert le dossier public/
└─ public/
   ├─ index.html            accueil, les trois piliers légaux, sources
   ├─ devis.html            générateur de devis
   ├─ contrat.html          contrat de prestation de services
   ├─ notice.html           notice explicative des clauses
   └─ assets/
      ├─ css/style.css      design complet + feuille d’impression A4
      └─ js/
         ├─ config.js       ⚠️ LE SEUL FICHIER À MODIFIER
         ├─ app.js          en-tête, pied de page, thème, injection des données
         └─ devis.js        logique du générateur de devis
```

## Intégrer les pages dans un site existant

Les pages sont de simples fichiers HTML statiques. Trois possibilités :

1. **Copier le dossier `public/`** dans le répertoire public de votre site (par exemple
   `www/kit/`), puis lier `https://votre-domaine.fr/kit/devis.html`.
2. **Espace client privé** : placez les pages derrière votre authentification existante et n’exposez
   publiquement que `contrat.html` et `notice.html`.
3. **Iframe** : `<iframe src="/kit/devis.html" style="width:100%;height:1400px;border:0"></iframe>`.

Le fichier `config.js` est chargé côté navigateur : n’y mettez jamais de mot de passe, de clé
d’API ni d’IBAN que vous ne souhaitez pas rendre public si les pages sont accessibles à tous.

## Rappels légaux essentiels

- **Garantie légale de conformité** — art. L217-3 et suivants du Code de la consommation
  ([Légifrance](https://www.legifrance.gouv.fr/codes/section_lc/LEGITEXT000006069565/LEGISCTA000032221271/))
- **Médiation de la consommation** — art. L612-1 et L616-1
  ([Légifrance](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032224805),
  [economie.gouv.fr](https://www.economie.gouv.fr/mediation-conso/vous-etes-un-professionnel/vos-principales-obligations-0)) :
  vous devez adhérer à un médiateur agréé avant de diffuser ces documents.
- **Clauses abusives** — art. L212-1, liste noire R212-1, liste grise R212-2
  ([Légifrance](https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032890812),
  [INC](https://www.inc-conso.fr/content/clauses-abusives-mode-demploi))
- **Contenu minimal d’un devis** —
  [economie.gouv.fr](https://www.economie.gouv.fr/entreprises/gerer-sa-comptabilite-et-ses-demarches/devis-obligatoire-comment-ca-marche)
  et [service-public.fr](https://entreprendre.service-public.gouv.fr/vosdroits/F31144)

Modèles fournis à titre informatif. Ils ne constituent pas un conseil juridique individualisé :
faites-les valider par un professionnel du droit au regard de votre activité.
