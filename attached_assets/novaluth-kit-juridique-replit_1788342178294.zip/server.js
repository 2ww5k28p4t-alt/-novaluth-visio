/* ==========================================================================
   server.js — mini serveur web sans aucune dependance (Node.js seul).
   Sur Replit : cliquez sur Run. En local : node server.js
   ========================================================================== */

const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const ROOT = path.join(__dirname, 'public');

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
};

const server = http.createServer((req, res) => {
  const url = decodeURIComponent(req.url.split('?')[0]);
  let rel = url === '/' ? 'index.html' : url.replace(/^\/+/, '');
  let file = path.join(ROOT, rel);

  // Empeche toute sortie du dossier public
  if (!file.startsWith(ROOT)) {
    res.writeHead(403).end('Acces refuse');
    return;
  }

  fs.stat(file, (err, stats) => {
    if (!err && stats.isDirectory()) file = path.join(file, 'index.html');

    fs.readFile(file, (readErr, data) => {
      if (readErr) {
        res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end('<h1>404 - page introuvable</h1><p><a href="/">Retour a l\'accueil</a></p>');
        return;
      }
      res.writeHead(200, {
        'Content-Type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'no-cache',
      });
      res.end(data);
    });
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('Kit juridique en ligne sur le port ' + PORT);
});
