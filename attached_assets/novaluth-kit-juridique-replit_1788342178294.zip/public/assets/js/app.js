/* ==========================================================================
   app.js — en-tête, pied de page, thème clair/sombre, injection des données
   de config.js dans les pages. Normalement, rien à modifier ici.
   ========================================================================== */

(function () {
  'use strict';

  var C = window.CONFIG || {};

  /* ---- Petits utilitaires --------------------------------------------- */
  function get(path) {
    return path.split('.').reduce(function (acc, key) {
      return acc && acc[key] !== undefined ? acc[key] : '';
    }, C);
  }

  function esc(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (ch) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch];
    });
  }

  window.KIT = { get: get, esc: esc };

  /* ---- Logo (SVG en ligne) -------------------------------------------- */
  var LOGO =
    '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
    '<path d="M12 2.5 20 6v6.2c0 4.3-3.2 7.9-8 9.3-4.8-1.4-8-5-8-9.3V6l8-3.5Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>' +
    '<path d="M8.4 12.1l2.5 2.5 4.7-4.9" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>' +
    '</svg>';

  var PAGES = [
    { href: 'index.html', label: 'Accueil' },
    { href: 'devis.html', label: 'Générateur de devis' },
    { href: 'contrat.html', label: 'Contrat de prestation' },
    { href: 'notice.html', label: 'Notice des clauses' },
  ];

  /* ---- En-tête et pied de page ---------------------------------------- */
  function currentFile() {
    var file = window.location.pathname.split('/').pop();
    return file === '' ? 'index.html' : file;
  }

  function buildHeader() {
    var here = currentFile();
    var links = PAGES.map(function (page) {
      var active = page.href === here ? ' aria-current="page"' : '';
      return '<a href="' + page.href + '"' + active + '>' + page.label + '</a>';
    }).join('');

    return (
      '<header class="site-header no-print"><div class="wrap">' +
      '<a class="brand" href="index.html">' +
      LOGO +
      '<span>' + esc(get('entreprise.nom')) + '</span>' +
      '</a>' +
      '<nav class="nav" aria-label="Navigation principale">' + links + '</nav>' +
      '<button class="theme-btn" id="themeBtn" type="button" aria-label="Changer de thème">' +
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">' +
      '<circle cx="12" cy="12" r="4.2" stroke="currentColor" stroke-width="1.8"/>' +
      '<path d="M12 2.6v2.2M12 19.2v2.2M2.6 12h2.2M19.2 12h2.2M5.4 5.4l1.6 1.6M17 17l1.6 1.6M18.6 5.4 17 7M7 17l-1.6 1.6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>' +
      '</svg></button>' +
      '</div></header>'
    );
  }

  function buildFooter() {
    return (
      '<footer class="site-footer no-print"><div class="wrap">' +
      '<div>' + esc(get('entreprise.nom')) + ' — ' + esc(get('entreprise.siret')) +
      ' — ' + esc(get('entreprise.email')) + '</div>' +
      '<div>Médiateur de la consommation : ' + esc(get('mediateur.nom')) +
      ' — <a href="' + esc(get('mediateur.site')) + '" target="_blank" rel="noopener">site du médiateur</a></div>' +
      '<div>Modèles fournis à titre informatif, à faire valider par un juriste.</div>' +
      '</div></footer>'
    );
  }

  /* ---- Thème clair / sombre ------------------------------------------- */
  var theme =
    window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';

  function applyTheme() {
    document.documentElement.setAttribute('data-theme', theme);
  }

  /* ---- Remplissage automatique : <span data-cfg="entreprise.nom"></span> */
  function fillConfig(root) {
    (root || document).querySelectorAll('[data-cfg]').forEach(function (el) {
      var value = get(el.getAttribute('data-cfg'));
      el.textContent = value === '' ? '—' : value;
    });
    (root || document).querySelectorAll('[data-cfg-href]').forEach(function (el) {
      el.setAttribute('href', get(el.getAttribute('data-cfg-href')) || '#');
    });
  }

  /* ---- Alerte si config.js n'a pas encore été personnalisé ------------ */
  function configWarning() {
    var todo = [];
    var manque = function (path) {
      return /A_COMPLETER|NOM DE VOTRE|NOM DU MÉDIATEUR/i.test(String(get(path) || ''));
    };
    if (manque('entreprise.nom')) todo.push('le nom de votre entreprise');
    if (manque('entreprise.siren') || manque('entreprise.siret')) todo.push('votre SIREN et votre SIRET');
    if (manque('entreprise.adresse')) todo.push('votre adresse');
    if (manque('entreprise.telephone')) todo.push('votre téléphone');
    if (manque('entreprise.representant')) todo.push('votre nom en tant que représentant');
    if (manque('entreprise.iban')) todo.push('votre IBAN');
    if (manque('mediateur.nom')) todo.push('le médiateur de la consommation (obligatoire, art. L612-1)');
    if (manque('assurance.assureur')) todo.push('votre assurance responsabilité civile professionnelle');
    if (!todo.length) return '';
    return (
      '<div class="alert no-print"><strong>À compléter avant utilisation réelle :</strong> ' +
      todo.join(', ') +
      '. Ouvrez le fichier <code>public/assets/js/config.js</code> et remplacez les valeurs d\u2019exemple.</div>'
    );
  }

  /* ---- Sommaire automatique des titres h2 ----------------------------- */
  function buildToc() {
    var toc = document.querySelector('[data-toc]');
    if (!toc) return;
    var target = document.querySelector(toc.getAttribute('data-toc'));
    if (!target) return;
    var html = '';
    target.querySelectorAll('h2[id]').forEach(function (heading) {
      html += '<a href="#' + heading.id + '">' + esc(heading.textContent) + '</a>';
    });
    toc.innerHTML = '<p class="eyebrow">Sommaire</p>' + html;
  }

  /* ---- Boutons d'impression ------------------------------------------- */
  function bindPrint() {
    document.querySelectorAll('[data-print]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        window.print();
      });
    });
  }

  /* ---- Démarrage ------------------------------------------------------ */
  document.addEventListener('DOMContentLoaded', function () {
    applyTheme();

    var headerSlot = document.getElementById('site-header');
    if (headerSlot) headerSlot.outerHTML = buildHeader();

    var footerSlot = document.getElementById('site-footer');
    if (footerSlot) footerSlot.outerHTML = buildFooter();

    var warn = document.getElementById('config-warning');
    if (warn) warn.innerHTML = configWarning();

    fillConfig(document);
    buildToc();
    bindPrint();

    var btn = document.getElementById('themeBtn');
    if (btn) {
      btn.addEventListener('click', function () {
        theme = theme === 'dark' ? 'light' : 'dark';
        applyTheme();
      });
    }

    document.dispatchEvent(new CustomEvent('kit:ready'));
  });
})();
