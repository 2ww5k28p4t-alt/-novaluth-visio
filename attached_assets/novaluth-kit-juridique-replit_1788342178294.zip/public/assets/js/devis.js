/* ==========================================================================
   devis.js — générateur de devis conforme au Code de la consommation
   Le formulaire (colonne de gauche) alimente l'aperçu A4 (colonne de droite).
   Le bouton « Imprimer / PDF » n'imprime que l'aperçu.
   ========================================================================== */

(function () {
  'use strict';

  var C, esc, get;

  var euro = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' });
  var pct = function (n) {
    return (Math.round(n * 100) / 100).toString().replace('.', ',') + ' %';
  };

  var lines = [];
  var nextId = 1;

  /* ---------------------------------------------------------------- lignes */
  function num(path, fallback) {
    var v = get(path);
    return v === null || v === undefined || v === '' ? fallback : Number(v);
  }

  function addLine(data) {
    lines.push({
      id: nextId++,
      designation: (data && data.designation) || '',
      qte: data && data.qte != null ? data.qte : 1,
      pu: data && data.pu != null ? data.pu : 0,
      tva: data && data.tva != null ? data.tva : num('devis.tauxTvaDefaut', 20),
    });
  }

  function lineTotal(line) {
    return (Number(line.qte) || 0) * (Number(line.pu) || 0);
  }

  function renderLines() {
    var host = document.getElementById('lines');
    host.innerHTML = lines
      .map(function (line) {
        return (
          '<div class="line" data-id="' + line.id + '">' +
          '<input type="text" data-f="designation" value="' + esc(line.designation) +
          '" placeholder="Désignation précise de la prestation ou fourniture" aria-label="Désignation">' +
          '<input type="number" data-f="qte" min="0" step="0.01" value="' + line.qte + '" aria-label="Quantité">' +
          '<input type="number" data-f="pu" min="0" step="0.01" value="' + line.pu + '" aria-label="Prix unitaire HT">' +
          '<select data-f="tva" aria-label="Taux de TVA">' +
          [0, 2.1, 5.5, 10, 20]
            .map(function (rate) {
              return (
                '<option value="' + rate + '"' +
                (Number(line.tva) === rate ? ' selected' : '') +
                '>' + pct(rate) + '</option>'
              );
            })
            .join('') +
          '</select>' +
          '<button type="button" class="line-del" data-del="' + line.id + '" aria-label="Supprimer la ligne">×</button>' +
          '</div>'
        );
      })
      .join('');
  }

  /* ---------------------------------------------------------------- calcul */
  function totals() {
    var remise = Number(document.getElementById('remise').value) || 0;
    var totalHtBrut = lines.reduce(function (sum, line) {
      return sum + lineTotal(line);
    }, 0);
    var coef = 1 - remise / 100;
    var groups = {};
    var totalHt = 0;
    var totalTva = 0;

    lines.forEach(function (line) {
      var ht = lineTotal(line) * coef;
      var rate = Number(line.tva) || 0;
      var tva = (ht * rate) / 100;
      groups[rate] = (groups[rate] || 0) + tva;
      totalHt += ht;
      totalTva += tva;
    });

    var acompte = Number(document.getElementById('acompte').value) || 0;
    var ttc = totalHt + totalTva;

    return {
      brut: totalHtBrut,
      remiseMontant: totalHtBrut - totalHt,
      remisePct: remise,
      ht: totalHt,
      tvaGroups: groups,
      tva: totalTva,
      ttc: ttc,
      acomptePct: acompte,
      acompte: (ttc * acompte) / 100,
      solde: ttc - (ttc * acompte) / 100,
    };
  }

  /* ------------------------------------------------------------- fragments */
  function val(id) {
    var el = document.getElementById(id);
    return el ? el.value.trim() : '';
  }

  function dash(text) {
    return text ? esc(text) : '<span style="color:#a5a39c">…</span>';
  }

  function frDate(iso) {
    if (!iso) return '';
    var parts = iso.split('-');
    return parts.length === 3 ? parts[2] + '/' + parts[1] + '/' + parts[0] : iso;
  }

  function prestataireBlock() {
    var e = C.entreprise;
    var a = C.assurance;
    var out = [];
    out.push('<strong>' + esc((e.mentionEI ? e.mentionEI + ' ' : '') + e.nom) + '</strong>');
    out.push(esc(e.formeJuridique + (e.capital ? ' — Capital : ' + e.capital : '')));
    out.push(esc(e.adresse));
    out.push('SIREN : ' + esc(e.siren) + ' — SIRET : ' + esc(e.siret));
    out.push(esc(e.rcs));
    out.push('TVA : ' + esc(e.tva));
    out.push('Tél. : ' + esc(e.telephone) + ' — ' + esc(e.email));
    out.push('RC professionnelle : ' + esc(a.assureur) + ', contrat n° ' + esc(a.numeroContrat) + ', ' + esc(a.zone));
    if (a.decennale) out.push('Assurance décennale : ' + esc(a.decennale));
    return out.join('<br>');
  }

  function clientBlock() {
    var out = [];
    out.push('<strong>' + dash(val('clientNom')) + '</strong>');
    if (val('clientAdresse')) out.push(esc(val('clientAdresse')));
    if (val('clientTel') || val('clientEmail')) {
      out.push(esc([val('clientTel'), val('clientEmail')].filter(Boolean).join(' — ')));
    }
    if (val('clientSiren')) out.push('SIREN : ' + esc(val('clientSiren')));
    out.push('Qualité : ' + (val('qualite') === 'conso' ? 'consommateur (particulier)' : 'professionnel'));
    out.push('Mode de conclusion : ' + document.getElementById('mode').selectedOptions[0].text);
    if (val('lieu')) out.push('Lieu d’exécution : ' + esc(val('lieu')));
    return out.join('<br>');
  }

  function linesTable(t) {
    var rows = lines
      .filter(function (line) {
        return line.designation || lineTotal(line);
      })
      .map(function (line) {
        return (
          '<tr><td>' + dash(line.designation) + '</td>' +
          '<td class="num">' + (Number(line.qte) || 0).toString().replace('.', ',') + '</td>' +
          '<td class="num">' + euro.format(Number(line.pu) || 0) + '</td>' +
          '<td class="num">' + pct(Number(line.tva) || 0) + '</td>' +
          '<td class="num">' + euro.format(lineTotal(line)) + '</td></tr>'
        );
      })
      .join('');

    if (!rows) {
      rows = '<tr><td colspan="5" style="color:#a5a39c">Ajoutez au moins une prestation…</td></tr>';
    }

    var tvaRows = Object.keys(t.tvaGroups)
      .sort(function (a, b) {
        return a - b;
      })
      .map(function (rate) {
        if (Number(rate) === 0) {
          return (
            '<tr><td colspan="4">' + esc(String(get('entreprise.tva') || 'TVA 0 %')) +
            '</td><td class="num">—</td></tr>'
          );
        }
        return (
          '<tr><td colspan="4">TVA ' + pct(Number(rate)) + '</td><td class="num">' +
          euro.format(t.tvaGroups[rate]) + '</td></tr>'
        );
      })
      .join('');

    return (
      '<div class="table-scroll"><table><thead><tr>' +
      '<th>Désignation (nature précise)</th><th class="num">Qté</th><th class="num">P.U. HT</th>' +
      '<th class="num">TVA</th><th class="num">Total HT</th></tr></thead><tbody>' +
      rows +
      '<tr><td colspan="4">Total HT</td><td class="num">' + euro.format(t.brut) + '</td></tr>' +
      (t.remisePct
        ? '<tr><td colspan="4">Remise ' + pct(t.remisePct) + '</td><td class="num">− ' +
          euro.format(t.remiseMontant) + '</td></tr><tr><td colspan="4">Total HT après remise</td>' +
          '<td class="num">' + euro.format(t.ht) + '</td></tr>'
        : '') +
      tvaRows +
      '<tr class="total"><td colspan="4">TOTAL À PAYER TTC</td><td class="num">' + euro.format(t.ttc) + '</td></tr>' +
      (t.acomptePct
        ? '<tr><td colspan="4">dont acompte à la commande (' + pct(t.acomptePct) + ')</td>' +
          '<td class="num">' + euro.format(t.acompte) + '</td></tr>' +
          '<tr><td colspan="4">Solde à la livraison</td><td class="num">' + euro.format(t.solde) + '</td></tr>'
        : '') +
      '</tbody></table></div>'
    );
  }

  /* ------------------------------------------- mentions légales du document */
  function mentionsLegales() {
    var isConso = val('qualite') === 'conso';
    var mode = val('mode');
    var m = C.mediateur;
    var html = '';

    html +=
      '<h2>4. Mentions légales et informations obligatoires</h2>' +
      '<p class="small">' +
      (isConso
        ? 'Informations fournies avant la conclusion du contrat, conformément aux articles L111-1 et suivants du Code de la consommation.'
        : 'Client professionnel : les dispositions protectrices du Code de la consommation ne s’appliquent pas ; le Code de commerce et le Code civil régissent la relation.') +
      '</p>';

    if (isConso) {
      html +=
        '<div class="legal-box"><h3>Garantie légale de conformité — art. L217-3 et suivants</h3>' +
        '<p>Lorsque la prestation comprend la fourniture d’un bien, d’un contenu numérique ou d’un service numérique, le professionnel livre un bien conforme au contrat et répond des défauts de conformité existant lors de la délivrance.</p>' +
        '<ul>' +
        '<li>Bien neuf : garantie de 2 ans à compter de la délivrance ; bien d’occasion : 1 an (art. L217-7).</li>' +
        '<li>Contenu ou service numérique fourni en continu : garantie pendant toute la durée de fourniture prévue au contrat.</li>' +
        '<li>Le consommateur choisit entre la réparation et le remplacement ; à défaut de mise en conformité, il peut obtenir une réduction du prix ou la résolution du contrat.</li>' +
        '<li>Tout bien réparé au titre de cette garantie bénéficie d’une extension de garantie de six mois (art. L217-13).</li>' +
        '<li>Cette garantie est gratuite, indépendante de toute garantie commerciale, et ne peut être ni exclue ni limitée. La garantie des vices cachés reste acquise (art. 1641 à 1649 du Code civil).</li>' +
        '</ul>' +
        '<p class="small">Pour les prestations de services non numériques, le prestataire répond de tout manquement contractuel dans les conditions des articles 1217 et suivants du Code civil.</p></div>';

      if (mode !== 'etablissement') {
        html +=
          '<div class="legal-box"><h3>Droit de rétractation — art. L221-18 et suivants</h3>' +
          '<p>Le contrat étant conclu ' +
          (mode === 'distance' ? 'à distance' : 'hors établissement') +
          ', le consommateur dispose de 14 jours pour se rétracter sans motif ni pénalité, à compter de la conclusion du contrat pour un service ou de la réception du bien pour une vente.</p>' +
          '<p>Notification par courrier à ' + esc(C.entreprise.adresse) + ' ou par courriel à ' +
          esc(C.entreprise.email) + ', ou au moyen du formulaire type de rétractation joint.</p>' +
          '<p>Le remboursement intervient au plus tard 14 jours après réception de la demande.</p>' +
          '<p><strong>Exécution anticipée (à cocher par le client) :</strong> ☐ Je demande expressément que la prestation débute avant la fin du délai de rétractation. Je reste libre de me rétracter mais devrai payer le montant correspondant à ce qui a déjà été exécuté, et je perds ce droit si la prestation est intégralement exécutée avant la fin du délai (art. L221-25 et L221-28, 1°).</p></div>';
      }

      html +=
        '<div class="legal-box"><h3>Médiation de la consommation — art. L612-1 et L616-1</h3>' +
        '<p>Tout consommateur a le droit de recourir gratuitement à un médiateur de la consommation en vue de la résolution amiable d’un litige.</p>' +
        '<p>Après une réclamation écrite préalable adressée à ' + esc(C.contactReclamation) +
        ' restée sans réponse satisfaisante pendant un mois, le consommateur peut saisir gratuitement :</p>' +
        '<p><strong>' + esc(m.nom) + '</strong><br>' + esc(m.adresse) + '<br>' +
        '<a href="' + esc(m.site) + '">' + esc(m.site) + '</a></p>' +
        '<p class="small">Informations de la Commission européenne sur les voies de recours des consommateurs : <a href="' +
        esc(m.infoUE) + '">' + esc(m.infoUE) + '</a>. La médiation est facultative et ne prive le consommateur d’aucun recours judiciaire.</p></div>';

      html +=
        '<div class="legal-box"><h3>Absence de clauses abusives — art. L212-1</h3>' +
        '<p>Le présent devis et les conditions générales annexées ne contiennent aucune clause créant, au détriment du consommateur, un déséquilibre significatif entre les droits et obligations des parties. Les clauses sont rédigées de façon claire et compréhensible et, en cas de doute, s’interprètent dans le sens le plus favorable au consommateur (art. L211-1).</p>' +
        '<p>En particulier : pas de modification unilatérale du prix, de la durée ou des caractéristiques de la prestation ; facultés de résiliation et pénalités réciproques ; aucune exclusion ou limitation des garanties légales ni du droit à réparation (art. R212-1 et R212-2).</p></div>';
    }

    html +=
      '<h3>Autres informations</h3><ul>' +
      '<li><strong>Données personnelles :</strong> données utilisées pour l’établissement du devis, l’exécution du contrat et la facturation. Droits d’accès, de rectification, d’effacement, de limitation et d’opposition auprès de ' +
      esc(C.contactRgpd) + ' ; réclamation possible auprès de la CNIL (RGPD, art. 12 à 22).</li>' +
      '<li><strong>Assurance :</strong> ' + esc(C.assurance.assureur) + ', contrat n° ' +
      esc(C.assurance.numeroContrat) + ', couvrant ' + esc(C.assurance.zone) + '.' +
      (C.assurance.decennale ? ' Assurance décennale : ' + esc(C.assurance.decennale) + '.' : '') + '</li>' +
      (isConso
        ? '<li><strong>Litiges :</strong> à défaut d’accord amiable, le consommateur peut saisir la juridiction de son choix parmi celles territorialement compétentes, y compris celle du lieu de son domicile (art. R631-3 du Code de la consommation).</li>'
        : '<li><strong>Retard de paiement :</strong> intérêts au taux de la BCE majoré de 10 points et indemnité forfaitaire de 40 € pour frais de recouvrement (art. L441-10 du Code de commerce).</li>') +
      '<li><strong>Périmètre :</strong> hors prestations non listées au décompte ci-dessus ; toute demande complémentaire fera l’objet d’un devis distinct.</li>' +
      '</ul>';

    return html;
  }

  /* ------------------------------------------------------------- rendu doc */
  function render() {
    var t = totals();
    var isConso = val('qualite') === 'conso';
    var e = C.entreprise;

    var html =
      '<h1>DEVIS</h1>' +
      '<p class="small">N° ' + dash(val('numero')) +
      ' — Établi le ' + (val('date') ? frDate(val('date')) : '…') +
      ' — Valable jusqu’au ' + (val('validite') ? frDate(val('validite')) : '…') + '</p>' +
      '<div class="two-col" style="margin-top:1.25rem">' +
      '<div class="party"><h3>Le prestataire</h3>' + prestataireBlock() + '</div>' +
      '<div class="party"><h3>Le client</h3>' + clientBlock() + '</div>' +
      '</div>' +
      '<h2>1. Objet et calendrier de la prestation</h2>' +
      '<div class="table-scroll"><table><tbody>' +
      '<tr><th style="width:32%">Objet</th><td>' + dash(val('objet')) + '</td></tr>' +
      '<tr><th>Date de début prévue</th><td>' + (val('debut') ? frDate(val('debut')) : '…') + '</td></tr>' +
      '<tr><th>Durée estimée</th><td>' + dash(val('duree')) + '</td></tr>' +
      '<tr><th>Date limite d’exécution</th><td>' + (val('fin') ? frDate(val('fin')) : '…') +
      (isConso ? ' <span class="small">(art. L216-1 du Code de la consommation)</span>' : '') + '</td></tr>' +
      '<tr><th>Livrables attendus</th><td>' + dash(val('livrables')) + '</td></tr>' +
      '<tr><th>Devis</th><td>' + (val('devisPayant') ? 'Payant : ' + esc(val('devisPayant')) + ' TTC, déduit de la facture en cas d’acceptation' : 'Gratuit') + '</td></tr>' +
      '</tbody></table></div>' +
      '<h2>2. Décompte détaillé des prestations et fournitures</h2>' +
      linesTable(t) +
      '<p class="small">Le prix est ferme et définitif pendant la durée de validité du devis. Aucune prestation supplémentaire ne sera facturée sans avenant écrit accepté par le client.</p>' +
      '<h2>3. Conditions de paiement et d’exécution</h2><ul>' +
      (Number(t.acomptePct) > 0
        ? '<li>Acompte : ' + pct(t.acomptePct) + ' à la signature du devis, soit ' + euro.format(t.acompte) +
          ' ; solde de ' + euro.format(t.solde) + ' à la livraison de la prestation.</li>'
        : '<li>Aucun acompte n’est demandé : le prix est payable à la mise à disposition du service.</li>') +
      '<li>Délai de règlement des factures : ' + num('devis.delaiPaiementJours', 30) +
      ' jours à compter de la date d’émission. Moyen de paiement : virement — IBAN ' + esc(e.iban) + '.</li>' +
      (isConso
        ? '<li>Retard de paiement : intérêts au taux légal en vigueur, après mise en demeure restée sans effet pendant 15 jours. Aucune pénalité forfaitaire disproportionnée n’est appliquée.</li>'
        : '<li>Retard de paiement : intérêts au taux BCE majoré de 10 points et indemnité forfaitaire de 40 € (art. L441-10 du Code de commerce).</li>') +
      '<li>Annulation après début d’exécution : seules les prestations effectivement réalisées et les fournitures commandées sont dues, sur justificatifs.</li>' +
      '</ul>' +
      mentionsLegales() +
      '<h2>5. Acceptation du devis</h2>' +
      '<p>Le client déclare avoir reçu, lu et accepté le présent devis ainsi que les mentions légales qui y figurent, avant tout début d’exécution.</p>' +
      '<div class="two-col">' +
      '<div class="party sign"><h3>Le client</h3>' +
      '<p class="small">Mention manuscrite obligatoire : « Devis reçu avant l’exécution des travaux — Bon pour accord »</p>' +
      '<p>Fait à ……………………… le ……/……/…………<br><br>Signature :</p></div>' +
      '<div class="party sign"><h3>Le prestataire</h3>' +
      '<p>' + esc(e.representant) + '</p>' +
      '<p>Fait à ……………………… le ……/……/…………<br><br>Signature et cachet :</p></div>' +
      '</div>';

    document.getElementById('doc').innerHTML = html;

    var recap = document.getElementById('recap');
    if (recap) {
      recap.textContent =
        'Total HT ' + euro.format(t.ht) + '  •  TVA ' + euro.format(t.tva) +
        '  •  TTC ' + euro.format(t.ttc) + '  •  Acompte ' + euro.format(t.acompte);
    }
  }

  /* ------------------------------------------------------------ interactions */
  function fillModeles() {
    var select = document.getElementById('modele');
    if (!select) return;
    var list = (C && C.prestations) || [];
    list.forEach(function (p, i) {
      var opt = document.createElement('option');
      opt.value = String(i);
      opt.textContent = p.titre;
      select.appendChild(opt);
    });
    select.addEventListener('change', function () {
      if (select.value === '') return;
      applyModele(list[Number(select.value)]);
    });
  }

  function applyModele(p) {
    if (!p) return;
    function set(id, value) {
      var el = document.getElementById(id);
      if (el && value != null) el.value = value;
    }
    set('qualite', p.qualite);
    set('mode', p.mode);
    set('objet', p.objet);
    set('livrables', p.livrables);
    set('duree', p.duree);
    set('lieu', p.lieu);
    if (p.remise != null) set('remise', p.remise);

    lines = [];
    (p.lignes || []).forEach(function (l) {
      addLine(l);
    });
    if (!lines.length) addLine({ designation: '', qte: 1, pu: 0 });
    renderLines();
    render();
  }

  function bind() {
    document.getElementById('form').addEventListener('input', function (event) {
      var line = event.target.closest('.line');
      if (line) {
        var id = Number(line.getAttribute('data-id'));
        var field = event.target.getAttribute('data-f');
        var item = lines.find(function (l) {
          return l.id === id;
        });
        if (item && field) item[field] = field === 'designation' ? event.target.value : Number(event.target.value);
      }
      render();
    });

    document.getElementById('form').addEventListener('change', render);

    document.getElementById('lines').addEventListener('click', function (event) {
      var btn = event.target.closest('[data-del]');
      if (!btn) return;
      var id = Number(btn.getAttribute('data-del'));
      lines = lines.filter(function (l) {
        return l.id !== id;
      });
      if (!lines.length) addLine();
      renderLines();
      render();
    });

    document.getElementById('addLine').addEventListener('click', function () {
      addLine();
      renderLines();
      render();
      var inputs = document.querySelectorAll('#lines .line input[data-f="designation"]');
      if (inputs.length) inputs[inputs.length - 1].focus();
    });

    document.getElementById('resetBtn').addEventListener('click', function () {
      HTMLFormElement.prototype.reset.call(document.getElementById('form'));
      var mSel = document.getElementById('modele');
      if (mSel) mSel.value = '';
      lines = [];
      addLine();
      renderLines();
      prefill();
      render();
    });
  }

  /* ------------------------------------------------------------- pré-remplissage */
  function iso(date) {
    return date.toISOString().slice(0, 10);
  }

  function prefill() {
    var today = new Date();
    var later = new Date(today.getTime() + num('devis.validiteJours', 30) * 86400000);

    document.getElementById('date').value = iso(today);
    document.getElementById('validite').value = iso(later);
    document.getElementById('numero').value =
      (get('devis.prefixe') || 'DEV') + '-' + today.getFullYear() + '-' +
      String(Math.floor(Math.random() * 900) + 100);
    document.getElementById('acompte').value = num('devis.acomptePourcentDefaut', 30);
    document.getElementById('remise').value = 0;
  }

  /* ------------------------------------------------------------------ start */
  document.addEventListener('kit:ready', function () {
    C = window.CONFIG;
    esc = window.KIT.esc;
    get = window.KIT.get;

    addLine({ designation: '', qte: 1, pu: 0 });
    renderLines();
    prefill();
    fillModeles();
    bind();
    render();
  });
})();
