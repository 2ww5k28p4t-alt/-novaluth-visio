# Déploiement de Novaluth

Objectif : mettre le site en ligne **sans jamais exposer les clés des subnets
Bittensor**. En production, on n'utilise pas `run.py` : on sépare le projet en
**deux Repls distincts**, à partir du même dossier de code.

---

## 1. Repl n°1 — `novaluth-passerelle`

C'est le coffre à clés. Il ne sert aucune page publique.

**Commande de démarrage** (`.replit`, section `[deployment]` ou bouton Run) :

```bash
uvicorn gateway.main:app --host 0.0.0.0 --port $PORT
```

**Secrets à définir — et rien d'autre :**

| Secret | Valeur |
|---|---|
| `CHUTES_API_KEY` | votre clé SN64 Chutes AI |
| `SN13_API_KEY` | votre clé SN13 Data Universe |
| `NOVALUTH_GATEWAY_SECRET` | chaîne longue et aléatoire, identique dans le Repl n°2 |
| `CHUTES_MODEL` | `Qwen/Qwen3-32B-TEE` (facultatif) |
| `PLAFOND_APPELS_IA_JOUR` | `1200` (facultatif) |
| `PLAFOND_APPELS_SN13_JOUR` | `80` (facultatif) |
| `NOVALUTH_ENV` | `prod` |

Pour générer le secret partagé, dans le shell du Repl :

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

**Vérification après démarrage :** ouvrez `https://<votre-passerelle>/sante`.
Vous devez voir `"service": "novaluth-passerelle"`, les clés marquées présentes,
la liste des modèles autorisés et les plafonds. Ouvrez ensuite `/docs` :
la réponse doit être **404**. C'est normal et voulu.

Notez l'URL publique du Repl, elle sert à l'étape suivante.

---

## 2. Repl n°2 — `novaluth-web`

C'est le site que voient les musiciens. Il ne contient **aucune clé de subnet**.

**Commande de démarrage :**

```bash
uvicorn web.main:app --host 0.0.0.0 --port $PORT
```

**Secrets à définir :**

| Secret | Valeur |
|---|---|
| `NOVALUTH_GATEWAY_URL` | `https://<votre-passerelle>` (URL du Repl n°1) |
| `NOVALUTH_GATEWAY_SECRET` | **exactement** le même secret que dans le Repl n°1 |
| `NOVALUTH_APP_SECRET` | autre chaîne aléatoire, pour les jetons CSRF |
| `NOVALUTH_ADMIN_TOKEN` | mot de passe d'accès à `/admin` |
| `NOVALUTH_URL` | `https://novaluth.com` ou l'URL du Repl |
| `NOVALUTH_ENV` | `prod` |

Ne définissez jamais `CHUTES_API_KEY` ni `SN13_API_KEY` ici. C'est toute la raison
d'être de la séparation.

**Vérification :** `https://<votre-site>/sante` doit renvoyer
`"cles_bittensor_dans_ce_service": false`. Si ce champ passe à `true`, une clé a été
ajoutée par erreur dans le mauvais Repl : retirez-la immédiatement et régénérez-la
côté fournisseur.

En mode `prod`, les cookies passent en `Secure`, les en-têtes de sécurité stricts
sont appliqués et `/admin` exige le jeton.

---

## 3. Nom de domaine

Dans le Repl `novaluth-web` : onglet Deployments → Custom domain → ajoutez
`novaluth.com` et `www.novaluth.com`, puis créez chez votre registrar les
enregistrements DNS affichés par Replit (un `A` et un `TXT` de vérification).

Le Repl passerelle **n'a pas besoin de domaine public**. Laissez son URL Replit
brute : moins elle est connue, mieux c'est.

---

## 4. Tâches programmées (Scheduled Deployments)

À créer dans le Repl `novaluth-web` — la collecte passe par la passerelle, elle n'a
donc pas besoin des clés.

| Fréquence conseillée | Commande |
|---|---|
| tous les jours à 6 h | `python -m pipeline.collecte luthiers` |
| tous les jours à 7 h | `python -m pipeline.collecte marques` |
| tous les lundis à 5 h | `python -m pipeline.collecte momentum` |
| tous les jours à 19 h | `python -m pipeline.collecte digest` |

Le job `digest` vous envoie le résumé de la journée sur Telegram : nouvelles
candidatures, fiches en attente d'arbitrage, quotas consommés.

Aucune fiche collectée n'est publiée automatiquement. Elle reste en attente
jusqu'à votre validation.

---

## 5. Bot Telegram de supervision

1. Dans Telegram, écrivez à **@BotFather** → `/newbot` → notez le jeton et
   placez-le dans `TELEGRAM_BOT_TOKEN`.
2. Envoyez un message quelconque à votre nouveau bot.
3. Récupérez votre identifiant de conversation :

```bash
curl "https://api.telegram.org/bot$TELEGRAM_BOT_TOKEN/getUpdates"
```

Cherchez `"chat":{"id":123456789` et mettez ce nombre dans `TELEGRAM_CHAT_ID`.

4. Pour l'arbitrage interactif, lancez la boucle en continu (Repl séparé « Always On »
   ou onglet Shell pendant vos sessions de tri) :

```bash
python -m pipeline.telegram
```

Chaque candidature arrive avec ses informations et quatre boutons :
✅ Publier · 🌱 À suivre · 🏭 Trop établie · ❌ Rejeter.
Commandes : `/etat` (état du système), `/attente` (file d'arbitrage), `/aide`.

---

## 6. Contrôle avant chaque mise en ligne

Dans le Shell du Repl `novaluth-web` :

```bash
python -m tools.verifier_conformite
```

Ne publiez pas tant qu'il reste une anomalie bloquante. Les avertissements
`[À COMPLÉTER]` doivent tous disparaître avant votre première vente : identité de
l'éditeur, SIRET, hébergeur, médiateur de la consommation.

---

## 7. Sauvegardes et données

- La base du site (`data/novaluth.db`) contient les fiches, les briefs et les
  preuves de consentement. Téléchargez-la régulièrement depuis Replit.
- Le journal de la passerelle (`gateway/audit_passerelle.db`) ne contient aucune
  donnée personnelle : uniquement des compteurs et des empreintes de requêtes.
- La purge des briefs de plus de 12 mois s'exécute au démarrage du service web
  (`store.purger_briefs_expires`). Redémarrez le Repl au moins une fois par mois,
  ou ajoutez une tâche programmée quotidienne appelant `python -c "from web import
  store; store.purger_briefs_expires()"`.

---

## 8. Si quelque chose casse

| Symptôme | Cause la plus probable |
|---|---|
| Le site affiche « Service temporairement indisponible » sur les résumés | passerelle éteinte ou `NOVALUTH_GATEWAY_URL` erronée — le site continue de fonctionner avec ses résumés de repli |
| `401 Requête non signée` dans les journaux | `NOVALUTH_GATEWAY_SECRET` différent entre les deux Repls |
| `403` horodatage | horloges désynchronisées de plus de 120 secondes |
| `429` | plafond journalier atteint ; ajustez `PLAFOND_APPELS_IA_JOUR` |
| Le formulaire refuse l'envoi | jeton CSRF expiré : rechargez la page |
| Le bot Telegram reste muet | `TELEGRAM_CHAT_ID` absent, ou boucle `pipeline.telegram` arrêtée |
