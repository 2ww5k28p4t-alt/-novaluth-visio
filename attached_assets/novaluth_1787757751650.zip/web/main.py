"""
NOVALUTH — Application publique (FastAPI, port 8000)
====================================================

Ce service ne détient aucune clé de subnet Bittensor. Quand il a besoin d'IA,
il signe une demande et l'envoie à la passerelle (gateway/), qui est le seul
détenteur des clés.

Routes principales :
  GET  /                     accueil
  GET  /annuaire             fiches publiées, filtrables
  GET  /fiche/{slug}         fiche détaillée
  GET  /brief                formulaire de projet
  POST /api/recommend        moteur de correspondance (JSON)
  POST /brief                envoi du brief (formulaire, anti-CSRF)
  GET  /legal/{document}     mentions légales, CGU, CGV, confidentialité…
  GET  /donnees              exercice des droits RGPD (accès / effacement)
  GET  /admin                supervision des fiches candidates (protégé)
  GET  /sante                état du service et de la passerelle
"""

from __future__ import annotations

import json
import os
import secrets
from pathlib import Path

from fastapi import Depends, FastAPI, Form, HTTPException, Request
from fastapi.responses import (FileResponse, HTMLResponse, JSONResponse,
                               RedirectResponse)
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from common.passerelle_client import passerelle_en_vie

from . import store
from .ia import resumer_correspondances
from .legal import DOCUMENTS_LEGAUX, rendre_document
from .matching import recommander
from .schemas import Brief, Fiche, StatutFiche
from .securite import (MiddlewareSecurite, creer_jeton_csrf, exiger_admin,
                       fermer_session_admin, limiter, ouvrir_session_admin,
                       session_admin_valide, verifier_jeton_csrf)

RACINE = Path(__file__).resolve().parent.parent
ENV = os.environ.get("NOVALUTH_ENV", "dev")

app = FastAPI(
    title="Novaluth",
    description="Annuaire des luthiers innovants et des marques émergentes.",
    docs_url="/api/docs" if ENV != "prod" else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if ENV != "prod" else None,
)
app.add_middleware(MiddlewareSecurite)
app.mount("/static", StaticFiles(directory=RACINE / "static"), name="static")
gabarits = Jinja2Templates(directory=str(RACINE / "templates"))


@app.on_event("startup")
def demarrage() -> None:
    store.initialiser()
    store.purger_briefs_expires()
    compteurs = store.compter_par_statut()
    print(f"[novaluth] base prête — {compteurs}")


def contexte(request: Request, **extra):
    base = {
        "request": request,
        "csrf": creer_jeton_csrf(),
        "admin": session_admin_valide(request),
        "documents_legaux": DOCUMENTS_LEGAUX,
        "env": ENV,
    }
    base.update(extra)
    return base


def rendre(request: Request, gabarit: str, *, status_code: int = 200, **extra):
    """Rendu d'un gabarit. On passe la requête en premier argument : c'est la
    signature attendue par les versions récentes de Starlette, et elle reste
    acceptée par les anciennes."""
    return gabarits.TemplateResponse(
        request, gabarit, contexte(request, **extra), status_code=status_code,
    )


# --------------------------------------------------------------------------- #
# Pages publiques
# --------------------------------------------------------------------------- #

@app.get("/", response_class=HTMLResponse)
def accueil(request: Request):
    fiches = store.lister_fiches(StatutFiche.publiee.value, limite=6)
    compteurs = store.compter_par_statut()
    return rendre(request, "accueil.html", fiches=fiches,
                  total_publiees=compteurs.get("publiee", 0))


@app.get("/annuaire", response_class=HTMLResponse)
def annuaire(request: Request, pays: str | None = None, type: str | None = None,
             innovation_min: int = 0):
    fiches = store.lister_fiches(StatutFiche.publiee.value, limite=300)
    if pays:
        fiches = [f for f in fiches if (f.pays or "").lower() == pays.lower()]
    if type:
        fiches = [f for f in fiches if f.type.value == type]
    if innovation_min:
        fiches = [f for f in fiches
                  if (f.innovation.niveau or f.score_innovation or 0) >= innovation_min]
    pays_disponibles = sorted({f.pays for f in store.lister_fiches(limite=300) if f.pays})
    return rendre(request, "annuaire.html", fiches=fiches,
                  pays_disponibles=pays_disponibles, filtre_pays=pays,
                  filtre_type=type, innovation_min=innovation_min)


@app.get("/fiche/{slug}", response_class=HTMLResponse)
def page_fiche(request: Request, slug: str):
    fiche = store.lire_fiche(slug)
    if not fiche or fiche.statut != StatutFiche.publiee:
        raise HTTPException(404, "Fiche introuvable.")
    return rendre(request, "fiche.html", fiche=fiche)


@app.get("/brief", response_class=HTMLResponse)
def page_brief(request: Request):
    return rendre(request, "brief.html",
                  libelle_consentement=store.LIBELLE_CONSENTEMENT)


# --------------------------------------------------------------------------- #
# API de recommandation
# --------------------------------------------------------------------------- #

@app.post("/api/recommend")
async def api_recommend(request: Request):
    limiter(request, "recommend", maximum=20, fenetre_s=60)
    try:
        brief = Brief(**(await request.json()))
    except Exception as e:
        raise HTTPException(422, f"Brief invalide : {e}")

    fiches = store.lister_fiches(StatutFiche.publiee.value, limite=300)
    resultats = recommander(brief, fiches, nombre=3)
    resume, origine = resumer_correspondances(brief, resultats)
    return {
        "resume": resume,
        "origine_resume": origine,
        "resultats": resultats,
        "avertissement": (
            "Novaluth référence et met en relation. Novaluth n'est ni vendeur, "
            "ni fabricant, ni transporteur, ni intermédiaire de paiement. "
            "Les informations proviennent de sources publiques ou de l'artisan "
            "lui-même et doivent être confirmées auprès de lui avant toute commande."
        ),
    }


@app.post("/brief", response_class=HTMLResponse)
async def envoyer_brief(
    request: Request,
    csrf: str = Form(...),
    type_instrument: str = Form("electrique"),
    budget_min_eur: int = Form(0),
    budget_max_eur: int = Form(5000),
    styles: str = Form(""),
    bois_souhaites: str = Form(""),
    delai_max_mois: str = Form(""),
    zone_preferee: str = Form("europe"),
    chaleur_souhaitee: str = Form(""),
    brillance_souhaitee: str = Form(""),
    innovation_recherchee: str = Form(""),
    personnalisation: str = Form(""),
    description_libre: str = Form(""),
    email: str = Form(""),
    consentement: str = Form(""),
    piege: str = Form(""),   # champ masqué anti-robot
):
    verifier_jeton_csrf(csrf)
    limiter(request, "brief", maximum=6, fenetre_s=300)
    if piege:
        raise HTTPException(400, "Requête refusée.")

    def entier(v: str) -> int | None:
        return int(v) if v.strip().isdigit() else None

    donne_consentement = consentement == "oui"
    try:
        brief = Brief(
            type_instrument=type_instrument,
            budget_min_eur=budget_min_eur,
            budget_max_eur=budget_max_eur,
            styles=[s.strip() for s in styles.split(",") if s.strip()][:8],
            bois_souhaites=[s.strip() for s in bois_souhaites.split(",") if s.strip()][:8],
            delai_max_mois=entier(delai_max_mois),
            zone_preferee=zone_preferee,
            chaleur_souhaitee=entier(chaleur_souhaitee),
            brillance_souhaitee=entier(brillance_souhaitee),
            innovation_recherchee=entier(innovation_recherchee),
            personnalisation=personnalisation == "oui",
            description_libre=description_libre[:1500],
            email=(email.strip() or None) if donne_consentement else None,
            consentement_transmission=donne_consentement,
        )
    except Exception as e:
        raise HTTPException(422, f"Formulaire invalide : {e}")

    if brief.email and not brief.consentement_transmission:
        raise HTTPException(400, "Aucune transmission sans consentement explicite.")

    fiches = store.lister_fiches(StatutFiche.publiee.value, limite=300)
    resultats = recommander(brief, fiches, nombre=3)
    resume, origine = resumer_correspondances(brief, resultats)

    reference = "NV-" + secrets.token_hex(4).upper()
    store.enregistrer_brief(
        reference=reference,
        criteres=brief.model_dump(mode="json"),
        recommandations=resultats,
        email=brief.email,
        consentement=brief.consentement_transmission,
    )
    return rendre(request, "resultat.html", reference=reference, resume=resume,
                  origine=origine, resultats=resultats, brief=brief)


# --------------------------------------------------------------------------- #
# Pages légales et droits RGPD
# --------------------------------------------------------------------------- #

@app.get("/legal", response_class=HTMLResponse)
def index_legal(request: Request):
    return rendre(request, "legal_index.html")


@app.get("/legal/{document}", response_class=HTMLResponse)
def page_legale(request: Request, document: str):
    if document not in DOCUMENTS_LEGAUX:
        raise HTTPException(404, "Document introuvable.")
    titre, corps_html, maj = rendre_document(document)
    return rendre(request, "legal.html", titre=titre, corps=corps_html,
                  maj=maj, cle=document)


@app.get("/donnees", response_class=HTMLResponse)
def page_donnees(request: Request):
    return rendre(request, "donnees.html")


@app.post("/donnees/{action}")
async def exercer_droit(request: Request, action: str,
                        csrf: str = Form(...), email: str = Form(...)):
    """Droits d'accès, de portabilité et d'effacement, exécutés immédiatement.
    Aucune vérification d'identité poussée n'est possible ici : on ne renvoie
    donc jamais les données par la page, on confirme et on traite."""
    verifier_jeton_csrf(csrf)
    limiter(request, "droits", maximum=5, fenetre_s=600)
    adresse = email.strip().lower()
    if action == "effacement":
        n = store.effacer_donnees_email(adresse)
        message = (f"Demande enregistrée. {n} enregistrement(s) associé(s) à cette "
                   f"adresse ont été anonymisés immédiatement.")
    elif action == "acces":
        donnees = store.exporter_donnees_email(adresse)
        store.journaliser("droit_acces", "brief", f"{len(donnees)} enregistrements")
        message = (f"Demande enregistrée : {len(donnees)} enregistrement(s) trouvé(s). "
                   f"Conformément au RGPD, l'export vous est adressé par e-mail sous "
                   f"un mois à l'adresse indiquée, après vérification.")
    else:
        raise HTTPException(404, "Action inconnue.")
    return rendre(request, "donnees.html", message=message)


# --------------------------------------------------------------------------- #
# Supervision — validation humaine des fiches (le cœur qualité du projet)
# --------------------------------------------------------------------------- #

@app.get("/admin", response_class=HTMLResponse)
def page_admin(request: Request):
    if not session_admin_valide(request):
        return rendre(request, "admin_connexion.html")
    candidates = store.lister_fiches(
        [StatutFiche.candidate.value, StatutFiche.a_verifier.value,
         StatutFiche.a_suivre.value], limite=200,
    )
    return rendre(request, "admin.html", candidates=candidates,
                  compteurs=store.compter_par_statut(),
                  passerelle=passerelle_en_vie())


@app.post("/admin/connexion")
def connexion_admin(request: Request, csrf: str = Form(...), jeton: str = Form(...)):
    verifier_jeton_csrf(csrf)
    limiter(request, "admin_connexion", maximum=5, fenetre_s=600)
    reponse = RedirectResponse("/admin", status_code=303)
    ouvrir_session_admin(reponse, jeton)
    store.journaliser("admin_connexion", "succes")
    return reponse


@app.post("/admin/deconnexion")
def deconnexion_admin(request: Request, csrf: str = Form(...)):
    verifier_jeton_csrf(csrf)
    reponse = RedirectResponse("/", status_code=303)
    fermer_session_admin(reponse)
    return reponse


@app.post("/admin/statut")
def maj_statut(request: Request, csrf: str = Form(...), slug: str = Form(...),
               statut: str = Form(...)):
    exiger_admin(request)
    verifier_jeton_csrf(csrf)
    if not store.changer_statut(slug, statut):
        raise HTTPException(404, "Fiche introuvable ou statut inconnu.")
    return RedirectResponse("/admin", status_code=303)


@app.post("/admin/fiche")
async def creer_fiche_manuelle(request: Request):
    """Saisie manuelle d'une fiche (les 10-20 premières fiches d'amorçage).
    Accepte le JSON complet d'une fiche conforme au schéma des 7 blocs."""
    exiger_admin(request)
    try:
        fiche = Fiche(**(await request.json()))
    except Exception as e:
        raise HTTPException(422, f"Fiche invalide : {e}")
    store.enregistrer_fiche(fiche)
    store.journaliser("fiche_manuelle", fiche.slug)
    return {"enregistre": fiche.slug, "statut": fiche.statut.value}


# --------------------------------------------------------------------------- #
# Application installable (PWA)
# --------------------------------------------------------------------------- #

@app.get("/manifest.json", include_in_schema=False)
def manifeste():
    return FileResponse(RACINE / "static" / "manifest.json",
                        media_type="application/manifest+json")


@app.get("/sw.js", include_in_schema=False)
def service_worker():
    """Servi à la racine : un service worker ne peut piloter que les pages
    situées sous son propre chemin. Depuis /static/, il ne verrait rien."""
    return FileResponse(
        RACINE / "static" / "sw.js",
        media_type="application/javascript",
        headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"},
    )


# --------------------------------------------------------------------------- #
# Santé
# --------------------------------------------------------------------------- #

@app.get("/sante")
def sante():
    etat_passerelle = passerelle_en_vie()
    return {
        "service": "novaluth-web",
        "environnement": ENV,
        "fiches": store.compter_par_statut(),
        "passerelle_ia": "disponible" if etat_passerelle else "indisponible",
        "cles_bittensor_dans_ce_service": False,  # invariant de sécurité
    }


@app.exception_handler(HTTPException)
async def erreur_lisible(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api/"):
        return JSONResponse({"erreur": exc.detail}, status_code=exc.status_code)
    return rendre(request, "erreur.html", status_code=exc.status_code,
                  code=exc.status_code, message=exc.detail)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8000)))
