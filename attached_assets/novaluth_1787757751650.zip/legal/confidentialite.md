Dernière mise à jour : 26/08/2026

## 1. Principe directeur

Novaluth est conçu pour fonctionner avec le minimum de données personnelles
possible. La recherche et la correspondance fonctionnent **sans compte et sans
identification**. Une adresse e-mail n'est demandée que si l'utilisateur souhaite
être mis en relation avec un artisan, et uniquement à ce moment-là.

## 2. Responsable de traitement

| Élément | Valeur |
|---|---|
| Responsable de traitement | [À COMPLÉTER — identité de l'éditeur, voir mentions légales] |
| Contact | contact@novaluth.com |
| Délégué à la protection des données | Non désigné (désignation non obligatoire à ce stade) |
| Autorité de contrôle | CNIL — [cnil.fr](https://www.cnil.fr) |

## 3. Traitements réalisés

| Traitement | Données | Base légale | Conservation |
|---|---|---|---|
| Correspondance sans mise en relation | Critères du projet (budget, style, zone, essences, texte libre). Aucune donnée identifiante | Intérêt légitime : fournir le service demandé | Enregistrement anonyme conservé à des fins statistiques |
| Mise en relation avec un artisan | Adresse e-mail + critères du projet | Consentement explicite (art. 6.1.a RGPD) | 12 mois maximum, puis anonymisation automatique |
| Réponse à une demande de contact | Adresse e-mail, contenu du message | Intérêt légitime : répondre à une sollicitation | 24 mois |
| Fiches des artisans | Données professionnelles publiques : nom d'atelier, ville, site, réseaux | Intérêt légitime : information du public, avec droit d'opposition et de retrait | Jusqu'à demande de retrait |
| Journal technique et sécurité | Horodatage, type d'événement, empreinte technique non nominative | Intérêt légitime : sécurité du service | 12 mois |
| Facturation (dès activité payante) | Identité et coordonnées professionnelles de l'artisan, factures | Obligation légale comptable | 10 ans |

Aucun profilage publicitaire, aucune décision entièrement automatisée produisant
un effet juridique, aucune revente de données, aucun échange de données à des
fins commerciales.

## 4. Destinataires

| Destinataire | Rôle | Localisation |
|---|---|---|
| Replit, Inc. | Hébergement de l'application et de la base | États-Unis — clauses contractuelles types |
| Artisan sélectionné | Destinataire du projet, uniquement sur consentement | UE et hors UE selon l'atelier |
| Chutes (subnet 64 du réseau Bittensor) | Rédaction automatique de résumés | Voir point 5 |
| Macrocosmos (subnet 13 du réseau Bittensor) | Collecte de publications publiques sur les réseaux | Voir point 5 |
| Prestataire de paiement (dès activité payante) | Encaissement | UE |

## 5. Usage de l'intelligence artificielle et transferts

Deux garanties techniques encadrent l'usage des subnets Bittensor :

1. **Aucune donnée personnelle n'est envoyée.** Seuls des critères anonymes
   (budget, style, zone, délai) sont transmis. Un filtre serveur retire
   automatiquement adresses e-mail, numéros de téléphone, adresses postales,
   IBAN et identifiants de portefeuille du texte avant tout envoi, y compris du
   champ de description libre.
2. **Les clés d'accès sont isolées.** Elles sont détenues par un service dédié,
   séparé de l'application publique, accessible uniquement par des requêtes
   signées, plafonné en volume et journalisé.

Ces traitements peuvent impliquer un transfert hors de l'Union européenne. Comme
seules des données non identifiantes sont transmises, aucun transfert de données
personnelles n'est réalisé à ce titre.

## 6. Vos droits

Vous disposez des droits d'accès, de rectification, d'effacement, de limitation,
d'opposition, de portabilité, et du droit de retirer votre consentement à tout
moment.

- Exercice immédiat en ligne : page [Mes données](/donnees).
- Par e-mail : contact@novaluth.com.
- Réponse sous un mois maximum.
- Réclamation possible auprès de la CNIL.

Le retrait du consentement n'affecte pas les transmissions déjà réalisées, mais
interrompt toute transmission ultérieure.

## 7. Sécurité

Mesures mises en œuvre : chiffrement des échanges (HTTPS), clés d'API stockées
uniquement en variables d'environnement d'un service dédié, jamais dans le code
ni dans le dépôt ; authentification signée entre services ; limitation du débit
des routes sensibles ; en-têtes de sécurité stricts ; protection anti-CSRF des
formulaires ; anonymisation automatique des données expirées ; journalisation
sans donnée personnelle.

## 8. Cookies

Le service ne dépose **aucun cookie de mesure d'audience ni de publicité**. Voir
[Gestion des cookies](/legal/cookies).

## 9. Mineurs

Le service n'est pas destiné aux personnes de moins de quinze ans et ne collecte
sciemment aucune donnée les concernant.
