Dernière mise à jour : 26/08/2026

> **Ce document ne s'applique qu'à partir du moment où Novaluth facture un
> service.** À la date ci-dessus, aucune prestation n'est payante et aucune somme
> n'est encaissée. Les CGV doivent être publiées et acceptées **avant** le premier
> euro encaissé, et l'immatriculation (micro-entreprise ou société) doit être
> effective à ce moment-là.

## 1. Objet et champ d'application

Les présentes conditions générales de vente (CGV) régissent la fourniture, par
l'éditeur de Novaluth, de services payants destinés **aux artisans et marques
référencés** :

| Prestation | Description | Prix indicatif |
|---|---|---|
| Accès à un projet qualifié | Déblocage des coordonnées d'un musicien dont le projet correspond à l'atelier | 15 à 25 € par projet |
| Abonnement professionnel | Tableau de bord, statistiques de fiche, outils de gestion | 19 à 29 € par mois |
| Mise en avant | Emplacement identifié « Sponsorisé », sans effet sur le classement organique | Sur devis |

Les prix sont indiqués en euros. La mention de TVA applicable est précisée sur
chaque facture (« TVA non applicable, article 293 B du CGI » en cas de franchise
en base).

**Aucun service payant n'est proposé aux musiciens.** La recherche, le dépôt d'un
projet et la consultation des fiches restent gratuits.

## 2. Ce qui est vendu, et ce qui ne l'est pas

L'objet du contrat est un **accès à une demande qualifiée** ou un **service
logiciel**. Il ne s'agit en aucun cas :

- d'une promesse d'obtenir une commande, une réponse ou un chiffre
  d'affaires ;
- d'un mandat d'agent commercial ni d'un contrat de courtage sur la vente
  d'instruments ;
- d'une prestation de conseil, de certification ou d'audit de l'atelier.

Aucune commission n'est perçue sur le prix des instruments vendus.

## 3. Commande et paiement

La commande est passée en ligne par l'artisan, qui reconnaît avoir pris
connaissance des présentes CGV. Le paiement est traité par un prestataire de
paiement agréé ; Novaluth ne conserve aucune donnée bancaire. La prestation est
fournie après encaissement. Une facture conforme est émise pour chaque paiement.

## 4. Droit de rétractation

Le professionnel employant cinq salariés au plus, qui souscrit à distance un
contrat dont l'objet n'entre pas dans le champ de son activité principale,
bénéficie du droit de rétractation de quatorze jours prévu par l'article
L. 221-3 du code de la consommation.

Par prudence, **Novaluth accorde contractuellement un droit de rétractation de
quatorze jours à tout artisan souscripteur**, à compter de la conclusion du
contrat, exercé par simple e-mail à contact@novaluth.com.

Pour l'accès à un projet qualifié, dont l'exécution est immédiate, l'artisan est
informé qu'en demandant l'exécution immédiate il consent à ce que la prestation
commence avant la fin du délai ; l'accès à un projet déjà consulté n'est alors
plus remboursable, le reste du contrat demeurant rétractable.

## 5. Qualité du projet transmis et remboursement

Un projet est dit « qualifié » lorsqu'il comporte au minimum un budget, un type
d'instrument, une zone de livraison et une adresse de contact valide, transmise
avec le consentement explicite du musicien.

Novaluth remplace ou rembourse un accès lorsque :

- l'adresse de contact est manifestement invalide ou inexistante ;
- le projet est un doublon d'un projet déjà facturé au même artisan ;
- le projet a été déposé de façon frauduleuse ou automatisée.

Novaluth ne rembourse pas au motif que le musicien n'a pas répondu, a changé
d'avis, ou n'a pas passé commande : Novaluth vend un accès, pas un résultat.

Demande à adresser dans les trente jours suivant l'accès, à contact@novaluth.com.

## 6. Durée, résiliation

L'abonnement professionnel est mensuel, sans engagement de durée, résiliable à
tout moment depuis l'espace de l'artisan ou par e-mail, avec effet à la fin de la
période en cours. Aucun frais de résiliation n'est appliqué.

Novaluth peut suspendre ou résilier l'accès d'un artisan, après mise en demeure
restée sans effet pendant quinze jours, en cas de manquement grave : informations
sciemment inexactes, non-respect de la [charte des artisans](/legal/charte-luthier),
comportement illicite. Les sommes correspondant à une période non exécutée sont
remboursées au prorata.

## 7. Responsabilité

Novaluth répond des manquements à ses obligations dans les conditions du droit
commun. Novaluth n'est pas responsable de l'exécution du contrat de vente ou de
fabrication conclu entre l'artisan et le musicien, ni des litiges qui en
découlent.

## 8. Données personnelles

Les données transmises dans le cadre d'un projet qualifié sont communiquées au
seul artisan destinataire, sur la base du consentement explicite du musicien, et
pour la seule finalité de la prise de contact. L'artisan agit en qualité de
responsable de traitement pour l'usage qu'il en fait et s'engage à ne pas les
réutiliser à d'autres fins, notamment de prospection de masse. Voir la
[politique de confidentialité](/legal/confidentialite).

## 9. Droit applicable et litiges

Droit français. En cas de litige, une solution amiable est recherchée en
priorité. À défaut, le litige est porté devant la juridiction compétente selon
les règles de droit commun ; aucune clause du présent document n'impose une
juridiction déterminée.
