Dernière mise à jour : 26/08/2026

## 1. Aucun traceur

Novaluth ne dépose aucun cookie publicitaire, aucun cookie de mesure d'audience,
aucun pixel de réseau social et aucun traceur tiers. Aucune bannière de
consentement n'est donc nécessaire, conformément à la position de la CNIL sur les
cookies strictement nécessaires.

## 2. Ce qui est réellement stocké

| Élément | Nature | Finalité | Durée |
|---|---|---|---|
| `nv_admin` | Cookie de session, `httpOnly`, `SameSite=Strict` | Maintenir la session de l'espace de supervision réservé à l'éditeur | 8 heures |
| Jeton de formulaire | Champ caché signé, non stocké | Protéger les formulaires contre les envois frauduleux (CSRF) | Le temps de la page |
| Cache de l'application installée | Stockage local du navigateur (service worker) | Permettre la consultation hors ligne des pages publiques | Jusqu'à désinstallation |

Le cache local ne contient jamais de page contenant des données personnelles :
les pages de projet, de supervision et de gestion des données sont explicitement
exclues.

## 3. Polices de caractères

La typographie Space Grotesk est chargée depuis Google Fonts, ce qui implique une
connexion à un serveur tiers susceptible de recevoir l'adresse IP du visiteur.
Pour supprimer cette dépendance, la police peut être auto-hébergée dans
`static/` : voir la note correspondante dans le fichier `README.md` du projet.

## 4. Effacer les données locales

Supprimez l'application de l'écran d'accueil, ou effacez les données du site dans
les réglages du navigateur.
