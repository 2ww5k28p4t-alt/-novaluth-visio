/* NOVALUTH — service worker minimal
   Objectif : rendre l'application installable sur iPhone et lisible hors ligne,
   sans jamais mettre en cache une page contenant des données personnelles.
   Les routes /brief (POST), /admin et /donnees ne sont jamais mises en cache. */

const CACHE = 'novaluth-v2';
const ESSENTIELS = [
  '/',
  '/annuaire',
  '/static/novaluth.css?v=2',
  '/static/novaluth-wordmark.png',
  '/static/novaluth-logo.png',
  '/static/novaluth-globe.png',
  '/static/polices/space-grotesk-latin.woff2',
  '/static/app.js',
  '/static/manifest.json',
];

const EXCLUS = ['/admin', '/donnees', '/api/', '/sante'];

self.addEventListener('install', (evenement) => {
  evenement.waitUntil(
    caches.open(CACHE).then((cache) => cache.addAll(ESSENTIELS)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (evenement) => {
  evenement.waitUntil(
    caches.keys()
      .then((cles) => Promise.all(cles.filter((c) => c !== CACHE).map((c) => caches.delete(c))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (evenement) => {
  const requete = evenement.request;
  if (requete.method !== 'GET') return;
  const url = new URL(requete.url);
  if (url.origin !== self.location.origin) return;
  if (EXCLUS.some((prefixe) => url.pathname.startsWith(prefixe))) return;

  evenement.respondWith(
    fetch(requete)
      .then((reponse) => {
        if (reponse.ok && reponse.type === 'basic') {
          const copie = reponse.clone();
          caches.open(CACHE).then((cache) => cache.put(requete, copie));
        }
        return reponse;
      })
      .catch(() => caches.match(requete).then((c) => c || caches.match('/')))
  );
});
