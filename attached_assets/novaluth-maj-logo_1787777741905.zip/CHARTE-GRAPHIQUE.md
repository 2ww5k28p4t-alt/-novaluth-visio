# Novaluth — charte graphique

Version 1.0 — 26/08/2026. Cette charte décrit l'usage du logotype officiel et le
système visuel du site. Elle sert de référence pour toute nouvelle page, tout
visuel de communication et toute déclinaison (réseaux sociaux, PDF, salon).

---

## 1. Le logotype

Trois fichiers, tous en PNG transparent, tous prévus pour un fond sombre.

| Fichier | Dimensions | Usage |
|---|---|---|
| `static/novaluth-wordmark.png` | 1200 × 247 | en-tête du site, pied de page, en-tête de document |
| `static/novaluth-logo.png` | 1400 × 392 | logo complet avec baseline : partage social, couverture, présentation |
| `static/novaluth-globe.png` | 1024 × 1024 | le globe détouré seul : favicon, icône d'application, puce décorative |

Le logotype comporte quatre éléments indissociables :

1. le mot-symbole **NOVALUTH**, en capitales, sans empattement, blanc ;
2. le **globe** violet à magenta qui remplace la lettre O, avec ses méridiens,
   ses trois points lumineux et ses trois cordes verticales ;
3. la **corde** blanche qui traverse les lettres U, T, H et se termine par une
   étincelle — c'est elle qui forme la barre horizontale du H, elle ne peut donc
   jamais être supprimée ;
4. la **baseline** « L'AVENIR DE L'INSTRUMENT », en capitales très espacées.

### Ce qui est interdit

- Poser le logo sur un fond clair ou sur un fond violet : il perd son contraste.
  Sur fond clair, utiliser un cartouche `#131217` avec au moins 24 px de marge.
- Recolorer, remplir le globe d'une couleur unie, retirer la lueur.
- Supprimer la corde ou l'étincelle, ou redessiner la barre du H.
- Déformer, incliner, ajouter une ombre portée, un contour ou un effet 3D.
- Recomposer la baseline dans une autre police ou la coller contre le mot-symbole.

### Zone de protection et taille minimale

Marge libre autour du logo : la hauteur du globe (soit environ 45 % de la hauteur
totale du fichier). Taille minimale d'affichage : 96 px de large à l'écran,
25 mm à l'impression. En dessous, utiliser le globe seul.

---

## 2. Couleurs

Toutes relevées directement sur le fichier du logo.

| Rôle | Jeton CSS | Valeur |
|---|---|---|
| Fond principal (charbon du logo) | `--nv-bg` | `#131217` |
| Fond profond (pied de page, champs) | `--nv-bg-absolu` | `#0C0B0F` |
| Surface de carte | `--nv-surface` | `#1B1B23` |
| Surface haute (en-tête de tableau) | `--nv-surface-haute` | `#21212B` |
| Bordure | `--nv-bordure` | `#2A2A36` |
| Bordure appuyée | `--nv-bordure-vive` | `#3A3A4A` |
| Violet | `--nv-violet` | `#7C3AED` |
| Pourpre | `--nv-pourpre` | `#A855F7` |
| Magenta | `--nv-magenta` | `#E040FB` |
| Texte principal | `--nv-texte` | `#FFFFFF` |
| Texte courant | `--nv-texte-doux` | `#E8E8EF` |
| Texte secondaire | `--nv-texte-secondaire` | `#8A8A9E` |

Le dégradé de signature reprend l'axe du globe :
`linear-gradient(45deg, #7C3AED, #A855F7 55%, #E040FB)`.

Le violet ne sert jamais de fond de texte long : uniquement en dégradé fin, en
lueur, en bordure ou sur un bouton. Le site n'a volontairement pas de thème
clair : le fond charbon fait partie de l'identité.

L'orange `#E0A44B` est réservé à un seul usage : signaler une fiche de
démonstration ou un avertissement. Il n'appartient pas à la palette de marque.

---

## 3. Typographie

**Space Grotesk**, hébergée dans `static/polices` (licence SIL OFL 1.1) : aucune
requête vers un service tiers, ce qui est cohérent avec la page cookies.

| Niveau | Traitement |
|---|---|
| `h1` | capitales, interlettrage `0.035em`, `clamp(1.65rem, 5.6vw, 2.45rem)` |
| `h2` | capitales, interlettrage `0.07em` |
| `h3` | casse normale, graisse 600 |
| Corps | casse normale, 16 px, interligne 1.6, `--nv-texte-doux` |
| Baseline | capitales, interlettrage `0.42em`, 0.68 rem |
| Navigation, étiquettes | capitales, interlettrage 0.08 à 0.12em |

Jamais de graisse supérieure à 600, jamais d'italique pour un titre : le
mot-symbole est droit et régulier, la mise en page le suit.

---

## 4. Les trois motifs issus du logo

Chaque ornement du site vient du logo, aucun n'est décoratif par hasard.

| Motif | Classe | Origine dans le logo |
|---|---|---|
| Lueur violette derrière une section | `.nv-halo` | le halo du globe |
| Grille très discrète en fond | `.nv-meridiens` | les méridiens du globe |
| Fil violet terminé par une étincelle | `.nv-corde` | la corde qui traverse U-T-H |
| Point blanc lumineux | `.nv-point` | les trois points du globe |
| Globe en puce | `.nv-globe` | le globe détouré |

Le fil violet sert de séparateur de section et souligne le titre de chaque page
intérieure. Le halo n'apparaît qu'une fois par page, sur le bloc d'introduction :
répété, il alourdit et brouille la lecture.

Les masques du halo et de la grille sont posés sur des pseudo-éléments, jamais
sur la section : un masque appliqué à la section atténue aussi son texte et fait
chuter le contraste.

---

## 5. Accessibilité

- Contraste : texte principal blanc sur `#131217` ≈ 17:1 ; texte secondaire
  `#8A8A9E` ≈ 5,4:1. Ne pas descendre le texte secondaire en dessous de
  `#8A8A9E`.
- Le violet `#A855F7` sur fond charbon ≈ 5,6:1 : utilisable pour un lien ou une
  étiquette, pas pour un paragraphe entier.
- Contour de focus visible partout : 2 px magenta, jamais supprimé.
- Toute animation est neutralisée sous `prefers-reduced-motion`.
- La couleur ne porte jamais seule une information : chaque étiquette colorée
  est accompagnée d'un texte explicite.

---

## 6. Ton des mentions affichées

Rappel repris des documents juridiques, car il conditionne les libellés
d'interface : les mentions portées sur les fiches sont **descriptives et
datées**. Aucun libellé ne doit suggérer une certification, une garantie ou un
conseil. Le vocabulaire proscrit est contrôlé automatiquement par
`python -m tools.verifier_conformite`.
