"""
NOVALUTH — Sécurité de l'application publique
=============================================

Cette application ne détient AUCUNE clé de subnet Bittensor (elles vivent
uniquement dans le service gateway/). Ce qu'elle protège ici :

  * les en-têtes HTTP (CSP stricte, pas d'iframe, pas de référent sortant) ;
  * le débit des routes sensibles (anti-abus du brief et de l'IA) ;
  * l'accès à l'espace de supervision (jeton d'administration + comparaison
    à temps constant + cookie httpOnly) ;
  * les formulaires (jeton anti-CSRF signé, sans base de sessions) ;
  * la taille des corps de requête.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request, Response
from starlette.middleware.base import BaseHTTPMiddleware

SECRET_APP = os.environ.get("NOVALUTH_APP_SECRET", "")
JETON_ADMIN = os.environ.get("NOVALUTH_ADMIN_TOKEN", "")
NOM_COOKIE_ADMIN = "nv_admin"
DUREE_SESSION_ADMIN_S = 8 * 3600
TAILLE_MAX_CORPS = 120_000

# Content-Security-Policy : tout est servi depuis le site, y compris la police
# (hebergee dans static/polices). Aucune connexion vers un domaine tiers.
CSP = (
    "default-src 'self'; "
    "img-src 'self' data:; "
    "style-src 'self' 'unsafe-inline'; "
    "font-src 'self'; "
    "script-src 'self'; "
    "connect-src 'self'; "
    "form-action 'self'; "
    "frame-ancestors 'none'; "
    "base-uri 'self'; "
    "object-src 'none'"
)

EN_TETES = {
    "Content-Security-Policy": CSP,
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), camera=(), microphone=(), payment=()",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
}


def secret_app() -> str:
    global SECRET_APP
    if not SECRET_APP or len(SECRET_APP) < 32:
        # Secret éphémère : l'application démarre, mais les sessions admin ne
        # survivent pas à un redémarrage. Le README explique comment le fixer.
        SECRET_APP = secrets.token_hex(32)
        print("[sécurité] NOVALUTH_APP_SECRET absent : secret temporaire généré.")
    return SECRET_APP


class MiddlewareSecurite(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        longueur = request.headers.get("content-length")
        if longueur and longueur.isdigit() and int(longueur) > TAILLE_MAX_CORPS:
            return Response("Requête trop volumineuse.", status_code=413)
        reponse: Response = await call_next(request)
        for cle, valeur in EN_TETES.items():
            reponse.headers.setdefault(cle, valeur)
        return reponse


# --------------------------------------------------------------------------- #
# Limitation de débit — en mémoire, suffisant pour un Repl à un seul processus
# --------------------------------------------------------------------------- #

_historique: dict[str, deque[float]] = defaultdict(deque)


def limiter(request: Request, cle: str, maximum: int, fenetre_s: int) -> None:
    ip = (request.headers.get("x-forwarded-for", "").split(",")[0].strip()
          or (request.client.host if request.client else "inconnu"))
    empreinte = hashlib.sha256(f"{cle}:{ip}".encode()).hexdigest()
    maintenant = time.time()
    file = _historique[empreinte]
    while file and maintenant - file[0] > fenetre_s:
        file.popleft()
    if len(file) >= maximum:
        raise HTTPException(429, "Trop de requêtes. Merci de patienter une minute.")
    file.append(maintenant)


# --------------------------------------------------------------------------- #
# Jeton anti-CSRF (signé, sans stockage serveur)
# --------------------------------------------------------------------------- #

def creer_jeton_csrf() -> str:
    horodatage = str(int(time.time()))
    aleatoire = secrets.token_hex(12)
    base = f"{horodatage}.{aleatoire}"
    signature = hmac.new(secret_app().encode(), base.encode(), hashlib.sha256).hexdigest()[:32]
    return f"{base}.{signature}"


def verifier_jeton_csrf(jeton: str | None, duree_max_s: int = 7200) -> None:
    if not jeton or jeton.count(".") != 2:
        raise HTTPException(400, "Formulaire expiré. Merci de recharger la page.")
    horodatage, aleatoire, signature = jeton.split(".")
    base = f"{horodatage}.{aleatoire}"
    attendue = hmac.new(secret_app().encode(), base.encode(), hashlib.sha256).hexdigest()[:32]
    if not hmac.compare_digest(signature, attendue):
        raise HTTPException(400, "Formulaire invalide.")
    if not horodatage.isdigit() or time.time() - int(horodatage) > duree_max_s:
        raise HTTPException(400, "Formulaire expiré. Merci de recharger la page.")


# --------------------------------------------------------------------------- #
# Session d'administration
# --------------------------------------------------------------------------- #

def _signer_session(expiration: int) -> str:
    signature = hmac.new(secret_app().encode(), str(expiration).encode(),
                         hashlib.sha256).hexdigest()
    return f"{expiration}.{signature}"


def ouvrir_session_admin(reponse: Response, jeton_fourni: str) -> None:
    if not JETON_ADMIN or len(JETON_ADMIN) < 16:
        raise HTTPException(503, "NOVALUTH_ADMIN_TOKEN non configuré "
                                "(16 caractères minimum).")
    if not hmac.compare_digest(jeton_fourni.strip(), JETON_ADMIN):
        # Même message et même délai qu'un succès pour ne rien révéler.
        time.sleep(0.4)
        raise HTTPException(401, "Jeton d'administration invalide.")
    expiration = int(time.time()) + DUREE_SESSION_ADMIN_S
    reponse.set_cookie(
        NOM_COOKIE_ADMIN, _signer_session(expiration),
        max_age=DUREE_SESSION_ADMIN_S, httponly=True, samesite="strict",
        secure=os.environ.get("NOVALUTH_ENV", "dev") == "prod", path="/",
    )


def fermer_session_admin(reponse: Response) -> None:
    reponse.delete_cookie(NOM_COOKIE_ADMIN, path="/")


def session_admin_valide(request: Request) -> bool:
    cookie = request.cookies.get(NOM_COOKIE_ADMIN)
    if not cookie or "." not in cookie:
        return False
    expiration, _, signature = cookie.partition(".")
    if not expiration.isdigit():
        return False
    attendue = hmac.new(secret_app().encode(), expiration.encode(),
                        hashlib.sha256).hexdigest()
    return hmac.compare_digest(signature, attendue) and int(expiration) > time.time()


def exiger_admin(request: Request) -> None:
    if not session_admin_valide(request):
        raise HTTPException(401, "Authentification requise.")
