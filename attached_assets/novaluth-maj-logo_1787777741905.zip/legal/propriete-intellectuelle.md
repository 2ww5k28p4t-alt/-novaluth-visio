Dernière mise à jour : 26/08/2026

## 1. Contenus de Novaluth

La marque Novaluth, son logotype, sa charte graphique, la structure et
l'architecture de la base de données, ainsi que les textes rédigés par l'éditeur
sont protégés par le droit d'auteur et, s'agissant de la base, par le droit du
producteur de base de données (articles L. 341-1 et suivants du code de la
propriété intellectuelle).

Sont interdites, sans autorisation écrite : l'extraction ou la réutilisation
substantielle de la base, la copie systématique des fiches, l'utilisation
d'automates d'extraction, et la reproduction du logotype.

## 2. Logotype et typographie du site

Le logotype Novaluth — le mot-symbole, le globe qui remplace la lettre O, la
corde qui traverse les dernières lettres et la baseline « L'avenir de
l'instrument » — est la propriété exclusive de l'éditeur. Sa reproduction, sa
modification, son recadrage, le changement de ses couleurs ou son intégration
dans un autre signe sont interdits sans autorisation écrite.

La typographie du site est Space Grotesk, de Florian Karsten, diffusée sous
licence SIL Open Font License 1.1 et hébergée sur nos serveurs. La notice de
licence est conservée dans `static/polices/LICENCE-space-grotesk.txt`.

## 3. Contenus des artisans

Les noms, marques, photographies et descriptions des artisans appartiennent à
leurs titulaires. Ils sont cités à des fins d'information du public.

Novaluth s'interdit de publier une photographie d'instrument ou d'atelier sans
autorisation de son auteur. Les fiches ne reprennent que des informations
factuelles et un lien vers la source.

## 4. Droit de retrait et de correction

Tout artisan peut demander, sans motif et sans frais :

- la correction d'une information ;
- le retrait d'un élément (photo, citation, description) ;
- le retrait complet de sa fiche.

Adresse unique : contact@novaluth.com. Traitement en priorité, retrait effectif
sans délai injustifié.

## 5. Signalement d'un contenu illicite

Conformément au règlement (UE) 2022/2065 sur les services numériques, toute
personne peut signaler un contenu qu'elle estime illicite.

Le signalement doit comporter : l'adresse exacte de la page, la description
précise du contenu visé, les motifs invoqués, et un moyen de contact.

Adresse de signalement : contact@novaluth.com

Traitement : accusé de réception, examen, décision motivée communiquée à
l'auteur du signalement et, lorsque c'est possible, à l'auteur du contenu, qui
peut contester. Les signalements manifestement abusifs ou répétés sans fondement
peuvent être écartés.

## 6. Liens sortants

Les liens vers les sites des artisans sont fournis pour information. Novaluth
n'exerce aucun contrôle sur ces sites et n'assume aucune responsabilité quant à
leur contenu.
