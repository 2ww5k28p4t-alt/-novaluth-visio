Dernière mise à jour : 26/08/2026

## 1. Aucun traceur

Novaluth ne dépose aucun cookie publicitaire, aucun cookie de mesure d'audience,
aucun pixel de réseau social et aucun traceur tiers. Aucune bannière de
consentement n'est donc nécessaire, conformément à la position de la CNIL sur les
cookies strictement nécessaires.

## 2. Ce qui est réellement stocké

| Élément | Nature | Finalité | Durée |
|---|---|---|---|
| `nv_admin` | Cookie de session, `httpOnly`, `SameSite=Strict` | Maintenir la session de l'espace de supervision réservé à l'éditeur | 8 heures |
| Jeton de formulaire | Champ caché signé, non stocké | Protéger les formulaires contre les envois frauduleux (CSRF) | Le temps de la page |
| Cache de l'application installée | Stockage local du navigateur (service worker) | Permettre la consultation hors ligne des pages publiques | Jusqu'à désinstallation |

Le cache local ne contient jamais de page contenant des données personnelles :
les pages de projet, de supervision et de gestion des données sont explicitement
exclues.

## 3. Polices de caractères

La typographie Space Grotesk est hébergée sur nos propres serveurs, dans le
dossier `static/polices`. Aucune police n'est chargée depuis un service tiers :
aucun serveur extérieur ne reçoit donc votre adresse IP lors de l'affichage des
pages. Le site ne fait aucune requête vers un domaine tiers, ce que la politique
de sécurité du contenu (`Content-Security-Policy`) interdit explicitement.

Space Grotesk est diffusée sous licence SIL Open Font License 1.1.

## 4. Effacer les données locales

Supprimez l'application de l'écran d'accueil, ou effacez les données du site dans
les réglages du navigateur.
