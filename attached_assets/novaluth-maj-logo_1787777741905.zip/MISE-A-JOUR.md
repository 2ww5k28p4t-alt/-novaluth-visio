# Mise à jour visuelle — logo officiel Novaluth

Version 2.0 du système visuel · 26/08/2026

Cette archive **ne contient que les fichiers nouveaux ou modifiés**. Elle se
dépose par-dessus le projet Novaluth déjà en place dans votre Repl : les chemins
sont identiques, les fichiers existants sont donc remplacés. Aucune modification
de la passerelle, du pipeline, du bot Telegram ni de la base de données.

---

## 1. Marche à suivre sur Replit (depuis l'iPhone)

1. Ouvrez votre Repl Novaluth.
2. Dans le panneau des fichiers, utilisez **Upload file** et déposez
   `novaluth-maj-logo.zip` à la racine du Repl (au même niveau que `run.py`).
3. Ouvrez le Shell et lancez :

   ```bash
   unzip -o novaluth-maj-logo.zip && rm novaluth-maj-logo.zip
   rm -f static/novaluth-logo.svg static/novaluth-icon.svg
   ```

   L'option `-o` écrase sans poser de question. La seconde ligne supprime les
   deux anciens logos dessinés en SVG, désormais inutiles.
4. Vérifiez que tout est conforme :

   ```bash
   python -m tools.verifier_conformite
   ```

   Résultat attendu : « Aucune anomalie bloquante », plus les 4 points à
   surveiller déjà connus (identité, SIRET, médiateur à compléter).
5. Cliquez sur **Run**, puis ouvrez le site.
6. Sur l'iPhone, si l'ancienne version reste affichée : fermez l'onglet, ou
   retirez puis réinstallez l'application depuis l'écran d'accueil. Le service
   worker passe en `novaluth-v2` et purge l'ancien cache automatiquement, mais
   iOS garde parfois la page précédente une minute.

Aucune nouvelle variable d'environnement, aucune nouvelle dépendance : le
fichier `requirements.txt` est inchangé.

---

## 2. Ce qui change

### Le logo est intégré partout

- **En-tête** : le mot-symbole `novaluth-wordmark.png` (30 px de haut, 24 px sur
  mobile), extrait de votre fichier d'origine avec sa lueur, sa transparence et
  sa corde.
- **Pied de page** : le mot-symbole suivi de la baseline en texte, pour rester
  lisible aux petites tailles.
- **Icône d'application** : le globe seul, détouré, en 192, 512 et 1024 px, plus
  l'icône Apple 180 px et le favicon 32 px. C'est ce que voit l'iPhone à
  l'installation sur l'écran d'accueil.
- **Partage** : `novaluth-logo.png` (logo complet avec baseline) est déclaré en
  image Open Graph.

### Le site colle au logo

Le fond passe au charbon exact du logo (`#131217`), et les trois motifs du
logotype deviennent le langage visuel du site :

| Motif du logo | Ce qu'il devient sur le site |
|---|---|
| Le halo du globe | lueur violette derrière le bloc d'accueil |
| Les méridiens du globe | grille très discrète en fond du même bloc |
| La corde et son étincelle | fil violet qui sépare les sections et souligne chaque titre de page |
| Les points lumineux du globe | puces et pastilles lumineuses |
| Les capitales du mot-symbole | titres en capitales espacées, navigation et étiquettes assorties |

Les cartes portent un fil violet sur leur bord supérieur, les boutons reprennent
le dégradé violet → magenta du globe avec sa lueur, les étapes de l'accueil sont
numérotées dans un cercle violet.

Tout est décrit dans le nouveau fichier `CHARTE-GRAPHIQUE.md` : palette, tailles,
usages interdits du logo, zone de protection, contrastes.

### La police n'est plus chargée chez Google

Space Grotesk est maintenant hébergée dans `static/polices` (deux fichiers
`.woff2`, licence SIL Open Font License 1.1, notice conservée dans le dossier).

Conséquences concrètes :

- plus aucune requête vers `fonts.googleapis.com` ni `fonts.gstatic.com`, donc
  aucun serveur tiers ne reçoit l'adresse IP de vos visiteurs ;
- la politique de sécurité du contenu est resserrée dans `web/securite.py` :
  `style-src 'self'` et `font-src 'self'`, plus aucun domaine externe autorisé ;
- `legal/cookies.md` est mis à jour en conséquence, et le point « polices
  distantes » disparaît de la liste des choses à traiter dans le `README.md` ;
- l'affichage est aussi plus rapide au premier chargement sur mobile.

### Un ajout juridique

`legal/propriete-intellectuelle.md` gagne une section « Logotype et typographie
du site » : elle décrit précisément votre logo (mot-symbole, globe, corde,
baseline), interdit sa reproduction, sa modification et sa recoloration sans
autorisation écrite, et documente la licence de la police. Les sections suivantes
ont été renumérotées.

---

## 3. Liste des fichiers de l'archive

```
CHARTE-GRAPHIQUE.md                      nouveau — charte complète
MISE-A-JOUR.md                           nouveau — ce document
README.md                                modifié — arborescence et §5
legal/cookies.md                         modifié — polices auto-hébergées
legal/propriete-intellectuelle.md        modifié — logotype et typographie
templates/base.html                      modifié — logo, icônes, police locale
templates/accueil.html                   modifié — halo, méridiens, fils, numéros
web/securite.py                          modifié — CSP resserrée
static/novaluth.css                      réécrit — système visuel 2.0
static/manifest.json                     modifié — couleurs et icônes
static/sw.js                             modifié — cache novaluth-v2
static/novaluth-wordmark.png             nouveau — 1200 × 247
static/novaluth-logo.png                 nouveau — 1400 × 392
static/novaluth-globe.png                nouveau — 1024 × 1024
static/icon-1024.png                     nouveau
static/icon-512.png                      remplacé
static/icon-192.png                      remplacé
static/apple-touch-icon.png              remplacé
static/favicon-32.png                    remplacé
static/polices/space-grotesk-latin.woff2         nouveau
static/polices/space-grotesk-latin-ext.woff2     nouveau
static/polices/LICENCE-space-grotesk.txt         nouveau
```

À supprimer après décompression : `static/novaluth-logo.svg` et
`static/novaluth-icon.svg`.

---

## 4. Contrôles effectués avant livraison

- Les 7 pages publiques répondent en 200, aucune erreur dans les journaux.
- Aucun débordement horizontal ni texte coupé, mesuré sur toutes les pages en
  390 × 844 (iPhone) et en 1440 px (bureau).
- Contrôle de conformité : aucune anomalie bloquante, aucun vocabulaire de
  garantie ou de conseil, aucune clé de subnet hors de la passerelle.
- La passerelle et l'isolation des clés Bittensor ne sont pas touchées par cette
  mise à jour.

Les 4 points connus restent à traiter avant la première mise en ligne
commerciale : identité de l'éditeur, SIRET, hébergeur et médiateur de la
consommation dans `legal/mentions-legales.md`, `legal/confidentialite.md`,
`legal/litiges.md` et `legal/conflits-interets.md`.
