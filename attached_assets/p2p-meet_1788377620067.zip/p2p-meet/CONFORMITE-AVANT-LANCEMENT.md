# Conformité — liste de contrôle avant mise en ligne

Ce document rassemble ce qui reste à faire pour que **visio.novaluth.com** soit exploitable en règle. Il complète le [registre des traitements](REGISTRE-TRAITEMENTS.md) et les trois pages publiées dans `public/legal/`.

Avertissement : ce document est une synthèse documentée de sources officielles, pas un conseil juridique. La dernière section liste les points qui doivent être tranchés par un avocat.

---

## 1. Ce qui est déjà en place dans le code

| Élément | État |
|---|---|
| Accès réservé par comptes, sans inscription libre | fait |
| Mots de passe hachés en bcrypt coût 12, minimum 12 caractères | fait |
| Verrouillage du compte après 5 échecs pendant 15 minutes | fait |
| Limitation à 15 tentatives de connexion par adresse et par quart d'heure | fait |
| Cookie de session signé, HttpOnly, Secure en production, SameSite=Lax, 12 heures | fait |
| Salles protégées par mot de passe, conservé en mémoire vive uniquement | fait |
| Aucun enregistrement des appels, aucun serveur de médias | fait |
| Journal d'accès minimal avec adresses IP pseudonymisées | fait |
| Purge automatique du journal au bout de 90 jours | fait |
| Export et effacement des données d'une personne depuis la page d'administration | fait |
| Politique de sécurité du contenu stricte, aucun script tiers, aucune police externe | fait |
| Pages mentions légales, confidentialité et conditions d'utilisation, liées depuis chaque page | fait, à compléter |
| Registre des activités de traitement | fait, à compléter |
| Identifiants TURN temporaires signés, secret jamais exposé au navigateur | fait |

---

## 2. À compléter dans les documents

Chaque champ entre crochets doit être renseigné.

- [ ] `public/legal/mentions-legales.html` : nom, prénoms, domicile, téléphone, directeur de la publication, coordonnées des deux hébergeurs
- [ ] `public/legal/confidentialite.html` : identité et adresse du responsable de traitement, nom de l'hébergeur du serveur TURN
- [ ] `public/legal/cgu.html` : relecture et validation des clauses de responsabilité
- [ ] `REGISTRE-TRAITEMENTS.md` : identité du responsable, liste définitive des sous-traitants
- [ ] Choisir entre l'option A, identification complète, et l'option B, anonymat de l'éditeur non professionnel, décrites en bas des mentions légales

---

## 3. Décisions à prendre avant la mise en ligne

### 3.1 Régime d'identification

L'article 1er-1, II de la loi n° 2004-575 autorise l'éditeur « à titre non professionnel » à ne publier que les coordonnées de son hébergeur, à condition de lui avoir communiqué son identité ([Journal officiel](https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000049563632)). Aucune source officielle consultée ne définit le seuil du « non professionnel ». Un service gratuit rattaché au projet commercial NovaLuth se situe dans une zone grise. La voie prudente est l'identification complète.

Le manquement est puni d'un an d'emprisonnement et de 75 000 € d'amende ([entreprendre.service-public.fr](https://entreprendre.service-public.fr/vosdroits/F31228)), montant porté à 375 000 € pour une personne morale ([entreprendre.service-public.fr](https://entreprendre.service-public.fr/vosdroits/F37351)).

### 3.2 Localisation de l'hébergement

Héberger l'application dans l'Union européenne supprime toute la question des transferts internationaux. Si l'application reste sur Replit, il faut :

- [ ] vérifier nommément l'inscription de Replit, Inc. sur la liste du Data Privacy Framework tenue par le département du Commerce des États-Unis, ainsi que la portée de la certification ;
- [ ] à défaut, mettre en place des clauses contractuelles types et documenter une analyse d'impact du transfert.

La CNIL est explicite : « Seuls les transferts vers les entités américaines certifiées ne nécessitent pas l'utilisation d'outils d'encadrement des transferts prévus par l'article 46 du RGPD » et « avant de procéder au transfert, les organismes doivent s'assurer que l'organisme destinataire figure sur cette liste » ([CNIL, adéquation des États-Unis](https://www.cnil.fr/fr/adequation-des-etats-unis-les-premieres-questions-reponses)).

Le serveur TURN, lui, sera hébergé dans l'Union européenne : la question ne se pose pas pour lui.

### 3.3 Contrats de sous-traitance

- [ ] Obtenir ou signer un contrat conforme à l'article 28.3 du RGPD avec l'hébergeur de l'application
- [ ] Signer un contrat conforme avec l'hébergeur du serveur TURN
- [ ] Vérifier le contrat du gestionnaire du domaine

La CNIL publie un [exemple de clauses de sous-traitance](https://www.cnil.fr/fr/sous-traitance-exemple-de-clauses) directement réutilisable. Le contrat doit imposer au sous-traitant, entre autres, de ne traiter les données que sur instruction documentée, d'assurer la confidentialité, d'appliquer les mesures de sécurité de l'article 32, de ne pas recruter de sous-traitant ultérieur sans autorisation écrite, d'aider à répondre aux demandes de droits, de supprimer ou renvoyer les données au terme de la prestation et de permettre des audits ([texte de l'article 28 publié par la CNIL](https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4)).

### 3.4 Cookies

Aucun bandeau n'est nécessaire tant que le seul cookie déposé est le cookie de session d'authentification, expressément exempté de consentement par la CNIL ([mettre son site web en conformité](https://www.cnil.fr/fr/cookies-et-autres-traceurs/regles/cookies/comment-mettre-mon-site-web-en-conformite)).

- [ ] Si vous ajoutez un outil de mesure d'audience, vérifier qu'il relève de la configuration exemptée décrite par la CNIL, sinon mettre en place un vrai mécanisme de consentement avec refus aussi simple que l'acceptation

### 3.5 Analyse d'impact

L'analyse figurant dans le [registre](REGISTRE-TRAITEMENTS.md) conclut qu'une analyse d'impact relative à la protection des données ne paraît pas obligatoire en l'état, car moins de deux des neuf critères du Comité européen de la protection des données sont clairement remplis ([méthode CNIL](https://www.cnil.fr/fr/ce-quil-faut-savoir-sur-lanalyse-dimpact-relative-la-protection-des-donnees-aipd)).

- [ ] Réévaluer immédiatement en cas d'enregistrement des appels, d'ouverture aux moins de quinze ans, de passage à grande échelle ou d'ajout de profilage

---

## 4. Si le service devient payant

- [ ] Publier des conditions générales de vente, obligatoires en cas de vente à des consommateurs, contrairement aux conditions d'utilisation ([entreprendre.service-public.fr](https://entreprendre.service-public.fr/vosdroits/F33527))
- [ ] Adhérer à un dispositif de médiation de la consommation et publier les coordonnées du médiateur de manière visible sur le site, en application de l'article L. 612-1 du code de la consommation ([ministère de l'Économie](https://www.economie.gouv.fr/mediation-conso/vous-etes-professionnel))
- [ ] Prévoir l'information précontractuelle et le droit de rétractation
- [ ] Créer l'entreprise et publier le numéro d'inscription au registre national des entreprises. La micro-entreprise reste possible jusqu'à 77 700 € de recettes annuelles pour une prestation de services ([ministère de l'Économie](https://www.economie.gouv.fr/entreprises/gerer-sa-micro-entreprise/comment-creer-une-micro-entreprise))

Le défaut d'information sur la médiation est passible d'une amende administrative pouvant atteindre 3 000 € pour une personne physique et 15 000 € pour une personne morale, en application de l'article L. 641-1 du code de la consommation ([ministère de l'Économie](https://www.economie.gouv.fr/mediation-conso/vous-etes-professionnel)).

---

## 5. Sécurité opérationnelle

- [ ] Générer `SESSION_SECRET`, `LOG_SALT` et `TURN_STATIC_AUTH_SECRET` avec `openssl rand -hex 32`, chacun différent
- [ ] Placer tous les secrets dans les Secrets de Replit, jamais dans un fichier versionné
- [ ] Définir `NODE_ENV=production` pour activer l'attribut Secure du cookie
- [ ] Changer immédiatement le mot de passe de l'administrateur créé au premier démarrage
- [ ] Utiliser un déploiement à machine réservée, les connexions WebSocket devant rester persistantes
- [ ] Vérifier le renouvellement automatique du certificat TLS du serveur TURN et le rechargement de Coturn après renouvellement
- [ ] Sauvegarder `data/users.json` de façon chiffrée, et le traiter comme un fichier contenant des données personnelles
- [ ] Consulter le journal d'accès de temps à autre pour repérer les séries d'échecs de connexion

---

## 6. Suivi dans le temps

- [ ] Relire le registre des traitements au moins une fois par an et à chaque évolution du service
- [ ] Tenir le registre des violations de données, même vide
- [ ] En cas de violation présentant un risque, notifier la CNIL dans les 72 heures
- [ ] Mettre à jour la date de dernière modification des pages légales à chaque changement
- [ ] Signaler les modifications substantielles sur la page de connexion

---

## 7. Points à faire trancher par un avocat

Ces douze points ne peuvent pas être résolus par la lecture des sources officielles. Ils sont classés par importance décroissante pour ce projet.

1. **Qualification d'hébergeur** au sens de la loi pour la confiance dans l'économie numérique. Un service de signalisation WebRTC, sans stockage de contenus, est-il un hébergeur ? C'est le point le plus incertain du dossier, car il déclenche les obligations de conservation des données de connexion du décret n° 2021-1362 ([Journal officiel](https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044228912)). Le Conseil d'État distingue le régime des hébergeurs de celui des opérateurs de communications électroniques ([décision du 21 avril 2021](https://www.legifrance.gouv.fr/ceta/id/CETATEXT000043411127)).
2. **Édition à titre professionnel ou non professionnel**, qui détermine la possibilité de l'anonymat des mentions légales.
3. **Contenu exact du décret n° 2021-1362** : catégories de données et durées, article par article, et maintien ou non de la clause selon laquelle certaines informations ne sont conservées « que dans la mesure où les personnes les collectent habituellement », présente dans le décret n° 2011-219 aujourd'hui abrogé ([Legifrance](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000023646013)). Ce texte n'est pas lisible article par article de façon fiable en consultation automatisée.
4. **Analyse d'impact** : le contenu d'une conversation audio et vidéo constitue-t-il une donnée « hautement personnelle » au sens du quatrième critère du Comité européen, malgré le chiffrement de bout en bout et l'absence de tout enregistrement ?
5. **Responsable de traitement avant création d'entreprise** : une personne physique non immatriculée peut-elle valablement l'être, et avec quelles conséquences en matière de responsabilité personnelle et d'assurance ?
6. **Mineurs** : politique d'âge minimum et conséquences sur le consentement parental et l'analyse d'impact.
7. **Service numérique fourni « contre des données personnelles »** : cette qualification issue de la directive (UE) 2019/2161 fait-elle basculer un service gratuit dans le champ du code de la consommation, avec médiation et droit de rétractation ?
8. **Transferts hors Union européenne** : statut de certification de l'hébergeur retenu et nécessité d'une analyse d'impact du transfert.
9. **Chiffrement de bout en bout** et demandes éventuelles de l'autorité judiciaire.
10. **Modération et signalement des contenus illicites** : obligations éventuelles au titre du règlement européen sur les services numériques pour un service de communication en temps réel, l'article 6 de la loi de 2004 mentionnant une sanction pouvant atteindre 6 % du chiffre d'affaires mondial en cas de manquement habituel ([Legifrance](https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000049577522)). Applicabilité à une micro-structure non analysée.
11. **Sanction de 375 000 €** applicable à une personne morale : mécanisme de l'article 131-38 du code pénal.
12. **Assurance responsabilité civile professionnelle** et validité des clauses de limitation de responsabilité pour un service gratuit.

Le dossier de recherche complet, avec chaque affirmation suivie de sa source officielle, se trouve dans `recherche-juridique.md`, à la racine du projet.
