# Déploiement 100 % européen de NovaLuth Visio

Version tout-en-un : **une seule machine, louée dans l'Union européenne, qui héberge l'application et le serveur TURN**. Aucun service tiers, aucun transfert de données hors de l'Union, aucune dépendance à un fournisseur américain.

Chaque commande est prête à copier-coller. Suivez les étapes dans l'ordre.

Si vous avez choisi OVHcloud, la fiche [OVH-COMMANDES.md](OVH-COMMANDES.md) reprend le même déploiement en douze étapes, sans les explications, avec les particularités d'OVHcloud déjà intégrées.

## Ce que cette version change par rapport au déploiement sur Replit

| | Version Replit | Version européenne |
|---|---|---|
| Hébergement de l'application | Replit, Inc., États-Unis | votre serveur, dans l'Union européenne |
| Transfert de données hors UE | oui, à encadrer | **aucun** |
| Sous-traitants | Replit + hébergeur du TURN | **un seul hébergeur** |
| Certificats TLS | gérés par Replit | Caddy, automatiquement |
| Machines à administrer | 2 | 1 |
| Coût mensuel | déploiement Replit + VPS | un seul VPS |
| Compétence requise | faible | ligne de commande, une heure de mise en place |

Sur le plan juridique, cette version supprime la question la plus délicate du dossier : les transferts vers les États-Unis, qui supposent de vérifier la certification du prestataire au titre du Data Privacy Framework ou de mettre en place des clauses contractuelles types ([CNIL, adéquation des États-Unis](https://www.cnil.fr/fr/adequation-des-etats-unis-les-premieres-questions-reponses)).

---

## Architecture

```
                    Internet
                        │
        ┌───────────────┴───────────────┐
        │   visio.novaluth.com          │  443/TCP  →  Caddy  →  app:3000
        │   turn.novaluth.com           │  3478/TCP+UDP, 5349/TCP+UDP  →  Coturn
        └───────────────┬───────────────┘
                        │
            un seul serveur, Union européenne

  ┌──────────┐    ┌──────────┐    ┌──────────────────────┐
  │  caddy   │──▶ │   app    │    │        coturn        │
  │ TLS auto │    │ Node.js  │    │  relais des appels   │
  └──────────┘    └──────────┘    └──────────────────────┘
   ports 80/443    réseau interne   réseau de l'hôte
                   jamais exposé

  Les flux audio et vidéo ne traversent aucun de ces conteneurs :
  ils vont directement de navigateur à navigateur, chiffrés en
  DTLS-SRTP. Coturn n'intervient qu'en cas d'échec de la liaison
  directe, et relaie alors des paquets dont il n'a pas les clés.
```

---

## Étape 0 — Choisir l'hébergeur

Restez chez un hébergeur soumis au seul droit de l'Union européenne, avec un centre de données dans l'Union.

| Hébergeur | Offre d'entrée | Prix | Ce qui est inclus | Centres de données dans l'UE |
|---|---|---|---|---|
| **OVHcloud** (France) | VPS-1 | 3,81 € HT par mois, soit 4,57 € TTC ([OVHcloud](https://www.ovhcloud.com/fr/vps/)) | 2 vCores, 4 Go de RAM, 40 Go NVMe, trafic illimité à 500 Mbit/s, **IPv4 dédiée incluse** ([OVHcloud](https://www.ovhcloud.com/fr/vps/)) | Gravelines, Strasbourg, Roubaix |
| **Hetzner** (Allemagne) | serveurs cloud partagés | tarifs à vérifier sur leur page ; l'IPv4 publique est facturée **0,50 € HT par mois** et n'est pas incluse par défaut ([documentation Hetzner](https://docs.hetzner.com/cloud/servers/overview/)) | selon l'offre retenue | Falkenstein, Nuremberg, Helsinki ([Hetzner](https://www.hetzner.com/cloud/)) |
| **Scaleway** (France) | PLAY2-PICO | environ 10,42 € HT par mois ([Scaleway](https://www.scaleway.com/fr/tarifs/virtual-instances/)) | 1 vCPU, 2 Go de RAM, 100 Mbit/s ; **IPv4 publique non incluse**, stockage non inclus ([Scaleway](https://www.scaleway.com/fr/tarifs/virtual-instances/)) | Paris, Amsterdam, Varsovie |

Recommandation pour ce projet : **OVHcloud VPS-1**. Le trafic illimité compte beaucoup, puisque chaque participant relayé consomme environ 1 Mbit/s dans chaque sens, et vous y gérez déjà `novaluth.com`. Les tarifs changent : vérifiez-les au moment de la commande.

Configuration minimale suffisante : 1 vCPU, 2 Go de RAM, une IPv4 publique dédiée, Debian 12 ou Ubuntu 24.04.

À éviter pour cet usage : Infomaniak, dont les centres de données sont en Suisse. La Suisse bénéficie d'une décision d'adéquation, mais elle n'est pas dans l'Union européenne ; si votre objectif est un hébergement strictement européen, restez dans l'Union.

Point juridique : l'hébergeur reste un sous-traitant au sens de l'article 28 du RGPD. Signez son contrat de sous-traitance et inscrivez-le dans le registre des traitements. La CNIL publie un [exemple de clauses de sous-traitance](https://www.cnil.fr/fr/sous-traitance-exemple-de-clauses) qui permet de vérifier que le contrat proposé est complet.

---

## Étape 1 — Enregistrements DNS

Chez le gestionnaire de `novaluth.com`, créez deux enregistrements pointant vers la même machine :

```
Type   Nom      Valeur                         TTL
A      visio    IP_PUBLIQUE_DU_SERVEUR         3600
A      turn     IP_PUBLIQUE_DU_SERVEUR         3600
AAAA   visio    IPV6_DU_SERVEUR                3600
AAAA   turn     IPV6_DU_SERVEUR                3600
```

Les enregistrements IPv6 sont optionnels. Vérifiez la propagation avant de continuer :

```bash
dig +short visio.novaluth.com
dig +short turn.novaluth.com
```

Les deux doivent renvoyer l'adresse du serveur. Ne passez pas à la suite avant : Let's Encrypt en a besoin pour délivrer les certificats.

---

## Étape 2 — Préparer le serveur

Connectez-vous en SSH, puis :

```bash
# Mise à jour du système
sudo apt update && sudo apt upgrade -y

# Outils de base
sudo apt install -y ca-certificates curl gnupg ufw

# Docker et le plugin Compose
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg \
  | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/debian $(lsb_release -cs) stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
```

Sur Ubuntu, remplacez les deux occurrences de `debian` par `ubuntu` dans les URL ci-dessus.

Vérification :

```bash
sudo docker run --rm hello-world
```

Sécurisation minimale de l'accès SSH, si ce n'est pas déjà fait par votre hébergeur :

```bash
# Authentification par clé uniquement, pas de connexion root directe
sudo sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sudo systemctl restart ssh
```

N'exécutez ces trois lignes qu'après avoir vérifié que votre clé SSH fonctionne, sinon vous perdez l'accès à la machine.

---

## Étape 3 — Installer les fichiers

```bash
sudo mkdir -p /opt/novaluth
sudo chown "$USER":"$USER" /opt/novaluth
cd /opt/novaluth
```

Envoyez l'archive du projet depuis votre poste, puis décompressez-la :

```bash
# Depuis votre ordinateur, dans le dossier contenant p2p-meet.zip
scp p2p-meet.zip utilisateur@IP_DU_SERVEUR:/opt/novaluth/
```

Puis, de retour sur le serveur :

```bash
cd /opt/novaluth
sudo apt install -y unzip
unzip -q p2p-meet.zip
mv p2p-meet app
rm p2p-meet.zip

# Les fichiers de deploiement remontent d'un niveau
cp app/deploy/ue/docker-compose.yml      .
cp app/deploy/ue/Caddyfile               .
cp app/deploy/ue/turnserver.conf         .
cp app/deploy/ue/sync-cert-turn.sh       .
cp app/deploy/ue/sauvegarde.sh           .
cp app/deploy/ue/app.env.example         app.env

chmod +x sync-cert-turn.sh sauvegarde.sh
mkdir -p data certs-turn caddy/data caddy/config

# L'application tourne sous l'uid 1000 dans son conteneur
sudo chown -R 1000:1000 data
```

Vous devez obtenir :

```
/opt/novaluth/
├── app/                  le projet, avec son Dockerfile
├── docker-compose.yml
├── Caddyfile
├── turnserver.conf
├── app.env
├── sync-cert-turn.sh
├── sauvegarde.sh
├── data/
├── certs-turn/
└── caddy/{data,config}/
```

---

## Étape 4 — Générer les secrets et remplir la configuration

### 4.1 Trois secrets, tous différents

```bash
echo "SESSION_SECRET  : $(openssl rand -hex 32)"
echo "LOG_SALT        : $(openssl rand -hex 32)"
echo "SECRET TURN     : $(openssl rand -hex 32)"
```

Notez les trois valeurs. La troisième devra figurer à **deux endroits** : dans `app.env` et dans `turnserver.conf`.

### 4.2 Groupe Diffie-Hellman pour Coturn

```bash
openssl dhparam -out /opt/novaluth/dhparam.pem 2048
```

Comptez une à deux minutes. C'est normal.

### 4.3 Variables de l'application

```bash
nano /opt/novaluth/app.env
```

Renseignez :

| Variable | Valeur |
|---|---|
| `SESSION_SECRET` | le premier secret généré |
| `LOG_SALT` | le deuxième secret généré |
| `TURN_STATIC_AUTH_SECRET` | le troisième secret généré |
| `ADMIN_LOGIN` | votre identifiant d'administrateur |
| `ADMIN_PASSWORD` | un mot de passe de 16 caractères minimum, provisoire |

Les autres valeurs conviennent en l'état. Protégez le fichier :

```bash
chmod 600 /opt/novaluth/app.env
```

### 4.4 Configuration de Coturn

```bash
nano /opt/novaluth/turnserver.conf
```

| Marqueur à remplacer | Valeur |
|---|---|
| `REMPLACER_PAR_IP_PUBLIQUE` | l'IPv4 publique du serveur : `curl -4 ifconfig.me` |
| `REMPLACER_PAR_LE_SECRET` | le troisième secret, identique à `app.env` |
| `REMPLACER_PAR_IPV6` | l'IPv6 du serveur, ou laissez la ligne commentée |

```bash
chmod 600 /opt/novaluth/turnserver.conf
```

### 4.5 Adresse électronique des certificats

Si `contact@novaluth.com` ne convient pas, changez-la dans le `Caddyfile`. Let's Encrypt s'en sert uniquement pour prévenir d'un problème de renouvellement.

---

## Étape 5 — Pare-feu

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing

sudo ufw allow 22/tcp                       comment 'SSH'
sudo ufw allow 80/tcp                       comment 'HTTP, redirection et Lets Encrypt'
sudo ufw allow 443/tcp                      comment 'HTTPS application'
sudo ufw allow 3478/tcp                     comment 'TURN'
sudo ufw allow 3478/udp                     comment 'TURN'
sudo ufw allow 5349/tcp                     comment 'TURN sur TLS'
sudo ufw allow 5349/udp                     comment 'TURN sur DTLS'
sudo ufw allow 49160:49200/udp              comment 'Relais TURN'

sudo ufw enable
sudo ufw status numbered
```

Si votre hébergeur propose en plus un pare-feu réseau en amont, reproduisez-y exactement les mêmes règles. C'est le cas chez OVHcloud, Scaleway et Hetzner.

Attention : Docker manipule directement les règles de filtrage et court-circuite parfois ufw pour les ports publiés. Ici, seuls 80 et 443 sont publiés par Caddy, et ils doivent de toute façon être ouverts.

---

## Étape 6 — Construire et démarrer

```bash
cd /opt/novaluth
sudo docker compose up -d --build
```

La construction de l'image dure une à deux minutes. Suivez ensuite le démarrage :

```bash
sudo docker compose ps
sudo docker compose logs -f --tail 50
```

Ce que vous devez voir :

- `novaluth-app` affiche la bannière de démarrage, avec `Comptes enregistres : 1` et `Administrateur créé`
- `novaluth-caddy` obtient les certificats de `visio.novaluth.com` et de `turn.novaluth.com`
- `novaluth-coturn` signale une erreur de certificat au premier démarrage : c'est **normal**, le certificat n'a pas encore été recopié. L'étape suivante corrige cela.

Quittez l'affichage avec `Ctrl+C` : les conteneurs continuent de tourner.

---

## Étape 7 — Certificat de Coturn et renouvellement automatique

Caddy sait obtenir et renouveler les certificats, mais Coturn ne sait pas lire son format de stockage et ne recharge pas ses certificats tout seul. Un petit script fait le pont.

```bash
sudo /opt/novaluth/sync-cert-turn.sh
```

Résultat attendu : une ligne indiquant que le certificat a été mis à jour et Coturn redémarré. Si le script répond que le certificat est introuvable, Caddy ne l'a pas encore obtenu : vérifiez les enregistrements DNS et les journaux de Caddy, puis réessayez.

Vérifiez ensuite que Coturn démarre proprement :

```bash
sudo docker compose logs --tail 30 coturn
```

Automatisez le contrôle quotidien :

```bash
sudo crontab -e
```

Ajoutez cette ligne :

```
17 4 * * * /opt/novaluth/sync-cert-turn.sh >> /var/log/novaluth-cert.log 2>&1
```

Le script ne fait rien tant que le certificat n'a pas changé. Coturn ne redémarre donc qu'environ tous les deux mois, après renouvellement, et cela n'interrompt que les appels en cours de relais.

---

## Étape 8 — Vérifications

Depuis votre poste :

```bash
# L'application repond
curl -s https://visio.novaluth.com/healthz

# La racine redirige vers la page de connexion
curl -s -o /dev/null -w "%{http_code} %{redirect_url}\n" https://visio.novaluth.com/

# L'API des serveurs ICE est bien protegee
curl -s -o /dev/null -w "%{http_code}\n" https://visio.novaluth.com/api/ice

# Le certificat du TURN est valide et au bon nom
echo | openssl s_client -connect turn.novaluth.com:5349 2>/dev/null \
  | openssl x509 -noout -subject -dates
```

| Test | Résultat attendu |
|---|---|
| `/healthz` | `{"status":"ok"}` |
| `/` sans session | code 302 vers `/connexion` |
| `/api/ice` sans session | code 401 |
| `/app` sans session | redirection vers `/connexion` |
| certificat du TURN | `subject=CN=turn.novaluth.com`, dates valides |

Test complet du relais TURN, le plus utile :

1. Connectez-vous sur `https://visio.novaluth.com/connexion`
2. Ouvrez `https://visio.novaluth.com/api/ice` dans un onglet : vous obtenez un `username` et un `credential` temporaires
3. Reportez-les dans l'outil officiel [Trickle ICE](https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/) avec l'URL `turns:turn.novaluth.com:5349?transport=tcp`
4. Un candidat de type `relay` doit apparaître

Si aucun candidat `relay` n'apparaît, vérifiez dans l'ordre : le pare-feu de l'hébergeur, la valeur `external-ip` dans `turnserver.conf`, puis la concordance du secret entre `app.env` et `turnserver.conf`.

Dernier test, décisif : passez `FORCE_RELAY=true` dans `app.env`, relancez `sudo docker compose restart app`, et faites un appel à deux depuis deux réseaux différents. S'il fonctionne, le relais est opérationnel. Remettez ensuite `false`.

---

## Étape 9 — Première connexion et création des comptes

1. Ouvrez `https://visio.novaluth.com/connexion`
2. Connectez-vous avec `ADMIN_LOGIN` et `ADMIN_PASSWORD`
3. **Changez immédiatement le mot de passe** depuis le panneau prévu sur la page de connexion
4. Ouvrez la page **Admin** et créez un compte par personne. Le bouton de génération produit un mot de passe aléatoire, affiché une seule fois : transmettez-le par un canal distinct et sûr
5. Une fois la nouvelle authentification vérifiée, remplacez `ADMIN_PASSWORD` dans `app.env` par une valeur inutilisable, ou supprimez la ligne : elle ne sert plus, le compte existant n'étant jamais réécrit

Pour un appel : la première personne qui entre dans une salle en définit le mot de passe, les suivantes doivent le saisir. Quand la salle se vide, elle disparaît, mot de passe compris.

---

## Étape 10 — Exploitation

### Redémarrage automatique après un reboot

Rien à faire : `restart: unless-stopped` suffit, le service Docker démarrant automatiquement au boot. Vérifiez-le une fois :

```bash
sudo systemctl is-enabled docker
sudo reboot
# puis, apres reconnexion
sudo docker compose -f /opt/novaluth/docker-compose.yml ps
```

### Sauvegardes chiffrées

```bash
# Mot de passe de chiffrement, a conserver ailleurs qu'ici
openssl rand -base64 32 | sudo tee /opt/novaluth/.backup-pass > /dev/null
sudo chmod 600 /opt/novaluth/.backup-pass

# Premier essai
sudo /opt/novaluth/sauvegarde.sh

# Automatisation quotidienne
sudo crontab -e
```

Ajoutez :

```
33 3 * * * /opt/novaluth/sauvegarde.sh >> /var/log/novaluth-sauvegarde.log 2>&1
```

Les archives sont chiffrées en AES-256 et purgées au bout de 30 jours. La procédure de restauration figure en commentaire à la fin du script. Sans le mot de passe, les sauvegardes sont irrécupérables : gardez-en une copie hors du serveur.

### Mise à jour de l'application

```bash
cd /opt/novaluth
sudo cp -a data data.avant-maj      # filet de securite
# remplacez le contenu de app/ par la nouvelle version, puis
sudo docker compose up -d --build app
sudo docker compose logs --tail 30 app
```

### Mise à jour des images et du système

```bash
cd /opt/novaluth
sudo docker compose pull
sudo docker compose up -d
sudo docker image prune -f
sudo apt update && sudo apt upgrade -y
```

À faire une fois par mois. Les mises à jour de sécurité du système sont le point le plus important : sur un serveur que vous administrez, personne ne le fait à votre place.

Pour automatiser les correctifs de sécurité de Debian ou Ubuntu :

```bash
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

### Journaux

```bash
# Journaux applicatifs
sudo docker compose logs --tail 100 app

# Journal d'acces de l'application, pseudonymise
sudo tail -n 20 /opt/novaluth/data/acces.log.jsonl
```

Les journaux Docker sont limités à trois fichiers de 10 Mo par conteneur : ils ne peuvent pas remplir le disque. Le journal d'accès de l'application est purgé automatiquement au bout de 90 jours.

### Surveillance minimale

```bash
# Espace disque et memoire
df -h /
free -m

# Etat des conteneurs
sudo docker compose ps
```

Un serveur d'entrée de gamme suffit largement : le processus de signalisation consomme quelques dizaines de mégaoctets de mémoire.

---

## Dimensionnement de la bande passante

Le relais TURN n'intervient que pour les appels dont la liaison directe échoue, soit environ 10 à 20 % des cas selon les réseaux. Quand il intervient, il consomme dans les deux sens.

| Situation | Bande passante sur le serveur |
|---|---|
| Appel à deux en liaison directe | proche de zéro |
| Appel à deux entièrement relayé | environ 1 Mbit/s montant et 1 Mbit/s descendant |
| Appel à quatre entièrement relayé | environ 6 Mbit/s dans chaque sens |
| `FORCE_RELAY=true`, quatre personnes | idem, mais systématiquement |

C'est pourquoi une offre à trafic illimité est préférable. Avec un forfait limité, surveillez la consommation le premier mois.

---

## Annexe A — Si vous avez besoin du TURN sur le port 443

Sur cette machine, le port 443 en TCP est occupé par le proxy web. Or certains réseaux d'entreprise très restrictifs ne laissent sortir que le port 443 : sur ces réseaux, un appel qui a besoin du relais échouera.

Trois solutions, par ordre de simplicité :

1. **Ne rien faire.** Les ports 3478 et 5349 passent sur la grande majorité des réseaux, y compris la plupart des Wi-Fi publics. C'est le choix par défaut.
2. **Ajouter une seconde adresse IPv4** au serveur, attribuer le port 443 du proxy à la première et celui de Coturn à la seconde. Possible chez OVHcloud et Scaleway, moyennant un supplément.
3. **Séparer les deux rôles sur deux machines.** Le serveur TURN reprend alors le port 443, en décommentant `alt-tls-listening-port=443` dans `turnserver.conf` et en passant `TURN_TLS_443=true` dans `app.env`. La procédure d'origine, en deux machines, figure dans `deploy/README-DEPLOIEMENT.md`.

---

## Annexe B — Migration depuis un déploiement Replit

Si vous avez déjà lancé la version Replit et créé des comptes :

1. Récupérez `data/users.json` et `data/acces.log.jsonl` depuis le Repl
2. Déposez-les dans `/opt/novaluth/data/` sur le nouveau serveur
3. `sudo chown -R 1000:1000 /opt/novaluth/data`
4. Reportez la **même** valeur de `LOG_SALT` dans `app.env`, sinon les empreintes d'adresses IP déjà enregistrées deviennent incomparables avec les nouvelles
5. `SESSION_SECRET` peut changer : cela déconnecte simplement tout le monde une fois
6. Basculez l'enregistrement DNS `visio` du domaine personnalisé Replit vers l'adresse IP du serveur
7. Attendez la propagation, vérifiez, puis supprimez le déploiement Replit
8. Mettez à jour les pages légales et le registre des traitements : Replit disparaît de la liste des sous-traitants, et la section sur les transferts hors Union européenne devient sans objet

---

## Annexe C — Ce qui sort de la machine

Inventaire complet des connexions sortantes, pour vérifier qu'il n'y a aucune dépendance cachée :

| Destination | Motif | Fréquence |
|---|---|---|
| Let's Encrypt, `acme-v02.api.letsencrypt.org` | délivrance et renouvellement des certificats | tous les 60 jours environ |
| Miroirs Debian ou Ubuntu | mises à jour du système | à votre initiative |
| Docker Hub | téléchargement des images Caddy et Coturn | à l'installation et aux mises à jour |
| Registre npm | installation des dépendances, pendant la construction de l'image | à la construction |

En fonctionnement normal, l'application n'appelle aucun service externe : aucun serveur STUN public, aucune police de caractères distante, aucun outil de mesure d'audience, aucun script tiers. Le navigateur des utilisateurs ne charge que des fichiers servis par votre serveur.

---

## Sources techniques

- [Configuration de référence Coturn](https://github.com/coturn/coturn/blob/master/examples/etc/turnserver.conf)
- [Image Docker Coturn officielle](https://github.com/coturn/coturn/blob/master/docker/coturn/README.md)
- [Installation de Coturn documentée par MiroTalk](https://docs.mirotalk.com/coturn/installation/)
- [TURN sur le port 443, manuel Jitsi](https://jitsi.github.io/handbook/docs/devops-guide/turn/)
- [Outil de test Trickle ICE](https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/)
- [Sécurité de WebRTC](https://webrtc-security.github.io/)
- [Exemple de clauses de sous-traitance de la CNIL](https://www.cnil.fr/fr/sous-traitance-exemple-de-clauses)
