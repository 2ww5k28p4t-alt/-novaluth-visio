# Commandes exactes — installation sur OVHcloud VPS

Fiche de mise en route pour **NovaLuth Visio** sur un serveur OVHcloud, hébergement 100 % européen, application et relais TURN sur la même machine.

Chaque bloc est prêt à copier-coller, dans l'ordre. Comptez environ une heure la première fois, dont vingt minutes d'attente pour la commande du serveur et la propagation DNS.

Le guide complet, avec les explications, est dans `README-UE.md`. Cette fiche-ci ne contient que le chemin le plus court.

---

## Avant de commencer

Trois choses à préparer :

1. Un compte OVHcloud
2. Une clé SSH. Si vous n'en avez pas, voir l'annexe 1 en bas de page
3. Un client SSH. Depuis un iPhone : Termius ou Blink Shell. Depuis un ordinateur : le terminal suffit

Notez au fur et à mesure, dans un gestionnaire de mots de passe, tout ce qui apparaît en gras dans cette fiche. Rien de tout cela ne doit finir dans une conversation, un courriel ou un fichier versionné.

---

## Étape 1 — Commander le serveur

Sur [la page VPS d'OVHcloud](https://www.ovhcloud.com/fr/vps/), choisissez :

| Champ | Valeur |
|---|---|
| Gamme | **VPS-1** : 2 vCores, 4 Go de RAM, 40 Go NVMe, trafic illimité, IPv4 dédiée incluse, 3,81 € HT par mois ([OVHcloud](https://www.ovhcloud.com/fr/vps/)) |
| Centre de données | **Gravelines** ou **Strasbourg**, tous deux en France |
| Système | **Debian 12** |
| Options payantes | aucune : pas de sauvegarde automatique, pas de snapshot, pas d'IP additionnelle |
| Clé SSH | ajoutez la vôtre pendant la commande, c'est le moment le plus simple |

Le serveur est livré en quelques minutes. Le courriel de livraison contient **l'adresse IPv4**, **le nom d'utilisateur** et un lien vers un **mot de passe temporaire**.

Sur un VPS OVHcloud, le compte `root` est désactivé, la première connexion se fait avec un compte nommé d'après le système, soit `debian` ici, et le mot de passe temporaire doit être changé dès la première connexion ([documentation OVHcloud](https://docs.ovhcloud.com/en/guides/bare-metal-cloud/virtual-private-servers/starting-with-a-vps)).

Notez l'adresse : **IP_SERVEUR**.

### Pare-feu réseau d'OVHcloud

Dans l'espace client, laissez le **Firewall Network** désactivé. Il est sans état, il ne suit pas les connexions et il rejette par défaut les paquets UDP fragmentés ([documentation OVHcloud](https://docs.ovhcloud.com/en/guides/bare-metal-cloud/dedicated-servers/firewall-network)), ce qui casse facilement un relais TURN. La protection anti-DDoS, elle, est toujours active et ne se désactive pas. Le pare-feu du serveur, configuré à l'étape 5, suffit.

---

## Étape 2 — Enregistrements DNS

Espace client OVHcloud, section **Noms de domaine**, `novaluth.com`, onglet **Zone DNS**. Ajoutez deux entrées :

```
Type   Sous-domaine   Cible
A      visio          IP_SERVEUR
A      turn           IP_SERVEUR
```

Attendez cinq à trente minutes, puis vérifiez depuis votre poste :

```bash
dig +short visio.novaluth.com
dig +short turn.novaluth.com
```

Les deux doivent renvoyer `IP_SERVEUR`. **Ne passez pas à la suite avant** : sans cela, les certificats ne pourront pas être délivrés.

Depuis un iPhone sans `dig`, ouvrez `https://dns.google/query?name=visio.novaluth.com&type=A` dans le navigateur et vérifiez que la réponse contient votre adresse.

---

## Étape 3 — Première connexion et durcissement

```bash
ssh debian@IP_SERVEUR
```

Le mot de passe temporaire vous est demandé, puis vous devez immédiatement en définir un nouveau. La session se ferme, reconnectez-vous.

Installez votre clé SSH si ce n'était pas fait à la commande, **depuis votre poste** :

```bash
ssh-copy-id debian@IP_SERVEUR
```

Vérifiez que `ssh debian@IP_SERVEUR` fonctionne désormais sans mot de passe. **Seulement après cette vérification**, sur le serveur :

```bash
sudo sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
sudo sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sudo systemctl restart ssh
```

Ces trois lignes exécutées avant que la clé fonctionne vous coupent définitivement l'accès au serveur.

---

## Étape 4 — Système et Docker

Un seul bloc, à coller entièrement :

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y ca-certificates curl gnupg ufw unzip lsb-release

sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg \
  | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/debian $(lsb_release -cs) stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
sudo docker run --rm hello-world
```

La dernière ligne doit afficher « Hello from Docker ». Correctifs de sécurité automatiques :

```bash
sudo apt install -y unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

---

## Étape 5 — Pare-feu du serveur

```bash
sudo ufw default deny incoming
sudo ufw default allow outgoing

sudo ufw allow 22/tcp            comment 'SSH'
sudo ufw allow 80/tcp            comment 'HTTP et Lets Encrypt'
sudo ufw allow 443/tcp           comment 'HTTPS application'
sudo ufw allow 3478/tcp          comment 'TURN'
sudo ufw allow 3478/udp          comment 'TURN'
sudo ufw allow 5349/tcp          comment 'TURN sur TLS'
sudo ufw allow 5349/udp          comment 'TURN sur DTLS'
sudo ufw allow 49160:49200/udp   comment 'Relais TURN'

sudo ufw --force enable
sudo ufw status numbered
```

---

## Étape 6 — Déposer le projet

```bash
sudo mkdir -p /opt/novaluth
sudo chown "$USER":"$USER" /opt/novaluth
```

Puis, au choix.

**Option A, depuis un ordinateur.** Dans le dossier contenant `p2p-meet.zip` :

```bash
scp p2p-meet.zip debian@IP_SERVEUR:/opt/novaluth/
```

**Option B, depuis un iPhone.** Publiez le projet sur un dépôt Git **privé** depuis Replit, puis sur le serveur :

```bash
sudo apt install -y git
cd /opt/novaluth
git clone https://github.com/VOTRE_COMPTE/novaluth-visio.git app
```

Avec l'option B, sautez la décompression et reprenez au bloc `cp` ci-dessous. Avec l'option A :

```bash
cd /opt/novaluth
unzip -q p2p-meet.zip
mv p2p-meet app
rm p2p-meet.zip
```

Dans les deux cas, ensuite :

```bash
cd /opt/novaluth
cp app/deploy/ue/docker-compose.yml  .
cp app/deploy/ue/Caddyfile           .
cp app/deploy/ue/turnserver.conf     .
cp app/deploy/ue/sync-cert-turn.sh   .
cp app/deploy/ue/sauvegarde.sh       .
cp app/deploy/ue/app.env.example     app.env

chmod +x sync-cert-turn.sh sauvegarde.sh
mkdir -p data certs-turn caddy/data caddy/config
sudo chown -R 1000:1000 data
ls -la
```

---

## Étape 7 — Secrets et configuration

### 7.1 Générer les trois secrets

```bash
echo "SESSION_SECRET : $(openssl rand -hex 32)"
echo "LOG_SALT       : $(openssl rand -hex 32)"
echo "SECRET_TURN    : $(openssl rand -hex 32)"
```

Copiez les trois valeurs dans votre gestionnaire de mots de passe. **SECRET_TURN** sera à reporter à deux endroits.

### 7.2 Groupe Diffie-Hellman et adresse IP

```bash
openssl dhparam -out /opt/novaluth/dhparam.pem 2048
curl -4 -s ifconfig.me; echo
```

La première commande prend une à deux minutes, c'est normal. La seconde affiche l'IPv4 publique à reporter dans `turnserver.conf`.

### 7.3 Variables de l'application

```bash
nano /opt/novaluth/app.env
```

À renseigner :

| Variable | Valeur |
|---|---|
| `SESSION_SECRET` | le premier secret |
| `LOG_SALT` | le deuxième secret |
| `TURN_STATIC_AUTH_SECRET` | **SECRET_TURN** |
| `ADMIN_LOGIN` | votre identifiant d'administrateur |
| `ADMIN_PASSWORD` | un mot de passe provisoire de 16 caractères minimum |

Le reste convient tel quel, `TURN_TLS_443=false` compris : sur cette machine, le port 443 en TCP appartient au proxy web.

Enregistrez avec `Ctrl+O`, `Entrée`, `Ctrl+X`, puis :

```bash
chmod 600 /opt/novaluth/app.env
```

### 7.4 Configuration de Coturn

```bash
nano /opt/novaluth/turnserver.conf
```

| Marqueur | Valeur |
|---|---|
| `REMPLACER_PAR_IP_PUBLIQUE` | l'IPv4 affichée à l'étape 7.2 |
| `REMPLACER_PAR_LE_SECRET` | **SECRET_TURN**, exactement la même valeur que dans `app.env` |
| `REMPLACER_PAR_IPV6` | laissez la ligne commentée |

```bash
chmod 600 /opt/novaluth/turnserver.conf
```

Contrôle utile avant de démarrer, les deux lignes doivent afficher la même valeur :

```bash
grep static-auth-secret /opt/novaluth/turnserver.conf
grep TURN_STATIC_AUTH_SECRET /opt/novaluth/app.env
```

---

## Étape 8 — Démarrer

```bash
cd /opt/novaluth
sudo docker compose up -d --build
sudo docker compose ps
sudo docker compose logs --tail 60
```

Attendu :

- `novaluth-app` affiche sa bannière, avec `Comptes enregistres : 1`
- `novaluth-caddy` obtient les certificats des deux sous-domaines
- `novaluth-coturn` se plaint de son certificat, **c'est normal**, l'étape suivante le corrige

---

## Étape 9 — Certificat du TURN

```bash
sudo /opt/novaluth/sync-cert-turn.sh
sudo docker compose -f /opt/novaluth/docker-compose.yml logs --tail 30 coturn
```

Si le script ne trouve pas le certificat, Caddy ne l'a pas encore obtenu : vérifiez le DNS, attendez une minute, réessayez.

Automatisation quotidienne :

```bash
sudo crontab -e
```

Ajoutez ces deux lignes, la seconde servira à l'étape 11 :

```
17 4 * * * /opt/novaluth/sync-cert-turn.sh >> /var/log/novaluth-cert.log 2>&1
33 3 * * * /opt/novaluth/sauvegarde.sh >> /var/log/novaluth-sauvegarde.log 2>&1
```

---

## Étape 10 — Vérifications

Depuis votre poste :

```bash
curl -s https://visio.novaluth.com/healthz; echo
curl -s -o /dev/null -w "racine : %{http_code}\n" https://visio.novaluth.com/
curl -s -o /dev/null -w "api ice : %{http_code}\n" https://visio.novaluth.com/api/ice
echo | openssl s_client -connect turn.novaluth.com:5349 2>/dev/null \
  | openssl x509 -noout -subject -dates
```

| Test | Résultat attendu |
|---|---|
| `/healthz` | `{"status":"ok"}` |
| racine sans session | `302` |
| `/api/ice` sans session | `401` |
| certificat du TURN | `subject=CN=turn.novaluth.com` et des dates valides |

Test du relais, le plus important :

1. Connectez-vous sur `https://visio.novaluth.com/connexion`
2. Ouvrez `https://visio.novaluth.com/api/ice` dans un onglet, relevez `username` et `credential`
3. Reportez-les dans [Trickle ICE](https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/) avec l'URL `turns:turn.novaluth.com:5349?transport=tcp`
4. Un candidat de type `relay` doit apparaître

Sans candidat `relay`, vérifiez dans l'ordre : `sudo ufw status`, la valeur `external-ip` de `turnserver.conf`, la concordance des secrets.

---

## Étape 11 — Comptes et sauvegardes

```bash
openssl rand -base64 32 | sudo tee /opt/novaluth/.backup-pass > /dev/null
sudo chmod 600 /opt/novaluth/.backup-pass
sudo cat /opt/novaluth/.backup-pass
sudo /opt/novaluth/sauvegarde.sh
ls -la /opt/novaluth/sauvegardes/
```

Recopiez ce mot de passe hors du serveur. Sans lui, les sauvegardes sont irrécupérables.

Puis, dans le navigateur :

1. `https://visio.novaluth.com/connexion`, connexion avec `ADMIN_LOGIN` et `ADMIN_PASSWORD`
2. Changez le mot de passe immédiatement
3. Page **Admin**, créez un compte par personne, transmettez chaque mot de passe par un canal séparé
4. Neutralisez `ADMIN_PASSWORD` dans `app.env`, il ne sert plus

---

## Étape 12 — Documents juridiques

Une fois le serveur en service, complétez les marqueurs `[...]` avec les informations réelles :

| Fichier | À renseigner |
|---|---|
| `public/legal/mentions-legales.html` | vos nom, prénom, domicile, téléphone ; hébergeur : **OVH SAS, 2 rue Kellermann, 59100 Roubaix, France**, serveurs à **Gravelines** ou **Strasbourg** |
| `public/legal/confidentialite.html` | responsable de traitement, et la même ligne d'hébergeur dans le tableau des sous-traitants |
| `REGISTRE-TRAITEMENTS.md` | ligne du sous-traitant, date de première version |
| `CONFORMITE-AVANT-LANCEMENT.md` | cocher au fur et à mesure |

Vérifiez ces coordonnées dans les conditions générales que vous acceptez à la commande : ce sont elles qui font foi. Récupérez également le contrat de sous-traitance d'OVHcloud et conservez-le avec le registre. La CNIL publie un [exemple de clauses de sous-traitance](https://www.cnil.fr/fr/sous-traitance-exemple-de-clauses) qui permet de vérifier qu'il est complet.

Après modification des pages :

```bash
cd /opt/novaluth
sudo docker compose up -d --build app
```

---

## Entretien courant

```bash
# Une fois par mois
cd /opt/novaluth
sudo docker compose pull
sudo docker compose up -d
sudo docker image prune -f
sudo apt update && sudo apt upgrade -y

# Etat du service
sudo docker compose ps
df -h /
sudo docker compose logs --tail 50 app
```

---

## Annexe 1 — Créer une clé SSH

Depuis un ordinateur :

```bash
ssh-keygen -t ed25519 -C "novaluth"
cat ~/.ssh/id_ed25519.pub
```

Copiez la ligne affichée dans le champ prévu à la commande du VPS, ou dans l'espace client OVHcloud.

Depuis un iPhone, Termius et Blink Shell savent tous deux générer une paire de clés et afficher la clé publique : générez-la dans l'application, puis collez la clé publique au même endroit.

---

## Annexe 2 — En cas de blocage

| Symptôme | Cause la plus fréquente | Vérification |
|---|---|---|
| Caddy n'obtient pas de certificat | DNS non propagé, ou port 80 fermé | `dig +short visio.novaluth.com`, `sudo ufw status` |
| Le site ne répond pas | conteneur arrêté | `sudo docker compose ps`, `sudo docker compose logs app` |
| Connexion refusée sur la page | mot de passe administrateur différent de `app.env` | la valeur n'est lue qu'à la toute première création du compte |
| Aucun candidat `relay` | `external-ip` erronée ou secrets différents | étape 7.4 |
| Appel qui ne s'établit pas | les deux participants derrière des réseaux très fermés | tester avec `FORCE_RELAY=true`, puis remettre `false` |
| Plus d'accès SSH | durcissement appliqué avant que la clé fonctionne | console **KVM** dans l'espace client OVHcloud |

La console KVM de l'espace client donne un accès écran-clavier direct au serveur, même sans SSH. C'est le filet de sécurité.
