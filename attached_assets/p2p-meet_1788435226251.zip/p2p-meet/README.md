# NovaLuth Visio — visioconférence 100 % pair-à-pair

Application prête à déployer sur Replit. Le serveur ne fait que de l'**authentification** et de la **signalisation** : il n'y a aucun serveur de médias, ni SFU, ni MCU. L'audio, la vidéo, le partage d'écran et les messages écrits circulent directement de navigateur à navigateur, chiffrés en DTLS-SRTP.

Version 2.0.0. Licence AGPL-3.0-or-later.

Deux déploiements sont fournis. Le premier est recommandé.

| | Où | Pour qui |
|---|---|---|
| **Déploiement européen tout-en-un** — [deploy/ue/README-UE.md](deploy/ue/README-UE.md) | un seul serveur loué dans l'Union européenne | souveraineté complète, aucun transfert hors UE, un seul sous-traitant |
| Déploiement sur Replit — [deploy/README-DEPLOIEMENT.md](deploy/README-DEPLOIEMENT.md) | Replit pour l'application, un VPS pour le TURN | mise en route la plus rapide, sans ligne de commande |

Ce projet est le compagnon du guide d'auto-hébergement WebRTC P2P sécurisé.

---

## Contenu du projet

```
p2p-meet/
├── server.js                      Serveur : authentification, signalisation, API TURN
├── lib/
│   ├── users.js                   Comptes : stockage JSON, bcrypt, verrouillage
│   ├── session.js                 Jetons de session signés en HMAC-SHA256
│   └── audit.js                   Journal d'accès pseudonymisé, purge automatique
├── public/
│   ├── connexion.html             Page de connexion et changement de mot de passe
│   ├── app.html                   Interface d'appel
│   ├── admin.html                 Page d'administration
│   ├── css/style.css              Style unique, mobile-first, aucune police externe
│   ├── js/auth.js                 Connexion, changement de mot de passe
│   ├── js/app.js                  Client WebRTC en maillage
│   ├── js/admin.js                Gestion des comptes et du journal
│   └── legal/
│       ├── mentions-legales.html
│       ├── confidentialite.html
│       └── cgu.html
├── Dockerfile                     Image de l'application, pour le déploiement européen
├── deploy/
│   ├── ue/                        Déploiement européen tout-en-un
│   │   ├── README-UE.md           Procédure complète, pas à pas
│   │   ├── OVH-COMMANDES.md       Fiche de commandes pour OVHcloud, la plus courte
│   │   ├── docker-compose.yml     Caddy + application + Coturn
│   │   ├── Caddyfile              Proxy web et certificats automatiques
│   │   ├── turnserver.conf        Coturn, variante machine unique
│   │   ├── app.env.example        Variables de l'application
│   │   ├── sync-cert-turn.sh      Recopie du certificat vers Coturn
│   │   └── sauvegarde.sh          Sauvegarde chiffrée des comptes
│   ├── turnserver.conf            Coturn, variante serveur TURN dédié
│   ├── docker-compose.yml         Coturn seul, en conteneur durci
│   └── README-DEPLOIEMENT.md      Procédure du déploiement sur Replit
├── REGISTRE-TRAITEMENTS.md        Registre RGPD article 30
├── CONFORMITE-AVANT-LANCEMENT.md  Liste de contrôle juridique
├── recherche-juridique.md         Dossier de recherche sourcé
├── .env.example                   Modèle de variables, à recopier dans les Secrets
├── .replit                        Configuration Replit
└── replit.nix                     Environnement Node.js 20
```

---

## Fonctionnement

### Accès

Il n'y a pas d'inscription libre. L'administrateur crée les comptes depuis la page `/admin`. Le premier compte administrateur est créé automatiquement au premier démarrage à partir des variables `ADMIN_LOGIN` et `ADMIN_PASSWORD`.

Chaque personne se connecte sur `/connexion`, puis accède à `/app`. Toute tentative d'accès direct à `/app` ou `/admin` sans session valide renvoie vers la page de connexion. La connexion Socket.IO elle-même vérifie le cookie de session : un appel ne peut pas être rejoint sans compte.

### Salles

La première personne qui ouvre une salle en définit le mot de passe. Les suivantes doivent le saisir. Le mot de passe n'existe qu'en mémoire vive : lorsque la dernière personne quitte la salle, la salle et son mot de passe disparaissent.

Une salle peut aussi être ouverte sans mot de passe : elle est alors accessible à tout titulaire d'un compte qui connaît son nom.

### Sécurité des comptes

- empreintes bcrypt, coût 12, mot de passe de 12 caractères minimum ;
- verrouillage du compte 15 minutes après 5 échecs consécutifs ;
- limitation à 15 tentatives par adresse et par quart d'heure ;
- comparaison à temps constant, y compris pour un identifiant inexistant ;
- cookie `nv_session` signé, HttpOnly, SameSite=Lax, Secure en production, durée 12 heures ;
- aucune table de sessions côté serveur : le jeton est autoportant et signé.

### Journal d'accès

Le fichier `data/acces.log.jsonl` enregistre les connexions, les échecs, les créations de comptes et les entrées et sorties de salle. Les adresses IP ne sont jamais stockées en clair : elles sont remplacées par une empreinte HMAC tronquée, calculée avec le sel `LOG_SALT`. Le journal est purgé automatiquement au-delà de `LOG_RETENTION_DAYS`, fixé à 90 jours par défaut.

La page d'administration permet d'exporter ou d'effacer toutes les données d'une personne, ce qui répond directement aux demandes fondées sur les articles 15 et 17 du RGPD.

### Nombre de participants

L'architecture est un maillage : chaque navigateur envoie son flux à tous les autres. Confortable de 2 à 4 personnes, dégradé de 5 à 8, au-delà il faut un serveur de médias, ce qui sortirait du modèle pair-à-pair. Compter environ 1 Mbit/s en émission par participant distant. La limite est réglée par `MAX_PEERS_PER_ROOM`, à 8 par défaut.

---

## Installation, version européenne

Le chemin le plus court, pour un serveur OVHcloud, est la fiche [deploy/ue/OVH-COMMANDES.md](deploy/ue/OVH-COMMANDES.md). Les explications complètes sont dans [deploy/ue/README-UE.md](deploy/ue/README-UE.md). En résumé :

1. Louer un serveur d'entrée de gamme dans l'Union européenne, 1 vCPU et 2 Go de RAM suffisent
2. Faire pointer `visio.novaluth.com` et `turn.novaluth.com` vers son adresse IP
3. Installer Docker, déposer le projet dans `/opt/novaluth/app`
4. Générer trois secrets, remplir `app.env` et `turnserver.conf`
5. Ouvrir les ports 80, 443, 3478, 5349 et la plage 49160-49200 en UDP
6. `sudo docker compose up -d --build`
7. Lancer une fois `sync-cert-turn.sh`, puis l'ajouter à la crontab quotidienne

Caddy obtient et renouvelle seul les certificats des deux sous-domaines. L'application n'est jamais exposée directement : elle n'est joignable que par le proxy, sur le réseau interne de Docker.

Dans cette configuration, le port 443 en TCP est occupé par le proxy web, donc Coturn n'y écoute pas. Les ports 3478 et 5349 suffisent sur la grande majorité des réseaux ; l'annexe A du guide de déploiement décrit les solutions si vous avez besoin du TURN sur 443.

---

## Installation sur Replit

### 1. Importer le projet

Décompressez l'archive, puis importez le dossier dans un nouveau Repl Node.js, ou glissez les fichiers dans un Repl vide.

### 2. Renseigner les Secrets

N'utilisez pas de fichier `.env` sur Replit : passez par l'onglet **Secrets**. Générez chaque secret séparément avec `openssl rand -hex 32`.

| Clé | Valeur |
|---|---|
| `NODE_ENV` | `production` |
| `SESSION_SECRET` | 64 caractères hexadécimaux aléatoires |
| `LOG_SALT` | 64 caractères hexadécimaux aléatoires, différents |
| `ADMIN_LOGIN` | votre identifiant d'administrateur |
| `ADMIN_PASSWORD` | mot de passe provisoire de 12 caractères minimum |
| `ADMIN_NAME` | nom affiché |
| `PUBLIC_URL` | `https://visio.novaluth.com` |
| `APP_NAME` | `NovaLuth Visio` |
| `TURN_HOST` | `turn.novaluth.com` |
| `TURN_STATIC_AUTH_SECRET` | le même secret que dans `turnserver.conf` |
| `STUN_URL` | `stun:turn.novaluth.com:3478` |

Variables optionnelles : `SESSION_TTL_HOURS` (12), `SELF_REGISTRATION` (`false`), `LOG_RETENTION_DAYS` (90), `TURN_TTL` (43200), `MAX_PEERS_PER_ROOM` (8), `FORCE_RELAY` (`false`).

`NODE_ENV=production` est indispensable : sans lui, le cookie de session n'est pas marqué Secure.

### 3. Choisir le bon type de déploiement

Utilisez un déploiement à **machine réservée**, pas un déploiement à mise à l'échelle automatique. Les connexions WebSocket doivent rester ouvertes pendant toute la durée d'un appel.

### 4. Brancher le domaine

Ajoutez `visio.novaluth.com` comme domaine personnalisé du déploiement, puis créez l'enregistrement DNS indiqué par Replit.

### 5. Première connexion

Ouvrez `https://visio.novaluth.com/connexion`, connectez-vous avec le compte administrateur, puis **changez immédiatement le mot de passe** depuis le panneau prévu sur la page de connexion. Créez ensuite les comptes des autres personnes depuis `/admin` : le mot de passe généré s'affiche une seule fois, transmettez-le par un canal distinct.

---

## Serveur TURN

Coturn ne peut pas tourner sur Replit : il lui faut de l'UDP brut et une adresse IP publique fixe. Dans le déploiement européen, il tourne sur la même machine que l'application. Dans le déploiement sur Replit, il faut un serveur séparé.

La procédure de la variante à deux machines, en dix étapes copiables, figure dans [deploy/README-DEPLOIEMENT.md](deploy/README-DEPLOIEMENT.md) : comparaison d'hébergeurs européens, enregistrements DNS, installation de Docker, certificat TLS, configuration, pare-feu, démarrage, renouvellement automatique du certificat et tests de validation.

Points essentiels :

- `turn.novaluth.com` doit pointer vers l'adresse IP publique du serveur ;
- le même `TURN_STATIC_AUTH_SECRET` doit figurer dans `turnserver.conf` et dans les Secrets de Replit ;
- les ports à ouvrir sont 3478 et 5349 en TCP et UDP, 443 en TCP si vous activez l'écoute sur ce port, et la plage 49160-49200 en UDP ;
- le navigateur ne reçoit jamais le secret : le serveur lui délivre des identifiants temporaires signés, valables 12 heures, via `/api/ice`.

---

## Développement local

```bash
npm install
cp .env.example .env
node server.js
```

Puis ouvrez `http://localhost:3000/connexion`. En local, le cookie n'est pas marqué Secure, ce qui permet de tester sans HTTPS.

Le dossier `data/` est créé au premier démarrage, avec des permissions restreintes. Il contient les comptes et le journal : traitez-le comme un fichier de données personnelles, sauvegardez-le de façon chiffrée et ne le versionnez jamais. Il est déjà exclu par `.gitignore`.

---

## Conformité

Trois pages publiques sont fournies dans `public/legal/` et liées depuis chaque page de l'application. Elles contiennent des champs entre crochets à compléter avant la mise en ligne : identité de l'éditeur, coordonnées et hébergeurs.

Les pages livrées décrivent le **déploiement européen** : un seul sous-traitant, aucun transfert hors de l'Union européenne. Si vous choisissez le déploiement sur Replit, il faut y réintroduire Replit dans la liste des sous-traitants et la section sur les transferts vers les États-Unis.

Lisez [CONFORMITE-AVANT-LANCEMENT.md](CONFORMITE-AVANT-LANCEMENT.md) avant de publier. Ce document liste ce qui est déjà en place, ce qui reste à compléter, les décisions à prendre et les douze points à faire trancher par un avocat.

Le [registre des activités de traitement](REGISTRE-TRAITEMENTS.md) est obligatoire et doit être tenu à jour. Il documente les quatre traitements du service, la liste des sous-traitants et l'appréciation portée sur la nécessité d'une analyse d'impact.

Ces documents sont une synthèse de sources officielles, pas un conseil juridique.

---

## Ce que le serveur ne fait pas

- il ne reçoit aucun flux audio ou vidéo ;
- il n'enregistre ni ne transcrit aucun appel ;
- il ne conserve aucun message écrit ;
- il ne charge aucun script, aucune police et aucune image depuis un domaine tiers ;
- il ne dépose aucun cookie publicitaire ou de mesure d'audience ;
- il n'appelle aucun service externe : ni STUN public, ni analytique, ni suivi.
