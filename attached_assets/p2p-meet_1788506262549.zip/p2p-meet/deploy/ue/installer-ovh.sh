#!/usr/bin/env bash
#
# NovaLuth Visio — installation automatisee sur un VPS OVHcloud
# Deploiement 100 % europeen : application, signalisation et relais TURN
# sur une seule machine, aucun service tiers, aucun transfert hors UE.
#
# Usage :
#   sudo bash installer-ovh.sh
#
# Le script est idempotent : vous pouvez le relancer sans risque.
# Il ne detruit jamais app.env, turnserver.conf ni le dossier data.
#
set -euo pipefail

BASE=/opt/novaluth
DOMAINE_APP=visio.novaluth.com
DOMAINE_TURN=turn.novaluth.com
COURRIEL=contact@novaluth.com

# ---------------------------------------------------------------- affichage

titre()   { printf '\n\033[1m== %s\033[0m\n' "$*"; }
info()    { printf '   %s\n' "$*"; }
ok()      { printf '   \033[32mok\033[0m  %s\n' "$*"; }
avert()   { printf '   \033[33m!\033[0m   %s\n' "$*"; }
echec()   { printf '\n\033[31mArret : %s\033[0m\n\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || echec "lancez le script avec sudo : sudo bash installer-ovh.sh"

# ------------------------------------------------------- 1. verifications

titre "1. Verifications prealables"

command -v apt-get >/dev/null || echec "systeme non compatible, Debian ou Ubuntu attendu"
info "systeme : $(. /etc/os-release && echo "$PRETTY_NAME")"

IP_PUBLIQUE="$(curl -4 -s --max-time 10 ifconfig.me || true)"
[ -n "$IP_PUBLIQUE" ] || echec "impossible de determiner l'adresse IPv4 publique"
ok "adresse IPv4 publique : $IP_PUBLIQUE"

apt-get install -y -qq dnsutils >/dev/null 2>&1 || true

verifier_dns() {
  local nom="$1" resolu
  resolu="$(dig +short "$nom" A | tail -n1)"
  if [ -z "$resolu" ]; then
    echec "$nom ne resout vers aucune adresse. Creez l'enregistrement A dans la zone DNS de novaluth.com, attendez la propagation, puis relancez."
  elif [ "$resolu" != "$IP_PUBLIQUE" ]; then
    echec "$nom pointe vers $resolu au lieu de $IP_PUBLIQUE. Corrigez l'enregistrement A, attendez la propagation, puis relancez."
  fi
  ok "$nom -> $resolu"
}

verifier_dns "$DOMAINE_APP"
verifier_dns "$DOMAINE_TURN"

[ -d "$BASE/app" ] || echec "le projet est introuvable dans $BASE/app. Deposez-le d'abord, voir l'etape 6 de OVH-COMMANDES.md"
[ -f "$BASE/app/Dockerfile" ] || echec "$BASE/app ne contient pas le projet attendu, Dockerfile absent"
ok "projet present dans $BASE/app"

# ------------------------------------------------------------ 2. systeme

titre "2. Systeme et Docker"

export DEBIAN_FRONTEND=noninteractive

if command -v docker >/dev/null && docker compose version >/dev/null 2>&1; then
  ok "Docker et le plugin Compose sont deja installes"
else
  info "mise a jour du systeme, comptez quelques minutes"
  apt-get update -qq
  apt-get upgrade -y -qq
  apt-get install -y -qq ca-certificates curl gnupg ufw unzip lsb-release

  install -m 0755 -d /etc/apt/keyrings
  DISTRO="$(. /etc/os-release && echo "$ID")"
  [ "$DISTRO" = "ubuntu" ] || DISTRO=debian
  curl -fsSL "https://download.docker.com/linux/$DISTRO/gpg" \
    | gpg --dearmor -o /etc/apt/keyrings/docker.gpg --yes
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/$DISTRO $(lsb_release -cs) stable" \
    > /etc/apt/sources.list.d/docker.list

  apt-get update -qq
  apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin
  ok "Docker installe"
fi

systemctl enable --now docker >/dev/null 2>&1 || true
docker run --rm hello-world >/dev/null 2>&1 && ok "Docker fonctionne" || echec "Docker ne demarre pas"

if ! dpkg -l unattended-upgrades >/dev/null 2>&1; then
  apt-get install -y -qq unattended-upgrades
  echo 'APT::Periodic::Unattended-Upgrade "1";' > /etc/apt/apt.conf.d/20auto-upgrades-novaluth
  echo 'APT::Periodic::Update-Package-Lists "1";' >> /etc/apt/apt.conf.d/20auto-upgrades-novaluth
  ok "correctifs de securite automatiques actives"
fi

# ------------------------------------------------------------ 3. fichiers

titre "3. Mise en place des fichiers"

cd "$BASE"
for f in docker-compose.yml Caddyfile sauvegarde.sh sync-cert-turn.sh; do
  cp -f "app/deploy/ue/$f" "$BASE/$f"
done
[ -f "$BASE/turnserver.conf" ] || cp "app/deploy/ue/turnserver.conf" "$BASE/turnserver.conf"
[ -f "$BASE/app.env" ]         || cp "app/deploy/ue/app.env.example"  "$BASE/app.env"

chmod +x "$BASE/sauvegarde.sh" "$BASE/sync-cert-turn.sh"
mkdir -p "$BASE/data" "$BASE/certs-turn" "$BASE/caddy/data" "$BASE/caddy/config" "$BASE/sauvegardes"
chown -R 1000:1000 "$BASE/data"
ok "fichiers de deploiement en place"

if [ ! -f "$BASE/dhparam.pem" ]; then
  info "generation du groupe Diffie-Hellman, une a deux minutes"
  openssl dhparam -out "$BASE/dhparam.pem" 2048 2>/dev/null
  ok "dhparam.pem genere"
else
  ok "dhparam.pem deja present"
fi

# ------------------------------------------------------------ 4. secrets

titre "4. Secrets et configuration"

remplacer() {  # fichier cle valeur separateur
  local fic="$1" cle="$2" val="$3" sep="$4"
  if grep -q "^${cle}${sep}" "$fic"; then
    python3 - "$fic" "$cle" "$val" "$sep" <<'PY'
import sys
fic, cle, val, sep = sys.argv[1:5]
lignes = open(fic).read().splitlines(True)
sortie = []
for l in lignes:
    if l.startswith(cle + sep):
        sortie.append(cle + sep + val + "\n")
    else:
        sortie.append(l)
open(fic, "w").writelines(sortie)
PY
  else
    printf '%s%s%s\n' "$cle" "$sep" "$val" >> "$fic"
  fi
}

valeur_de() { grep -m1 "^$2=" "$1" 2>/dev/null | cut -d= -f2- || true; }

# vrai si la valeur est absente, encore un marqueur, ou trop courte
a_regenerer() {
  local v="$1"
  [ -z "$v" ] && return 0
  case "$v" in REMPLACER*) return 0 ;; esac
  [ ${#v} -lt 32 ] && return 0
  return 1
}

SECRET_SESSION="$(valeur_de "$BASE/app.env" SESSION_SECRET)"
if a_regenerer "$SECRET_SESSION"; then
  SECRET_SESSION="$(openssl rand -hex 32)"
  remplacer "$BASE/app.env" SESSION_SECRET "$SECRET_SESSION" "="
  ok "SESSION_SECRET genere"
else
  ok "SESSION_SECRET conserve"
fi

SEL_JOURNAL="$(valeur_de "$BASE/app.env" LOG_SALT)"
if a_regenerer "$SEL_JOURNAL"; then
  SEL_JOURNAL="$(openssl rand -hex 32)"
  remplacer "$BASE/app.env" LOG_SALT "$SEL_JOURNAL" "="
  ok "LOG_SALT genere"
else
  ok "LOG_SALT conserve, les empreintes deja enregistrees restent comparables"
fi

SECRET_TURN="$(valeur_de "$BASE/app.env" TURN_STATIC_AUTH_SECRET)"
if a_regenerer "$SECRET_TURN"; then
  SECRET_TURN="$(openssl rand -hex 32)"
  remplacer "$BASE/app.env" TURN_STATIC_AUTH_SECRET "$SECRET_TURN" "="
  ok "secret TURN genere"
else
  ok "secret TURN conserve"
fi

# Identifiants d'administration, uniquement au premier passage
if [ ! -f "$BASE/data/users.json" ]; then
  ADMIN_LOGIN="$(valeur_de "$BASE/app.env" ADMIN_LOGIN)"
  if [ -z "$ADMIN_LOGIN" ] || [ "$ADMIN_LOGIN" = "admin" ]; then
    printf '   identifiant administrateur [admin] : '
    read -r saisie </dev/tty || saisie=""
    ADMIN_LOGIN="${saisie:-admin}"
    remplacer "$BASE/app.env" ADMIN_LOGIN "$ADMIN_LOGIN" "="
  fi
  MOT_ADMIN="$(openssl rand -base64 18 | tr -d '/+=' | cut -c1-20)"
  remplacer "$BASE/app.env" ADMIN_PASSWORD "$MOT_ADMIN" "="
  ok "compte administrateur : $ADMIN_LOGIN"
else
  MOT_ADMIN=""
  ok "comptes existants conserves, aucun mot de passe reecrit"
fi

remplacer "$BASE/app.env" TURN_HOST   "$DOMAINE_TURN"           "="
remplacer "$BASE/app.env" STUN_URL    "stun:$DOMAINE_TURN:3478" "="
remplacer "$BASE/app.env" PUBLIC_URL  "https://$DOMAINE_APP"    "="
remplacer "$BASE/app.env" NODE_ENV    "production"              "="
remplacer "$BASE/app.env" TURN_TLS_443 "false"                  "="
chmod 600 "$BASE/app.env"
ok "app.env complete et protege"

# Coturn
sed -i "s|REMPLACER_PAR_IP_PUBLIQUE|$IP_PUBLIQUE|g" "$BASE/turnserver.conf"
sed -i "s|REMPLACER_PAR_LE_SECRET|$SECRET_TURN|g"   "$BASE/turnserver.conf"
sed -i "s|^external-ip=.*|external-ip=$IP_PUBLIQUE|" "$BASE/turnserver.conf"
sed -i "s|^static-auth-secret=.*|static-auth-secret=$SECRET_TURN|" "$BASE/turnserver.conf"
chmod 600 "$BASE/turnserver.conf"

grep -q "^external-ip=$IP_PUBLIQUE$" "$BASE/turnserver.conf" \
  || echec "external-ip n'a pas ete renseignee dans turnserver.conf"
grep -q "^static-auth-secret=$SECRET_TURN$" "$BASE/turnserver.conf" \
  || echec "le secret TURN n'a pas ete renseigne dans turnserver.conf"
ok "turnserver.conf complete, secret identique a celui de l'application"

# ----------------------------------------------------------- 5. pare-feu

titre "5. Pare-feu"

ufw --force reset >/dev/null 2>&1 || true
ufw default deny incoming  >/dev/null
ufw default allow outgoing >/dev/null
ufw allow 22/tcp          comment 'SSH'                    >/dev/null
ufw allow 80/tcp          comment 'HTTP et Lets Encrypt'   >/dev/null
ufw allow 443/tcp         comment 'HTTPS application'      >/dev/null
ufw allow 3478/tcp        comment 'TURN'                   >/dev/null
ufw allow 3478/udp        comment 'TURN'                   >/dev/null
ufw allow 5349/tcp        comment 'TURN sur TLS'           >/dev/null
ufw allow 5349/udp        comment 'TURN sur DTLS'          >/dev/null
ufw allow 49160:49200/udp comment 'Relais TURN'            >/dev/null
ufw --force enable >/dev/null
ok "pare-feu actif, 22 80 443 3478 5349 et 49160-49200 ouverts"
avert "laissez le Firewall Network d'OVHcloud desactive dans l'espace client, il est sans etat et bloque l'UDP fragmente"

# ---------------------------------------------------------- 6. demarrage

titre "6. Construction et demarrage"

cd "$BASE"
docker compose up -d --build
ok "conteneurs lances"

info "attente de la delivrance des certificats, jusqu'a deux minutes"
for _ in $(seq 1 24); do
  sleep 5
  if docker compose exec -T caddy ls "/data/caddy/certificates" >/dev/null 2>&1 \
     && docker compose exec -T caddy find /data/caddy/certificates -name "*$DOMAINE_TURN*" 2>/dev/null | grep -q .; then
    break
  fi
done

if curl -s --max-time 10 "https://$DOMAINE_APP/healthz" | grep -q '"ok"'; then
  ok "l'application repond en HTTPS sur https://$DOMAINE_APP"
else
  avert "l'application ne repond pas encore, consultez : docker compose logs --tail 50"
fi

# --------------------------------------------------- 7. certificat Coturn

titre "7. Certificat du relais TURN"

if "$BASE/sync-cert-turn.sh"; then
  ok "certificat recopie vers Coturn"
else
  avert "certificat pas encore disponible, relancez plus tard : sudo $BASE/sync-cert-turn.sh"
fi

# --------------------------------------------------- 8. taches planifiees

titre "8. Sauvegardes et taches planifiees"

if [ ! -f "$BASE/.backup-pass" ]; then
  openssl rand -base64 32 > "$BASE/.backup-pass"
  chmod 600 "$BASE/.backup-pass"
  ok "mot de passe de sauvegarde genere"
fi

TMP_CRON="$(mktemp)"
crontab -l 2>/dev/null | grep -v novaluth > "$TMP_CRON" || true
{
  echo "17 4 * * * $BASE/sync-cert-turn.sh >> /var/log/novaluth-cert.log 2>&1"
  echo "33 3 * * * $BASE/sauvegarde.sh >> /var/log/novaluth-sauvegarde.log 2>&1"
} >> "$TMP_CRON"
crontab "$TMP_CRON"
rm -f "$TMP_CRON"
ok "taches quotidiennes installees, certificat a 4 h 17 et sauvegarde a 3 h 33"

"$BASE/sauvegarde.sh" >/dev/null 2>&1 && ok "premiere sauvegarde effectuee" || avert "sauvegarde a relancer plus tard"

# ------------------------------------------------------ 9. recapitulatif

titre "9. Verifications finales"

etat() {
  local libelle="$1" attendu="$2" obtenu="$3"
  if [ "$obtenu" = "$attendu" ]; then
    printf '   \033[32mok\033[0m  %-34s %s\n' "$libelle" "$obtenu"
  else
    printf '   \033[31mko\033[0m  %-34s %s, attendu %s\n' "$libelle" "$obtenu" "$attendu"
  fi
}

CODE_SANTE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "https://$DOMAINE_APP/healthz" || echo 000)
CODE_RACINE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "https://$DOMAINE_APP/" || echo 000)
CODE_ICE=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "https://$DOMAINE_APP/api/ice" || echo 000)

etat "page de sante"              "200" "$CODE_SANTE"
etat "racine sans session"        "302" "$CODE_RACINE"
etat "api ice sans session"       "401" "$CODE_ICE"

SUJET_CERT=$(echo | openssl s_client -connect "$DOMAINE_TURN:5349" 2>/dev/null \
  | openssl x509 -noout -subject 2>/dev/null || true)
if echo "$SUJET_CERT" | grep -q "$DOMAINE_TURN"; then
  ok "certificat du TURN valide : $SUJET_CERT"
else
  avert "certificat du TURN non verifiable pour l'instant, reessayez dans quelques minutes"
fi

docker compose ps

cat <<FIN

============================================================
  Installation terminee
============================================================

  Application     https://$DOMAINE_APP
  Relais TURN     $DOMAINE_TURN, ports 3478 et 5349
  Fichiers        $BASE

FIN

if [ -n "$MOT_ADMIN" ]; then
cat <<FIN
  Compte administrateur
    identifiant   $ADMIN_LOGIN
    mot de passe  $MOT_ADMIN

  Ce mot de passe n'est affiche qu'une seule fois. Notez-le,
  connectez-vous, puis changez-le immediatement.

FIN
fi

cat <<FIN
  Mot de passe des sauvegardes, a conserver hors du serveur :
$(cat "$BASE/.backup-pass" | sed 's/^/    /')

  Sans lui, les sauvegardes sont irrecuperables.

  A faire ensuite
    1. Se connecter et changer le mot de passe administrateur
    2. Creer un compte par personne depuis la page Admin
    3. Tester le relais avec l'outil Trickle ICE, etape 10 de OVH-COMMANDES.md
    4. Completer les marqueurs des pages legales, etape 12

  Commandes utiles
    sudo docker compose -f $BASE/docker-compose.yml ps
    sudo docker compose -f $BASE/docker-compose.yml logs --tail 50 app
    sudo $BASE/sync-cert-turn.sh

============================================================

FIN
