# Déploiement de NovaLuth Visio

Guide pas à pas, à suivre dans l'ordre. Chaque commande est prête à copier-coller.

Deux machines interviennent :

| Machine | Rôle | Sous-domaine |
|---|---|---|
| Replit | Application web + signalisation | `visio.novaluth.com` |
| VPS (à louer) | Serveur TURN/STUN Coturn | `turn.novaluth.com` |

Coturn ne peut pas tourner sur Replit : il a besoin de ports UDP bruts et d'une IP publique fixe, ce que Replit ne fournit pas. Un petit VPS suffit.

---

## Étape 0 — Choisir l'hébergeur du VPS

Le TURN ne relaie que les appels dont la liaison directe échoue (environ 10 à 20 % des cas). Un VPS d'entrée de gamme convient. Pour garder la maîtrise juridique, restez chez un hébergeur soumis au seul droit européen.

| Hébergeur | Offre d'entrée | Ordre de prix | Localisation | Remarque |
|---|---|---|---|---|
| Scaleway (France) | DEV1-S | ~4 à 6 €/mois | Paris, Amsterdam, Varsovie | Société française, facturation à l'heure |
| OVHcloud (France) | VPS Value | ~5 à 7 €/mois | Gravelines, Strasbourg, Roubaix | Vous y avez déjà des domaines |
| Infomaniak (Suisse) | Cloud Public | ~5 à 8 €/mois | Suisse, Genève | Hors UE mais pays reconnu adéquat par la Commission |
| Hetzner (Allemagne) | CX22 | ~4 à 5 €/mois | Nuremberg, Falkenstein, Helsinki | Excellent rapport prix/bande passante |

Vérifiez les prix au moment de la commande : ils changent régulièrement.

Configuration minimale suffisante : 1 vCPU, 2 Go de RAM, IPv4 publique dédiée, trafic sortant non facturé à l'excès. Chaque participant relayé consomme environ 1 Mbit/s dans chaque sens.

Point juridique important : l'hébergeur du VPS est un sous-traitant au sens de l'article 28 du RGPD. Signez son contrat de sous-traitance (généralement appelé DPA) et notez-le dans le registre des traitements. Le TURN ne peut de toute façon pas lire le contenu des appels, qui reste chiffré de bout en bout.

---

## Étape 1 — Enregistrements DNS

Chez votre registrar (là où `novaluth.com` est géré), ajoutez :

```
Type   Nom      Valeur                          TTL
A      turn     IP_PUBLIQUE_DU_VPS              3600
AAAA   turn     IPV6_DU_VPS (si disponible)     3600
CNAME  visio    <votre-projet>.replit.app        3600
```

Vérifiez la propagation avant de continuer :

```bash
dig +short turn.novaluth.com
dig +short visio.novaluth.com
```

Ne passez à l'étape suivante que lorsque `turn.novaluth.com` renvoie bien l'IP du VPS : Let's Encrypt en a besoin.

---

## Étape 2 — Préparer le VPS

Connectez-vous en SSH puis exécutez :

```bash
# Mise à jour du système
sudo apt update && sudo apt upgrade -y

# Docker et le plugin Compose
sudo apt install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/debian/gpg \
  | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
https://download.docker.com/linux/debian $(lsb_release -cs) stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null
sudo apt update
sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# Certbot pour les certificats TLS
sudo apt install -y certbot
```

Sur Ubuntu, remplacez `debian` par `ubuntu` dans les deux URL ci-dessus.

---

## Étape 3 — Certificat TLS pour turn.novaluth.com

```bash
sudo certbot certonly --standalone -d turn.novaluth.com \
  --agree-tos --no-eff-email -m contact@novaluth.com
```

Le mode `--standalone` occupe brièvement le port 80. Il doit donc être libre et ouvert pendant l'opération.

Vérification :

```bash
sudo ls -l /etc/letsencrypt/live/turn.novaluth.com/
```

Vous devez y voir `fullchain.pem` et `privkey.pem`.

---

## Étape 4 — Installer la configuration Coturn

```bash
sudo mkdir -p /opt/coturn && cd /opt/coturn

# Groupe Diffie-Hellman (compter 1 à 2 minutes)
sudo openssl dhparam -out /opt/coturn/dhparam.pem 2048

# Générer le secret partagé, à conserver précieusement
openssl rand -hex 32
```

Copiez la valeur affichée : c'est elle qui devra figurer à la fois dans `turnserver.conf` et dans les Secrets Replit.

Placez ensuite les deux fichiers `turnserver.conf` et `docker-compose.yml` de ce dossier `deploy/` dans `/opt/coturn/`, puis remplacez les trois marqueurs :

```bash
sudo nano /opt/coturn/turnserver.conf
```

| Marqueur | Valeur à mettre |
|---|---|
| `REMPLACER_PAR_IP_PUBLIQUE` | l'IPv4 publique du VPS (`curl -4 ifconfig.me`) |
| `REMPLACER_PAR_LE_SECRET` | le secret généré ci-dessus |
| `REMPLACER_PAR_IPV6` | l'IPv6 du VPS, ou laissez la ligne commentée |

Protégez le fichier, il contient un secret :

```bash
sudo chmod 600 /opt/coturn/turnserver.conf
```

---

## Étape 5 — Pare-feu

```bash
sudo apt install -y ufw

sudo ufw default deny incoming
sudo ufw default allow outgoing

sudo ufw allow 22/tcp comment 'SSH'
sudo ufw allow 80/tcp comment 'Certbot HTTP-01'
sudo ufw allow 3478/tcp comment 'TURN'
sudo ufw allow 3478/udp comment 'TURN'
sudo ufw allow 5349/tcp comment 'TURN TLS'
sudo ufw allow 443/tcp comment 'TURN TLS port web'
sudo ufw allow 49160:49200/udp comment 'Relais TURN'

sudo ufw enable
sudo ufw status numbered
```

Si votre hébergeur propose aussi un pare-feu réseau en amont (Scaleway, OVHcloud, Hetzner), reproduisez-y les mêmes règles.

---

## Étape 6 — Démarrer Coturn

```bash
cd /opt/coturn
sudo docker compose up -d
sudo docker compose logs -f --tail 50
```

Les journaux doivent afficher les adresses d'écoute sans erreur. Arrêtez l'affichage avec `Ctrl+C` : le conteneur continue de tourner.

En cas d'erreur du type `CONFIG ERROR`, une directive est mal orthographiée. Corrigez `turnserver.conf` puis relancez `sudo docker compose restart`.

---

## Étape 7 — Renouvellement automatique du certificat

Coturn charge les certificats au démarrage. Après chaque renouvellement, il faut le redémarrer :

```bash
sudo mkdir -p /etc/letsencrypt/renewal-hooks/deploy

sudo tee /etc/letsencrypt/renewal-hooks/deploy/coturn.sh > /dev/null <<'EOF'
#!/bin/sh
# Redémarre Coturn après un renouvellement de certificat
cd /opt/coturn && /usr/bin/docker compose restart coturn
EOF

sudo chmod +x /etc/letsencrypt/renewal-hooks/deploy/coturn.sh
```

Le renouvellement utilise le port 80 en mode standalone : il faut donc l'autoriser en permanence dans le pare-feu, ce qui a été fait à l'étape 5.

Test à blanc :

```bash
sudo certbot renew --dry-run
```

---

## Étape 8 — Vérifier que le TURN fonctionne

Sur le VPS :

```bash
sudo docker exec -it coturn turnutils_uclient -T -u test -w test turn.novaluth.com
```

L'échec d'authentification est normal et attendu : le serveur n'accepte que les identifiants temporaires signés. Ce qui compte est que la connexion aboutisse.

Depuis un navigateur, le test le plus fiable est l'outil officiel Trickle ICE :

1. Ouvrez l'application NovaLuth Visio et connectez-vous
2. Ouvrez `https://visio.novaluth.com/api/ice` dans un onglet : vous obtenez un `username` et un `credential` temporaires
3. Reportez-les dans [Trickle ICE](https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/) avec l'URL `turns:turn.novaluth.com:443?transport=tcp`
4. Vous devez voir apparaître au moins un candidat de type `relay`

Si aucun candidat `relay` n'apparaît, vérifiez dans l'ordre : le pare-feu de l'hébergeur, la valeur `external-ip`, la concordance du secret entre les deux machines.

---

## Étape 9 — Configurer l'application sur Replit

Importez le projet, puis, dans l'onglet **Secrets** de Replit (jamais dans un fichier `.env`, qui serait versionné) :

| Clé | Valeur | Obligatoire |
|---|---|---|
| `SESSION_SECRET` | `openssl rand -hex 32` | oui |
| `ADMIN_LOGIN` | votre identifiant, ex. `admin` | oui |
| `ADMIN_PASSWORD` | mot de passe fort, 16 caractères ou plus | oui |
| `ADMIN_NAME` | votre nom affiché | non |
| `TURN_HOST` | `turn.novaluth.com` | oui |
| `TURN_STATIC_AUTH_SECRET` | le même secret que dans `turnserver.conf` | oui |
| `STUN_URL` | `stun:turn.novaluth.com:3478` | oui |
| `PUBLIC_URL` | `https://visio.novaluth.com` | oui |
| `NODE_ENV` | `production` | oui |
| `TURN_TTL` | `43200` | non |
| `MAX_PEERS_PER_ROOM` | `8` | non |
| `SESSION_TTL_HOURS` | `12` | non |
| `LOG_RETENTION_DAYS` | `90` | non |
| `LOG_SALT` | `openssl rand -hex 16` | non |
| `FORCE_RELAY` | `false` | non |
| `SELF_REGISTRATION` | `false` | non |

Points d'attention sur Replit :

- `NODE_ENV=production` active l'attribut `Secure` du cookie de session. Sans HTTPS, la connexion ne fonctionnera pas ; avec le domaine personnalisé, HTTPS est automatique.
- Sans `SESSION_SECRET`, un secret aléatoire est généré à chaque démarrage et tout le monde est déconnecté à chaque redéploiement.
- Choisissez un **Reserved VM** plutôt qu'un déploiement Autoscale : les connexions WebSocket de la signalisation doivent rester ouvertes, et l'Autoscale les coupe.
- Le fichier `data/users.json` contient les comptes. Sur un Reserved VM il persiste. Sauvegardez-le, ou recréez simplement les comptes après une réinitialisation.

Rattachement du domaine : dans les paramètres du déploiement Replit, ajoutez le domaine personnalisé `visio.novaluth.com` et suivez l'enregistrement DNS que Replit vous indique (il remplace le `CNAME` provisoire de l'étape 1).

---

## Étape 10 — Première connexion et création des comptes

1. Ouvrez `https://visio.novaluth.com` : vous arrivez sur la page de connexion
2. Connectez-vous avec `ADMIN_LOGIN` / `ADMIN_PASSWORD`
3. Ouvrez la page **Admin** et créez un compte par personne
4. Le bouton « Générer un mot de passe » produit un mot de passe aléatoire à transmettre à la personne concernée par un canal sûr, à changer à la première connexion
5. Retirez le mot de passe administrateur initial des Secrets seulement après avoir vérifié que vous pouvez vous reconnecter

Pour un appel :

- La première personne qui entre dans une salle en définit le mot de passe
- Les suivantes doivent le saisir
- Quand la salle se vide, elle disparaît, mot de passe compris : rien n'est conservé

---

## Vérifications finales

```bash
# L'application répond
curl -s https://visio.novaluth.com/healthz

# La page d'accueil redirige bien vers la connexion
curl -s -o /dev/null -w "%{http_code} %{redirect_url}\n" https://visio.novaluth.com/

# L'API ICE est bien protégée (401 attendu)
curl -s -o /dev/null -w "%{http_code}\n" https://visio.novaluth.com/api/ice
```

| Test | Résultat attendu |
|---|---|
| `/healthz` | `{"status":"ok"}` |
| `/` sans session | redirection 302 vers `/connexion` |
| `/api/ice` sans session | code 401 |
| `/app` sans session | redirection vers `/connexion` |
| Appel à deux, réseaux différents | vidéo et audio dans les deux sens |
| Appel avec `FORCE_RELAY=true` | fonctionne aussi, ce qui valide le TURN |

---

## Sources techniques

- [Configuration de référence Coturn](https://github.com/coturn/coturn/blob/master/examples/etc/turnserver.conf)
- [Image Docker Coturn officielle](https://github.com/coturn/coturn/blob/master/docker/coturn/README.md)
- [Installation Coturn documentée par MiroTalk](https://docs.mirotalk.com/coturn/installation/)
- [TURN sur le port 443 — manuel Jitsi](https://jitsi.github.io/handbook/docs/devops-guide/turn/)
- [Outil de test Trickle ICE](https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/)
- [Sécurité de WebRTC](https://webrtc-security.github.io/)
