#!/bin/sh
# ==================================================================
#  Recopie du certificat TLS de turn.novaluth.com pour Coturn
#  A placer dans /opt/novaluth/sync-cert-turn.sh
# ==================================================================
#  Caddy obtient et renouvelle le certificat, mais Coturn ne sait pas
#  lire le format de stockage de Caddy et ne recharge pas ses
#  certificats tout seul. Ce script fait le pont :
#
#    1. il retrouve le certificat dans les donnees de Caddy
#    2. il le recopie dans certs-turn/ si la copie differe
#    3. il redemarre Coturn uniquement dans ce cas
#
#  A executer une fois par jour par cron. Le redemarrage de Coturn
#  n'a donc lieu qu'environ tous les deux mois, apres renouvellement,
#  et il coupe seulement les appels en cours de relais.
# ==================================================================

set -eu

BASE="/opt/novaluth"
DOMAINE="turn.novaluth.com"
DST="$BASE/certs-turn"

# Caddy range ses certificats sous un dossier dont le nom depend de
# l'autorite utilisee : on le retrouve donc par recherche.
SRC=$(find "$BASE/caddy/data/caddy/certificates" -type d -name "$DOMAINE" 2>/dev/null | head -n 1 || true)

if [ -z "$SRC" ]; then
  echo "$(date -Is) certificat de $DOMAINE introuvable : Caddy l'a-t-il deja obtenu ?" >&2
  exit 1
fi

CRT="$SRC/$DOMAINE.crt"
KEY="$SRC/$DOMAINE.key"

if [ ! -f "$CRT" ] || [ ! -f "$KEY" ]; then
  echo "$(date -Is) fichiers de certificat incomplets dans $SRC" >&2
  exit 1
fi

mkdir -p "$DST"

if cmp -s "$CRT" "$DST/fullchain.pem"; then
  # Rien de neuf : on ne redemarre pas Coturn.
  exit 0
fi

cp "$CRT" "$DST/fullchain.pem"
cp "$KEY" "$DST/privkey.pem"
chmod 644 "$DST/fullchain.pem"
chmod 600 "$DST/privkey.pem"

cd "$BASE"
docker compose restart coturn

echo "$(date -Is) certificat de $DOMAINE mis a jour, Coturn redemarre"
