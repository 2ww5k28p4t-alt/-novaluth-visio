#!/bin/sh
# ==================================================================
#  Sauvegarde chiffree des donnees de NovaLuth Visio
#  A placer dans /opt/novaluth/sauvegarde.sh
# ==================================================================
#  Sauvegarde le dossier data/ (comptes et journal d'acces) sous
#  forme d'une archive chiffree en AES-256. Les donnees restent sur
#  le serveur : aucun envoi vers un service tiers.
#
#  Le mot de passe de chiffrement est lu dans /opt/novaluth/.backup-pass
#  (fichier d'une seule ligne, permissions 600). Conservez-en une
#  copie ailleurs : sans lui, les sauvegardes sont irrecuperables.
#
#  Les archives de plus de 30 jours sont supprimees, ce qui evite
#  d'accumuler des donnees personnelles sans raison.
# ==================================================================

set -eu

BASE="/opt/novaluth"
DEST="$BASE/sauvegardes"
PASSFILE="$BASE/.backup-pass"
HORODATAGE=$(date +%Y-%m-%d_%H%M)

if [ ! -f "$PASSFILE" ]; then
  echo "Mot de passe de sauvegarde absent : creez $PASSFILE" >&2
  exit 1
fi

mkdir -p "$DEST"
chmod 700 "$DEST"

tar -czf - -C "$BASE" data \
  | openssl enc -aes-256-cbc -pbkdf2 -iter 200000 -salt \
      -pass "file:$PASSFILE" \
      -out "$DEST/novaluth-data-$HORODATAGE.tar.gz.enc"

chmod 600 "$DEST/novaluth-data-$HORODATAGE.tar.gz.enc"

# Purge des sauvegardes de plus de 30 jours
find "$DEST" -name 'novaluth-data-*.tar.gz.enc' -mtime +30 -delete

echo "$(date -Is) sauvegarde ecrite : $DEST/novaluth-data-$HORODATAGE.tar.gz.enc"

# ------------------------------------------------------------------
#  Restauration :
#
#    openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 \
#      -pass file:/opt/novaluth/.backup-pass \
#      -in /opt/novaluth/sauvegardes/novaluth-data-XXXX.tar.gz.enc \
#      | tar -xzf - -C /opt/novaluth
#
#  Puis :  cd /opt/novaluth && docker compose restart app
# ------------------------------------------------------------------
