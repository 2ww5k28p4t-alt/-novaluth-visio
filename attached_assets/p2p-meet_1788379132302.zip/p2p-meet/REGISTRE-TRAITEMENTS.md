# Registre des activités de traitement — NovaLuth Visio

Document interne à conserver et à tenir à jour. Il doit être mis à la disposition de la CNIL sur demande, en application de l'article 30.4 du RGPD.

Modèle inspiré du [registre simplifié publié par la CNIL](https://www.cnil.fr/fr/la-cnil-publie-un-nouveau-modele-de-registre-simplifie).

- Date de création du registre : 2 septembre 2026
- Dernière mise à jour : 2 septembre 2026
- Version : 1.1, déploiement européen sur une machine unique

## Pourquoi ce registre est obligatoire

La CNIL indique que « l'obligation de tenir un registre des traitements concerne tous les organismes, publics comme privés et quelle que soit leur taille, dès lors qu'ils traitent des données personnelles » ([CNIL, le registre des activités de traitement](https://www.cnil.fr/fr/RGPD-le-registre-des-activites-de-traitement)).

La dérogation de l'article 30.5 du RGPD ne s'applique qu'aux organisations de moins de 250 employés dont le traitement est **occasionnel**, sans risque et sans données sensibles — les trois conditions étant alternatives ([texte de l'article 30.5 sur le site de la CNIL](https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4)). Un service de visioconférence exploité en continu est un traitement non occasionnel : la dérogation ne joue pas et le registre reste obligatoire.

---

## Responsable du traitement

| Champ | Valeur |
|---|---|
| Identité | **[NOM Prénom]**, personne physique — à compléter |
| Adresse | **[adresse postale]** — à compléter |
| Contact | contact@novaluth.com |
| Représentant | sans objet (établi en France) |
| Délégué à la protection des données | aucun ; désignation non obligatoire pour ce traitement |

---

## Traitement n° 1 — Gestion des comptes d'accès

| Champ | Contenu |
|---|---|
| **Finalité principale** | Contrôler l'accès au service de visioconférence privé |
| **Finalités secondaires** | Identifier les participants pendant un appel via leur nom affiché |
| **Base juridique** | Article 6.1 b du RGPD : exécution du service demandé par la personne concernée |
| **Catégories de personnes** | Utilisateurs autorisés : membres de l'équipe NovaLuth, luthiers, musiciens et marques partenaires invités |
| **Catégories de données** | Identifiant de connexion ; nom affiché ; empreinte bcrypt du mot de passe ; rôle (utilisateur ou administrateur) ; date de création ; date de dernière connexion ; compteur de tentatives échouées et date de fin de verrouillage éventuel |
| **Données sensibles** | Aucune |
| **Destinataires internes** | Administrateur du service uniquement |
| **Destinataires externes** | Aucun |
| **Sous-traitants** | Hébergeur du serveur (voir liste des sous-traitants) |
| **Transferts hors UE** | Aucun : serveur situé dans l'Union européenne |
| **Durée de conservation** | Jusqu'à la suppression du compte par l'administrateur ou à la demande de la personne |
| **Support de stockage** | Fichier JSON local `data/users.json`, permissions 600, sur le serveur européen ; sauvegardes chiffrées en AES-256 conservées 30 jours sur la même machine |
| **Mesures de sécurité** | HTTPS obligatoire ; mots de passe hachés en bcrypt coût 12 ; longueur minimale de 12 caractères ; verrouillage après 5 échecs ; limitation à 15 tentatives par adresse et par quart d'heure ; comparaison à temps constant ; page d'administration réservée au rôle administrateur |

---

## Traitement n° 2 — Journal d'accès et de sécurité

| Champ | Contenu |
|---|---|
| **Finalité principale** | Détecter les tentatives d'intrusion et les usages abusifs ; disposer d'éléments de preuve en cas d'incident de sécurité |
| **Base juridique** | Article 6.1 f du RGPD : intérêt légitime tenant à la sécurité du service |
| **Catégories de personnes** | Utilisateurs autorisés ; toute personne tentant de se connecter |
| **Catégories de données** | Horodatage ; type d'événement ; identifiant concerné ; nom de la salle rejointe ou quittée ; empreinte HMAC tronquée de l'adresse IP ; succès ou échec |
| **Données sensibles** | Aucune |
| **Contenu des communications** | **Jamais journalisé** : ni audio, ni vidéo, ni messages écrits |
| **Destinataires** | Administrateur du service uniquement |
| **Transferts hors UE** | Aucun : serveur situé dans l'Union européenne |
| **Durée de conservation** | **90 jours**, puis suppression automatique au démarrage du serveur et une fois par jour |
| **Support de stockage** | Fichier `data/acces.log.jsonl`, permissions 600 |
| **Mesures de sécurité** | Pseudonymisation irréversible des adresses IP par HMAC-SHA256 tronqué, avec un sel présent uniquement sur le serveur ; minimisation stricte des champs enregistrés ; purge automatique ; accès réservé au rôle administrateur ; fonctions d'export et d'effacement par personne pour répondre aux demandes de droits |

Justification de la durée : le journal ne sert qu'à la sécurité courante. Quatre-vingt-dix jours permettent de constater une série de tentatives d'intrusion tout en respectant le principe de minimisation. À titre de comparaison, la CNIL retient un maximum de trois mois pour les données de trafic dans le cadre de la fourniture d'un accès internet au public ([CNIL, fournir un accès internet public](https://www.cnil.fr/fr/fournir-un-acces-internet-public-quelles-obligations)).

---

## Traitement n° 3 — Établissement des appels (signalisation WebRTC)

| Champ | Contenu |
|---|---|
| **Finalité** | Permettre à deux navigateurs d'établir une liaison directe chiffrée |
| **Base juridique** | Article 6.1 b du RGPD : exécution du service demandé |
| **Catégories de personnes** | Participants à un appel |
| **Catégories de données** | Descriptions de session (SDP) et candidats de connexion (ICE), qui contiennent les adresses IP locales et publiques des participants ; identifiant technique de socket ; nom affiché ; nom de la salle ; empreinte du mot de passe de salle |
| **Conservation** | **Aucune.** Ces données transitent en mémoire vive pendant l'appel et sont détruites à la déconnexion. La salle et son mot de passe disparaissent lorsque le dernier participant la quitte |
| **Destinataires** | Les autres participants de la même salle, ce qui est une nécessité technique du protocole WebRTC |
| **Sous-traitants** | Hébergeur du serveur, qui porte à la fois l'application et le relais TURN |
| **Mesures de sécurité** | Le serveur relaie les messages de signalisation sans les lire ni les modifier ; il refuse tout message destiné à une personne d'une autre salle ; le contenu des appels est chiffré en DTLS-SRTP entre navigateurs ; les identifiants du serveur TURN sont temporaires, signés en HMAC-SHA1 et valables 12 heures ; le secret partagé ne quitte jamais les serveurs |

Remarque à porter à la connaissance des utilisateurs, et déjà présente dans la politique de confidentialité : le protocole WebRTC suppose l'échange d'adresses IP entre participants. L'option `FORCE_RELAY` permet de faire passer tous les appels par le serveur TURN, ce qui masque les adresses entre participants au prix d'une consommation de bande passante accrue.

---

## Traitement n° 4 — Cookie de session

| Champ | Contenu |
|---|---|
| **Finalité** | Maintenir la session authentifiée |
| **Base juridique** | Traceur strictement nécessaire à la fourniture du service ; **exempté de consentement** au titre des lignes directrices de la CNIL |
| **Données** | Jeton signé contenant l'identifiant de connexion, le rôle, la date d'émission et la date d'expiration |
| **Nom du cookie** | `nv_session` |
| **Durée** | 12 heures |
| **Attributs** | HttpOnly, Secure, SameSite=Lax, Path=/ |
| **Stockage serveur** | **Aucun** : la session est validée par signature HMAC-SHA256, sans table de sessions |

Fondement de l'exemption : la CNIL range parmi les traceurs exemptés ceux « destinés à l'authentification auprès d'un service, y compris ceux visant à assurer la sécurité du mécanisme d'authentification » ([CNIL, mettre son site en conformité](https://www.cnil.fr/fr/cookies-et-autres-traceurs/regles/cookies/comment-mettre-mon-site-web-en-conformite)). Aucun bandeau de consentement n'est donc nécessaire tant qu'aucun autre traceur n'est ajouté.

---

## Liste des sous-traitants (article 28 du RGPD)

Le service est déployé sur **une seule machine louée dans l'Union européenne**, qui porte l'application, la signalisation et le relais TURN.

| Prestataire | Rôle | Pays | Contrat de sous-traitance |
|---|---|---|---|
| **[nom de l'hébergeur]** | Location du serveur hébergeant l'application, la signalisation et le relais TURN | **[ville et pays]**, Union européenne | **[à signer]** |
| **[gestionnaire du domaine]** | Gestion DNS de novaluth.com | **[à préciser]** | **[à obtenir]** |

**Transferts hors Union européenne : aucun.** Toutes les données restent sur un serveur situé dans l'Union, chez un prestataire soumis au droit de l'Union. Les mécanismes du chapitre V du RGPD, décisions d'adéquation et clauses contractuelles types comprises, sont sans objet.

Points de vigilance :

- Le contrat de sous-traitance doit reproduire les obligations des points a) à h) de l'article 28.3 du RGPD ([texte publié par la CNIL](https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4)). La CNIL fournit un [exemple de clauses de sous-traitance](https://www.cnil.fr/fr/sous-traitance-exemple-de-clauses) réutilisable.
- Vérifiez que l'hébergeur choisi ne recourt pas lui-même à un sous-traitant ultérieur situé hors de l'Union, notamment pour la sauvegarde ou la supervision. L'article 28.2 impose une autorisation écrite préalable pour tout sous-traitant ultérieur.
- Si vous ajoutez un jour un service tiers, envoi de courriels ou mesure d'audience par exemple, ajoutez-le ici et vérifiez sa localisation avant de le mettre en production.
- Si vous reveniez à un hébergement aux États-Unis, il faudrait vérifier la certification du prestataire au titre du Data Privacy Framework, seule la certification dispensant de garanties supplémentaires ([CNIL, adéquation des États-Unis](https://www.cnil.fr/fr/adequation-des-etats-unis-les-premieres-questions-reponses)).

---

## Analyse d'impact : le service en a-t-il besoin ?

Méthode appliquée : celle publiée par la CNIL, en trois étapes ([CNIL, ce qu'il faut savoir sur l'AIPD](https://www.cnil.fr/fr/ce-quil-faut-savoir-sur-lanalyse-dimpact-relative-la-protection-des-donnees-aipd)).

1. Le traitement figure-t-il sur la [liste des cas où une analyse n'est pas obligatoire](https://www.cnil.fr/fr/liste-traitements-aipd-non-requise) ? Les douze entrées visent principalement des traitements de ressources humaines, de gestion de membres ou de comptabilité. Un service de visioconférence ouvert à des tiers n'y figure pas explicitement.
2. Figure-t-il sur la [liste des cas où une analyse est obligatoire](https://www.cnil.fr/fr/listes-des-traitements-pour-lesquels-une-aipd-est-requise-ou-non) ? Les quatorze entrées visent des données de santé, génétiques, biométriques, des profilages et de la surveillance des salariés. **Aucune ne correspond au service.**
3. Combien de critères parmi les neuf du Comité européen de la protection des données sont remplis ?

| Critère | Rempli ? | Justification |
|---|---|---|
| 1. Évaluation ou scoring | Non | Aucun profilage, aucune notation |
| 2. Décision automatisée avec effet juridique | Non | Seul le verrouillage temporaire après cinq échecs est automatique, sans effet juridique |
| 3. Surveillance systématique | Non | Journalisation limitée aux événements de sécurité, sans suivi comportemental |
| 4. Données sensibles ou hautement personnelles | À apprécier | Le contenu d'une conversation est hautement personnel, mais l'éditeur ne le traite pas : chiffrement de bout en bout, aucun enregistrement |
| 5. Collecte à grande échelle | Non | Quelques dizaines de comptes attendus |
| 6. Croisement de données | Non | Aucun croisement avec un autre traitement |
| 7. Personnes vulnérables | Non | Service réservé aux quinze ans et plus |
| 8. Usage innovant | Non | WebRTC est une technologie normalisée et éprouvée |
| 9. Exclusion du bénéfice d'un droit | Non | Sans objet |

**Conclusion** : moins de deux critères sont clairement remplis. En l'état, une analyse d'impact ne paraît pas obligatoire. Cette conclusion est une appréciation, pas une certitude : la CNIL recommande de réaliser une analyse en cas de doute.

Une analyse d'impact deviendrait très probablement obligatoire si l'un des changements suivants intervenait :

- enregistrement ou transcription des appels ;
- ouverture du service aux mineurs de moins de quinze ans ;
- passage à plusieurs milliers d'utilisateurs ;
- appels portant sur des données de santé ou d'autres données sensibles ;
- ajout d'une fonction de profilage, de mesure d'audience détaillée ou de modération automatisée.

À réévaluer à chaque évolution majeure du service, et au moins une fois par an.

---

## Registre des violations de données

À tenir même en l'absence de violation, en application de l'article 33.5 du RGPD. En cas de violation présentant un risque, la notification à la CNIL doit intervenir dans les 72 heures.

| Date de découverte | Nature | Données concernées | Personnes concernées | Conséquences probables | Mesures prises | Notification CNIL | Information des personnes |
|---|---|---|---|---|---|---|---|
| *(aucune à ce jour)* | | | | | | | |
