# Recherche juridique — service de visioconférence WebRTC P2P auto-hébergé (`visio.novaluth.com`)

**Contexte** : service de visioconférence pair-à-pair, chiffré, sans enregistrement, auto-hébergé, édité par une **personne physique** résidant en France (Marseille), **sans entreprise créée à ce jour**, adossé au projet NovaLuth.

**Date de la recherche** : 2 septembre 2026.
**Sources** : uniquement legifrance.gouv.fr, cnil.fr, economie.gouv.fr, entreprendre.service-public.fr.
**Avertissement** : document de recherche documentaire, pas un conseil juridique. Chaque affirmation est suivie de l'URL de sa source. Les incertitudes sont signalées explicitement. Aucun article ni montant n'a été inventé ; ce qui n'a pas pu être vérifié sur source officielle est marqué **« non vérifié sur source officielle »**.

**Point d'attention majeur sur l'état du droit** : l'article 6 III de la LCEN (loi n° 2004-575 du 21 juin 2004), classiquement cité comme fondement des mentions légales, **a été recodifié** par la loi n° 2024-449 du 21 mai 2024 (loi SREN). Les obligations d'identification figurent désormais aux **articles 1er-1 et 1er-2** de la loi de 2004 (https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000049563632). Beaucoup de contenus en ligne, y compris certaines pages administratives, citent encore « article 6 III ». Le texte de fond est quasi identique.

---

## 1. Mentions légales — LCEN (loi n° 2004-575), désormais articles 1er-1 et 1er-2

### 1.1 Informations obligatoires — éditeur personne physique

L'article 1er-1, I de la loi n° 2004-575 impose aux personnes physiques dont l'activité est d'éditer un service de communication au public en ligne de tenir à la disposition du public, dans un standard ouvert : « **ses nom, prénoms, domicile et numéro de téléphone et, si elle est assujettie aux formalités d'inscription au registre du commerce et des sociétés ou au registre national des entreprises, son numéro d'inscription** » (https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000049563632 ; version consolidée : https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049568614).

S'y ajoutent, quel que soit le statut :
- « le nom du directeur ou du codirecteur de la publication et, le cas échéant, celui du responsable de la rédaction au sens de l'article 93-2 de la loi n° 82-652 du 29 juillet 1982 » (https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000049563632) ;
- « le nom, la dénomination ou la raison sociale, l'adresse et le numéro de téléphone » du **fournisseur d'hébergement** (même source) ;
- « le cas échéant, l'identité des personnes assurant, même à titre gratuit, le stockage de signaux, d'écrits, d'images, de sons ou de messages » (même source).

Pour une **personne morale** (société), les informations sont : dénomination ou raison sociale, siège social, numéro de téléphone, numéro d'inscription au RCS ou au RNE, capital social, nom du représentant légal (https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000049563632). La page Bercy synthétise le tableau des mentions selon le statut et rappelle que les mentions relatives à l'hébergeur sont dues **même pour un site gratuit ou non professionnel** (https://www.economie.gouv.fr/entreprises/innover-et-numeriser-son-entreprise/mentions-sur-votre-site-internet-les-obligations).

### 1.2 Anonymat de l'éditeur non professionnel : OUI, sous condition

L'article 1er-1, II prévoit expressément : « **Les personnes éditant à titre non professionnel un service de communication au public en ligne peuvent ne tenir à la disposition du public, pour préserver leur anonymat, que le nom, la dénomination ou la raison sociale et l'adresse du fournisseur de services d'hébergement, sous réserve d'avoir communiqué à ce fournisseur les éléments d'identification personnelle mentionnés au I** » (https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000049563632).

Le même texte précise que les hébergeurs « sont assujettis au secret professionnel dans les conditions prévues aux articles 226-13 et 226-14 du code pénal » pour ces éléments d'identification, secret « non opposable à l'autorité judiciaire » (même source).

**Deux réserves importantes pour ce projet :**
1. La dispense ne joue que **« à titre non professionnel »**. Un service adossé à une plateforme commerciale (NovaLuth), monétisé, ou exploité dans le cadre d'une activité économique, sort très probablement de cette qualification. **Aucune source officielle consultée ne définit précisément le seuil entre édition professionnelle et non professionnelle** — non vérifié sur source officielle, à faire valider.
2. La dispense couvre l'identité vis-à-vis du **public**, pas vis-à-vis de l'hébergeur, ni des autorités, ni des obligations RGPD (l'identité du responsable de traitement doit être fournie aux personnes concernées, art. 13.1 a) RGPD — voir point 7).

### 1.3 Sanctions pénales

Article 1er-2 de la loi n° 2004-575 : « **Est puni d'un an d'emprisonnement et de 75 000 euros d'amende le fait, pour une personne physique ou le dirigeant de droit ou de fait d'une personne morale exerçant l'activité définie à l'article 1er-1, de ne pas respecter les I et II du même article 1er-1** » (https://www.legifrance.gouv.fr/jorf/article_jo/JORFARTI000049563632).

Le même article prévoit que « les personnes morales peuvent être déclarées pénalement responsables de ces infractions dans les conditions prévues à l'article 121-2 du code pénal », les peines encourues étant « **l'amende, suivant les modalités prévues par l'article 131-38 du code pénal** » ainsi que les peines des 2° et 9° de l'article 131-39 du code pénal, l'interdiction du 2° étant prononcée pour cinq ans au plus (même source).

Confirmation par les fiches administratives :
- entrepreneur individuel / micro-entrepreneur : « 1 an d'emprisonnement et 75 000 € d'amende » (https://entreprendre.service-public.fr/vosdroits/F31228) ;
- société : « **375 000 € d'amende** » (https://entreprendre.service-public.fr/vosdroits/F37351).

⚠️ Le mécanisme du quintuple (art. 131-38 du code pénal : amende quintuplée pour les personnes morales, soit 5 × 75 000 = 375 000 €) est cohérent avec le montant publié par service-public.fr, mais **le texte de l'article 131-38 du code pénal n'a pas pu être lu verbatim** : les URL Legifrance en `/codes/` sont bloquées à la lecture automatisée. Le montant de 375 000 € est en revanche bien vérifié sur entreprendre.service-public.fr (https://entreprendre.service-public.fr/vosdroits/F37351).

Attention à ne pas confondre avec les sanctions applicables aux **hébergeurs** (défaut de conservation des données d'identification, non-conservation, etc.) et à la dénonciation abusive de contenus, qui figurent dans l'article 6 actuel de la LCEN (https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000049577522).

---

## 2. RGPD — registre des activités de traitement (art. 30)

### 2.1 Position de la CNIL

La CNIL écrit : « **L'obligation de tenir un registre des traitements concerne tous les organismes, publics comme privés et quelle que soit leur taille, dès lors qu'ils traitent des données personnelles** » (https://www.cnil.fr/fr/RGPD-le-registre-des-activites-de-traitement).

Elle ajoute, à propos des petites structures : « Pour les entreprises de moins de 250 salariés, il existe des **dérogations (limitées à des cas très particuliers de traitements)** » (https://www.cnil.fr/fr/comment-gerer-vos-donnees).

### 2.2 Le texte de la dérogation (art. 30.5 RGPD, verbatim)

« **Les obligations visées aux paragraphes 1 et 2 ne s'appliquent pas à une entreprise ou à une organisation comptant moins de 250 employés, sauf si le traitement qu'elles effectuent est susceptible de comporter un risque pour les droits et des libertés des personnes concernées, s'il n'est pas occasionnel ou s'il porte notamment sur les catégories particulières de données visées à l'article 9, paragraphe 1, ou sur des données à caractère personnel relatives à des condamnations pénales et à des infractions visées à l'article 10** » (https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4).

**Lecture pratique** : les trois conditions d'exclusion étant alternatives (« ou »), la dérogation ne joue que pour des traitements **occasionnels**, sans risque et sans données sensibles. Un service de visioconférence exploité en continu constitue un traitement **non occasionnel** : la dérogation ne s'applique donc pas, et le registre reste **obligatoire**. Cette qualification est une interprétation du texte, pas une position explicite de la CNIL sur ce cas d'espèce.

Le registre doit être mis « à la disposition de l'autorité de contrôle sur demande » (art. 30.4, https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4).

### 2.3 Registre simplifié CNIL

La CNIL publie un **modèle de registre simplifié** destiné notamment aux « TPE-PME, associations, petites collectivités » (https://www.cnil.fr/fr/la-cnil-publie-un-nouveau-modele-de-registre-simplifie). Le contenu minimal attendu figure sur la page dédiée : nom et coordonnées du responsable de traitement, finalités, catégories de personnes concernées et de données, destinataires, transferts hors UE, durées de conservation, mesures de sécurité (https://www.cnil.fr/fr/RGPD-le-registre-des-activites-de-traitement).

La CNIL publie également un questions-réponses spécifique aux TPE/PME (https://www.cnil.fr/fr/appliquer-le-rgpd-dans-une-tpe-ou-pme-les-questionsreponses-de-la-cnil) ; **son contenu détaillé n'a pas été extrait** — non vérifié sur source officielle pour ce qui n'est pas repris ci-dessus.

---

## 3. Cookies / traceurs — cookie de session d'authentification

### 3.1 Fondement

L'obligation de consentement au dépôt de traceurs repose sur l'**article 82 de la loi Informatique et Libertés**, transposant l'article 5(3) de la directive 2002/58/CE (https://www.cnil.fr/fr/cookies-et-autres-traceurs/que-dit-la-loi).

### 3.2 Catégories exemptées de consentement (liste CNIL)

La CNIL liste les traceurs exemptés (https://www.cnil.fr/fr/cookies-et-autres-traceurs/que-dit-la-loi et https://www.cnil.fr/fr/cookies-et-autres-traceurs/regles/cookies/comment-mettre-mon-site-web-en-conformite) :

1. traceurs conservant le **choix exprimé par l'utilisateur sur le dépôt de traceurs** ;
2. traceurs destinés à l'**authentification auprès d'un service, y compris ceux visant à assurer la sécurité du mécanisme d'authentification** ;
3. traceurs destinés à garder en mémoire le **contenu d'un panier d'achat** ou à facturer le produit/service ;
4. traceurs de **personnalisation de l'interface utilisateur** (choix de langue, présentation), lorsqu'elle constitue un élément intrinsèque et attendu du service ;
5. traceurs permettant l'**équilibrage de charge** des équipements ;
6. traceurs permettant aux sites payants de **limiter l'accès gratuit** à un échantillon de contenu ;
7. certains traceurs de **mesure d'audience**, sous conditions strictes (finalité limitée à la mesure d'audience pour le compte exclusif de l'éditeur, pas de recoupement avec d'autres traitements, portée limitée à un seul site/application, durée de vie limitée).

**Conclusion pour `visio.novaluth.com`** : un cookie strictement nécessaire à l'authentification (cookie de session) relève explicitement de la catégorie 2 et est donc **exempté de consentement**. Idem, le cas échéant, pour un cookie de répartition de charge sur les serveurs de signalisation/TURN. Un traceur d'analytics tiers, de mesure de performance étendue ou de publicité **n'est pas exempté**.

### 3.3 Faut-il informer malgré l'exemption ?

Oui, c'est recommandé, et le RGPD continue de s'appliquer aux données associées : « **Ces traceurs ne nécessitent pas de consentement des internautes mais vous pouvez cependant les informer de leur utilisation... Les traitements de données personnelles associés restent néanmoins soumis aux principes du RGPD** » (https://www.cnil.fr/fr/cookies-et-autres-traceurs/regles/cookies/comment-mettre-mon-site-web-en-conformite).

En pratique : pas de bandeau de consentement nécessaire si **seuls** des traceurs exemptés sont utilisés, mais une rubrique « cookies » informative dans la politique de confidentialité (nom du cookie, finalité, durée) est la bonne pratique. Les lignes directrices de référence sont la délibération n° 2020-091 du 17 septembre 2020 (https://www.cnil.fr/sites/default/files/atoms/files/lignes_directrices_de_la_cnil_sur_les_cookies_et_autres_traceurs.pdf).

---

## 4. AIPD / DPIA — analyse d'impact

### 4.1 Méthode de la CNIL (arbre de décision)

La CNIL applique l'ordre suivant (https://www.cnil.fr/fr/ce-quil-faut-savoir-sur-lanalyse-dimpact-relative-la-protection-des-donnees-aipd) :
1. le traitement figure-t-il sur la **liste des cas pour lesquels une AIPD n'est pas obligatoire** ? Si oui → AIPD non requise.
2. sinon, figure-t-il sur la **liste des cas pour lesquels une AIPD est obligatoire** ? Si oui → AIPD requise.
3. sinon, combien de **critères** parmi neuf le traitement remplit-il :

> 1. Évaluation/scoring (y compris le profilage) — 2. Décision automatique avec effet légal ou similaire — 3. Surveillance systématique — 4. Données sensibles ou hautement personnelles — 5. Collecte à large échelle — 6. Croisement de données — 7. Personnes vulnérables (patients, personnes âgées, enfants, etc.) — 8. Usage innovant (utilisation d'une nouvelle technologie) — 9. Exclusion du bénéfice d'un droit/contrat
> (https://www.cnil.fr/fr/ce-quil-faut-savoir-sur-lanalyse-dimpact-relative-la-protection-des-donnees-aipd ; également https://www.cnil.fr/fr/gerer-les-risques)

Règle : « **Si au moins deux critères sont remplis, ou un critère mais je considère que mon traitement présente un risque élevé : l'AIPD est requise** » ; si aucun critère n'est rempli, l'AIPD est non requise, mais « même non soumis à une AIPD, les traitements doivent respecter les principes de protection des données et les droits des personnes concernées » (https://www.cnil.fr/fr/ce-quil-faut-savoir-sur-lanalyse-dimpact-relative-la-protection-des-donnees-aipd).

### 4.2 Liste « AIPD requise » — 14 types (vérifiée verbatim)

La liste CNIL (https://www.cnil.fr/sites/cnil/files/atoms/files/liste-traitements-aipd-requise.pdf ; page de présentation : https://www.cnil.fr/fr/listes-des-traitements-pour-lesquels-une-aipd-est-requise-ou-non) comporte 14 entrées : 1) données de santé par établissements de santé/médico-sociaux ; 2) données génétiques de personnes vulnérables ; 3) profils de personnes physiques à des fins de gestion RH ; 4) surveillance constante de l'activité des employés ; 5) gestion des alertes et signalements en matière sociale et sanitaire ; 6) gestion des alertes et signalements en matière professionnelle ; 7) entrepôts / registres de données de santé ; 8) profilage pouvant aboutir à l'exclusion ou à la rupture d'un contrat ; 9) traitements mutualisés de manquements contractuels ; 10) profilage à partir de sources externes ; 11) données biométriques d'identification unique incluant des personnes vulnérables ; 12) demandes et gestion des logements sociaux ; 13) accompagnement social ou médico-social ; 14) données de localisation à large échelle.

**Un service de visioconférence chiffré sans enregistrement ne figure sur aucune de ces 14 entrées.**

### 4.3 Liste « AIPD non requise » — 12 types (vérifiée verbatim)

Liste adoptée définitivement le **12 septembre 2019**, comportant **douze types** d'opérations, non exhaustive (https://www.cnil.fr/fr/liste-traitements-aipd-non-requise). Le PDF précise en préambule : « La mise en œuvre d'un traitement figurant sur la présente liste ne dispense pas le responsable de traitement du respect de ses autres obligations prévues par le RGPD... Conformément aux lignes directrices du CEPD, en cas de doute quant à la nécessité d'effectuer une AIPD il est recommandé d'en effectuer une » (https://www.cnil.fr/sites/default/files/atoms/files/liste-traitements-aipd-non-requise.pdf).

Point notable : l'entrée n° 1 de cette liste (traitements RH pour la seule gestion du personnel d'organismes de moins de 250 personnes) cite expressément, parmi les traitements dispensés, « **l'utilisation d'outils de communication (messagerie électronique, téléphonie, vidéoconférences, outils collaboratifs en ligne) sans recours au profilage ni à la biométrie** » (https://www.cnil.fr/sites/default/files/atoms/files/liste-traitements-aipd-non-requise.pdf).

⚠️ **Attention à ne pas surinterpréter** : cette mention concerne l'usage **interne, à des fins de ressources humaines**, d'outils de visioconférence par un employeur de moins de 250 salariés. Elle **ne couvre pas** l'exploitation d'un service de visioconférence offert à des tiers. **Aucune source officielle consultée ne classe explicitement un service de visioconférence grand public dans l'une ou l'autre liste** — non vérifié sur source officielle.

### 4.4 Analyse pour `visio.novaluth.com`

Application des 9 critères à un service P2P chiffré, sans enregistrement, sans profilage, avec compte et cookie de session :
- critères probablement **non** remplis : 1 (scoring), 2 (décision automatisée), 3 (surveillance systématique — sous réserve qu'aucune journalisation comportementale ne soit mise en place), 6 (croisement), 9 (exclusion d'un droit) ;
- critère 5 (large échelle) : non rempli au démarrage, à réévaluer en cas de croissance ;
- critère 4 (données sensibles/hautement personnelles) : le **contenu** des communications est une donnée hautement personnelle ; le chiffrement de bout en bout et l'architecture P2P réduisent l'exposition (l'éditeur ne traite pas le contenu), mais ce point mérite l'avis d'un avocat ;
- critère 7 (personnes vulnérables) : deviendrait pertinent si des mineurs sont admis ;
- critère 8 (usage innovant) : discutable — WebRTC n'est pas une technologie nouvelle.

**Conclusion prudente** : en l'état (pas d'enregistrement, pas de profilage, faible volume), le service semble rester **sous le seuil des deux critères**, donc hors AIPD obligatoire. Il s'agit d'une **appréciation, pas d'une certitude** : la CNIL recommande de réaliser une AIPD en cas de doute (https://www.cnil.fr/sites/default/files/atoms/files/liste-traitements-aipd-non-requise.pdf). Une AIPD deviendrait très probablement requise en cas d'enregistrement des sessions, de transcription automatique, d'ouverture aux mineurs, de données de santé, ou de passage à grande échelle.

Références complémentaires : liste des traitements soumis à AIPD publiée au JO n° 326 du 6 novembre 2018 (https://www.cnil.fr/sites/default/files/2023-06/journal_officiel_de_la_republique_francaise_ndeg_326_du_6_novembre_2018.pdf) ; annonce de publication (https://www.cnil.fr/fr/analyse-dimpact-relative-la-protection-des-donnees-publication-dune-liste-des-traitements-pour).

---

## 5. Conservation des données de connexion (LCEN + décret n° 2021-1362)

### 5.1 Le texte applicable

Dans sa rédaction issue de la loi SREN, l'article 6 de la LCEN prévoit (V, A) que les fournisseurs d'accès à internet **et** les fournisseurs d'hébergement conservent les données permettant d'identifier toute personne ayant contribué à la création d'un contenu mis en ligne, « **dans les conditions prévues aux II bis à III bis de l'article L. 34-1 du code des postes et des communications électroniques** », un décret en Conseil d'État déterminant les données concernées et les durées (https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000049577522).

Le décret d'application est le **décret n° 2021-1362 du 20 octobre 2021** relatif à la conservation des données permettant d'identifier toute personne ayant contribué à la création d'un contenu mis en ligne, « pris en application du II de l'article 6 de la loi n° 2004-575 » (https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044228912). Sa notice précise qu'il applique ces obligations « dans les conditions prévues aux II bis, III et III bis de l'article L. 34-1 du code des postes et communications électroniques » (même URL).

⚠️ **Limite de vérification** : le **texte article par article du décret n° 2021-1362 n'a pas pu être lu** sur Legifrance (pages rendues en JavaScript, contenu non extractible ; les URL `/codes/` renvoient une erreur de robots). Le détail des catégories du décret en vigueur est donc **non vérifié verbatim sur source officielle**. Ce qui est vérifié : son intitulé, son objet, et le fait qu'il a abrogé le décret n° 2011-219 (voir 5.3).

### 5.2 Durées (vérifiées)

Via l'article L. 34-1, II bis du CPCE (https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000028345210/, texte lu en extrait de recherche Legifrance) :
- **informations relatives à l'identité civile** de l'utilisateur : **5 ans** à compter de la fin de validité du contrat ;
- **autres informations fournies lors de la souscription / création de compte, et informations relatives au paiement** : **1 an** à compter de la fin de validité du contrat ou de la clôture du compte ;
- **données techniques permettant d'identifier la source de la connexion** ou relatives aux équipements terminaux : **1 an** à compter de la connexion.

La CNIL confirme ces durées et y ajoute les données de trafic : identité civile 5 ans ; autres informations de compte 1 an ; données techniques (adresse IP et port) 1 an ; **données de trafic : 3 mois maximum** (https://www.cnil.fr/fr/fournir-un-acces-internet-public-quelles-obligations).

⚠️ Ces durées sont vérifiées comme celles du **régime L. 34-1 CPCE** (opérateurs / fourniture d'accès), auquel l'article 6 de la LCEN renvoie. Le rattachement exact de chaque catégorie à un petit éditeur de service reste une question d'interprétation.

### 5.3 Ces obligations visent-elles un petit éditeur de service ?

C'est le point le plus incertain du dossier.

- Le texte vise les personnes mentionnées aux **1 et 2 du I de l'article 6** de la LCEN, c'est-à-dire les **fournisseurs d'accès à internet** et les **fournisseurs d'hébergement** (stockage de contenus fournis par des tiers), et non les éditeurs de services en général (https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000049577522).
- Le Conseil d'État, dans sa décision d'Assemblée du 21 avril 2021 (n° 393099), distingue le régime des hébergeurs de celui des opérateurs de communications électroniques et se prononce sur la conservation des adresses IP pour un an (https://www.legifrance.gouv.fr/ceta/id/CETATEXT000043411127). Voir aussi CE, 30 juin 2023, n° 468361 (https://www.legifrance.gouv.fr/ceta/id/CETATEXT000047773981).
- La CNIL indique, s'agissant de la fourniture d'un accès internet au public, qu'il n'existe **pas d'obligation d'identifier les utilisateurs** et que les employeurs fournissant un accès à leurs seuls employés ne sont pas concernés (https://www.cnil.fr/fr/fournir-un-acces-internet-public-quelles-obligations).
- Le décret n° 2011-219 du 25 février 2011, **abrogé par l'article 9 du décret n° 2021-1362**, énumérait les catégories de données dues par ces personnes, en précisant notamment que les informations de compte et de paiement « **ne doivent être conservées que dans la mesure où les personnes les collectent habituellement** » (https://www.legifrance.gouv.fr/loda/id/JORFTEXT000023646013). Cette clause de « collecte habituelle » est un point à vérifier dans le décret de 2021 — **non vérifié sur source officielle**.

**Analyse prudente** : un service de visioconférence P2P chiffré, sans stockage de contenus fournis par les utilisateurs, ne correspond a priori ni à un FAI, ni à un hébergeur au sens du 2 du I de l'article 6. En revanche, si le service permet de **stocker** des contenus (enregistrements, pièces jointes, messages persistants, salles publiques nommées), la qualification d'hébergeur devient plausible et les obligations de conservation s'appliqueraient. **Cette qualification doit être tranchée par un avocat** ; les sources officielles consultées ne fournissent pas de réponse directe pour ce cas de figure.

Décret connexe (injonction de conservation par le Premier ministre pour un an, sécurité nationale) : décret n° 2021-1363 du 20 octobre 2021 (https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000044228976).

---

## 6. Sous-traitants RGPD (art. 28) et hébergement hors UE

### 6.1 Exigences de l'article 28 (verbatim CNIL)

Le responsable du traitement ne peut faire appel qu'à un sous-traitant « qui présente des garanties suffisantes » ; le traitement par un sous-traitant est régi par un **contrat ou un autre acte juridique** qui définit « l'objet et la durée du traitement, la nature et la finalité du traitement, le type de données à caractère personnel et les catégories de personnes concernées, et les obligations et les droits du responsable du traitement » (https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4).

Le contrat doit prévoir que le sous-traitant :
- a) ne traite les données que sur **instruction documentée** du responsable de traitement ;
- b) veille à ce que les personnes autorisées s'engagent à la **confidentialité** ;
- c) prend toutes les mesures requises en vertu de l'**article 32** (sécurité) ;
- d) ne recrute pas un **sous-traitant ultérieur** sans autorisation écrite préalable, spécifique ou générale ;
- e) aide le responsable à respecter les **droits des personnes** ;
- f) aide le responsable à garantir le respect des **articles 32 à 36** (sécurité, violations, AIPD) ;
- g) **supprime ou renvoie** les données au terme de la prestation ;
- h) met à disposition toutes les **informations nécessaires** et permet la réalisation d'**audits** ;
et informe immédiatement le responsable si une instruction constitue une violation du RGPD (https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre4).

La CNIL publie un **exemple de clauses de sous-traitance** réutilisable (https://www.cnil.fr/fr/sous-traitance-exemple-de-clauses). Les **clauses contractuelles types responsable/sous-traitant** adoptées par la Commission européenne le **4 juin 2021** peuvent être utilisées ; elles ne sont pas obligatoires si le contrat comporte déjà tous les éléments de l'article 28, et elles ne servent **pas** à encadrer les transferts au titre du chapitre V (https://www.cnil.fr/fr/clauses-contractuelles-types-entre-responsable-de-traitement-et-sous-traitant).

### 6.2 Cas d'un hébergeur américain (type Replit)

Cadre général des transferts : décision d'adéquation (art. 45), garanties appropriées (art. 46, dont les CCT et les BCR), codes de conduite et certification, dérogations de l'article 49 (https://www.cnil.fr/fr/transferts-de-donnees-hors-ue-le-cadre-general-prevu-par-le-rgpd et https://www.cnil.fr/fr/les-outils-de-la-conformite/transferer-des-donnees-hors-de-lue).

- **Privacy Shield invalidé** : « Le 16 juillet 2020, la Cour de justice de l'Union européenne (CJUE) dans son arrêt Schrems II a invalidé la précédente décision d'adéquation de la Commission européenne à l'égard des États-Unis (Privacy Shield) » (https://www.cnil.fr/fr/adequation-des-etats-unis-les-premieres-questions-reponses).
- **Cadre actuel — Data Privacy Framework** : « Le 10 juillet 2023, la Commission européenne a adopté une nouvelle décision d'adéquation constatant que les États-Unis assurent un niveau de protection substantiellement équivalent à celui de l'Union européenne » (même source). Le DPF est « un mécanisme d'auto-certification pour les entreprises états-uniennes » (https://www.cnil.fr/sites/cnil/files/2024-07/cepd_dpf_faq_particuliers.pdf).
- **Portée limitée aux entités certifiées** : « **Seuls les transferts vers les entités américaines certifiées ne nécessitent pas l'utilisation d'outils d'encadrement des transferts prévus par l'article 46 du RGPD** » ; « **Avant de procéder au transfert, les organismes doivent s'assurer que l'organisme destinataire figure sur cette liste mise à disposition sur le site du Département du Commerce des États-Unis** » (https://www.cnil.fr/fr/adequation-des-etats-unis-les-premieres-questions-reponses). Le CEPD précise que la certification peut ne pas couvrir toutes les catégories de données et qu'il faut vérifier la **portée** de la certification (https://www.cnil.fr/sites/cnil/files/2024-07/cepd_dpf_faq_particuliers.pdf).
- **Si le prestataire n'est pas certifié** : « Les transferts vers des entités étatsuniennes ne figurant pas sur la liste du Département du Commerce ne peuvent pas être fondés sur la décision d'adéquation et nécessitent des garanties appropriées. Il est notamment possible de réaliser le transfert en mettant en place des clauses contractuelles types ou règles d'entreprise contraignantes » ; il incombe alors à l'exportateur d'évaluer au cas par cas le niveau de protection, évaluation qui « peut prendre la forme d'une **analyse d'impact des transferts de données (AITD ou TIA)** » (https://www.cnil.fr/fr/adequation-des-etats-unis-les-premieres-questions-reponses).

**À faire concrètement pour ce projet** : (1) recenser tous les sous-traitants (hébergeur, serveur TURN, e-mail transactionnel, monitoring, analytics) dans le registre ; (2) pour chacun, obtenir un **DPA** conforme à l'art. 28 ; (3) vérifier nommément la certification DPF sur la liste du Département du Commerce américain pour tout prestataire américain, et sa portée ; (4) à défaut, CCT + AITD documentée ; (5) mentionner les transferts hors UE dans la politique de confidentialité (art. 13.1 f). **Le statut DPF de Replit, Inc. n'a pas été vérifié dans cette recherche** — non vérifié sur source officielle. Une alternative simple et souvent préférable est un hébergement dans l'UE, ce qui supprime la question du chapitre V.

---

## 7. Droits des personnes et mention de la réclamation auprès de la CNIL

### 7.1 Droits listés par la CNIL

La CNIL énumère les droits suivants : **droit à l'information, droit d'accès, droit de rectification, droit d'opposition, droit à l'effacement, droit à la limitation du traitement, droit à la portabilité, droit d'obtenir une intervention humaine (profilage / décision automatisée)** (https://www.cnil.fr/fr/les-droits-pour-maitriser-vos-donnees-personnelles).

### 7.2 Ce que la politique de confidentialité doit contenir (art. 13 RGPD, verbatim)

Au moment de la collecte, le responsable de traitement doit fournir (https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre3) :
- a) l'identité et les coordonnées du responsable du traitement (et du représentant s'il y en a) ;
- b) le cas échéant, les coordonnées du DPO ;
- c) les finalités du traitement et la **base juridique** ;
- d) si le traitement repose sur l'intérêt légitime (art. 6.1 f), les intérêts légitimes poursuivis ;
- e) les destinataires ou catégories de destinataires ;
- f) le cas échéant, l'intention de **transférer les données vers un pays tiers**, l'existence ou l'absence d'une décision d'adéquation, ou la référence aux garanties appropriées et le moyen d'en obtenir copie ;

puis, au titre du § 2 :
- a) la **durée de conservation** ou les critères la déterminant ;
- b) l'existence des droits d'**accès, rectification, effacement, limitation, opposition et portabilité** ;
- c) lorsque le traitement repose sur le consentement, « l'existence du droit de **retirer son consentement** à tout moment » ;
- d) « **le droit d'introduire une réclamation auprès d'une autorité de contrôle** » ;
- e) le caractère réglementaire/contractuel de la fourniture des données et les conséquences d'un refus ;
- f) l'existence d'une **prise de décision automatisée**, y compris le profilage, et la logique sous-jacente.

L'obligation d'indiquer la possibilité de réclamation est donc **explicite** (art. 13.2 d), et se retrouve également dans le droit d'accès de l'article 15 (https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre3). Il faut indiquer que la réclamation s'adresse à la CNIL, avec un renvoi vers son service de plaintes (https://www.cnil.fr/fr/plaintes).

Ressources pratiques : cadre général de l'information et de la transparence, articles 12, 13 et 14 (https://www.cnil.fr/fr/conformite-rgpd-information-des-personnes-et-transparence) ; **modèles de mentions d'information** de la CNIL, directement réutilisables (https://www.cnil.fr/fr/les-modeles-de-mentions-dinformation).

**Note** : le droit de **retrait du consentement** et les **directives post-mortem** (art. 85 loi Informatique et Libertés) ne figurent pas dans la liste synthétique de la page « droits » de la CNIL ; le retrait du consentement est bien exigé par l'art. 13.2 c) lorsque le traitement repose sur le consentement (https://www.cnil.fr/fr/reglement-europeen-protection-donnees/chapitre3). L'obligation de mentionner les directives post-mortem est **non vérifiée sur source officielle** dans cette recherche.

---

## 8. Médiation de la consommation et CGU

### 8.1 L'obligation de médiation

« Depuis le 1er janvier 2016, vous devez, en tant que professionnel, permettre à tout consommateur l'accès à un dispositif de médiation de la consommation en vue de la résolution amiable de tout éventuel litige » ; il faut « choisir un médiateur parmi ceux inscrits sur la liste des médiateurs prévue à l'article L.615-1 du code de la consommation » et adhérer à son dispositif. « Cette obligation résulte de l'**article L.612-1 du code de la consommation** » (https://www.economie.gouv.fr/mediation-conso/vous-etes-professionnel).

Information obligatoire du consommateur : les coordonnées du médiateur doivent figurer de manière visible et lisible sur le site internet, dans les CGV/CGS et les bons de commande (articles L.616-1 et R.616-1, ainsi que L.111-1 et L.221-5 du code de la consommation) (https://www.economie.gouv.fr/mediation-conso/vous-etes-un-professionnel/vos-principales-obligations-0).

**Sanction** : « Conformément à l'article L641-1 du code de la consommation, tout manquement à ces obligations d'information est passible d'une **amende administrative dont le montant ne peut excéder 3 000 euros pour une personne physique et 15 000 euros pour une personne morale** » (https://www.economie.gouv.fr/mediation-conso/vous-etes-professionnel).

### 8.2 Champ d'application : service gratuit, entre particuliers

Trois éléments décisifs, tous vérifiés :

1. **Notion de professionnel** — article liminaire du code de la consommation : « 1° Consommateur : toute personne physique qui agit à des fins qui n'entrent pas dans le cadre de son activité commerciale, industrielle, artisanale, libérale ou agricole ; ... 3° Professionnel : toute personne physique ou morale, publique ou privée, qui **agit à des fins entrant dans le cadre de son activité commerciale, industrielle, artisanale, libérale ou agricole** » (https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000049464063, extrait de recherche Legifrance).
2. **Champ de la médiation** — article L611-1 du code de la consommation : le litige national ou transfrontalier est « un litige de nature contractuelle entre un consommateur et un professionnel portant sur l'exécution d'un contrat de vente ou de fourniture de services » ; et le « 4° Contrat de prestation de services : tout contrat ayant pour objet la fourniture d'un service par le professionnel **en contrepartie duquel le consommateur s'engage à payer le prix** » (https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000032224815, extrait de recherche Legifrance).
3. **Périmètre pratique** — la fiche officielle indique que la médiation concerne « tous les litiges opposant un consommateur et un professionnel à l'occasion d'un contrat de vente ou de fourniture de services », quels que soient la taille et le secteur, à l'initiative du seul consommateur, avec une liste d'exclusions (litiges entre professionnels, services d'intérêt général non économiques, santé, enseignement supérieur public…) (https://entreprendre.service-public.fr/vosdroits/F33338).

**Conclusion pour `visio.novaluth.com`** :
- Aujourd'hui — service **gratuit**, édité par une personne physique **sans activité professionnelle déclarée** — deux conditions cumulatives de l'obligation font défaut : la qualité de professionnel et l'existence d'un contrat à titre onéreux (« s'engage à payer le prix »). L'obligation de médiateur de la consommation **ne paraît pas applicable**. Il s'agit d'une lecture des textes, non d'une affirmation explicite d'une source officielle sur les services gratuits : **le cas d'un service numérique gratuit n'est pas traité expressément** dans les pages consultées — non vérifié sur source officielle.
- ⚠️ Nuance importante : le droit de la consommation issu de la directive 2019/2161 tend à qualifier de « contrat » la fourniture d'un service numérique contre des **données personnelles**. Ce point n'a pas été vérifié dans cette recherche — **non vérifié sur source officielle** ; à faire trancher.
- **Si le service devient payant** (abonnement, option premium) : l'éditeur devient professionnel, un contrat de prestation de services onéreux existe, et l'obligation de désigner un médiateur inscrit sur la liste de l'art. L.615-1 s'applique, avec l'information obligatoire sur le site et dans les CGV (https://www.economie.gouv.fr/mediation-conso/vous-etes-professionnel et https://www.economie.gouv.fr/mediation-conso/vous-etes-un-professionnel/vos-principales-obligations-0).

### 8.3 CGU vs CGV

« **Il ne faut pas confondre les conditions générales de vente (CGV) avec les conditions générales d'utilisation (CGU)**. Les CGU servent à réglementer l'utilisation d'un service (un site internet notamment), tandis que les CGV servent à encadrer les relations commerciales » (https://entreprendre.service-public.fr/vosdroits/F33527). Les CGU ne sont donc pas juridiquement obligatoires en tant que telles ; elles restent fortement recommandées (règles d'usage, responsabilité, résiliation, modération).

En cas de passage au payant à distance avec des consommateurs : les CGV deviennent **obligatoires sur le site**, avec l'information précontractuelle des articles L111-1, R111-1 et R111-2 du code de la consommation (https://www.economie.gouv.fr/cedef/fiches-pratiques/que-doivent-contenir-les-conditions-generales-de-vente) ; « Le non-respect de cette obligation d'information est puni de **3 000 € d'amende pour l'entreprise individuelle (dont micro-entrepreneur) et 15 000 € pour une société** » (https://entreprendre.service-public.fr/vosdroits/F23455). Le droit de rétractation de 14 jours (art. L221-18) s'appliquerait également aux contrats à distance avec des consommateurs — **non vérifié verbatim sur source officielle** dans cette recherche.

### 8.4 Remarque sur le statut

Si le service devient payant, la création d'une structure est nécessaire. Le régime le plus léger est la **micro-entreprise** : formalités gratuites via le guichet unique de l'INPI (formalites.entreprises.gouv.fr), plafond de chiffre d'affaires de **77 700 €** pour les prestations de services BIC/BNC, abattement forfaitaire de 34 % pour les prestations de service non commerciales et 50 % pour les prestations de service commerciales, domiciliation obligatoire (https://www.economie.gouv.fr/entreprises/gerer-sa-micro-entreprise/comment-creer-une-micro-entreprise, https://www.economie.gouv.fr/cedef/fiches-pratiques/micro-entrepreneur-auto-entrepreneur et https://entreprendre.service-public.fr/vosdroits/F23961). Les activités du numérique non réglementées sont admises en micro-entreprise (https://www.economie.gouv.fr/entreprises/gerer-sa-micro-entreprise/quelles-activites-peut-exercer-en-micro-entreprise).

---

## Synthèse opérationnelle

| Sujet | Obligatoire aujourd'hui ? | Base |
|---|---|---|
| Mentions légales complètes | Oui, mais anonymat possible si édition « à titre non professionnel » (identité communiquée à l'hébergeur) | art. 1er-1 loi 2004-575 |
| Identité du responsable de traitement dans la politique de confidentialité | Oui, sans exception | art. 13.1 a) RGPD |
| Registre des traitements | Oui (traitement non occasionnel ⇒ dérogation < 250 employés inapplicable) | art. 30 RGPD |
| Bandeau de consentement cookies | Non si uniquement cookie de session d'authentification | exemptions CNIL / art. 82 LIL |
| Information sur les cookies exemptés | Recommandée ; RGPD applicable aux données associées | CNIL |
| AIPD | Probablement non en l'état ; à réévaluer (enregistrement, mineurs, échelle) | art. 35 RGPD + listes CNIL |
| Conservation des données de connexion | Incertain ; a priori non si pas de stockage de contenus tiers | art. 6 LCEN + décret 2021-1362 |
| DPA art. 28 avec chaque prestataire | Oui | art. 28 RGPD |
| Vérification DPF / CCT + AITD si prestataire US | Oui si transfert hors UE | déc. adéquation 10/07/2023 |
| Médiateur de la consommation | A priori non (gratuit, non professionnel) ; oui si payant | art. L612-1 c. conso |
| CGU | Non obligatoires ; CGV obligatoires si payant avec consommateurs | service-public.fr |

---

## Points à faire valider par un avocat

1. **Qualification « édition à titre non professionnel »** (art. 1er-1, II loi 2004-575) : un service gratuit rattaché à un projet commercial (NovaLuth), même sans revenu, permet-il de bénéficier de la dispense d'identification publique ? Aucune définition officielle du seuil n'a été trouvée. Le choix a un effet direct : anonymat possible ou publication de nom, prénoms, domicile et téléphone.
2. **Qualification d'hébergeur au sens du 2 du I de l'art. 6 LCEN** : un service de signalisation WebRTC (+ éventuel relais TURN, salles nommées, messages persistants) stocke-t-il des « contenus fournis par des destinataires du service » ? C'est le déclencheur des obligations de conservation du décret n° 2021-1362 et du régime de responsabilité/notification. Point le plus incertain du dossier.
3. **Contenu exact du décret n° 2021-1362** : catégories de données et durées applicables article par article, et maintien ou non de la clause « dans la mesure où les personnes les collectent habituellement » de l'ancien décret 2011-219. Non vérifiable en lecture automatisée sur Legifrance.
4. **AIPD** : le contenu des communications audio/vidéo constitue-t-il une donnée « hautement personnelle » au sens du critère 4 du CEPD malgré le chiffrement de bout en bout et l'architecture P2P ? Combinaison éventuelle avec le critère 8 (usage innovant) et le critère 5 (échelle).
5. **Statut du responsable de traitement avant création d'entreprise** : une personne physique non immatriculée peut-elle valablement être responsable de traitement, et quelles conséquences en termes de responsabilité personnelle illimitée et d'assurance ? Non traité par les sources consultées.
6. **Mineurs** : politique d'âge minimum (art. 45 loi Informatique et Libertés, majorité numérique à 15 ans en France) et conséquences sur l'AIPD et sur le consentement. Non vérifié sur source officielle dans cette recherche.
7. **Fourniture d'un service numérique « contre des données personnelles »** : cette qualification, issue de la directive (UE) 2019/2161, fait-elle basculer un service gratuit dans le champ du code de la consommation (médiation, information précontractuelle, rétractation) ?
8. **Transferts hors UE** : statut de certification DPF de l'hébergeur retenu (Replit, Inc. ou autre) et portée de cette certification ; nécessité et contenu d'une AITD. Le statut de Replit n'a pas été vérifié ici.
9. **Chiffrement et obligations de déchiffrement** : compatibilité du chiffrement de bout en bout avec les demandes éventuelles de l'autorité judiciaire. Hors périmètre des sources consultées.
10. **Modération et signalement des contenus illicites** : obligations éventuelles au titre du DSA / de l'art. 6 LCEN pour un service de communication en temps réel (l'art. 6 en vigueur mentionne une sanction pouvant atteindre 6 % du chiffre d'affaires mondial pour manquement habituel aux obligations de l'art. 18 du DSA — https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000049577522). Applicabilité à une micro-structure non analysée.
11. **Sanction de 375 000 €** pour la personne morale : vérifier le mécanisme de l'art. 131-38 du code pénal (non lu verbatim) ; montant confirmé par https://entreprendre.service-public.fr/vosdroits/F37351.
12. **Assurance responsabilité civile professionnelle** et clauses de limitation de responsabilité dans les CGU pour un service gratuit. Non traité par les sources consultées.
