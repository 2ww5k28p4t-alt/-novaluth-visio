/**
 * NovaLuth Visio — serveur de signalisation WebRTC + authentification
 * ==================================================================
 * Ce serveur ne transporte AUCUN media audio/video. Il assure :
 *   1. l'authentification par comptes individuels (bcrypt)
 *   2. la protection des salles par mot de passe
 *   3. le relais de signalisation (SDP + candidats ICE)
 *   4. la fourniture d'identifiants TURN temporaires (HMAC-SHA1)
 *   5. un journal d'acces minimal et auto-purge
 *
 * Le media circule directement de navigateur a navigateur, chiffre
 * en DTLS-SRTP. Aucun serveur de medias (SFU/MCU), aucun
 * enregistrement cote serveur.
 * ==================================================================
 */

'use strict';

require('dotenv').config();

const crypto = require('crypto');
const path = require('path');
const http = require('http');
const express = require('express');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const { Server } = require('socket.io');

const users = require('./lib/users');
const audit = require('./lib/audit');
const session = require('./lib/session');

// ==================================================================
// Configuration
// ==================================================================
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

const APP_NAME = process.env.APP_NAME || 'NovaLuth Visio';
const PUBLIC_URL = process.env.PUBLIC_URL || 'https://visio.novaluth.com';

const STUN_URL = process.env.STUN_URL || '';
const TURN_HOST = process.env.TURN_HOST || '';
const TURN_TLS_443 = String(process.env.TURN_TLS_443 || 'false') === 'true';
const TURN_SECRET = process.env.TURN_STATIC_AUTH_SECRET || '';
const TURN_USERNAME = process.env.TURN_USERNAME || '';
const TURN_PASSWORD = process.env.TURN_PASSWORD || '';
const TURN_TTL = parseInt(process.env.TURN_TTL || '43200', 10);

const MAX_PEERS = parseInt(process.env.MAX_PEERS_PER_ROOM || '8', 10);
const FORCE_RELAY = String(process.env.FORCE_RELAY || 'false') === 'true';
const SESSION_TTL_HOURS = parseInt(process.env.SESSION_TTL_HOURS || '12', 10);
const LOG_RETENTION_DAYS = parseInt(process.env.LOG_RETENTION_DAYS || '90', 10);
const SELF_REGISTRATION = String(process.env.SELF_REGISTRATION || 'false') === 'true';

// Secret de signature des sessions. En production il DOIT venir des
// Secrets : sinon toutes les sessions sont invalidees a chaque
// redemarrage du serveur.
const SESSION_SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex');
const SESSION_TTL = SESSION_TTL_HOURS * 3600;
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

audit.configure({
  retentionDays: LOG_RETENTION_DAYS,
  salt: process.env.LOG_SALT || SESSION_SECRET
});
setInterval(() => audit.purge(), 24 * 3600 * 1000).unref();

// Creation du premier administrateur
const seed = users.seedAdmin({
  login: process.env.ADMIN_LOGIN,
  password: process.env.ADMIN_PASSWORD,
  displayName: process.env.ADMIN_NAME
});

// ==================================================================
// Application Express
// ==================================================================
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(express.json({ limit: '32kb' }));

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'"],
        'style-src': ["'self'"],
        'img-src': ["'self'", 'data:', 'blob:'],
        'media-src': ["'self'", 'blob:'],
        'font-src': ["'self'"],
        'connect-src': ["'self'", 'ws:', 'wss:'],
        'frame-ancestors': ["'none'"],
        'base-uri': ["'self'"],
        'form-action': ["'self'"],
        'object-src': ["'none'"]
      }
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'no-referrer' }
  })
);

app.use((req, res, next) => {
  res.setHeader(
    'Permissions-Policy',
    'caméra=(self), microphone=(self), display-capture=(self), geolocation=(), payment=()'
  );
  next();
});

function clientIp(req) {
  return (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || req.socket.remoteAddress;
}

// ------------------------------------------------------------------
// Middleware d'authentification
// ------------------------------------------------------------------
function currentUser(req) {
  const cookies = session.parseCookies(req.headers.cookie);
  const payload = session.readToken(cookies[session.COOKIE_NAME], SESSION_SECRET);
  if (!payload) return null;
  const user = users.findByLogin(payload.login);
  if (!user) return null; // compte supprime : la session ne vaut plus rien
  return users.publicView(user);
}

function requireAuth(req, res, next) {
  const user = currentUser(req);
  if (!user) {
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ ok: false, error: 'Authentification requise.' });
    }
    return res.redirect(`/connexion?suivant=${encodeURIComponent(req.originalUrl)}`);
  }
  req.user = user;
  next();
}

function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (req.user.role !== 'admin') {
      if (req.path.startsWith('/api/')) {
        return res.status(403).json({ ok: false, error: 'Accès réservé aux administrateurs.' });
      }
      return res.status(403).send('Accès réservé aux administrateurs.');
    }
    next();
  });
}

// ------------------------------------------------------------------
// Limitation du debit des tentatives de connexion (par IP)
// ------------------------------------------------------------------
const loginAttempts = new Map(); // ipHash -> { count, firstAt }
const LOGIN_WINDOW = 15 * 60 * 1000;
const LOGIN_MAX = 15;

function throttleLogin(ip) {
  const key = audit.fingerprint(ip) || 'inconnu';
  const now = Date.now();
  const entry = loginAttempts.get(key);

  if (!entry || now - entry.firstAt > LOGIN_WINDOW) {
    loginAttempts.set(key, { count: 1, firstAt: now });
    return { allowed: true };
  }
  entry.count += 1;
  if (entry.count > LOGIN_MAX) {
    const minutes = Math.ceil((LOGIN_WINDOW - (now - entry.firstAt)) / 60000);
    return { allowed: false, minutes };
  }
  return { allowed: true };
}

setInterval(() => {
  const now = Date.now();
  loginAttempts.forEach((entry, key) => {
    if (now - entry.firstAt > LOGIN_WINDOW) loginAttempts.delete(key);
  });
}, LOGIN_WINDOW).unref();

// ==================================================================
// Pages
// ==================================================================
const PUBLIC_DIR = path.join(__dirname, 'public');

app.get('/', (req, res) => {
  res.redirect(currentUser(req) ? '/app' : '/connexion');
});

app.get('/connexion', (req, res) => {
  if (currentUser(req)) return res.redirect('/app');
  res.sendFile(path.join(PUBLIC_DIR, 'connexion.html'));
});

app.get('/app', requireAuth, (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'app.html'));
});

app.get('/admin', requireAdmin, (req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, 'admin.html'));
});

// Les pages HTML protegees ne doivent jamais etre servies en direct
app.use((req, res, next) => {
  if (/^\/(app|admin)\.html$/.test(req.path)) return res.redirect(req.path.replace('.html', ''));
  next();
});

// Ressources statiques : CSS, JS, pages legales (toutes publiques)
app.use(express.static(PUBLIC_DIR, { index: false, maxAge: '1h', etag: true }));

// ==================================================================
// API — authentification
// ==================================================================
app.post('/api/login', (req, res) => {
  const ip = clientIp(req);
  const limit = throttleLogin(ip);
  if (!limit.allowed) {
    audit.record('login_bloque_debit', { ip, ok: false });
    return res.status(429).json({
      ok: false,
      error: `Trop de tentatives. Réessayez dans ${limit.minutes} minute(s).`
    });
  }

  const { login, password } = req.body || {};
  const result = users.verify(login, password);

  if (!result.ok) {
    audit.record('login_echec', { ip, login: String(login || '').toLowerCase(), ok: false });
    return res.status(401).json({ ok: false, error: result.error });
  }

  const token = session.createToken(
    { login: result.user.login, role: result.user.role },
    SESSION_SECRET,
    SESSION_TTL
  );
  res.setHeader('Set-Cookie', session.buildCookie(token, {
    ttlSeconds: SESSION_TTL,
    secure: IS_PRODUCTION
  }));

  audit.record('login_reussi', { ip, login: result.user.login, ok: true });
  res.json({ ok: true, user: result.user });
});

app.post('/api/logout', (req, res) => {
  const user = currentUser(req);
  res.setHeader('Set-Cookie', session.clearCookie({ secure: IS_PRODUCTION }));
  if (user) audit.record('deconnexion', { ip: clientIp(req), login: user.login, ok: true });
  res.json({ ok: true });
});

app.get('/api/me', requireAuth, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ok: true, user: req.user });
});

// Changement de son propre mot de passe
app.post('/api/password', requireAuth, (req, res) => {
  const { current, next: nextPassword } = req.body || {};
  const check = users.verify(req.user.login, current);
  if (!check.ok) return res.status(401).json({ ok: false, error: 'Mot de passe actuel incorrect.' });

  const stored = users.findByLogin(req.user.login);
  const result = users.setPassword(stored.id, nextPassword);
  if (!result.ok) return res.status(400).json(result);

  audit.record('mot_de_passe_change', { ip: clientIp(req), login: req.user.login, ok: true });
  res.json({ ok: true });
});

// Auto-inscription, desactivee par defaut
app.post('/api/register', (req, res) => {
  if (!SELF_REGISTRATION) {
    return res.status(403).json({
      ok: false,
      error: "L'inscription libre est désactivée. Demandez un compte a l'administrateur."
    });
  }
  const { login, password, displayName } = req.body || {};
  const result = users.create({ login, password, displayName, role: 'user' });
  if (!result.ok) return res.status(400).json(result);
  audit.record('compte_cree_auto', { ip: clientIp(req), login: result.user.login, ok: true });
  res.json(result);
});

// ==================================================================
// API — administration
// ==================================================================
app.get('/api/admin/users', requireAdmin, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ok: true, users: users.list() });
});

app.post('/api/admin/users', requireAdmin, (req, res) => {
  const { login, password, displayName, role } = req.body || {};
  const result = users.create({ login, password, displayName, role, mustChangePassword: true });
  if (!result.ok) return res.status(400).json(result);
  audit.record('compte_cree', { ip: clientIp(req), login: result.user.login, ok: true });
  res.json(result);
});

app.post('/api/admin/users/:id/password', requireAdmin, (req, res) => {
  const result = users.setPassword(req.params.id, (req.body || {}).password, {
    mustChangePassword: true
  });
  if (!result.ok) return res.status(400).json(result);
  audit.record('mot_de_passe_reinitialise', { ip: clientIp(req), login: req.user.login, ok: true });
  res.json({ ok: true });
});

app.delete('/api/admin/users/:id', requireAdmin, (req, res) => {
  const result = users.remove(req.params.id);
  if (!result.ok) return res.status(400).json(result);
  audit.record('compte_supprime', { ip: clientIp(req), login: req.user.login, ok: true });
  res.json({ ok: true });
});

app.get('/api/admin/logs', requireAdmin, (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ ok: true, retentionDays: LOG_RETENTION_DAYS, entries: audit.tail(200) });
});

// Droit d'accès (RGPD art. 15) : export des données d'un compte
app.get('/api/admin/export/:login', requireAdmin, (req, res) => {
  const user = users.findByLogin(req.params.login);
  res.set('Cache-Control', 'no-store');
  res.json({
    ok: true,
    compte: user ? users.publicView(user) : null,
    journal: audit.exportForLogin(req.params.login),
    remarque: "Aucun contenu de communication n'est conserve par le service."
  });
});

// Droit a l'effacement (RGPD art. 17)
app.delete('/api/admin/export/:login', requireAdmin, (req, res) => {
  const result = audit.eraseForLogin(req.params.login);
  audit.record('effacement_journal', { ip: clientIp(req), login: req.user.login, ok: true });
  res.json({ ok: true, ...result });
});

// ==================================================================
// API — configuration WebRTC
// ==================================================================
// TURN_TLS_443 : a mettre a true seulement si Coturn ecoute vraiment
// sur le port 443. Dans le deploiement tout-en-un sur un seul serveur
// europeen, le port 443 est occupe par le proxy web : laissez false,
// sinon le navigateur perd du temps sur un port ferme.
function turnUrls() {
  const urls = [
    `turn:${TURN_HOST}:3478?transport=udp`,
    `turn:${TURN_HOST}:3478?transport=tcp`,
    `turns:${TURN_HOST}:5349?transport=tcp`
  ];
  if (TURN_TLS_443) urls.push(`turns:${TURN_HOST}:443?transport=tcp`);
  return urls;
}

function buildIceServers(userId) {
  const iceServers = [];
  if (STUN_URL) iceServers.push({ urls: STUN_URL });

  if (TURN_HOST && TURN_SECRET) {
    const expiry = Math.floor(Date.now() / 1000) + TURN_TTL;
    const username = `${expiry}:${userId}`;
    const credential = crypto.createHmac('sha1', TURN_SECRET).update(username).digest('base64');
    iceServers.push({ urls: turnUrls(), username, credential });
  } else if (TURN_HOST && TURN_USERNAME && TURN_PASSWORD) {
    iceServers.push({
      urls: turnUrls(),
      username: TURN_USERNAME,
      credential: TURN_PASSWORD
    });
  }
  return iceServers;
}

app.get('/api/ice', requireAuth, (req, res) => {
  const iceServers = buildIceServers(crypto.randomBytes(6).toString('hex'));
  res.set('Cache-Control', 'no-store');
  res.json({
    iceServers,
    iceTransportPolicy: FORCE_RELAY ? 'relay' : 'all',
    iceCandidatePoolSize: 2,
    bundlePolicy: 'max-bundle',
    rtcpMuxPolicy: 'require',
    warning: iceServers.length === 0
      ? "Aucun serveur STUN/TURN configuré : les appels ne fonctionneront qu'en reseau local."
      : null
  });
});

app.get('/api/config', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({
    appName: APP_NAME,
    publicUrl: PUBLIC_URL,
    maxPeers: MAX_PEERS,
    forceRelay: FORCE_RELAY,
    selfRegistration: SELF_REGISTRATION,
    minPasswordLength: users.MIN_PASSWORD_LENGTH
  });
});

app.get('/healthz', (req, res) => res.json({ status: 'ok' }));

// ==================================================================
// Signalisation Socket.IO
// ==================================================================
const server = http.createServer(app);
const io = new Server(server, {
  serveClient: true,
  cors: { origin: false },
  maxHttpBufferSize: 1e5,
  pingTimeout: 30000
});

/** roomId -> { passwordHash, createdBy, createdAt, peers: Map(socketId -> {name, login}) } */
const rooms = new Map();

function sanitize(value, maxLength) {
  return String(value || '').replace(/[<>"'`\\]/g, '').trim().slice(0, maxLength);
}

/**
 * Normalisation du nom de salle : minuscules, espaces convertis en
 * tirets, accents et caracteres speciaux supprimes.
 */
function normalizeRoom(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\-_ ]/g, '')
    .replace(/[\s_]+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60);
}

// Seules les connexions authentifiees peuvent ouvrir un socket.
io.use((socket, next) => {
  const cookies = session.parseCookies(socket.handshake.headers.cookie);
  const payload = session.readToken(cookies[session.COOKIE_NAME], SESSION_SECRET);
  if (!payload) return next(new Error('non-authentifie'));

  const user = users.findByLogin(payload.login);
  if (!user) return next(new Error('compte-inconnu'));

  socket.data.login = user.login;
  socket.data.displayName = user.displayName;
  socket.data.role = user.role;
  next();
});

io.on('connection', (socket) => {
  let currentRoom = null;
  const ip = (socket.handshake.headers['x-forwarded-for'] || '').split(',')[0].trim()
    || socket.handshake.address;

  socket.on('join', async (payload = {}, ack) => {
    const roomId = normalizeRoom(payload.room);
    const roomPassword = String(payload.roomPassword || '');
    const name = sanitize(payload.name, 24) || socket.data.displayName;

    const reply = (data) => typeof ack === 'function' && ack(data);

    if (roomId.length < 2) {
      return reply({ ok: false, error: 'Nom de salle invalide (2 caractères minimum).' });
    }

    let room = rooms.get(roomId);

    // Premiere personne : elle cree la salle et definit son mot de passe
    if (!room) {
      room = {
        passwordHash: roomPassword ? bcrypt.hashSync(roomPassword, 10) : null,
        createdBy: socket.data.login,
        createdAt: Date.now(),
        peers: new Map()
      };
      rooms.set(roomId, room);
    } else {
      // Salle existante protegee : le mot de passe est exige
      if (room.passwordHash) {
        if (!roomPassword) {
          return reply({ ok: false, error: 'Cette salle est protégée par un mot de passe.', needRoomPassword: true });
        }
        if (!bcrypt.compareSync(roomPassword, room.passwordHash)) {
          audit.record('salle_mdp_incorrect', { ip, login: socket.data.login, room: roomId, ok: false });
          return reply({ ok: false, error: 'Mot de passe de salle incorrect.', needRoomPassword: true });
        }
      }
      if (room.peers.size >= MAX_PEERS) {
        return reply({ ok: false, error: `Salle pleine (${MAX_PEERS} participants maximum).` });
      }
    }

    currentRoom = roomId;
    socket.data.name = name;
    socket.join(roomId);
    room.peers.set(socket.id, { name, login: socket.data.login });

    const existing = [];
    for (const [id, info] of room.peers) {
      if (id !== socket.id) existing.push({ id, name: info.name });
    }

    socket.to(roomId).emit('peer-joined', { id: socket.id, name });

    reply({
      ok: true,
      selfId: socket.id,
      room: roomId,
      protected: !!room.passwordHash,
      isCreator: room.createdBy === socket.data.login,
      peers: existing
    });

    audit.record('salle_rejointe', { ip, login: socket.data.login, room: roomId, ok: true });
    console.log(`[join] ${socket.data.login} -> "${roomId}" (${room.peers.size} pairs)`);
  });

  // Relais opaque : le serveur ne lit ni ne modifie le contenu SDP/ICE
  socket.on('signal', ({ to, data } = {}) => {
    if (!to || !data || !currentRoom) return;
    const room = rooms.get(currentRoom);
    if (!room || !room.peers.has(to)) return; // interdit de signaler hors de sa salle
    io.to(to).emit('signal', { from: socket.id, name: socket.data.name, data });
  });

  socket.on('chat', ({ text } = {}) => {
    if (!currentRoom) return;
    const message = sanitize(text, 800);
    if (!message) return;
    io.to(currentRoom).emit('chat', {
      from: socket.id,
      name: socket.data.name,
      text: message,
      at: Date.now()
    });
  });

  socket.on('state', (state = {}) => {
    if (!currentRoom) return;
    socket.to(currentRoom).emit('state', {
      from: socket.id,
      audio: !!state.audio,
      video: !!state.video
    });
  });

  socket.on('disconnect', () => {
    if (!currentRoom) return;
    const room = rooms.get(currentRoom);
    if (room) {
      room.peers.delete(socket.id);
      // Salle vide : elle disparait, son mot de passe avec elle.
      if (room.peers.size === 0) rooms.delete(currentRoom);
    }
    socket.to(currentRoom).emit('peer-left', { id: socket.id });
    audit.record('salle_quittee', { ip, login: socket.data.login, room: currentRoom, ok: true });
  });
});

// ==================================================================
// Demarrage
// ==================================================================
server.listen(PORT, HOST, () => {
  const ice = buildIceServers('boot');
  console.log('============================================================');
  console.log(`  ${APP_NAME} — http://${HOST}:${PORT}`);
  console.log(`  URL publique declaree : ${PUBLIC_URL}`);
  console.log(`  Comptes enregistres : ${users.count()}`);
  if (seed.ok) console.log(`  Administrateur créé : ${seed.user.login}`);
  console.log(`  Duree de session : ${SESSION_TTL_HOURS} h`);
  console.log(`  Conservation du journal : ${LOG_RETENTION_DAYS} jours`);
  console.log(`  Politique ICE : ${FORCE_RELAY ? 'relais forcé' : 'P2P direct prioritaire'}`);
  console.log(`  Serveurs ICE configurés : ${ice.length}`);

  if (users.count() === 0) {
    console.warn('  ATTENTION : aucun compte. Renseignez ADMIN_LOGIN et ADMIN_PASSWORD.');
  }
  if (!process.env.SESSION_SECRET) {
    console.warn('  ATTENTION : SESSION_SECRET absent. Les sessions seront perdues au redemarrage.');
  }
  if (ice.length === 0) {
    console.warn('  ATTENTION : aucun STUN/TURN. Renseignez STUN_URL et TURN_HOST.');
  }
  console.log('============================================================');
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));
