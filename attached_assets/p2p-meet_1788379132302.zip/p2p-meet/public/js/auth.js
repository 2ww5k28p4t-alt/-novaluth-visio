/* ==================================================================
   Page de connexion — NovaLuth Visio
   ================================================================== */

'use strict';

(function () {
  const $ = (id) => document.getElementById(id);

  const formLogin = $('form-login');
  const inputLogin = $('input-login');
  const inputPassword = $('input-password');
  const btnLogin = $('btn-login');
  const loginError = $('login-error');

  const formPassword = $('form-password');
  const cpLogin = $('cp-login');
  const cpCurrent = $('cp-current');
  const cpNext = $('cp-next');
  const cpMessage = $('cp-message');
  const cpHint = $('cp-hint');
  const toastEl = $('toast');

  let minLength = 12;
  let toastTimer = null;

  function toast(message, duration = 3200) {
    toastEl.textContent = message;
    toastEl.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.add('hidden'), duration);
  }

  function nextUrl() {
    const params = new URLSearchParams(location.search);
    const target = params.get('suivant');
    // On n'accepte qu'un chemin interne : evite une redirection ouverte
    return target && /^\/[a-zA-Z0-9\-_/?=&.]*$/.test(target) ? target : '/app';
  }

  fetch('/api/config')
    .then((r) => r.json())
    .then((config) => {
      minLength = config.minPasswordLength || 12;
      cpHint.textContent = `${minLength} caractères minimum.`;
    })
    .catch(() => {});

  formLogin.addEventListener('submit', async (event) => {
    event.preventDefault();
    loginError.textContent = '';
    btnLogin.disabled = true;
    btnLogin.textContent = 'Connexion…';

    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          login: inputLogin.value,
          password: inputPassword.value
        })
      });
      const data = await response.json();

      if (!response.ok || !data.ok) {
        loginError.textContent = data.error || 'Connexion refusée.';
        inputPassword.value = '';
        return;
      }

      if (data.user.mustChangePassword) {
        toast('Pensez a changer votre mot de passe provisoire.');
      }
      location.href = nextUrl();
    } catch (_) {
      loginError.textContent = 'Serveur injoignable. Vérifiez votre connexion.';
    } finally {
      btnLogin.disabled = false;
      btnLogin.textContent = 'Se connecter';
    }
  });

  formPassword.addEventListener('submit', async (event) => {
    event.preventDefault();
    cpMessage.textContent = '';
    cpMessage.classList.remove('success');

    if (cpNext.value.length < minLength) {
      cpMessage.textContent = `Le nouveau mot de passe doit contenir au moins ${minLength} caractères.`;
      return;
    }

    try {
      // On ouvre d'abord une session avec le mot de passe actuel,
      // puis on effectue le changement.
      const loginResponse = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ login: cpLogin.value, password: cpCurrent.value })
      });
      const loginData = await loginResponse.json();
      if (!loginResponse.ok || !loginData.ok) {
        cpMessage.textContent = loginData.error || 'Identifiants incorrects.';
        return;
      }

      const response = await fetch('/api/password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ current: cpCurrent.value, next: cpNext.value })
      });
      const data = await response.json();

      if (!response.ok || !data.ok) {
        cpMessage.textContent = data.error || 'Changement impossible.';
        return;
      }

      cpMessage.classList.add('success');
      cpMessage.textContent = 'Mot de passe modifié. Vous pouvez vous connecter.';
      cpCurrent.value = '';
      cpNext.value = '';
      await fetch('/api/logout', { method: 'POST' });
    } catch (_) {
      cpMessage.textContent = 'Serveur injoignable.';
    }
  });

  inputLogin.focus();
})();
