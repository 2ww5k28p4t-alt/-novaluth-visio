/* ==================================================================
   Page d'administration — NovaLuth Visio
   Gestion des comptes, consultation du journal, reponses RGPD.
   ================================================================== */

'use strict';

(function () {
  const $ = (id) => document.getElementById(id);
  const el = {
    usersBody: $('users-body'),
    logsBody: $('logs-body'),
    logNote: $('log-note'),
    formCreate: $('form-create'),
    newLogin: $('new-login'),
    newName: $('new-name'),
    newPassword: $('new-password'),
    newRole: $('new-role'),
    newHint: $('new-hint'),
    btnGenerate: $('btn-generate'),
    createMessage: $('create-message'),
    btnRefresh: $('btn-refresh'),
    btnLogout: $('btn-logout'),
    formRgpd: $('form-rgpd'),
    rgpdLogin: $('rgpd-login'),
    btnExport: $('btn-export'),
    btnErase: $('btn-erase'),
    rgpdOutput: $('rgpd-output'),
    toast: $('toast')
  };

  let minLength = 12;
  let toastTimer = null;

  function toast(message, duration = 3200) {
    el.toast.textContent = message;
    el.toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.add('hidden'), duration);
  }

  function formatDate(iso) {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleString('fr-FR', {
        day: '2-digit', month: '2-digit', year: '2-digit',
        hour: '2-digit', minute: '2-digit'
      });
    } catch (_) {
      return iso;
    }
  }

  function cell(row, text) {
    const td = document.createElement('td');
    td.textContent = text; // textContent : aucune injection HTML possible
    row.appendChild(td);
    return td;
  }

  async function api(url, options) {
    const response = await fetch(url, options);
    if (response.status === 401) { location.href = '/connexion?suivant=/admin'; return null; }
    const data = await response.json().catch(() => ({ ok: false, error: 'Réponse illisible.' }));
    if (!response.ok || !data.ok) throw new Error(data.error || 'Opération refusée.');
    return data;
  }

  // ---------------------------------------------------------------
  // Comptes
  // ---------------------------------------------------------------
  async function loadUsers() {
    try {
      const data = await api('/api/admin/users');
      if (!data) return;
      el.usersBody.textContent = '';

      if (data.users.length === 0) {
        const row = el.usersBody.insertRow();
        cell(row, 'Aucun compte.').colSpan = 5;
        return;
      }

      data.users.forEach((user) => {
        const row = el.usersBody.insertRow();
        cell(row, user.login);
        cell(row, user.displayName);
        cell(row, user.role === 'admin' ? 'Administrateur' : 'Utilisateur');
        cell(row, formatDate(user.lastLoginAt));

        const actions = document.createElement('td');
        actions.className = 'table__actions';

        const reset = document.createElement('button');
        reset.type = 'button';
        reset.className = 'btn btn--ghost btn--small';
        reset.textContent = 'Reinitialiser';
        reset.addEventListener('click', () => resetPassword(user));

        const del = document.createElement('button');
        del.type = 'button';
        del.className = 'btn btn--danger btn--small';
        del.textContent = 'Supprimer';
        del.addEventListener('click', () => removeUser(user));

        actions.appendChild(reset);
        actions.appendChild(del);
        row.appendChild(actions);
      });
    } catch (err) {
      el.usersBody.textContent = '';
      const row = el.usersBody.insertRow();
      cell(row, err.message).colSpan = 5;
    }
  }

  function randomPassword(length = 16) {
    const alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const values = new Uint32Array(length);
    crypto.getRandomValues(values);
    return Array.from(values, (v) => alphabet[v % alphabet.length]).join('');
  }

  async function resetPassword(user) {
    const password = randomPassword();
    if (!confirm(`Réinitialiser le mot de passe de "${user.login}" ?\n\nNouveau mot de passe provisoire :\n${password}\n\nNotez-le maintenant : il ne sera plus affiché.`)) return;
    try {
      await api(`/api/admin/users/${encodeURIComponent(user.id)}/password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      toast('Mot de passe réinitialisé.');
      loadUsers();
      loadLogs();
    } catch (err) {
      toast(err.message, 5000);
    }
  }

  async function removeUser(user) {
    if (!confirm(`Supprimer définitivement le compte "${user.login}" ?`)) return;
    try {
      await api(`/api/admin/users/${encodeURIComponent(user.id)}`, { method: 'DELETE' });
      toast('Compte supprime.');
      loadUsers();
      loadLogs();
    } catch (err) {
      toast(err.message, 5000);
    }
  }

  el.formCreate.addEventListener('submit', async (event) => {
    event.preventDefault();
    el.createMessage.textContent = '';
    el.createMessage.classList.remove('success');

    if (el.newPassword.value.length < minLength) {
      el.createMessage.textContent = `Le mot de passe doit contenir au moins ${minLength} caracteres.`;
      return;
    }

    try {
      await api('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          login: el.newLogin.value,
          displayName: el.newName.value,
          password: el.newPassword.value,
          rôle: el.newRole.value
        })
      });
      el.createMessage.classList.add('success');
      el.createMessage.textContent =
        `Compte cree. Communiquez le mot de passe provisoire a la personne concernee : ${el.newPassword.value}`;
      el.newLogin.value = '';
      el.newName.value = '';
      el.newPassword.value = '';
      loadUsers();
      loadLogs();
    } catch (err) {
      el.createMessage.textContent = err.message;
    }
  });

  el.btnGenerate.addEventListener('click', () => {
    el.newPassword.value = randomPassword();
    el.newPassword.focus();
  });

  // ---------------------------------------------------------------
  // Journal
  // ---------------------------------------------------------------
  const LABELS = {
    login_reussi: 'Connexion réussie',
    login_echec: 'Echec de connexion',
    login_bloque_debit: 'Connexion bloquée (trop de tentatives)',
    déconnexion: 'Déconnexion',
    compte_cree: 'Compte créé',
    compte_cree_auto: 'Compte créé (auto-inscription)',
    compte_supprime: 'Compte supprime',
    mot_de_passe_change: 'Mot de passe change',
    mot_de_passe_reinitialise: 'Mot de passe réinitialisé',
    salle_rejointe: 'Salle rejointe',
    salle_quittee: 'Salle quittee',
    salle_mdp_incorrect: 'Mot de passe de salle incorrect',
    effacement_journal: 'Effacement de journal'
  };

  async function loadLogs() {
    try {
      const data = await api('/api/admin/logs');
      if (!data) return;
      el.logNote.textContent =
        `Journalisation limitee aux evenements de securite, conservee ${data.retentionDays} jours puis supprimee automatiquement. `
        + "Les adresses IP sont remplacées par une empreinte irréversible. Aucun contenu de communication n'est enregistré.";

      el.logsBody.textContent = '';
      if (data.entries.length === 0) {
        const row = el.logsBody.insertRow();
        cell(row, 'Journal vide.').colSpan = 5;
        return;
      }

      data.entries.forEach((entry) => {
        const row = el.logsBody.insertRow();
        if (entry.ok === false) row.className = 'row--warn';
        cell(row, formatDate(entry.at));
        cell(row, LABELS[entry.event] || entry.event);
        cell(row, entry.login || '—');
        cell(row, entry.room || '—');
        cell(row, entry.ipHash || '—');
      });
    } catch (err) {
      el.logsBody.textContent = '';
      const row = el.logsBody.insertRow();
      cell(row, err.message).colSpan = 5;
    }
  }

  el.btnRefresh.addEventListener('click', () => { loadUsers(); loadLogs(); });

  // ---------------------------------------------------------------
  // Droits RGPD
  // ---------------------------------------------------------------
  el.formRgpd.addEventListener('submit', (event) => event.preventDefault());

  el.btnExport.addEventListener('click', async () => {
    const login = el.rgpdLogin.value.trim();
    if (!login) return;
    try {
      const data = await api(`/api/admin/export/${encodeURIComponent(login)}`);
      if (!data) return;
      el.rgpdOutput.classList.remove('hidden');
      el.rgpdOutput.textContent = JSON.stringify(data, null, 2);
    } catch (err) {
      toast(err.message, 5000);
    }
  });

  el.btnErase.addEventListener('click', async () => {
    const login = el.rgpdLogin.value.trim();
    if (!login) return;
    if (!confirm(`Effacer toutes les entrees de journal liees a "${login}" ? Cette action est irreversible.`)) return;
    try {
      const data = await api(`/api/admin/export/${encodeURIComponent(login)}`, { method: 'DELETE' });
      if (!data) return;
      toast(`${data.removed} entree(s) effacee(s).`);
      el.rgpdOutput.classList.add('hidden');
      loadLogs();
    } catch (err) {
      toast(err.message, 5000);
    }
  });

  el.btnLogout.addEventListener('click', async () => {
    try { await fetch('/api/logout', { method: 'POST' }); } catch (_) {}
    location.href = '/connexion';
  });

  // ---------------------------------------------------------------
  fetch('/api/config')
    .then((r) => r.json())
    .then((config) => {
      minLength = config.minPasswordLength || 12;
      el.newHint.textContent = `${minLength} caracteres minimum.`;
    })
    .catch(() => {});

  loadUsers();
  loadLogs();
})();
