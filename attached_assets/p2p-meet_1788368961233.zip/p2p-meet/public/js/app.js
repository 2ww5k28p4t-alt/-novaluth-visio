/* ==================================================================
   P2P Meet — client WebRTC en maillage (mesh) pair-a-pair
   ------------------------------------------------------------------
   Regle de negociation : c'est TOUJOURS le nouvel arrivant qui emet
   les offres vers les pairs deja presents. Cela supprime tout risque
   de collision de negociation (glare) sans code complexe.
   ================================================================== */

'use strict';

(function () {
  // ---------------------------------------------------------------
  // Etat global
  // ---------------------------------------------------------------
  const state = {
    socket: null,
    selfId: null,
    name: '',
    room: '',
    localStream: null,
    cameraTrack: null,      // piste camera d'origine (conservee pendant le partage d'ecran)
    screenStream: null,
    facingMode: 'user',
    audioOn: true,
    videoOn: true,
    sharing: false,
    rtcConfig: null,
    peers: new Map()        // socketId -> { pc, name, stream, tile }
  };

  // ---------------------------------------------------------------
  // Raccourcis DOM
  // ---------------------------------------------------------------
  const $ = (id) => document.getElementById(id);

  const el = {
    screenJoin: $('screen-join'),
    screenCall: $('screen-call'),
    formJoin: $('form-join'),
    inputName: $('input-name'),
    inputRoom: $('input-room'),
    inputCode: $('input-code'),
    fieldCode: $('field-code'),
    btnJoin: $('btn-join'),
    joinError: $('join-error'),
    noteIce: $('note-ice'),
    grid: $('grid'),
    roomLabel: $('room-label'),
    peerCount: $('peer-count'),
    connDot: $('conn-dot'),
    btnMic: $('btn-mic'),
    btnCam: $('btn-cam'),
    btnFlip: $('btn-flip'),
    btnShare: $('btn-share'),
    btnLeave: $('btn-leave'),
    btnCopy: $('btn-copy'),
    btnChat: $('btn-chat'),
    btnChatClose: $('btn-chat-close'),
    chatPanel: $('chat-panel'),
    chatLog: $('chat-log'),
    chatForm: $('chat-form'),
    chatInput: $('chat-input'),
    micState: $('mic-state'),
    camState: $('cam-state'),
    shareState: $('share-state'),
    toast: $('toast')
  };

  let toastTimer = null;
  function toast(message, duration = 3200) {
    el.toast.textContent = message;
    el.toast.classList.remove('hidden');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => el.toast.classList.add('hidden'), duration);
  }

  // ---------------------------------------------------------------
  // Initialisation : configuration serveur + parametres d'URL
  // ---------------------------------------------------------------
  async function init() {
    if (!navigator.mediaDevices || !window.RTCPeerConnection) {
      el.joinError.textContent =
        "Ce navigateur ne prend pas en charge WebRTC. Utilisez Safari, Chrome ou Firefox a jour, en HTTPS.";
      el.btnJoin.disabled = true;
      return;
    }

    if (location.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(location.hostname)) {
      el.joinError.textContent =
        "HTTPS est obligatoire pour acceder a la camera et au micro.";
    }

    // Pre-remplissage depuis l'URL : /?room=ma-salle&name=Alex
    const params = new URLSearchParams(location.search);
    if (params.get('room')) el.inputRoom.value = params.get('room');
    if (params.get('name')) el.inputName.value = params.get('name');
    const savedName = localStorage.getItem('p2pmeet.name');
    if (savedName && !el.inputName.value) el.inputName.value = savedName;

    try {
      const config = await fetch('/api/config').then((r) => r.json());
      if (config.accessCodeRequired) {
        el.fieldCode.classList.remove('field--hidden');
        el.inputCode.required = true;
      }
    } catch (_) { /* valeurs par defaut */ }

    try {
      state.rtcConfig = await fetch('/api/ice').then((r) => r.json());
      if (state.rtcConfig.warning) {
        el.noteIce.textContent = state.rtcConfig.warning;
      } else {
        const relay = state.rtcConfig.iceTransportPolicy === 'relay';
        el.noteIce.textContent = relay
          ? 'Serveurs STUN/TURN prives — mode relais force'
          : `Serveurs STUN/TURN prives (${state.rtcConfig.iceServers.length}) actifs`;
      }
    } catch (_) {
      el.noteIce.textContent = 'Impossible de recuperer la configuration ICE.';
    }
  }

  // ---------------------------------------------------------------
  // Acces camera / micro
  // ---------------------------------------------------------------
  async function getLocalStream() {
    const constraints = {
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true
      },
      video: {
        facingMode: state.facingMode,
        width: { ideal: 1280 },
        height: { ideal: 720 },
        frameRate: { ideal: 30, max: 30 }
      }
    };

    try {
      return await navigator.mediaDevices.getUserMedia(constraints);
    } catch (err) {
      // Repli : audio seul si la camera est indisponible
      if (err.name === 'NotFoundError' || err.name === 'OverconstrainedError') {
        toast('Camera indisponible : connexion en audio seul.');
        state.videoOn = false;
        return await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      }
      throw err;
    }
  }

  // ---------------------------------------------------------------
  // Tuiles video
  // ---------------------------------------------------------------
  function initials(name) {
    return (name || '?').trim().charAt(0).toUpperCase() || '?';
  }

  function createTile(id, name, isSelf) {
    const tile = document.createElement('div');
    tile.className = 'tile' + (isSelf ? ' tile--self' : '');
    tile.id = `tile-${id}`;

    const placeholder = document.createElement('div');
    placeholder.className = 'tile__placeholder';
    placeholder.textContent = initials(name);

    const video = document.createElement('video');
    video.autoplay = true;
    video.playsInline = true;
    video.muted = isSelf; // indispensable : evite le larsen sur son propre flux

    const label = document.createElement('div');
    label.className = 'tile__name';
    label.textContent = isSelf ? `${name} (vous)` : name;

    const flags = document.createElement('div');
    flags.className = 'tile__flags';

    tile.append(placeholder, video, label, flags);
    el.grid.appendChild(tile);
    refreshGridClass();
    return { tile, video, label, flags, placeholder };
  }

  function refreshGridClass() {
    const count = el.grid.children.length;
    el.grid.classList.toggle('grid--few', count <= 2);
    el.peerCount.textContent = String(count);
  }

  function setFlags(tileParts, { audio, video }) {
    tileParts.flags.innerHTML = '';
    if (!audio) {
      const f = document.createElement('span');
      f.className = 'flag flag--muted';
      f.textContent = 'micro coupe';
      tileParts.flags.appendChild(f);
    }
    if (!video) {
      const f = document.createElement('span');
      f.className = 'flag';
      f.textContent = 'camera off';
      tileParts.flags.appendChild(f);
    }
  }

  // ---------------------------------------------------------------
  // Creation d'une connexion pair-a-pair
  // ---------------------------------------------------------------
  function createPeer(peerId, peerName, isInitiator) {
    if (state.peers.has(peerId)) return state.peers.get(peerId);

    const pc = new RTCPeerConnection({
      iceServers: state.rtcConfig?.iceServers || [],
      iceTransportPolicy: state.rtcConfig?.iceTransportPolicy || 'all',
      bundlePolicy: 'max-bundle',
      rtcpMuxPolicy: 'require',
      iceCandidatePoolSize: 2
    });

    const tileParts = createTile(peerId, peerName, false);
    const entry = { pc, name: peerName, stream: new MediaStream(), tileParts, isInitiator };
    state.peers.set(peerId, entry);

    // Publication de nos pistes locales
    if (state.localStream) {
      state.localStream.getTracks().forEach((track) => pc.addTrack(track, state.localStream));
    }

    pc.ontrack = (event) => {
      event.streams[0].getTracks().forEach((track) => {
        if (!entry.stream.getTracks().includes(track)) entry.stream.addTrack(track);
      });
      tileParts.video.srcObject = entry.stream;
      tileParts.video.play().catch(() => {});
    };

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        state.socket.emit('signal', { to: peerId, data: { candidate: event.candidate } });
      }
    };

    pc.onconnectionstatechange = () => {
      const s = pc.connectionState;
      if (s === 'connected') {
        el.connDot.className = 'dot dot--on';
      } else if (s === 'failed') {
        el.connDot.className = 'dot dot--off';
        toast(`Connexion echouee avec ${entry.name}. Un serveur TURN est probablement necessaire.`);
        pc.restartIce?.();
      } else if (s === 'disconnected') {
        el.connDot.className = 'dot';
      }
    };

    if (isInitiator) {
      pc.onnegotiationneeded = async () => {
        try {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          state.socket.emit('signal', { to: peerId, data: { sdp: pc.localDescription } });
        } catch (err) {
          console.error('Erreur de negociation', err);
        }
      };
    }

    return entry;
  }

  async function handleSignal({ from, name, data }) {
    let entry = state.peers.get(from);

    // Un pair nous contacte avant que nous l'ayons enregistre
    if (!entry) {
      entry = createPeer(from, name || 'Invite', false);
    }

    const pc = entry.pc;

    try {
      if (data.sdp) {
        await pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
        if (data.sdp.type === 'offer') {
          const answer = await pc.createAnswer();
          await pc.setLocalDescription(answer);
          state.socket.emit('signal', { to: from, data: { sdp: pc.localDescription } });
        }
      } else if (data.candidate) {
        await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
      }
    } catch (err) {
      console.error('Erreur de signalisation', err);
    }
  }

  function removePeer(peerId) {
    const entry = state.peers.get(peerId);
    if (!entry) return;
    try { entry.pc.close(); } catch (_) {}
    entry.tileParts.tile.remove();
    state.peers.delete(peerId);
    refreshGridClass();
  }

  // ---------------------------------------------------------------
  // Connexion a la salle
  // ---------------------------------------------------------------
  async function join(evt) {
    evt.preventDefault();
    el.joinError.textContent = '';
    el.btnJoin.disabled = true;
    el.btnJoin.textContent = 'Connexion…';

    state.name = el.inputName.value.trim();
    // La normalisation definitive est faite par le serveur, qui renvoie
    // le nom de salle retenu dans sa reponse.
    state.room = el.inputRoom.value.trim();
    localStorage.setItem('p2pmeet.name', state.name);

    try {
      state.localStream = await getLocalStream();
    } catch (err) {
      el.joinError.textContent =
        err.name === 'NotAllowedError'
          ? "Acces a la camera ou au micro refuse. Autorisez-le dans les reglages du navigateur."
          : `Impossible d'acceder aux peripheriques : ${err.name}`;
      el.btnJoin.disabled = false;
      el.btnJoin.textContent = 'Rejoindre la salle';
      return;
    }

    state.cameraTrack = state.localStream.getVideoTracks()[0] || null;

    state.socket = io({ transports: ['websocket', 'polling'] });

    state.socket.on('connect', () => {
      state.socket.emit(
        'join',
        { room: state.room, name: state.name, code: el.inputCode.value },
        (res) => {
          if (!res || !res.ok) {
            el.joinError.textContent = (res && res.error) || 'Connexion refusee.';
            el.btnJoin.disabled = false;
            el.btnJoin.textContent = 'Rejoindre la salle';
            state.socket.disconnect();
            stopStream(state.localStream);
            return;
          }

          state.selfId = res.selfId;
          state.room = res.room || state.room;
          enterCall();

          // Nous initions les offres vers tous les pairs deja presents
          res.peers.forEach((peer) => createPeer(peer.id, peer.name, true));
        }
      );
    });

    state.socket.on('peer-joined', ({ id, name }) => {
      // Le nouvel arrivant enverra l'offre : nous restons passifs
      createPeer(id, name, false);
      toast(`${name} a rejoint la salle.`);
    });

    state.socket.on('signal', handleSignal);

    state.socket.on('peer-left', ({ id }) => {
      const entry = state.peers.get(id);
      if (entry) toast(`${entry.name} a quitte la salle.`);
      removePeer(id);
    });

    state.socket.on('state', ({ from, audio, video }) => {
      const entry = state.peers.get(from);
      if (entry) setFlags(entry.tileParts, { audio, video });
    });

    state.socket.on('chat', appendChat);

    state.socket.on('disconnect', () => {
      el.connDot.className = 'dot dot--off';
      toast('Connexion au serveur de signalisation perdue.');
    });
  }

  function enterCall() {
    el.screenJoin.classList.add('hidden');
    el.screenCall.classList.remove('hidden');
    el.roomLabel.textContent = state.room;

    const selfTile = createTile('self', state.name, true);
    selfTile.video.srcObject = state.localStream;
    selfTile.video.play().catch(() => {});
    state.selfTile = selfTile;
    setFlags(selfTile, { audio: state.audioOn, video: state.videoOn });

    history.replaceState(null, '', `?room=${encodeURIComponent(state.room)}`);
  }

  // ---------------------------------------------------------------
  // Controles
  // ---------------------------------------------------------------
  function broadcastState() {
    state.socket?.emit('state', { audio: state.audioOn, video: state.videoOn });
    if (state.selfTile) setFlags(state.selfTile, { audio: state.audioOn, video: state.videoOn });
  }

  function toggleMic() {
    const track = state.localStream?.getAudioTracks()[0];
    if (!track) return toast('Aucun micro detecte.');
    state.audioOn = !state.audioOn;
    track.enabled = state.audioOn;
    el.btnMic.setAttribute('aria-pressed', String(state.audioOn));
    el.micState.textContent = state.audioOn ? 'actif' : 'coupe';
    broadcastState();
  }

  function toggleCam() {
    const track = state.sharing ? state.cameraTrack : state.localStream?.getVideoTracks()[0];
    if (!track) return toast('Aucune camera detectee.');
    state.videoOn = !state.videoOn;
    track.enabled = state.videoOn;
    el.btnCam.setAttribute('aria-pressed', String(state.videoOn));
    el.camState.textContent = state.videoOn ? 'active' : 'coupee';
    broadcastState();
  }

  async function flipCamera() {
    if (state.sharing) return toast("Arretez le partage d'ecran d'abord.");
    state.facingMode = state.facingMode === 'user' ? 'environment' : 'user';

    try {
      const fresh = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: state.facingMode, width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false
      });
      const newTrack = fresh.getVideoTracks()[0];
      await replaceOutgoingVideo(newTrack);

      const old = state.localStream.getVideoTracks()[0];
      if (old) { state.localStream.removeTrack(old); old.stop(); }
      state.localStream.addTrack(newTrack);
      state.cameraTrack = newTrack;
      newTrack.enabled = state.videoOn;

      state.selfTile.video.srcObject = state.localStream;
      state.selfTile.tile.classList.toggle('tile--self', state.facingMode === 'user');
    } catch (err) {
      toast('Impossible de changer de camera sur cet appareil.');
      state.facingMode = state.facingMode === 'user' ? 'environment' : 'user';
    }
  }

  async function replaceOutgoingVideo(newTrack) {
    const tasks = [];
    state.peers.forEach(({ pc }) => {
      const sender = pc.getSenders().find((s) => s.track && s.track.kind === 'video');
      if (sender) tasks.push(sender.replaceTrack(newTrack));
    });
    await Promise.all(tasks);
  }

  async function toggleShare() {
    if (state.sharing) return stopShare();

    if (!navigator.mediaDevices.getDisplayMedia) {
      return toast("Le partage d'ecran n'est pas disponible sur ce navigateur.");
    }

    try {
      state.screenStream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: { ideal: 15, max: 30 } },
        audio: false
      });
      const screenTrack = state.screenStream.getVideoTracks()[0];
      await replaceOutgoingVideo(screenTrack);

      state.sharing = true;
      state.selfTile.video.srcObject = state.screenStream;
      state.selfTile.tile.classList.add('tile--screen');
      el.btnShare.classList.add('ctrl--active');
      el.shareState.textContent = 'en cours';

      screenTrack.addEventListener('ended', stopShare);
    } catch (err) {
      if (err.name !== 'NotAllowedError') toast("Partage d'ecran impossible.");
    }
  }

  async function stopShare() {
    if (!state.sharing) return;
    stopStream(state.screenStream);
    state.screenStream = null;
    state.sharing = false;

    if (state.cameraTrack && state.cameraTrack.readyState === 'live') {
      await replaceOutgoingVideo(state.cameraTrack);
    }
    state.selfTile.video.srcObject = state.localStream;
    state.selfTile.tile.classList.remove('tile--screen');
    el.btnShare.classList.remove('ctrl--active');
    el.shareState.textContent = 'partager';
  }

  function stopStream(stream) {
    stream?.getTracks().forEach((t) => t.stop());
  }

  function leave() {
    state.peers.forEach((_, id) => removePeer(id));
    stopStream(state.localStream);
    stopStream(state.screenStream);
    state.socket?.disconnect();
    location.href = location.pathname;
  }

  async function copyLink() {
    const url = `${location.origin}${location.pathname}?room=${encodeURIComponent(state.room)}`;
    try {
      await navigator.clipboard.writeText(url);
      toast("Lien d'invitation copie.");
    } catch (_) {
      toast(url);
    }
  }

  // ---------------------------------------------------------------
  // Chat (via la signalisation, pas de stockage serveur)
  // ---------------------------------------------------------------
  function appendChat({ from, name, text, at }) {
    const wrap = document.createElement('div');
    wrap.className = 'msg' + (from === state.selfId ? ' msg--self' : '');

    const meta = document.createElement('div');
    meta.className = 'msg__meta';
    const time = new Date(at || Date.now()).toLocaleTimeString('fr-FR', {
      hour: '2-digit',
      minute: '2-digit'
    });
    meta.textContent = `${from === state.selfId ? 'Vous' : name} · ${time}`;

    const body = document.createElement('div');
    body.className = 'msg__body';
    body.textContent = text; // textContent : aucune injection HTML possible

    wrap.append(meta, body);
    el.chatLog.appendChild(wrap);
    el.chatLog.scrollTop = el.chatLog.scrollHeight;

    if (el.chatPanel.classList.contains('hidden') && from !== state.selfId) {
      toast(`${name} : ${text.slice(0, 60)}`);
    }
  }

  function sendChat(evt) {
    evt.preventDefault();
    const text = el.chatInput.value.trim();
    if (!text) return;
    state.socket?.emit('chat', { text });
    el.chatInput.value = '';
  }

  // ---------------------------------------------------------------
  // Ecouteurs
  // ---------------------------------------------------------------
  el.formJoin.addEventListener('submit', join);
  el.btnMic.addEventListener('click', toggleMic);
  el.btnCam.addEventListener('click', toggleCam);
  el.btnFlip.addEventListener('click', flipCamera);
  el.btnShare.addEventListener('click', toggleShare);
  el.btnLeave.addEventListener('click', leave);
  el.btnCopy.addEventListener('click', copyLink);
  el.btnChat.addEventListener('click', () => el.chatPanel.classList.remove('hidden'));
  el.btnChatClose.addEventListener('click', () => el.chatPanel.classList.add('hidden'));
  el.chatForm.addEventListener('submit', sendChat);

  window.addEventListener('beforeunload', () => {
    stopStream(state.localStream);
    stopStream(state.screenStream);
  });

  init();
})();
