# P2P Meet — visioconférence 100 % pair-à-pair

Application prête à déployer sur Replit. Le serveur ne fait que de la **signalisation** :
il n'y a aucun serveur de médias (pas de SFU, pas de MCU). L'audio et la vidéo
circulent directement de navigateur à navigateur, chiffrés en DTLS-SRTP.

Ce projet est le compagnon du guide d'auto-hébergement WebRTC P2P sécurisé.

---

## Ce que contient le projet

```
p2p-meet/
├── server.js               # Serveur : fichiers statiques + signalisation + API TURN
├── package.json            # Dépendances (express, socket.io, helmet, dotenv)
├── .replit                 # Configuration Replit (commande de démarrage, port)
├── replit.nix              # Environnement Node.js 20
├── .env.example            # Modèle de variables — à recopier dans les Secrets
├── .gitignore
└── public/
    ├── index.html          # Interface (accueil + salle d'appel)
    ├── css/style.css       # Style unique, mobile-first, aucune police externe
    └── js/app.js           # Client WebRTC en maillage (mesh) pair-à-pair
```

Fonctions incluses : salles nommées, lien d'invitation, micro / caméra coupables,
bascule caméra avant-arrière, partage d'écran, chat texte, code d'accès optionnel,
indicateurs d'état des participants.

---

## Installation sur Replit — pas à pas

### 1. Créer le Repl

Deux méthodes, au choix.

**Méthode A — import du dossier (la plus simple depuis un iPhone)**

1. Aller sur [replit.com](https://replit.com) et se connecter
2. Bouton **+ Create Repl** → onglet **Import** → **Upload a folder / zip**
3. Envoyer l'archive `p2p-meet.zip` ou le dossier `p2p-meet`
4. Replit détecte Node.js automatiquement grâce au fichier `.replit`

**Méthode B — depuis GitHub**

1. Créer un dépôt GitHub, y déposer le contenu du dossier `p2p-meet`
2. Sur Replit : **+ Create Repl** → **Import from GitHub** → coller l'URL du dépôt

### 2. Installer les dépendances

Dans l'onglet **Shell** du Repl :

```bash
npm install
```

### 3. Renseigner les Secrets

Ouvrir l'outil **Secrets** (icône cadenas dans la barre latérale). Ne créez **pas**
de fichier `.env` sur Replit : il serait visible. Ajoutez ces clés une par une.

| Clé | Valeur | Obligatoire |
|---|---|---|
| `STUN_URL` | `stun:turn.votredomaine.fr:3478` | Oui en production |
| `TURN_HOST` | `turn.votredomaine.fr` | Oui en production |
| `TURN_STATIC_AUTH_SECRET` | le même que `static-auth-secret` dans `turnserver.conf` | Recommandé |
| `TURN_USERNAME` | login TURN (si pas de secret HMAC) | Alternative |
| `TURN_PASSWORD` | mot de passe TURN (si pas de secret HMAC) | Alternative |
| `MAX_PEERS_PER_ROOM` | `8` | Non |
| `ACCESS_CODE` | un code partagé, ou laissez vide | Non |
| `FORCE_RELAY` | `false` | Non |

Pour générer le secret HMAC, dans le Shell :

```bash
openssl rand -hex 32
```

Cette même valeur doit figurer dans le `turnserver.conf` de votre Coturn, sous
la directive `static-auth-secret=`.

### 4. Lancer

Appuyer sur **Run**. La console affiche :

```
P2P Meet demarre sur http://0.0.0.0:3000
Serveurs ICE configures : 2
```

Replit fournit automatiquement une URL en `https://…replit.dev`. HTTPS est
**obligatoire** : sans lui, les navigateurs refusent l'accès à la caméra.

### 5. Tester

1. Ouvrir l'URL du Repl, saisir un prénom et un nom de salle, puis **Rejoindre**
2. Autoriser la caméra et le micro
3. Appuyer sur **Lien** pour copier l'invitation
4. Ouvrir ce lien sur un second appareil, ou dans une fenêtre privée

Deux onglets du même navigateur fonctionnent aussi, mais coupez le micro de l'un
des deux pour éviter le larsen.

### 6. Passer en production

Pour un usage régulier, préférez **Deployments → Reserved VM** plutôt que
Autoscale : la signalisation repose sur des connexions WebSocket persistantes,
qui supportent mal la mise en veille et les redémarrages d'instances.

---

## Sans serveur TURN, que se passe-t-il ?

| Situation | Résultat sans TURN |
|---|---|
| Deux appareils sur le même Wi-Fi | Fonctionne |
| Deux box internet différentes, NAT classique | Fonctionne le plus souvent (STUN suffit) |
| NAT symétrique, 4G/5G opérateur, réseau d'entreprise | **Échoue** — le TURN est indispensable |

C'est pourquoi le guide d'auto-hébergement décrit le déploiement de Coturn.
Rappel de la configuration minimale à mettre côté Coturn pour que ce projet
fonctionne avec des identifiants temporaires :

```ini
listening-port=3478
tls-listening-port=5349
realm=turn.votredomaine.fr
use-auth-secret
static-auth-secret=LA_MEME_VALEUR_QUE_DANS_LES_SECRETS_REPLIT
cert=/etc/letsencrypt/live/turn.votredomaine.fr/fullchain.pem
pkey=/etc/letsencrypt/live/turn.votredomaine.fr/privkey.pem
min-port=49160
max-port=49200
fingerprint
no-multicast-peers
```

---

## Vérifications de sécurité intégrées

- **Aucune ressource externe** : le client Socket.IO est servi depuis votre serveur, pas depuis un CDN. Les polices sont celles du système.
- **CSP stricte** appliquée par Helmet : `default-src 'self'`, `object-src 'none'`.
- **Le secret TURN ne quitte jamais le serveur** : `/api/ice` renvoie un couple identifiant/mot de passe calculé en HMAC-SHA1, valable 12 heures.
- **Aucun stockage** : ni médias, ni messages, ni comptes. Le chat vit en mémoire le temps de la session.
- **Le serveur ne lit pas les SDP** : la route `signal` est un relais opaque.
- **Anti-injection** : les messages sont insérés via `textContent`, jamais via `innerHTML`.
- **Noms de salle normalisés** côté serveur : accents retirés, espaces convertis en tirets, caractères spéciaux supprimés.

---

## Limite du maillage P2P

Chaque participant envoie un flux vers chaque autre participant. La bande passante
montante nécessaire croît donc avec le nombre de personnes :

| Participants | Flux montants par personne | Verdict |
|---|---|---|
| 2 | 1 | Idéal |
| 4 | 3 | Confortable |
| 6 | 5 | Correct en réduisant la résolution |
| 8 | 7 | Limite haute (valeur par défaut de `MAX_PEERS_PER_ROOM`) |

Au-delà, il faudrait un SFU — ce qui sortirait du modèle « aucun serveur de médias ».

---

## Personnalisation rapide

| Envie | Fichier | Quoi changer |
|---|---|---|
| Nom et slogan | `public/index.html` | balises `.logo` et `.tagline` |
| Couleurs | `public/css/style.css` | bloc `:root` (`--accent`, `--bg`…) |
| Qualité vidéo | `public/js/app.js` | objet `constraints` dans `getLocalStream()` |
| Nombre max de participants | Secrets Replit | `MAX_PEERS_PER_ROOM` |
| Forcer le passage par votre TURN | Secrets Replit | `FORCE_RELAY=true` |

---

## Dépannage

| Symptôme | Cause | Solution |
|---|---|---|
| « Accès à la caméra refusé » | Permission bloquée ou site en HTTP | Utiliser l'URL `https://` de Replit et réautoriser dans les réglages du navigateur |
| Les participants se voient dans la liste mais l'image reste noire | Pas de TURN joignable | Renseigner `TURN_HOST` et le secret, vérifier les ports 3478 / 5349 |
| « Connexion échouée » sur réseau mobile | NAT symétrique | Le TURN est obligatoire ; testez `FORCE_RELAY=true` |
| Écho permanent | Deux onglets avec micro actif | Couper le micro de l'un des deux |
| Le Repl s'endort | Plan gratuit | Passer en Reserved VM |
| Partage d'écran indisponible sur iPhone | Limitation de Safari iOS | Fonction disponible sur ordinateur uniquement |

---

## Licence

AGPL-3.0-or-later. Si vous exposez une version modifiée sur un réseau, le code
source de cette version doit être mis à disposition.
