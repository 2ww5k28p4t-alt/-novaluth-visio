/**
 * P2P Meet — serveur de signalisation WebRTC
 * ------------------------------------------------------------------
 * Ce serveur ne transporte AUCUN media audio/video.
 * Il ne fait que trois choses :
 *   1. servir les fichiers statiques du client (HTML/CSS/JS)
 *   2. relayer les messages de signalisation (SDP + candidats ICE)
 *   3. fournir des identifiants TURN temporaires (HMAC-SHA1)
 *
 * Le media circule directement de navigateur a navigateur,
 * chiffre en DTLS-SRTP. Aucun serveur de medias (SFU/MCU).
 * ------------------------------------------------------------------
 */

'use strict';

require('dotenv').config();

const crypto = require('crypto');
const path = require('path');
const http = require('http');
const express = require('express');
const helmet = require('helmet');
const { Server } = require('socket.io');

// ------------------------------------------------------------------
// Configuration (via variables d'environnement / Secrets Replit)
// ------------------------------------------------------------------
const PORT = process.env.PORT || 3000;
const HOST = '0.0.0.0';

const STUN_URL = process.env.STUN_URL || '';
const TURN_HOST = process.env.TURN_HOST || '';
const TURN_SECRET = process.env.TURN_STATIC_AUTH_SECRET || '';
const TURN_USERNAME = process.env.TURN_USERNAME || '';
const TURN_PASSWORD = process.env.TURN_PASSWORD || '';
const TURN_TTL = parseInt(process.env.TURN_TTL || '43200', 10); // 12 h

const MAX_PEERS = parseInt(process.env.MAX_PEERS_PER_ROOM || '8', 10);
const ACCESS_CODE = process.env.ACCESS_CODE || ''; // vide = acces libre
const FORCE_RELAY = String(process.env.FORCE_RELAY || 'false') === 'true';

// ------------------------------------------------------------------
// Application Express
// ------------------------------------------------------------------
const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');

// En-tetes de securite. Aucune ressource externe n'est autorisee :
// polices, scripts et styles sont servis depuis ce serveur uniquement.
app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        'default-src': ["'self'"],
        'script-src': ["'self'"],
        'style-src': ["'self'"],
        'img-src': ["'self'", 'data:', 'blob:'],
        'media-src': ["'self'", 'blob:'],
        'font-src': ["'self'"],
        'connect-src': ["'self'", 'ws:', 'wss:'],
        'frame-ancestors': ["'self'"],
        'base-uri': ["'self'"],
        'form-action': ["'self'"],
        'object-src': ["'none'"]
      }
    },
    crossOriginEmbedderPolicy: false,
    referrerPolicy: { policy: 'no-referrer' }
  })
);

app.use((req, res, next) => {
  res.setHeader(
    'Permissions-Policy',
    'camera=(self), microphone=(self), display-capture=(self), geolocation=()'
  );
  next();
});

app.use(
  express.static(path.join(__dirname, 'public'), {
    maxAge: '1h',
    etag: true
  })
);

// ------------------------------------------------------------------
// Identifiants TURN temporaires (norme TURN REST API)
// Le secret ne quitte jamais le serveur : on renvoie un couple
// username/password valable TURN_TTL secondes.
// ------------------------------------------------------------------
function buildIceServers(userId) {
  const iceServers = [];

  if (STUN_URL) {
    iceServers.push({ urls: STUN_URL });
  }

  if (TURN_HOST && TURN_SECRET) {
    const expiry = Math.floor(Date.now() / 1000) + TURN_TTL;
    const username = `${expiry}:${userId}`;
    const credential = crypto
      .createHmac('sha1', TURN_SECRET)
      .update(username)
      .digest('base64');

    iceServers.push({
      urls: [
        `turn:${TURN_HOST}:3478?transport=udp`,
        `turn:${TURN_HOST}:3478?transport=tcp`,
        `turns:${TURN_HOST}:5349?transport=tcp`,
        `turns:${TURN_HOST}:443?transport=tcp`
      ],
      username,
      credential
    });
  } else if (TURN_HOST && TURN_USERNAME && TURN_PASSWORD) {
    // Mode identifiants statiques (plus simple, moins sur)
    iceServers.push({
      urls: [
        `turn:${TURN_HOST}:3478?transport=udp`,
        `turns:${TURN_HOST}:5349?transport=tcp`,
        `turns:${TURN_HOST}:443?transport=tcp`
      ],
      username: TURN_USERNAME,
      credential: TURN_PASSWORD
    });
  }

  return iceServers;
}

app.get('/api/ice', (req, res) => {
  const userId = crypto.randomBytes(6).toString('hex');
  const iceServers = buildIceServers(userId);

  res.set('Cache-Control', 'no-store');
  res.json({
    iceServers,
    iceTransportPolicy: FORCE_RELAY ? 'relay' : 'all',
    iceCandidatePoolSize: 2,
    bundlePolicy: 'max-bundle',
    rtcpMuxPolicy: 'require',
    // Avertissement affiche dans l'interface si aucun serveur n'est configure
    warning: iceServers.length === 0
      ? "Aucun serveur STUN/TURN configure : les appels ne fonctionneront qu'en reseau local."
      : null
  });
});

app.get('/api/config', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({
    maxPeers: MAX_PEERS,
    accessCodeRequired: ACCESS_CODE.length > 0,
    forceRelay: FORCE_RELAY
  });
});

app.get('/healthz', (req, res) => res.json({ status: 'ok' }));

// ------------------------------------------------------------------
// Serveur de signalisation Socket.IO
// ------------------------------------------------------------------
const server = http.createServer(app);
const io = new Server(server, {
  serveClient: true, // le client socket.io est servi en local, pas depuis un CDN
  cors: { origin: false },
  maxHttpBufferSize: 1e5,
  pingTimeout: 30000
});

/** roomId -> Map(socketId -> { name }) */
const rooms = new Map();

function peersInRoom(roomId) {
  return rooms.get(roomId) || new Map();
}

function sanitize(value, maxLength) {
  return String(value || '')
    .replace(/[<>"'`\\]/g, '')
    .trim()
    .slice(0, maxLength);
}

/**
 * Normalisation du nom de salle : minuscules, espaces convertis en
 * tirets, caracteres speciaux supprimes. Indispensable pour que
 * "Salle Test", "salle-test" et "SALLE TEST" designent bien la meme
 * salle, quel que soit le client utilise.
 */
function normalizeRoom(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')   // accents
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\-_ ]/g, '')     // caracteres autorises uniquement
    .replace(/[\s_]+/g, '-')           // espaces -> tirets
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60);
}

io.on('connection', (socket) => {
  let currentRoom = null;

  socket.on('join', (payload = {}, ack) => {
    const roomId = normalizeRoom(payload.room);
    const name = sanitize(payload.name, 24) || 'Invite';
    const code = String(payload.code || '');

    if (roomId.length < 2) {
      return typeof ack === 'function'
        && ack({ ok: false, error: 'Nom de salle invalide (2 caracteres minimum, lettres et chiffres).' });
    }

    if (ACCESS_CODE && code !== ACCESS_CODE) {
      return typeof ack === 'function' && ack({ ok: false, error: "Code d'acces incorrect." });
    }

    const peers = peersInRoom(roomId);
    if (peers.size >= MAX_PEERS) {
      return typeof ack === 'function'
        && ack({ ok: false, error: `Salle pleine (${MAX_PEERS} participants maximum).` });
    }

    currentRoom = roomId;
    socket.data.name = name;
    socket.join(roomId);

    if (!rooms.has(roomId)) rooms.set(roomId, new Map());
    rooms.get(roomId).set(socket.id, { name });

    // Liste des pairs deja presents : c'est le nouvel arrivant qui initie
    // les offres, ce qui evite toute collision de negociation.
    const existing = [];
    for (const [id, info] of rooms.get(roomId)) {
      if (id !== socket.id) existing.push({ id, name: info.name });
    }

    socket.to(roomId).emit('peer-joined', { id: socket.id, name });

    if (typeof ack === 'function') {
      ack({ ok: true, selfId: socket.id, room: roomId, peers: existing });
    }

    console.log(`[join] ${name} (${socket.id}) -> salle "${roomId}" (${rooms.get(roomId).size} pairs)`);
  });

  // Relais pur : le serveur ne lit ni ne modifie le contenu SDP/ICE.
  socket.on('signal', ({ to, data } = {}) => {
    if (!to || !data || !currentRoom) return;
    io.to(to).emit('signal', { from: socket.id, name: socket.data.name, data });
  });

  socket.on('chat', ({ text } = {}) => {
    if (!currentRoom) return;
    const message = sanitize(text, 800);
    if (!message) return;
    io.to(currentRoom).emit('chat', {
      from: socket.id,
      name: socket.data.name,
      text: message,
      at: Date.now()
    });
  });

  socket.on('state', (state = {}) => {
    if (!currentRoom) return;
    socket.to(currentRoom).emit('state', {
      from: socket.id,
      audio: !!state.audio,
      video: !!state.video
    });
  });

  socket.on('disconnect', () => {
    if (!currentRoom) return;
    const peers = rooms.get(currentRoom);
    if (peers) {
      peers.delete(socket.id);
      if (peers.size === 0) rooms.delete(currentRoom);
    }
    socket.to(currentRoom).emit('peer-left', { id: socket.id });
    console.log(`[left] ${socket.data.name || socket.id} <- salle "${currentRoom}"`);
  });
});

// ------------------------------------------------------------------
// Demarrage
// ------------------------------------------------------------------
server.listen(PORT, HOST, () => {
  const ice = buildIceServers('boot');
  console.log('------------------------------------------------------------');
  console.log(`  P2P Meet demarre sur http://${HOST}:${PORT}`);
  console.log(`  Participants max par salle : ${MAX_PEERS}`);
  console.log(`  Code d'acces : ${ACCESS_CODE ? 'active' : 'desactive'}`);
  console.log(`  Politique ICE : ${FORCE_RELAY ? 'relay uniquement' : 'all (P2P direct prioritaire)'}`);
  console.log(`  Serveurs ICE configures : ${ice.length}`);
  if (ice.length === 0) {
    console.warn('  ATTENTION : aucun STUN/TURN configure. Renseignez STUN_URL et TURN_HOST.');
  }
  console.log('------------------------------------------------------------');
});

process.on('SIGTERM', () => server.close(() => process.exit(0)));
process.on('SIGINT', () => server.close(() => process.exit(0)));
